import md.image3d.python.image3d_tools as ctools
import md.image3d.python.image3d_io as cio
import md.image3d.python.image3d_vis as cvis
from md.segmentation3d.utils.vseg_helpers import AdaptiveNormalizer
import os
import glob
import re
import numpy as np
import ConfigParser


def generate_imgpairlist(folder, orgkey='org.mha', segkey='seg.mha'):
    print 'Generating img pair list...'
    imgpairlist = []
    folders = glob.glob(os.path.join(folder, '*'))
    folders.sort()
    for folder in folders:
        if os.path.isdir(folder):
            status_str = "\r%s" % folder
            # print status_str,
            flist=glob.glob(os.path.join(folder, "*"+orgkey))
            if len(flist)!=1: continue
            orgfile=flist[0]
            flist = glob.glob(os.path.join(folder, "*"+segkey))
            if len(flist)!=1: continue
            segfile=flist[0]

            if os.path.exists(orgfile) and os.path.exists(segfile):
                imgpairlist.append((orgfile, segfile))
    return imgpairlist


def batch_dump_seg_result_folder(folder, config_file, outputfolder, orgkey='org.mha', segkey='seg.mha'):
    """
    batch visualize segmentation results from all cases in the specified folder
    the folder structure should be like:
    top-folder
        - case 1
          - org.mha (by default)
          - seg.mha (by default)
        - case 2
        - ...
        - case N

    :param folder: the top-level folder
    :param config_file: the configuration file for label visualization
    :param outputfolder: output folder
    :param orgkey: the intensity image name (supports partial name)
    :param segkey: the segmentation image name (supports partial name and multi-class)
    :return: None
    """
    imgpairlist = generate_imgpairlist(folder, orgkey=orgkey, segkey=segkey)
    batch_dump_seg_result(imgpairlist, config_file, outputfolder)
    return


def parse_config_file(config_file):
    param_dict = {}
    conf = ConfigParser.ConfigParser()
    if not conf.read(config_file):
        print "%s does not exist!" % (config_file)
        return None

    param_dict['label'] = conf.getint('Display', 'label')
    param_dict['alpha'] = conf.getfloat('Display', 'alpha')
    param_dict['auto_norm'] = conf.getfloat('Display', 'auto_norm')

    param_dict['win_min'] = conf.getint('Display', 'win_min')
    param_dict['win_max'] = conf.getint('Display', 'win_max')
    param_dict['spacing'] = conf.getfloat('Display', 'spacing')

    param_dict['imgs_per_row'] = conf.getint('Layout', 'imgs_per_row')
    param_dict['height'] = conf.getint('Layout', 'height')
    param_dict['width'] = conf.getint('Layout', 'width')

    colormapstr = conf.items(section="ColorMap")
    colormap = convert_color_map(colormapstr)
    param_dict['colormap'] = colormap

    return param_dict


def convert_color_map(colormapstr):
    colormap = []
    for colorstr in colormapstr:
        tmp = re.split(',', colorstr[1])
        color_item = [int(a) for a in tmp]
        colormap.append(color_item)
    return colormap


def create_color_config_file(colormap,color_config_file):
    fp = open(color_config_file, 'w')
    fp.write('%d\n' % len(colormap))
    for i in range(len(colormap)):
        fp.write('%d\t%d\t%d\t%d\n'%(colormap[i][0], colormap[i][1], colormap[i][2], colormap[i][3]))
    fp.close()
    return


def batch_dump_seg_result(imgpairlist, config_file, outputfolder):
    param_dict = parse_config_file(config_file)

    if not os.path.exists(outputfolder):
        os.makedirs(outputfolder)

    log_file = os.path.join(outputfolder, 'log.txt')
    fp = open(log_file, 'w')
    fp.close()

    color_config_file = os.path.join(outputfolder, 'color_config.txt')
    create_color_config_file(param_dict['colormap'], color_config_file)

    print '\n'
    for i in range(len(imgpairlist)):
        try:
            print '\rProcessing %dth subject ...' % (i),
            # Load org image
            orgimg = cio.read_image(imgpairlist[i][0])

            # normalize if necessary (e.g., MR)
            if param_dict['auto_norm'] > 0:
                normalizer = AdaptiveNormalizer()
                normalizer(orgimg)

            # Load seg image
            segimg = cio.read_image(imgpairlist[i][1])

            #output_file_prefix = os.path.join(outputfolder, "subject_%03d"%(i))
            filename,_ = os.path.split(imgpairlist[i][1])
            _, filename = os.path.split(filename)

            output_file_prefix = os.path.join(outputfolder, "subject_%03d" % (i)+"_%s" % (filename))
            dump_seg_result(orgimg, segimg, param_dict, color_config_file, output_file_prefix)

            fp = open(log_file, 'a')
            fp.write('subject_%03d\t%s\n'%(i,imgpairlist[i][0]))
            fp.close()
        except:
            fp = open(log_file, 'a')
            fp.write('EXCEPTION:subject_%03d\t%s\n'%(i,imgpairlist[i][0]))
            fp.close()
            continue

    filelist = glob.glob(os.path.join(outputfolder, '*.jpg'))
    filelist.sort()
    for i in range(len(filelist)):
        filelist[i] = os.path.basename(filelist[i])
    save_images_to_html(filelist,imgs_per_row=param_dict['imgs_per_row'], img_width=param_dict['width'],
                        img_height=param_dict['height'], out_path=os.path.join(outputfolder, '_result.html'))
    return


def dump_seg_result(orgimg, segimg, param_dict, color_config_file, output_file_prefix):
    minlabel = param_dict['label']
    maxlabel = param_dict['label']
    alpha = param_dict['alpha']
    spacing = [param_dict['spacing']] * 3

    # Step 1: Find center and cropsize from labeled image
    segimg_rai = ctools.resample_volume_nn_rai(segimg, spacing=spacing, padtype=0)
    vcenter = ctools.mass_voxel_center(segimg_rai, minlabel, maxlabel)
    wcenter = segimg_rai.voxel_to_world(vcenter)
    vminbox, vmaxbox = ctools.bounding_box_voxel(segimg_rai, minlabel, maxlabel)
    minbox = segimg_rai.voxel_to_world(vminbox)
    maxbox = segimg_rai.voxel_to_world(vmaxbox)
    cropsize = maxbox-minbox+np.array([50, 50, 50])

    # Step 2: isotropic resample and crop
    subsegimg = ctools.center_crop(segimg_rai, wcenter, spacing=spacing, size=cropsize, padtype=0, is_world=True)
    suborgimg = ctools.resample_volume_as_ref(orgimg,subsegimg)

    # Step 3: dump overlaid mid slices
    imgsize = subsegimg.size()

    output_file = output_file_prefix+'.a.jpg'
    cvis.dump_labeled_slice(suborgimg, subsegimg, slice_index=imgsize[2]/2, slice_option=0, alpha=alpha,
                             color_config_file=color_config_file, win_min=param_dict['win_min'], win_max=param_dict['win_max'],
                             output_file=output_file)

    output_file = output_file_prefix + '.c.jpg'
    cvis.dump_labeled_slice(suborgimg, subsegimg, slice_index=imgsize[1] / 2, slice_option=1, alpha=alpha,
                             color_config_file=color_config_file, win_min=param_dict['win_min'], win_max=param_dict['win_max'],
                             output_file=output_file)

    output_file = output_file_prefix + '.s.jpg'
    cvis.dump_labeled_slice(suborgimg, subsegimg, slice_index=imgsize[0] / 2, slice_option=2, alpha=alpha,
                            color_config_file=color_config_file, win_min=param_dict['win_min'], win_max=param_dict['win_max'],
                            output_file=output_file)
    return


def save_images_to_html(image_paths, imgs_per_row, img_width, img_height, out_path):
    """
    group multiple images into a single html file for visualization
    :param image_paths: a list of image paths
    :param imgs_per_row: the number of images per row
    :param img_width: the image width in the table
    :param img_height: the image height in the table
    :param out_path: output html path
    :return: None
    """
    num_imgs = len(image_paths)
    if num_imgs % imgs_per_row == 0:
        rows = num_imgs // imgs_per_row
    else:
        rows = num_imgs // imgs_per_row + 1

    image_idx = 0

    str = '<table border="1">\n'
    for r in range(rows):
        if r == rows - 1: # last row
            cols = imgs_per_row if num_imgs % imgs_per_row == 0 else num_imgs % imgs_per_row
        else:
            cols = imgs_per_row

        # image row
        str += '\t<tr>\n'
        for c in range(cols):
            im_path = image_paths[image_idx+c]
            if img_width>0 and img_height>0:
                td_text = '\t\t<td><img src="{}" alt="{}" width="{}" height="{}"></td>\n'.format(im_path, im_path, img_width, img_height)
            elif img_width>0:
                td_text = '\t\t<td><img src="{}" alt="{}" width="{}"></td>\n'.format(im_path, im_path, img_width)
            elif img_height>0:
                td_text = '\t\t<td><img src="{}" alt="{}" height="{}"></td>\n'.format(im_path, im_path, img_height)
            else:
                td_text = '\t\t<td><img src="{}" alt="{}"></td>\n'.format(im_path, im_path)
            str += td_text
        str += '\t</tr>\n'

        # text row
        str += '\t<tr>\n'
        for c in range(cols):
            _, filename = os.path.split(image_paths[image_idx+c])
            filename, _ = os.path.splitext(filename)
            td_text = '\t\t<td align=center>{}</td>\n'.format(filename)
            str += td_text
        str += '\t</tr>\n'

        image_idx += cols

    str += '</table>'

    with open(out_path, 'w') as f:
        f.write(str)


def test():
    orgimg = cio.read_image(r"D:\Data\1\1.3.6.1.4.1.14519.5.2.1.6279.6001.105756658031515062000744821260_intensity.mhd")
    #segimg = cio.read_image(r"D:\Data\1\1.3.6.1.4.1.14519.5.2.1.6279.6001.105756658031515062000744821260_seg.mhd")
    segimg = cio.read_image(r"D:\Data\2\1.3.6.1.4.1.14519.5.2.1.6279.6001.108197895896446896160048741492_intensity.mhd")

    param_dict = parse_config_file(r"C:\temp\segdump.ini")
    color_config_file = os.path.join(r'C:\temp\color_config.txt')
    create_color_config_file(param_dict['colormap'],color_config_file)
    output_file_prefix = r"c:\temp\test"
    dump_seg_result(orgimg, segimg, param_dict, color_config_file, output_file_prefix)
    return


if __name__ == '__main__':

    batch_dump_seg_result_folder('/home/ubuntu2/data/seg', '/home/ubuntu2/data/segdump.ini', '/home/ubuntu2/data/vis_debug')

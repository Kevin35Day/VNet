
def export_ref_segini(out_file):

    text  = ['[Display]']
    text += ['alpha = 0.75']
    text += ['label = 1']
    text += ['win_min = -1000']
    text += ['win_max = 1000']
    text += ['spacing = 1']
    text += ['']
    text += ['[ColorMap]']
    text += ['label1 = 1, 255, 255, 0']
    text += ['']
    text += ['[Layout]']
    text += ['imgs_per_row = 3']
    text += ['width = 0']
    text += ['height = 400']

    with open(out_file, 'w') as f:
        for line in text:
            f.write(line + '\n')

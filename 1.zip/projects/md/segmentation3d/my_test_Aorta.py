from vseg_test import test as vnet_test

if __name__ == '__main__':
    model = '/home/yaojun/organs/femur_left_v4'
    input_female = '/home/yaojun/organs/femur_left_v4/test_Aorta.txt'
    output_female = '/mnt/disk/Data/pelvic/femur_left_test_v4_Aorta'

    vnet_test(input_female, model, output_female, gpu_id=3)
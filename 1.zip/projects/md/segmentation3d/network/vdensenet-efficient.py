import torch.nn as nn
import torch
import numpy as np

__net__ = 'vdensenet-efficient'


class VNetConv(nn.Module):
    """ classic combination: conv + batch normalization [+ relu] """

    def __init__(self, in_channels, out_channels, ksize, padding, do_act=True):
        super(VNetConv, self).__init__()
        self.conv = nn.Conv3d(in_channels, out_channels, kernel_size=ksize, padding=padding, groups=1)
        self.bn = nn.BatchNorm3d(out_channels)
        self.do_act = do_act
        if do_act:
            self.act = nn.ReLU(inplace=True)

    def forward(self, input):
        out = self.bn(self.conv(input))
        if self.do_act:
            out = self.act(out)
        return out


class BottleneckBlock(nn.Module):
    def __init__(self, in_planes, out_planes):
        super(BottleneckBlock, self).__init__()
        inter_planes = out_planes * 2
        self.bn1 = nn.BatchNorm3d(inter_planes)
        self.relu = nn.ReLU(inplace=True)
        self.conv1 = nn.Conv3d(in_planes, inter_planes, kernel_size=1, stride=1,
                               padding=0, bias=False)
        self.bn2 = nn.BatchNorm3d(out_planes)
        self.conv2 = nn.Conv3d(inter_planes, out_planes, kernel_size=3, stride=1,
                               padding=1, bias=False)
    def forward(self, input):
        out = self.relu(self.bn1(self.conv1(input)))
        out = self.relu(self.bn2(self.conv2(out)))
        return torch.cat([input, out], 1)


class DenseBlock(nn.Module):
    def __init__(self, nb_layers, in_planes, growth_rate):
        super(DenseBlock, self).__init__()
        self.in_planes = in_planes
        self.layer = self._make_layer(in_planes, growth_rate, nb_layers)
    def _make_layer(self,  in_planes, growth_rate, nb_layers):
        layers = []
        for i in range(nb_layers):
            layers.append(BottleneckBlock(in_planes+i*growth_rate, growth_rate))
        return nn.Sequential(*layers)
    def forward(self, input):
        return torch.add(self.layer(input)[:,:self.in_planes,:,:,:],self.layer(input)[:,self.in_planes:,:,:,:])


class ResidualBlock(nn.Module):
    """ residual block with variable number of convolutions """

    def __init__(self, channels, ksize, padding, num_convs):
        super(ResidualBlock, self).__init__()

        layers = []
        for i in range(num_convs):
            if i != num_convs - 1:
                layers.append(VNetConv(channels, channels, ksize, padding, do_act=True))
            else:
                layers.append(VNetConv(channels, channels, ksize, padding, do_act=False))

        self.ops = nn.Sequential(*layers)
        self.act = nn.ReLU(inplace=True)

    def forward(self, input):

        output = self.ops(input)
        return self.act(input + output)


class DownBlock(nn.Module):
    """ downsample block of v-net """

    def __init__(self, in_channels, num_convs, use_bottle_neck = False):
        super(DownBlock, self).__init__()
        out_channels = in_channels * 2
        self.down_conv = nn.Conv3d(in_channels, out_channels, kernel_size=2, stride=2, groups=1)
        self.down_bn = nn.BatchNorm3d(out_channels)
        self.down_act = nn.ReLU(inplace=True)
        if use_bottle_neck:
            self.rblock = DenseBlock(num_convs, out_channels, out_channels//num_convs)
        else:
            self.rblock = ResidualBlock(out_channels, 3, 1, num_convs)

    def forward(self, input):
        out = self.down_act(self.down_bn(self.down_conv(input)))
        out = self.rblock(out)
        return out


class UpBlock(nn.Module):
    """ upsample block of v-net """

    def __init__(self, in_channels, out_channels, num_convs, use_bottle_neck=False):
        super(UpBlock, self).__init__()
        self.up_conv = nn.ConvTranspose3d(in_channels, out_channels // 2, kernel_size=2, stride=2, groups=1)
        self.up_bn = nn.BatchNorm3d(out_channels // 2)
        self.up_act = nn.ReLU(inplace=True)
        if use_bottle_neck:
            self.rblock = DenseBlock(num_convs, out_channels, out_channels//num_convs)
        else:
            self.rblock = ResidualBlock(out_channels, 3, 1, num_convs)

    def forward(self, input, skip):
        out = self.up_act(self.up_bn(self.up_conv(input)))
        out = torch.cat((out, skip), 1)
        out = self.rblock(out)
        return out


class InputBlock(nn.Module):
    """ input block of v-net """

    def __init__(self, in_channels, out_channels):
        super(InputBlock, self).__init__()
        self.conv = nn.Conv3d(in_channels, out_channels, kernel_size=3, padding=1)
        self.bn = nn.BatchNorm3d(out_channels)
        self.act = nn.ReLU(inplace=True)

    def forward(self, input):
        out = self.act(self.bn(self.conv(input)))
        return out


class OutputBlock(nn.Module):
    """ output block of v-net

        The output is a list of foreground-background probability vectors.
        The length of the list equals to the number of voxels in the volume
    """

    def __init__(self, in_channels):
        super(OutputBlock, self).__init__()
        self.conv1 = nn.Conv3d(in_channels, 2, kernel_size=3, padding=1)
        self.bn1 = nn.BatchNorm3d(2)
        self.act1 = nn.ReLU(inplace=True)
        self.conv2 = nn.Conv3d(2, 2, kernel_size=1)

        tokens = torch.__version__.split('.')
        version = int(tokens[0] + tokens[1])
        if version < 3:
            self.softmax = nn.Softmax()
        else:
            self.softmax = nn.Softmax(dim=1)


    def forward(self, input):
        out = self.act1(self.bn1(self.conv1(input)))
        out = self.conv2(out)
        out_size = out.size()

        # move channels to last dimension and softmax
        out = out.permute(0, 2, 3, 4, 1).contiguous()
        out = out.view(out.numel() // 2, 2)
        out = self.softmax(out)

        # reshape back to output size
        out = out.view(out_size[0], out_size[2], out_size[3], out_size[4], out_size[1])
        out = out.permute(0, 4, 1, 2, 3).contiguous()

        return out


def __kaiming_weight_init(m):

    classname = m.__class__.__name__
    if 'Conv3d' in classname or 'ConvTranspose3d' in classname:
        nn.init.kaiming_normal(m.weight)
        if m.bias is not None:
            m.bias.data.zero_()
    elif 'BatchNorm' in classname:
        m.weight.data.normal_(1.0, 0.02)
        m.bias.data.zero_()


def __regular_weight_init(m):

    classname = m.__class__.__name__
    if 'Conv3d' in classname or 'ConvTranspose3d' in classname:
        m.weight.data.normal_(0, 0.01)
        if m.bias is not None:
            m.bias.data.zero_()
    elif 'BatchNorm' in classname:
        m.weight.data.normal_(1.0, 0.01)
        m.bias.data.zero_()


def vnet_kaiming_init(net):

    net.apply(__kaiming_weight_init)


def vnet_focal_init(net, obj_p):

    net.apply(__regular_weight_init)
    # initialize bias such as the initial predicted prob for objects are at obj_p.
    net.out_block.conv2.bias.data[1] = -np.log((1 - obj_p) / obj_p)


class VNet(nn.Module):
    """ v-net for segmentation """

    def __init__(self, in_channels):
        super(VNet, self).__init__()
        self.in_block   =   InputBlock(in_channels, 16)
        self.down_32    =   DownBlock(16, 1, use_bottle_neck=False)
        self.down_64    =   DownBlock(32, 16, use_bottle_neck=True)
        self.down_128   =   DownBlock(64, 16, use_bottle_neck=True)
        self.down_256   =   DownBlock(128, 16,use_bottle_neck=True)
        self.up_256     =   UpBlock(256, 256, 16, use_bottle_neck=True)
        self.up_128     =   UpBlock(256, 128, 16, use_bottle_neck=True)
        self.up_64      =   UpBlock(128, 64, 2, use_bottle_neck=False)
        self.up_32      =   UpBlock(64, 32, 1, use_bottle_neck=False)
        self.out_block  =   OutputBlock(32)


    def forward(self, input):
        out16  =  self.in_block(input)
        out32  =  self.down_32(out16)
        out64  =  self.down_64(out32)
        out128 =  self.down_128(out64)
        out256 =  self.down_256(out128)
        out    =  self.up_256(out256, out128)
        out    =  self.up_128(out, out64)
        out    =  self.up_64(out, out32)
        out    =  self.up_32(out, out16)
        out    =  self.out_block(out)
        return out


    def max_stride(self):
        return 16
"""
python wrapper for vseg c++ library

this file includes:

autoseg_load_model
autoseg_volume

"""

import ctypes
import _ctypes
from md.utils.python.find_dll import find_dll
import platform
from md.image3d.python.image3d import Image3d
import time
import os
import numpy as np

# dynamic library
lib = None

# function pointer dictionary
fun_dict = {}


def __get_library_path():

    dll_file = find_dll('vseg')
    if dll_file is None:
        raise OSError('dll not found')
    return dll_file


def __load_c_functions():

    global lib, fun_dict

    lib = ctypes.cdll.LoadLibrary(__get_library_path())

    lib.vseg_load.argtypes = [ctypes.c_char_p, ctypes.c_int32, ctypes.POINTER(ctypes.c_void_p)]
    lib.vseg_load.restype = ctypes.c_int32
    fun_dict['vseg_load'] = lib.vseg_load

    lib.vseg_segment_general.argtypes = [ctypes.c_void_p,   # input image
                                         ctypes.c_float,    # intensity slope
                                         ctypes.c_float,    # intensity intercept
                                         ctypes.c_void_p,   # model
                                         ctypes.c_void_p,   # output image
                                         ctypes.c_bool,     # whether to allocate output
                                         ctypes.c_void_p,   # box center
                                         ctypes.c_void_p    # box size
                                        ]
    lib.vseg_segment_general.restype = ctypes.c_int32
    fun_dict['vseg_segment_general'] = lib.vseg_segment_general

    lib.vseg_release.argtypes = [ctypes.c_void_p]
    lib.vseg_release.restype = ctypes.c_int32
    fun_dict['vseg_release'] = lib.vseg_release

    lib.vseg_get_error_string.argtypes = [ctypes.c_int32]
    lib.vseg_get_error_string.restype = ctypes.c_char_p
    fun_dict['vseg_get_error_string'] = lib.vseg_get_error_string


def unload():

    global lib, fun_dict

    try:
        while lib is not None:
            if platform.system() == 'Windows':
                _ctypes.FreeLibrary(lib._handle)
            else:
                _ctypes.dlclose(lib._handle)
    except:
        lib = None
        fun_dict = {}


def load():

    unload()
    __load_c_functions()


# load dynamic library and function pointers
load()


def load_c_functions_if_necesary():

    if len(fun_dict) == 0:
        print '[info] vseg dll reloaded'
        __load_c_functions()


def call_func(func_name, *args):

    load_c_functions_if_necesary()

    if len(args) == 0:
        return fun_dict[func_name]()
    else:
        return fun_dict[func_name](*args)


class VNetSeg(object):
    """ VNetSeg python wrapper """

    def __init__(self, model_folder, gpu_id=0):

        assert os.path.isdir(model_folder), 'model_path must a folder that contains model'
        self.ptr = ctypes.c_void_p()
        err = call_func('vseg_load', model_folder, ctypes.c_int32(gpu_id), ctypes.byref(self.ptr))
        assert err == 0, 'vseg failure: fail to load model: code ' + call_func('vseg_get_error_string', err)
        self.ptr = self.ptr.value

    def __del__(self):

        if self.ptr is not None:
            err = call_func('vseg_release', self.ptr)
            assert err == 0, 'vseg failure: fail to release model: code ' + call_func('vseg_get_error_string', err)
        self.ptr = None

    def segment(self, im, im_slope=1.0, im_intercept=0.0):

        assert isinstance(im, Image3d)
        seg = Image3d(width=im.width(), height=im.height(), depth=im.depth(), dtype=np.int8)
        seg.set_frame(im.frame())

        box_center = np.empty((3,), dtype=np.double)
        box_center_ptr = box_center.ctypes.data_as(ctypes.POINTER(ctypes.c_double))

        box_size = np.empty((3,), dtype=np.double)
        box_size_ptr = box_size.ctypes.data_as(ctypes.POINTER(ctypes.c_double))

        out_alloc = ctypes.c_bool(False)
        im_slope = ctypes.c_float(im_slope)
        im_intercept = ctypes.c_float(im_intercept)

        err = call_func('vseg_segment_general', im.ptr, im_slope, im_intercept, self.ptr, seg.ptr, out_alloc, box_center_ptr, box_size_ptr)
        assert err == 0, 'vseg failure: fail to do segmentation: code ' + call_func('vseg_get_error_string', err)

        return seg, box_center, box_size


def autoseg_load_model(model_folder, gpu_id):
    """
    load segmentation model from folder
    :param model_folder:       the folder that contains segmentation model
    :param gpu_id:             which gpu to run segmentation model
    :return: a segmentation model
    """
    assert isinstance(gpu_id, int)
    model = VNetSeg(model_folder, gpu_id)
    return model


def autoseg_volume(image, model):
    """
    segment image using the pre-loaded model
    :param image:              an image3d object
    :param model:              the pre-loaded model
    :return: a segmentation image
    """
    assert isinstance(model, VNetSeg)
    begin = time.time()
    seg, box_center, box_size = model.segment(image)
    test_time = time.time() - begin
    return seg, box_center, box_size, test_time

import argparse
import importlib
import logging
import os
import shutil
import sys
import time

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.autograd import Variable
from torch.backends import cudnn
from torch.utils.data import DataLoader

from md.image3d.python.frame3d import Frame3d
from md.image3d.python.image3d_io import write_image
from md.mdpytorch.loss.binary_dice_loss import BinaryDiceLoss, cal_dsc_loss
from md.mdpytorch.loss.focal_loss import FocalLoss
from md.segmentation3d.utils.vseg_dataset import SingleSegDataset
from md.mdpytorch.utils.train_tools import EpochConcateSampler
from md.utils.python.plotly_tools import plot_loss
from md.mdpytorch.utils.tensor_tools import ToImage


def load_config(config_file):
    """
    Load a training config file
    :param config_file: the path of config file with py extension
    :return: a configuration dictionary
    """
    dirname = os.path.dirname(config_file)
    basename = os.path.basename(config_file)
    modulename, _ = os.path.splitext(basename)

    os.sys.path.append(dirname)
    lib = importlib.import_module(modulename)
    del os.sys.path[-1]

    return lib.cfg


def load_net_module(net_name):
    """
    Load network module
    :param net_name: the name of network module
    :return: the module object
    """
    lib = importlib.import_module('md.segmentation3d.network.' + net_name)
    return lib


def setup_logger(log_file):
    """
    setup logger for logging training messages
    :param log_file: the location of log file
    :return: a logger object
    """
    dirname = os.path.dirname(log_file)
    if not os.path.isdir(dirname):
        os.makedirs(dirname)

    logger = logging.getLogger('vnet')
    logger.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

    # stream handler
    h1 = logging.StreamHandler()
    h1.setLevel(logging.DEBUG)
    h1.setFormatter(formatter)
    logger.addHandler(h1)

    # file handler
    h2 = logging.FileHandler(log_file)
    h2.setLevel(logging.DEBUG)
    h2.setFormatter(formatter)
    logger.addHandler(h2)

    return logger


def save_checkpoint(net, epoch_idx, batch_idx, cfg, config_file, net_module, max_stride):
    """
    save model and parameters into a checkpoint file (.pth)
    :param net: the network object
    :param epoch_idx: the epoch index
    :param batch_idx: the batch index
    :param cfg: the configuration object
    :param config_file: the configuration file path
    :param net_module: the net module
    :param max_stride: the maximum stride of network
    :return: None
    """
    chk_folder = os.path.join(cfg.general.save_dir, 'checkpoints', 'chk_{}'.format(epoch_idx))
    if not os.path.isdir(chk_folder):
        os.makedirs(chk_folder)

    filename = os.path.join(chk_folder, 'params.pth'.format(epoch_idx))

    crop_normalizer = cfg.dataset.crop_normalizer.to_dict()

    state = {'epoch':           epoch_idx,
             'batch':           batch_idx,
             'net':             cfg.net.name,
             'max_stride':      max_stride,
             'state_dict':      net.state_dict(),
             'spacing':         cfg.dataset.spacing,
             'crop_normalizer': crop_normalizer}

    torch.save(state, filename)

    # copy network file and config file
    net_filename, _ = os.path.splitext(net_module.__file__)
    shutil.copy(net_filename+'.py', os.path.join(chk_folder, 'net.py'))
    shutil.copy(config_file, os.path.join(chk_folder, 'config.py'))


def load_checkpoint(epoch_idx, net, save_dir):
    """
    load network parameters from directory
    :param epoch_idx: the epoch idx of model to load
    :param net: the network object
    :param save_dir: the save directory
    :return: loaded epoch index, loaded batch index
    """
    chk_file = os.path.join(save_dir, 'checkpoints', 'chk_{}'.format(epoch_idx), 'params.pth')
    if not os.path.isfile(chk_file):
        raise ValueError('checkpoint file not found: {}'.format(chk_file))

    state = torch.load(chk_file)
    net.load_state_dict(state['state_dict'])

    return state['epoch'], state['batch']


def save_intermediate_results(idxs, crops, seg, pred, frames, filenames, out_folder):
    """
    save intermediate results to training folder
    :param idxs: the indices of crops within batch to save
    :param crops: the batch tensor of image crops
    :param seg: the batch tensor of seg crops
    :param pred: the batch tensor of prediction maps
    :param frames: the batch frames
    :param filenames: the batch filenames
    :param out_folder: the batch output folder
    :return: None
    """
    if not os.path.isdir(out_folder):
        os.makedirs(out_folder)

    for i in idxs:

        case_out_folder = os.path.join(out_folder, filenames[i])
        if not os.path.isdir(case_out_folder):
            os.makedirs(case_out_folder)

        frame = Frame3d()
        frame.from_numpy(frames[i].numpy())

        if crops is not None:
            im = ToImage()(crops[i, 0])
            im.set_frame(frame)
            write_image(im, os.path.join(case_out_folder, 'crop.mha'))

        if seg is not None:
            im = ToImage()(seg[i, 0])
            im.set_frame(frame)
            write_image(im, os.path.join(case_out_folder, 'seg.mha'))

        if pred is not None:
            im = ToImage()(pred[i, 1].data)
            im.set_frame(frame)
            write_image(im, os.path.join(case_out_folder, 'pred.mha'))


def train(config_file):
    """
    volumetric segmentation training engine
    :param config_file: the input configuration file
    :return: None
    """

    # load config file
    if not os.path.isfile(config_file):
        raise ValueError('config not found: {}'.format(config_file))
    cfg = load_config(config_file)

    # convert to absolute path since cfg uses relative path
    rootdir = os.path.dirname(config_file)
    cfg.general.imseg_list = os.path.join(rootdir, cfg.general.imseg_list)
    cfg.general.save_dir = os.path.join(rootdir, cfg.general.save_dir)

    # control randomness during training
    np.random.seed(cfg.general.seed)
    torch.manual_seed(cfg.general.seed)
    torch.cuda.manual_seed(cfg.general.seed)

    # clean the existing folder if not continue training
    if cfg.general.resume_epoch < 0 and os.path.isdir(cfg.general.save_dir):
        sys.stdout.write("Found non-empty save dir.\nType 'yes' to delete, 'no' to continue: ")
        choice = raw_input().lower()
        if choice == 'yes':
            shutil.rmtree(cfg.general.save_dir)
        elif choice == 'no':
            pass
        else:
            raise ValueError("Please type either 'yes' or 'no'!")

    # enable logging
    log_file = os.path.join(cfg.general.save_dir, 'train_log.txt')
    logger = setup_logger(log_file)

    # enable cudnn
    cudnn.benchmark = True

    if not torch.cuda.is_available():
        raise EnvironmentError('CUDA is not available! Please check nvidia driver!')

    # dataset
    dataset = SingleSegDataset(
                imlist_file=cfg.general.imseg_list,
                label=cfg.dataset.label,
                spacing=cfg.dataset.spacing,
                cropsize=cfg.dataset.cropsize,
                sampling_method=cfg.dataset.sampling_method,
                box_pad_voxel=cfg.dataset.box_pad_voxel,
                crop_always_in=cfg.dataset.crop_always_in,
                cropper=cfg.dataset.cropper,
                crop_normalizer=cfg.dataset.crop_normalizer)

    sampler = EpochConcateSampler(dataset, cfg.train.epochs)

    dataloader = DataLoader(dataset, sampler=sampler, batch_size=cfg.train.batchsize,
                            num_workers=cfg.train.num_threads, pin_memory=True)

    # define network
    gpu_ids = range(cfg.general.num_gpus)

    net_module = load_net_module(cfg.net.name)

    net = net_module.VNet(1)
    max_stride = net.max_stride()
    net_module.vnet_kaiming_init(net)
    net = nn.parallel.DataParallel(net, device_ids=gpu_ids)
    net = net.cuda()

    if (cfg.dataset.cropsize[0] % max_stride != 0) or (cfg.dataset.cropsize[1] % max_stride != 0) or (cfg.dataset.cropsize[2] % max_stride != 0):
        raise ValueError('crop size not divisible by max_stride')

    # load checkpoint if resume epoch > 0
    if cfg.general.resume_epoch >= 0:
        _, batch_start = load_checkpoint(cfg.general.resume_epoch, net, cfg.general.save_dir)
    else:
        batch_start = 0

    # training buffer
    input_size = cfg.dataset.cropsize
    input = torch.FloatTensor(cfg.train.batchsize, 1, input_size[2], input_size[1], input_size[0])
    target = torch.FloatTensor(cfg.train.batchsize, 1, input_size[2], input_size[1], input_size[0])
    input = input.cuda()
    target = target.cuda()

    opt = optim.Adam(net.parameters(), lr=cfg.train.lr, betas=cfg.train.betas)

    batch_idx = batch_start
    dataiter = iter(dataloader)
    loss_func = None

    for i in range(len(dataloader)):

        begin_t = time.time()

        crop, seg, frames, filename = dataiter.next()

        # save training crops for visualization
        if cfg.train.save_inputs:
            batch_size = crop.size(0)
            save_intermediate_results(range(batch_size), crop, seg, None, frames, filename, cfg.general.save_dir)

        input.resize_(crop.size())
        input.copy_(crop)
        target.resize_(seg.size())
        target.copy_(seg)

        input_v = Variable(input)
        target_v = Variable(target)

        # clear previous gradients
        opt.zero_grad()

        # network forward
        pred = net(input_v)

        # define loss function
        if cfg.loss.name == 'Focal':
            # reuse focal loss if exists
            if loss_func is None:
                alpha = [1 - cfg.loss.focal_obj_alpha, cfg.loss.focal_obj_alpha]
                gamma = cfg.loss.focal_gamma
                loss_func = FocalLoss(class_num=2, alpha=alpha, gamma=gamma)

        elif cfg.loss.name == 'Dice':
            # one-time use per batch
            loss_func = BinaryDiceLoss()

        else:
            raise ValueError('Unknown loss function')

        # compute training loss and dice loss
        train_loss = loss_func(pred, target_v)
        batch_dice_loss = cal_dsc_loss(pred, target_v)
        dice_loss = batch_dice_loss.mean()

        # save training hard cases for debugging
        if cfg.train.save_hard_start >= 0 and batch_idx >= cfg.train.save_hard_start:
            high_loss_idxs = np.flatnonzero(batch_dice_loss.cpu().numpy() >= cfg.train.save_hard_dsc_loss)
            if len(high_loss_idxs) > 0:
                bad_case_folder = os.path.join(cfg.general.save_dir, 'Batch_{:05d}_Hards'.format(batch_idx))
                save_intermediate_results(high_loss_idxs, crop, seg, pred, frames, filename, bad_case_folder)

        # backward propagation
        train_loss.backward()

        # update weights
        opt.step()

        epoch_idx = batch_idx * cfg.train.batchsize // len(dataset)
        batch_idx += 1
        batch_duration = time.time() - begin_t
        sample_duration = batch_duration * 1.0 / cfg.train.batchsize

        # print loss per batch
        if cfg.loss.name == 'Dice':
            msg = 'epoch: {}, batch: {}, dloss: {:.4f}, time: {:.4f} s/vol'
            msg = msg.format(epoch_idx, batch_idx, dice_loss, sample_duration)
        elif cfg.loss.name == 'Focal':
            msg = 'epoch: {}, batch: {}, dloss: {:.4f}, floss: {:.4f}, time: {:.4f} s/vol'
            msg = msg.format(epoch_idx, batch_idx, dice_loss, train_loss.data[0], sample_duration)
        logger.info(msg)

        if batch_idx % cfg.train.plot_snapshot == 0:
            dloss_plot_file = os.path.join(cfg.general.save_dir, 'dloss.html')
            plot_loss(log_file, dloss_plot_file, name='dloss', display='Dice loss')

            if cfg.loss.name == 'Focal':
                floss_plot_file = os.path.join(cfg.general.save_dir, 'floss.html')
                plot_loss(log_file, floss_plot_file, name='floss', display='Focal loss')

        if epoch_idx % cfg.train.save_epochs == 0:
            save_checkpoint(net, epoch_idx, batch_idx, cfg, config_file, net_module, max_stride)


if __name__ == '__main__':

    parser = argparse.ArgumentParser()
    parser.add_argument('-i', '--input',
                        default='/home/mfh/organs/liverVbb/fine.py',
                        help='vnet train config file')
    args = parser.parse_args()
    train(args.input)

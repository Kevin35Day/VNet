import re
import random
import os
from md.utils.python.file_tools import readlines


class Filter(object):
    """ interface class for file path filtering
        True to keep the file, False to discard the file
    """

    def test(self, file_path):
        return True


class TxtFilter(Filter):
    """ filter file paths not in the loaded txt """

    def __init__(self, file_path):
        if os.path.isfile(file_path):
            lines = readlines(file_path)
            self.list = lines[1:]
        else:
            raise ValueError('Text file do not exist!')

    def test(self, file_path):
        if file_path in self.list:
            return True
        else:
            return False


class CaseNameFilter(Filter):
    """ select cases that does not include target file name """

    def __init__(self, name):
        cpl = re.compile('\w+\.(mha|mhd|nii.gz|nii|hdr)$')
        if not cpl.match(name):
            raise ValueError('Suffix Not Supported!')
        self.name = name

    def test(self, file_path):
        case_dir, _ = os.path.split(file_path)
        if os.path.isfile(os.path.join(case_dir, self.name)):
            return True
        else:
            return False


class FileNameFilter(Filter):
    """ filter file name that does not match given pattern """

    def __init__(self, name):
        self.cpl = re.compile(name)

    def test(self, file_path):
        _, file_name = os.path.split(file_path)
        if self.cpl.match(file_name):
            return True
        else:
            return False


class AndFilter(Filter):

    def __init__(self):
        self.filter = []

    def add_filter(self, flt):
        self.filter.append(flt)

    def test(self, file_path):
        for i in range(len(self.filter)):
            if not self.filter[i].test(file_path):
                return False
        return True


class OrFilter(Filter):

    def __init__(self):
        self.filter = []

    def add_filter(self, flt):
        self.filter.append(flt)

    def test(self, file_path):
        for i in range(len(self.filter)):
            if self.filter[i].test(file_path):
                return True
        return False


class NotFilter(Filter):

    def __init__(self, flt):
        self.filter = flt

    def test(self, file_path):
        if self.filter.test(file_path):
            return False
        else:
            return True


class Pattern(object):

    def test(self, filename):
        raise NotImplementedError("test function not implemented in Pattern sub-class")


class MedImagePattern(Pattern):

    def __init__(self, file_name=None):
        if file_name:
            self.cpl = re.compile(file_name)
        else:
            self.cpl = re.compile('\S+\.(mha|mhd|nii\.gz|nii|hdr)$')

    def test(self, file_name):
        match_result = self.cpl.match(file_name)
        if match_result:
            return True
        else:
            return False


def make_train_imlist_fp(root_dir, fp, org_name, seg_name, filter=None):
    """
    generate image-seg pairs from a root folder
    :param root_dir: the top-level folder
    :param fp: output text file pointer
    :param org_name: intensity image name, class MedImagePattern
    :param seg_name: segmentation image name, class MedImagePattern
    :param filter: rules to choose cases
    :return: None
    """
    #  check inputs
    assert isinstance(org_name, (Pattern, str, unicode))
    if isinstance(org_name, (str, unicode)):
        org_name = MedImagePattern(org_name)
    assert isinstance(seg_name, (Pattern, str, unicode))
    if isinstance(seg_name, (str, unicode)):
        seg_name = MedImagePattern(seg_name)
    if filter is None:
        filter = Filter()

    ind = 0
    name_text = ''
    for dir_name in sorted(os.listdir(root_dir)):
        if os.path.isdir(os.path.join(root_dir, dir_name)):
            case_dir = os.path.join(root_dir, dir_name)
            SEG_EXIST = 0
            IMG_EXIST = 0
            for parent, _, file_name_all in os.walk(case_dir):
                for file_name in file_name_all:
                    name_to_match = os.path.join(parent.split(case_dir)[1], file_name)
                    name_to_match = name_to_match.lstrip('/')
                    if org_name.test(name_to_match):
                        file_path = os.path.join(parent, file_name)
                        if filter.test(file_path):
                            IMG_EXIST = 1
                            img_file_path = file_path
                    if seg_name.test(name_to_match):
                        file_path = os.path.join(parent, file_name)
                        if filter.test(file_path):
                            SEG_EXIST = 1
                            seg_file_path = file_path

            if SEG_EXIST and IMG_EXIST:
                ind = ind + 1
                name_text = name_text + img_file_path + '\n'
                name_text = name_text + seg_file_path + '\n'

    if ind > 0:
        fp.write(str(ind) + '\n' + name_text)
        print('%d image files were found.' % ind)
    else:
        raise ValueError('No image file exist in root_dir!')


def make_train_imlist(root_dir, out_file, org_name, seg_name, filter=None):
    """
    generate image-seg pairs from a root folder
    :param root_dir: the top-level folder
    :param out_file: output file path
    :param org_name: intensity image name, class MedImagePattern
    :param seg_name: segmentation image name, class MedImagePattern
    :param filter: rules to choose cases
    :return: None
    """
    with open(out_file, 'w') as fp:
        make_train_imlist_fp(root_dir, fp, org_name, seg_name, filter)


def cut_shuffle_train_imlist(file_dir, cut_persent=0.8, to_shuffle=True):
    name_text = ''
    if os.path.isfile(file_dir):
        lines = readlines(file_dir)
        num = int(lines[0])
        shuffle_num = range(num)
        if to_shuffle:
            random.shuffle(shuffle_num)
        shuffle_num = shuffle_num[0: int(len(shuffle_num)*cut_persent)]
        for i in shuffle_num:
            name_text += lines[i*2+1]+'\n'
            name_text += lines[i*2+2]+'\n'
        with open(file_dir,'w') as fp:
            fp.write(str(len(shuffle_num))+'\n'+name_text)
    else:
        raise ValueError('Text file does not exist')


def make_test_imlist_fp(root_dir, fp, org_name=None, filter=None):
    """
    generate test image list from case folder or root folder
    :param root_dir: the top-level folder
    :param fp: output file pointer
    :param org_name: this param must be specified if your root_dir is case based, or it should be None
    :param filter: rules to choose cases
    :return: None
    """
    if filter is None:
        filter = Filter()

    ind = 0
    name_text = ''
    pattern = MedImagePattern()
    if org_name is None:
        # all test data are in the same folder
        print ('Generating image list from root folder...')
        for file_name in sorted(os.listdir(root_dir)):
            if pattern.test(file_name):
                file_path = os.path.join(root_dir, file_name)
                if filter.test(file_path):
                    ind += 1
                    name_text += file_name + ' ' + os.path.join(root_dir, file_name) + '\n'
    else:
        # case based. Test data are in different folder
        print ('Generating image list from case folder...')
        assert isinstance(org_name, (Pattern, str, unicode))
        if isinstance(org_name, (str, unicode)):
            org_name = MedImagePattern(org_name)
        for case_name in sorted(os.listdir(root_dir)):
            case_dir = os.path.join(root_dir, case_name)
            if os.path.isdir(case_dir):
                for parent, _, file_name_list in os.walk(case_dir):
                    for file_name in file_name_list:
                        # 'sub/name.nii' for sub folder search
                        name_to_match = os.path.join(parent.split(case_dir)[1], file_name)
                        name_to_match = name_to_match.lstrip('/')
                        if org_name.test(name_to_match):
                            file_path = os.path.join(parent, file_name)
                            if filter.test(file_path):
                                ind = ind + 1
                                name_text += case_name + ' ' + file_path + '\n'
                                break
    if ind > 0:
        fp.write(str(ind) + '\n' + name_text)
        print('%d image files were found.' % ind)
    else:
        raise ValueError('No image file exist in root_dir!')


def make_test_imlist(root_dir, out_file, org_name=None, filter=None):
    """
    generate test image list from case folder or root folder
    :param root_dir: the top-level folder
    :param out_file: output file path
    :param org_name: this param must be specified if your root_dir is case based, or it should be None
    :param filter: rules to choose cases
    :return: None
    """
    with open(out_file, 'w') as fp:
        make_test_imlist_fp(root_dir, fp, org_name, filter)



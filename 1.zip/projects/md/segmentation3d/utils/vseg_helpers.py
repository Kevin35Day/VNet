import md.image3d.python.image3d_tools as ctools
import md.image3d.python.image3d_io as cio
from md.image3d.python.image3d import Image3d
import numpy as np
import os
import glob
import subprocess


def get_gpu_memory(gpu_id):
    """Get the gpu memory usage.

    :param gpu_id the gpu id
    :return the gpu memory used
    """
    result = subprocess.check_output(
        [
            'nvidia-smi', '--query-gpu=memory.used',
            '--format=csv,nounits,noheader'
        ])

    # convert lines into a dictionary
    gpu_memory = [int(x) for x in result.strip().split('\n')]
    gpu_memory_dict = dict(zip(range(len(gpu_memory)), gpu_memory))

    return gpu_memory_dict[gpu_id]


def last_checkpoint(chk_root):
    """
    find the directory of last check point
    :param chk_root: the check point root directory, which may contain multiple checkpoints
    :return: the last check point directory
    """

    last_epoch = -1
    chk_folders = os.path.join(chk_root, 'chk_*')
    for folder in glob.glob(chk_folders):
        folder_name = os.path.basename(folder)
        tokens = folder_name.split('_')
        epoch = int(tokens[-1])
        if epoch > last_epoch:
            last_epoch = epoch

    if last_epoch == -1:
        raise OSError('No checkpoint folder found!')

    return os.path.join(chk_root, 'chk_{}'.format(last_epoch))


class RandomHistMatch(object):
    """ random histogram matching """
    def __init__(self, prob=0.5):
        """
        constructor
        :param prob: hist matching probability
        """
        self.prob = prob

    def __call__(self, image, im_list):
        prob = np.random.uniform(0, 1)
        if prob < self.prob:
            idx = np.random.randint(0, len(im_list))
            target_im = cio.read_image(im_list[idx], dtype=np.float32)
            ctools.hist_match(image, target_im)


class FixedNormalizer(object):
    """
    use fixed mean and stddev to normalize image intensities
    intensity = (intensity - mean) / stddev
    if clip is enabled:
        intensity = np.clip((intensity - mean) / stddev, -1, 1)
    """
    def __init__(self, mean, stddev, clip=False):
        """ constructor """
        assert stddev > 0, 'stddev must be positive'
        assert isinstance(clip, bool), 'clip must be a boolean'
        self.mean = mean
        self.stddev = stddev
        self.clip = clip

    def __call__(self, image):
        """ normalize image """
        if isinstance(image, Image3d):
            ctools.intensity_normalize(image, self.mean, self.stddev, self.clip)
        elif isinstance(image, (list, tuple)):
            for im in image:
                assert isinstance(im, Image3d)
                ctools.intensity_normalize(im, self.mean, self.stddev, self.clip)
        else:
            raise ValueError('Unknown type of input. Normalizer only supports Image3d or Image3d list/tuple')

    def static_obj(self):
        """ get a static normalizer object by removing randomness """
        obj = FixedNormalizer(self.mean, self.stddev, self.clip)
        return obj

    def to_dict(self):
        """ convert parameters to dictionary """
        obj = {'mean': self.mean, 'stddev': self.stddev, 'clip': self.clip}
        return obj


class AdaptiveNormalizer(object):
    """
    use the minimum and maximum percentiles to normalize image intensities
    """
    def __init__(self, min_p=0.001, max_p=0.999, clip=True, min_rand=0, max_rand=0):
        """
        constructor
        :param min_p: percentile for computing minimum value
        :param max_p: percentile for computing maximum value
        :param clip: whether to clip the intensity between min and max
        :param min_rand: the random perturbation (%) of minimum value (0-1)
        :param max_rand: the random perturbation (%) of maximum value (0-1)
        """
        assert min_p >= 0 and min_p <= 1, 'min_p must be between 0 and 1'
        assert max_p >= 0 and max_p <= 1, 'max_p must be between 0 and 1'
        assert max_p > min_p, 'max_p must be > min_p'
        assert min_rand >= 0 and min_rand <= 1, 'min_rand must be between 0 and 1'
        assert max_rand >= 0 and max_rand <= 1, 'max_rand must be between 0 and 1'
        assert isinstance(clip, bool), 'clip must be a boolean'
        self.min_p = min_p
        self.max_p = max_p
        self.clip = clip
        self.min_rand = min_rand
        self.max_rand = max_rand

    def normalize(self, single_image):

        assert isinstance(single_image, Image3d), 'image must be an image3d object'
        normalize_min, normalize_max = ctools.percentiles(single_image, [self.min_p, self.max_p])

        if self.min_rand > 0:
            offset = np.abs(normalize_min) * self.min_rand
            offset = np.random.uniform(-offset, offset)
            normalize_min += offset

        if self.max_rand > 0:
            offset = np.abs(normalize_max) * self.max_rand
            offset = np.random.uniform(-offset, offset)
            normalize_max += offset

        normalize_mean = (normalize_min + normalize_max) / 2.0
        normalize_stddev = (normalize_max - normalize_min) / 2.0
        ctools.intensity_normalize(single_image, normalize_mean, normalize_stddev, clip=self.clip)

    def __call__(self, image):
        """ normalize image """
        if isinstance(image, Image3d):
            self.normalize(image)
        elif isinstance(image, (list, tuple)):
            for im in image:
                assert isinstance(im, Image3d)
                self.normalize(im)
        else:
            raise ValueError('Unknown type of input. Normalizer only supports Image3d or Image3d list/tuple')

    def static_obj(self):
        """ get a static normalizer object by removing randomness """
        obj = AdaptiveNormalizer(self.min_p, self.max_p, self.clip, min_rand=0, max_rand=0)
        return obj

    def to_dict(self):
        """ convert parameters to dictionary """
        obj = {'min_p': self.min_p, 'max_p': self.max_p, 'clip': self.clip}
        return obj


class SinglescaleCropper(object):
    """ single-scale cropper """

    def __init__(self, crop_size):
        """
        constructor
        :param crop_size: the 3d vector describing crop size in voxels
        """
        assert len(crop_size) == 3, 'crop size is not a 3d vector'
        self.crop_size = np.array(crop_size, dtype=np.int32)

    def __call__(self, image, seg, world_center):
        """
        crop a rectangluar patch from image
        :param image: an image3d object
        :param seg: a segmentation mask of the same frame as image
        :param world_center: a world coordinate of a sample point
        :return: a crop
        """
        assert isinstance(image, Image3d) and isinstance(seg, Image3d)

        voxel_center = seg.world_to_voxel(world_center)
        sp = np.round(voxel_center - self.crop_size / 2).astype(np.int32)
        ep = sp + self.crop_size
        image_crop = ctools.crop(image, sp, ep)
        seg_crop = ctools.crop(seg, sp, ep)

        return image_crop, seg_crop


class MultiscaleCropper(object):
    """ multi-scale cropper  """

    def __init__(self, crop_size):
        """
        constructor
        :param crop_size: the 3d vector describing crop size in voxels
        """
        assert len(crop_size) == 3, 'crop size is not a 3d vector'
        self.crop_size = np.array(crop_size, dtype=np.int32)

    def __call__(self, images, seg, world_center):
        """
        crop a rectangluar patch from image
        :param images: a list of image3d object
        :param seg: a segmentation image3d object at the target resolution
        :param world_center: a world coordinate of a sample point
        :return: a list of image crops, and a segmentation crop
        """
        image_crops = []
        seg_crop = None

        for i in range(len(images)):
            assert isinstance(images[i], Image3d)
            spacing = images[i].spacing()
            world_sp = world_center - spacing * self.crop_size / 2.0
            voxel_sp = np.round(images[i].world_to_voxel(world_sp)).astype(np.int32)
            voxel_ep = voxel_sp + self.crop_size
            image_crop = ctools.crop(images[i], voxel_sp, voxel_ep)
            image_crops.append(image_crop)

            if i == 0:
                seg_crop = ctools.crop(seg, voxel_sp, voxel_ep)

        return image_crops, seg_crop

#include "segmentation3d/deploy/vseg.h"
#include "segmentation3d/deploy/common/vseg_alg.h"

using namespace medvision;


int vseg_load(const char* folder, int gpu_id, void** model)
{
    vsegError_t err_code = VSEG_Success;
    if(model == nullptr) {
        return VSEG_NullOutputPointer;
    }

    VSegAlg* vseg_alg = new VSegAlg(gpu_id);
    try {
        err_code = vseg_alg->load(folder);
        *model = vseg_alg;
    }
    catch(neuro_error& e) {
        if(vseg_alg != nullptr) delete vseg_alg;
        std::cerr << "Neuro failure: " << e.what() << std::endl;
        return static_cast<int>(VSEG_NeuroError);
    }
    catch(cuda_error& e) {
        if(vseg_alg != nullptr) delete vseg_alg;
        std::cerr << "Cuda failure: " << e.what() << std::endl;
        return static_cast<int>(VSEG_CudaError);
    }
    catch(cudnn_error& e) {
        if(vseg_alg != nullptr) delete vseg_alg;
        std::cerr << "Cudnn failure: " << e.what() << std::endl;
        return static_cast<int>(VSEG_CudnnError);
    }
    catch(std::exception& e) {
        if(vseg_alg != nullptr) delete vseg_alg;
        std::cerr << "Unknown failure: " << e.what() << std::endl;
        return static_cast<int>(VSEG_UnknownError);
    }

    return static_cast<int>(err_code);
}


int vseg_segment(short* im_buffer, float im_slope, float im_intercept, const int size[3], const double origin[3], const double spacing[3], const double axis[9], void* model, char* mask_out)
{
    VSegAlg* vnet_alg = static_cast<VSegAlg*>(model);

    // setup input and segmentation image
    Image3d im;
    im.set_axes(axis);
    im.set_spacing(spacing[0], spacing[1], spacing[2]);
    im.set_origin(origin[0], origin[1], origin[2]);
    im.set_data(im_buffer, vec3d<int>(size[0], size[1], size[2]), PT_SHORT, false);

    Image3d seg;
    seg.set_axes(axis);
    seg.set_spacing(spacing[0], spacing[1], spacing[2]);
    seg.set_origin(origin[0], origin[1], origin[2]);
    seg.set_data(mask_out, vec3d<int>(size[0], size[1], size[2]), PT_CHAR, false);

    vec3d<double> box_center, box_size;
    int err_code = vseg_segment_general(&im, im_slope, im_intercept, model, &seg, false, box_center.data(), box_size.data());

    return err_code;
}


int vseg_segment_general(void* im, float im_slope, float im_intercept, void* model, void* out_im, bool out_alloc, double* box_center, double* box_size)
{
    VSegAlg* vnet_alg = static_cast<VSegAlg*>(model);
    Image3d* input_im = static_cast<Image3d*>(im);
    Image3d* seg_im = static_cast<Image3d*>(out_im);

    if(!out_alloc && seg_im->pixel_type() != PT_CHAR)
        return VSEG_WrongOutPixelType;

    vec3d<double> box_center_out, box_size_out;
    vsegError_t err_code = VSEG_Success;
    try {
        err_code = vnet_alg->segment(*input_im, im_slope, im_intercept, *seg_im, box_center_out, box_size_out, out_alloc);
        for(int i = 0; i < 3; ++i) {
            box_center[i] = box_center_out[i];
            box_size[i] = box_size_out[i];
        }
    }
    catch(neuro_error& e) {
        std::cerr << "Neuro failure: " << e.what() << std::endl;
        return static_cast<int>(VSEG_NeuroError);
    }
    catch(cuda_error& e) {
        std::cerr << "Cuda failure: " << e.what() << std::endl;
        return static_cast<int>(VSEG_CudaError);
    }
    catch(cudnn_error& e) {
        std::cerr << "Cudnn failure: " << e.what() << std::endl;
        return static_cast<int>(VSEG_CudnnError);
    }
    catch(std::exception& e) {
        std::cerr << "Unknown failure: " << e.what() << std::endl;
        return static_cast<int>(VSEG_UnknownError);
    }

    return static_cast<int>(err_code);
}


int vseg_release(void* model)
{
    VSegAlg* vnet_alg = static_cast<VSegAlg*>(model);
    delete vnet_alg;
    return static_cast<int>(VSEG_Success);
}


const char* vseg_get_error_string(int code)
{
    vsegError_t err_code = static_cast<vsegError_t>(code);
    return vsegGetErrorString(err_code);
}


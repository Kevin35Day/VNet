#ifndef VSEG_H
#define VSEG_H

#include <cstddef>

#ifdef __cplusplus
extern "C" {
#endif

/*! \brief read vseg model from disk */
int vseg_load(const char* folder, int gpu_id, void** model);

/*! \brief segment an organ from short-data-type volume */
int vseg_segment(short* im_buffer,
				 float im_slope,
				 float im_intercept,
				 const int size[3],
				 const double origin[3],
				 const double spacing[3],
				 const double axis[9],
				 void* model,
				 char* mask_out);

/*! \brief segment an organ with general interface */
int vseg_segment_general(void* im,
						 float im_slope,
						 float im_intercept,
						 void* model,
						 void* out_im,
						 bool out_alloc,
						 double* box_center,
						 double* box_size);

/*! \brief release vseg model */
int vseg_release(void* model);

/*! \brief parse error code */
const char* vseg_get_error_string(int code);

#ifdef __cplusplus
}
#endif

#endif // VSEG_H

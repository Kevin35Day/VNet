#include "segmentation3d/deploy/common/vseg_alg.h"
#include "segmentation3d/deploy/common/vseg_errors.h"
#include "neuro/csrc/io.h"
#include "neuro/csrc/errors.h"
#include "neuro/csrc/tensor_utils.h"
#include "utils/csrc/ini/SimpleIni.h"
#include <memory>
#include "image3d/csrc/image3d_tools.h"
#include <iomanip>
#include "utils/csrc/string_utils.h"
#include "utils/csrc/template_macros.h"

namespace medvision {

// Device Switcher
DeviceSwitcher::DeviceSwitcher(int gpu_id)
{
    cudaThrowError(cudaGetDevice(&m_orig_gpu_id));
    cudaThrowError(cudaSetDevice(gpu_id));
}

DeviceSwitcher::~DeviceSwitcher()
{
    cudaThrowError(cudaSetDevice(m_orig_gpu_id));
}


// VSegAlg class
VSegAlg::VSegAlg(int gpu_id): m_gpu_id(gpu_id), m_coarse_net(nullptr), m_fine_net(nullptr)
{
    m_padmm = vec3d<double>(20, 20, 20);
    m_maxcropsize = vec3d<int>(-1, -1, -1);

    DeviceSwitcher switcher(gpu_id);
    cudnnThrowError(cudnnCreate(&m_cudnn_handle));
}

VSegAlg::~VSegAlg()
{
    DeviceSwitcher switcher(m_gpu_id);

    release_networks();
    cudnnThrowError(cudnnDestroy(m_cudnn_handle));
}

vsegError_t VSegAlg::check_version() const
{
    int cuda_ver = 0, cuda_major = 0;
    cudaThrowError(cudaRuntimeGetVersion(&cuda_ver));
    cuda_major = cuda_ver / 1000;
    if(cuda_major != 8) {
        std::cerr << "Wrong cuda version: " << cuda_major << ", Supported version: 8" << std::endl;
        return VSEG_WrongCudaVersion;
    }

    size_t cudnn_ver = cudnnGetVersion();
    size_t cudnn_major = cudnn_ver / 1000;
    if(cudnn_major != CUDNN_MAJOR) {
        std::cerr << "Wrong cudnn version: " << cudnn_major << ", Compiled version: " << CUDNN_MAJOR << std::endl;
        return VSEG_WrongCudnnVersion;
    }

    return VSEG_Success;
}

vsegError_t VSegAlg::create_network(const std::string &netname, int in_channels, NetworkModule** network)
{
    if(network == nullptr) {
        std::cerr << "[Error] invalid address for network pointer" << std::endl;
        return VSEG_NullOutputPointer;
    }

    // release pre-allocated network
    if(*network != nullptr) {
        delete *network;
        *network = nullptr;
    }

    if(netname == std::string("vnet"))
        *network = new VNet3(in_channels, 3, 1);
    else if (netname == std::string("vbnet"))
        *network = new VBNet3(in_channels, 3, 1);
    else if (netname == std::string("vbbnet"))
        *network = new VBBNet3(in_channels, 3, 1);
    else {
        std::cerr << "[Error] network name not supported" << std::endl;
        return VSEG_NotImplemented;
    }

    return VSEG_Success;
}

void VSegAlg::release_networks()
{
    if(m_coarse_net != nullptr) {
        delete m_coarse_net;
        m_coarse_net = nullptr;
    }

    if(m_fine_net != nullptr) {
        delete m_fine_net;
        m_fine_net = nullptr;
    }
}

vsegError_t VSegAlg::load(const char *folder)
{
    checkVSEG(check_version());

    // set specified device to use
    DeviceSwitcher switcher(m_gpu_id);
    release_networks();

    std::string coarse_model = std::string(folder) + "/deploy/coarse.neuro";
    std::string fine_model = std::string(folder) + "/deploy/fine.neuro";
    std::string ini_file = std::string(folder) + "/deploy/params.ini";

    // read ini parameters
    checkVSEG(read_ini_params(ini_file.c_str()));

    // load coarse model and net
    const int in_channels = 1;

    checkVSEG(m_coarse_model.load_model(coarse_model.c_str()));
    checkVSEG(create_network(m_coarse_model.netname(), in_channels, &m_coarse_net));
    neuroThrowError(m_coarse_net->set_param_ptrs(*m_coarse_model.param_dict()));

    // load fine model and net
    checkVSEG(m_fine_model.load_model(fine_model.c_str()));
    checkVSEG(create_network(m_fine_model.netname(), in_channels, &m_fine_net));
    neuroThrowError(m_fine_net->set_param_ptrs(*m_fine_model.param_dict()));

    return VSEG_Success;
}

void VSegAlg::release()
{
    DeviceSwitcher switcher(m_gpu_id);
    m_coarse_model.release_model();
    m_fine_model.release_model();
    release_networks();
}

vsegError_t VSegAlg::read_ini_params(const char* ini_file)
{
    CSimpleIniA ini;
    if(ini.LoadFile(ini_file) != SI_OK)
        return VSEG_INIError;

    const char* padmm_str = ini.GetValue("General", "pad_mm", "20,20,20");
    const char* maxsize_str = ini.GetValue("General", "maxsize", "-1,-1,-1");

    std::vector<double> padmm = split_numbers<double>(padmm_str, ',');
    if(padmm.size() != 1 && padmm.size() != 3) {
        std::cerr << "[Error] padmm must be 1-dimensional or 3-dimensional" << std::endl;
        return VSEG_INIError;
    }

    if(padmm.size() == 1)
        m_padmm = vec3d<double>(padmm[0], padmm[0], padmm[0]);
    else if(padmm.size() == 3)
        m_padmm = vec3d<double>(padmm[0], padmm[1], padmm[2]);
    else {
        std::cerr << "[Error] padmm must be 1-dimensional or 3-dimensional" << std::endl;
        return VSEG_INIError;
    }

    std::vector<int> maxsize = split_numbers<int>(maxsize_str, ',');
    if(maxsize.size() != 3) {
        std::cerr << "[Error] maxsize must be 3-dimensional" << std::endl;
        return VSEG_INIError;
    } else {
        m_maxcropsize = vec3d<int>(maxsize[0], maxsize[1], maxsize[2]);
    }

    return VSEG_Success;
}

vsegError_t VSegAlg::CT_to_HU(Image3d& im, float im_slope, float im_intercept)
{
    size_t pixel_num = im.size().self_prod<size_t>();
    float* im_data = static_cast<float*>(im.data());

    if(im_slope == 1.0f) {
        if(im_intercept == 0.0f)
            return VSEG_Success;
        else {
            for(size_t i = 0; i < pixel_num; ++i)
                im_data[i] += im_intercept;
        }
    } else {
        for(size_t i = 0; i < pixel_num; ++i)
            im_data[i] = im_data[i] * im_slope + im_intercept;
    }

    return VSEG_Success;
}

vsegError_t VSegAlg::compute_target_pos_and_size(const Image3d& mask, vec3d<int>& minbox_voxel, vec3d<int>& maxbox_voxel,
                                                 vec3d<double>& center, vec3d<double>& size)
{
    // compute organ localization and size
    bool found = boundingbox_voxel<char>(mask, 1.0, 1.0, minbox_voxel, maxbox_voxel);
    if(!found)
        return VSEG_NoSegmentation;

    vec3d<double> spacing = mask.spacing();
    for(int i = 0; i < 3; ++i) {
        size[i] = (maxbox_voxel[i] - minbox_voxel[i]) * spacing[i];
        center[i] = (maxbox_voxel[i] + minbox_voxel[i]) / 2.0;
    }
    center = mask.voxel_to_world(center);

    return VSEG_Success;
}

vsegError_t VSegAlg::network_forward(Image3d& im, NetworkModule* net, Image3d& mask)
{
    FloatTensor5 im_tensor, seg_tensor;

    // create input image tensor
    vec3d<int> imsize = im.size();
    int im_tensor_size[] = {1, 1, imsize[2], imsize[1], imsize[0]};
    im_tensor.set_size(im_tensor_size);
    im_tensor.create_desc();

    // create network descriptors and estimate memory requirement
    size_t max_layer_size = 0, max_workspace_size = 0;
    neuroThrowError(net->create_descs(m_cudnn_handle, im_tensor, seg_tensor, true, max_layer_size, max_workspace_size));
    std::cout << "Forward pass: ";
    std::cout << std::setprecision(4) << (2 * max_layer_size + max_workspace_size) * 1.0 / 1024.0 / 1024.0 << " Mb" << std::endl;

    // allocate gpu memory
    void* gpu_buffer_ptr = nullptr;
    cudaThrowError(cudaMalloc(&gpu_buffer_ptr, max_layer_size * 2 + max_workspace_size));
    std::unique_ptr<void, CudaDeviceDeleter> gpu_buffer;
    gpu_buffer.reset(gpu_buffer_ptr);

    // setup input and output tensor
    im_tensor.set_ptr(gpu_buffer_ptr);
    seg_tensor.set_ptr( (void*)(static_cast<char*>(gpu_buffer_ptr) + max_layer_size) );
    void* workspace_ptr = (void*)(static_cast<char*>(gpu_buffer_ptr) + max_layer_size * 2);

    // copy image data to input tensor
    neuroThrowError(copy_floatims_to_tensor(&im, 1, im_tensor));

    // net forward pass
    neuroThrowError(net->forward(im_tensor, seg_tensor, workspace_ptr));

    // copy tensor data to image
    neuroThrowError(convert_binaryProbTensor_to_mask(seg_tensor, mask));

    // setup world coordinate system of mask
    mask.set_frame(im.frame());

    // release gpu buffer
    gpu_buffer.reset();

    return VSEG_Success;
}

vsegError_t VSegAlg::segment_(const Image3d& im,
                              float im_slope,
                              float im_intercept,
                              VSegModel& model,
                              NetworkModule* net,
                              Image3d& seg,
                              const Image3d* prev_seg)
{
    vec3d<double> spacing = model.spacing();
    int max_stride = model.max_stride();

    // resampled crop (float data type)
    Image3d iso_image;

    if(prev_seg == nullptr) {

        // coarse resolution
        // resample input image to RAI space, pad the size to multiples of max_stride
        ptypecall_2(resample_volume_nn_with_padding_rai, im.pixel_type(), PT_FLOAT, im, spacing, max_stride, 0, iso_image);

    } else {

        // fine resolution

        // compute bounding box of coarse segmentation
        vec3d<int> minbox, maxbox;
        bool found = boundingbox_voxel<char>(*prev_seg, 1.0, 1.0, minbox, maxbox);
        if(!found)
            return VSEG_NoSegmentation;

        // compute world coordinates of bounding box
        vec3d<double> minbox_world(minbox[0], minbox[1], minbox[2]);
        vec3d<double> maxbox_world(maxbox[0], maxbox[1], maxbox[2]);
        minbox_world = prev_seg->voxel_to_world(minbox_world);
        maxbox_world = prev_seg->voxel_to_world(maxbox_world);

        // pad the bounding box
        for(int i = 0; i < 3; ++i) {
            minbox_world[i] -= m_padmm[i];
            maxbox_world[i] += m_padmm[i];
        }

        // setup output frame
        Frame3d iso_frame(prev_seg->frame());
        iso_frame.set_origin(minbox_world);
        iso_frame.set_spacing(spacing);

        // compute output crop size
        vec3d<int> box_size;
        for(int i = 0; i < 3; ++i)
            box_size[i] = static_cast<int>((maxbox_world[i] - minbox_world[i]) / spacing[i] + 0.5);

        // resample an isotropic crop from image using padding bounding box
        ptypecall_2(resample_volumn_nn_with_padding, im.pixel_type(), PT_FLOAT, im, iso_frame, box_size, max_stride, 0, iso_image);
    }

    // check whether the crop size exceeds the maximum
    if(m_maxcropsize[0] > 0 && m_maxcropsize[1] > 0 && m_maxcropsize[2] > 0) {
        vec3d<int> iso_size = iso_image.size();
        if(iso_size[0] > m_maxcropsize[0] && iso_size[1] > m_maxcropsize[1] && iso_size[2] > m_maxcropsize[2])
            return VSEG_BigVolumeError;
    }

    // convert CT value to HU value
    // for other image modality, simply set im_slope = 1, im_intercept = 0 to bypass this step
    checkVSEG(CT_to_HU(iso_image, im_slope, im_intercept));

    // image intensity normalization
    const Normalizer<float>* normalizer = model.normalizer();
    if(normalizer != nullptr)
        normalizer->normalize(iso_image);
    else
        return VSEG_UnknownNormalizer;

    // network forward pass
    checkVSEG(network_forward(iso_image, net, seg));

    // pick largest connected component
    pick_largest_component<char>(seg, false);

    return VSEG_Success;
}

vsegError_t VSegAlg::segment(const Image3d& im, float im_slope, float im_intercept, Image3d& seg, vec3d<double>& box_center, vec3d<double>& box_size, bool out_alloc)
{
    DeviceSwitcher switcher(m_gpu_id);

    Image3d coarse_seg, fine_seg;
    checkVSEG(segment_(im, im_slope, im_intercept, m_coarse_model, m_coarse_net, coarse_seg));
    checkVSEG(segment_(im, im_slope, im_intercept, m_fine_model, m_fine_net, fine_seg, &coarse_seg));

    // compute organ center and size
    vec3d<int> minbox_voxel, maxbox_voxel;
    checkVSEG(compute_target_pos_and_size(fine_seg, minbox_voxel, maxbox_voxel, box_center, box_size));

    // resample mask back to original image space
    resample_nn_bb<char,char>(fine_seg, im.frame(), im.size(), minbox_voxel, maxbox_voxel, 0, seg, out_alloc);

    return VSEG_Success;
}

}







#include "segmentation3d/deploy/common/vseg_model.h"
#include "neuro/csrc/errors.h"
#include "neuro/csrc/io.h"

namespace medvision {

VSegModel::VSegModel()
{
    m_device_param_buffer = nullptr;
}

VSegModel::~VSegModel()
{
    release_model();
}

vsegError_t VSegModel::load_model(const char* filepath)
{
    // release previous loaded model if necessary
    release_model();

    NeuroFile file("1.0.1");
    neuroThrowError(file.open(filepath));

    size_t byte_size = file.get_data_bytes();
    // std::cout << "Model params: ";
    // std::cout << std::setprecision(4) << byte_size * 1.0 / 1024.0 / 1024.0 << " Mb" << std::endl;

    // read all parameters into page-locked memory for fast host-to-device transfer
    std::unique_ptr<void, CudaHostDeleter> param_buffer;
    void* param_buffer_ptr = nullptr;
    cudaThrowError(cudaMallocHost(&param_buffer_ptr, byte_size));
    param_buffer.reset(param_buffer_ptr);

    // read all parameters into page-locked memory
    neuroThrowError(file.read(param_buffer.get()));

    // read out non-neural-network parameters, e.g., spacings, normalizer
    checkVSEG(read_params(file, param_buffer.get()));

    // allocate gpu memory and transfer parameter buffer
    cudaThrowError(cudaMalloc(&m_device_param_buffer, byte_size));
    cudaThrowError(cudaMemcpy(m_device_param_buffer, param_buffer.get(), byte_size, cudaMemcpyHostToDevice));

    // assign device ptr to each parameter
    unsigned char* device_byte_buffer = static_cast<unsigned char*>(m_device_param_buffer);
    std::vector<std::string> param_names = file.list_names();
    for(size_t i = 0; i < param_names.size(); ++i) {
        const std::string& name = param_names[i];
        size_t offset = file.pos_in_datablock(name);
        m_device_ptrs[name] = static_cast<void*>(device_byte_buffer + offset);
    }

    return VSEG_Success;
}


vsegError_t VSegModel::read_params(const NeuroFile& file, const void* in_ptr)
{
    // read spacing
    std::string field_name("spacing");
    size_t pos = file.pos_in_datablock(field_name);
    size_t bytes = file.get_byte_size(field_name.c_str());
    if(bytes != 12) {
        std::cerr << "[Error] spacing: 12 bytes, read: " << bytes << " bytes." << std::endl;
        return VSEG_FieldLengthError;
    }

    const float* spacing_ptr = (const float*)((const char*)(in_ptr) + pos);
    m_spacing[0] = spacing_ptr[0];
    m_spacing[1] = spacing_ptr[1];
    m_spacing[2] = spacing_ptr[2];

    // read maximum stride
    field_name = std::string("max_stride");
    pos = file.pos_in_datablock(field_name);
    bytes = file.get_byte_size(field_name.c_str());
    if(bytes != 4) {
        std::cerr << "[Error] max_stride: 4 bytes, read: " << bytes << " bytes." << std::endl;
        return VSEG_FieldLengthError;
    }
    m_max_stride = *(const int *)((const char *)(in_ptr) + pos);

    // read net name
    field_name = std::string("net");
    pos = file.pos_in_datablock(field_name);
    bytes = file.get_byte_size(field_name.c_str());
    const char* net_cstr = (const char*)(in_ptr) + pos;
    std::string netname(net_cstr, strlen(net_cstr));
    m_netname = netname;

    // read normalization type
    pos = file.pos_in_datablock(std::string("normalizer.type"));
    int normtype = *((const int*)((const char*)(in_ptr) + pos));
    if(normtype < 0 || normtype > 1) {
        return VSEG_UnknownNormalizer;
    }

    // read specific parameters for each normalizer
    if(normtype == 0) {

        pos = file.pos_in_datablock(std::string("fixed_normalizer.mean"));
        float normalizer_mean = *((const float*)((const char*)(in_ptr) + pos));
        double fixed_mean = normalizer_mean;

        pos = file.pos_in_datablock(std::string("fixed_normalizer.stddev"));
        float normalizer_stddev = *((const float*)((const char*)(in_ptr) + pos));
        double fixed_stddev = normalizer_stddev;

        pos = file.pos_in_datablock(std::string("fixed_normalizer.clip"));
        int clip = *((const int*)((const char*)(in_ptr) + pos));
        if(clip < 0 || clip > 1)
            return VSEG_UnknownNormalizer;

        bool fixed_clip = (clip == 1 ? true : false);
        m_normalizer.reset(new FixedNormalizer<float>(fixed_mean, fixed_stddev, fixed_clip));

    } else if(normtype == 1) {

        pos = file.pos_in_datablock(std::string("adaptive_normalizer.min_p"));
        float min_p = *((const float*)((const char*)(in_ptr) + pos));
        double adapt_min_p = min_p;

        pos = file.pos_in_datablock(std::string("adaptive_normalizer.max_p"));
        float max_p = *((const float*)((const char*)(in_ptr) + pos));
        double adapt_max_p = max_p;

        pos = file.pos_in_datablock(std::string("adaptive_normalizer.clip"));
        int clip = *((const int*)((const char*)(in_ptr) + pos));
        if(clip < 0 || clip > 1)
            return VSEG_UnknownNormalizer;

        bool adapt_clip = (clip == 1 ? true : false);
        m_normalizer.reset(new AdaptiveNormalizer<float>(adapt_min_p, adapt_max_p, adapt_clip));

    } else {

        return VSEG_UnknownNormalizer;
    }

    return VSEG_Success;
}


void VSegModel::release_model()
{
    if(m_device_param_buffer != nullptr) {
        cudaThrowError(cudaFree(m_device_param_buffer));
        m_device_param_buffer = nullptr;
    }
    m_device_ptrs.clear();
}


}

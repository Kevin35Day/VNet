#include "segmentation3d/deploy/vseg.h"
#include "segmentation3d/deploy/common/vseg_model.h"
#include "image3d/csrc/itk/image3d_io.h"
#include <iostream>
#include "cudnn.h"
#include <iomanip>
//#include <chrono>

using namespace medvision;


int main(int argc, char** argv)
{
    const char* folder = "/media/4t/abdomen/model/v2.0/spleen";//"/media/4t/abdomen/zhangyu/vnet2d/deploy/breast.neuro";
    const char* data_folder = "/mnt/disk/Data/abdomen";
//    MamoModel a;
//    a.read_model_to_device(folder);
//    a.release_model();

//     load vseg model
    void* model = nullptr;
    int gpu_id = 1;
    int err_code = vseg_load(folder, gpu_id, &model);
    if(err_code != 0) {
        std::cerr << vseg_get_error_string(err_code) << std::endl;
        return -1;
    }

    for(int i = 0; i < 1; ++i) {

        std::ostringstream ss;
        ss << "/home/zhangyu/abdomen/data/0003/image.nii.gz";
        std::string impath = ss.str();

        Image3d im;
        if(!read_image(impath.c_str(), im)) {
            std::cerr << "Error: read image fails" << std::endl;
            return -1;
        }

        // do segmentation
        void* im_buffer = im.data();
        vec3d<int> im_size = im.size();
        vec3d<double> im_origin = im.origin();
        vec3d<double> im_spacing = im.spacing();
        vec3d<double> axis[3] = {im.axis(0), im.axis(1), im.axis(2)};
        double axes[9] = {axis[0][0], axis[0][1], axis[0][2],
                          axis[1][0], axis[1][1], axis[1][2],
                          axis[2][0], axis[2][1], axis[2][2]};

        Image3d seg;
        seg.set_frame(im.frame());
        seg.allocate(im_size, PT_CHAR);

        //auto t1 = std::chrono::high_resolution_clock::now();

        short* input_ptr = static_cast<short*>(im_buffer);
        char* output_ptr = static_cast<char*>(seg.data());

        err_code = vseg_segment(input_ptr, 1.0f, 0.0f, im_size.data(), im_origin.data(), im_spacing.data(), axes, model, output_ptr);
        if(err_code != 0) {
            std::cerr << vseg_get_error_string(err_code) << std::endl;
            return -1;
        }

         //auto t2 = std::chrono::high_resolution_clock::now();
         //std::chrono::duration<double, std::milli> fp_ms = t2 - t1;
         //std::cout << fp_ms.count() << " ms" << std::endl;

        ss.str("");
        ss << "/home/zhangyu/Desktop/1/" << std::setw(2) << std::setfill('0') << i << ".mhd";
        write_image(seg, ss.str().c_str(), PT_UNKNOWN, true);
    }

    // release vseg model
    vseg_release(model);

    return 0;
}


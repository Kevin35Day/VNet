#ifndef VBNET3_H
#define VBNET3_H

#include <cudnn.h>
#include "neuro/csrc/layers.h"
#include "segmentation3d/deploy/network/vnet3.h"
#include <sstream>

namespace medvision {

/*! \brief VBNet 3D network architecture */
class VBNet3: public NetworkModule
{
public:
    /*! \brief parametric constructor
     *
     *  \param in_channels      input channels
     *  \param ksize            the isotropic kernel size
     *  \param pad              the isotropic padding size
     */
    VBNet3(int in_channels, int ksize, int pad);

    /*! \brief detailed implementation of set_param_ptrs */
    virtual neuroError_t set_param_ptrs(const ParamDictType& param_dict);

    /*! \brief detailed implementation of create_descs */
    virtual neuroError_t create_descs(cudnnHandle_t handle,
                              const Tensor& intensor,
                              Tensor& outtensor,
                              bool infer_shape,
                              size_t& max_layer_size,
                              size_t& workspace_size);

    /*! \brief detailed implementation of forward */
    virtual neuroError_t forward(Tensor& intensor, Tensor& outtensor, void* workspace);

private:

    /*! \brief create concatenated descriptor in VNET */
    neuroError_t create_concatenate_desc(const FloatTensor5& half, FloatTensor5& full);

    std::string m_name;
    cudnnHandle_t m_cudnn_handle;

    /*! \brief bytes of shared memory
     *
     *  m_bytes_of_u256_in -> memory D
     *  m_bytes_of_u128_in -> memory C
     *  m_bytes_of_u64_in  -> memory B
     *  m_bytes_of_u32_in  -> memory A
     */
    size_t m_bytes_of_u256_in, m_bytes_of_u128_in, m_bytes_of_u64_in, m_bytes_of_u32_in;

    /*! \brief input_channels -> 16 */
    ConvBnRelu3 m_d16;                  // input     -> d16_out   (shared memory A part 2)

    /*! \brief downsample layer, channels 16 -> 32 */
    ConvBnRelu3 m_d32;                  // d16_out   -> d32_out

    /*! \brief residual block, channels 32 -> 32 */
    ResidualBlock3 m_dr32;               // d32_out   -> dr32_out  (shared memory B part 2)

    /*! \brief downsample layer, channels 32 -> 64 */
    ConvBnRelu3 m_d64;                  // dr32_out  -> d64_out

    /*! \brief residual block, channels 64 -> 64 */
    BottResidualBlock3 m_dr64;               // d64_out   -> dr64_out  (shared memory C part 2)

    /*! \brief downsample layer, channels 64 -> 128 */
    ConvBnRelu3 m_d128;                 // dr64_out  -> d128_out

    /*! \brief residual block, channels 128 -> 128 */
    BottResidualBlock3 m_dr128;              // d128_out  -> dr128_out (shared memory D part 2)

    /*! \brief downsample layer, channels 128 -> 256 */
    ConvBnRelu3 m_d256;                 // dr128_out -> d256_out

    /*! \brief residual block, channels 256 -> 256 */
    BottResidualBlock3 m_dr256;              // d256_out  -> dr256_out

    /*! \brief upsample layer, channels 256 -> 128 + 128 */
    ConvTransposeBnRelu3 m_u256;        // dr256_out -> u128_out   (shared memory D part 1)
                                        // u128_out + dr128_out -> u256_in

    /*! \brief residual block, channels 256 -> 256 */
    BottResidualBlock3 m_ur256;              // u256_in   -> ur256_out

    /*! \brief upsample layer, channels 256 -> 64 + 64 */
    ConvTransposeBnRelu3 m_u128;        // ur256_out  -> u64_out    (shared memory C part 1)
                                        // u64_out + dr64_out -> u128_in

    /*! \brief residual block, channels 128 -> 128 */
    BottResidualBlock3 m_ur128;              // u128_in   -> ur128_out

    /*! \brief upsample layer, channels 128 -> 32 + 32 */
    ConvTransposeBnRelu3 m_u64;         // ur128_out  -> u32_out    (shared memory B part 1)
                                        // u32_out + dr32_out -> u64_in

    /*! \brief residual block, channels 64 -> 64 */
    ResidualBlock3 m_ur64;               // u64_in    -> ur64_out

    /*! \brief upsample layer, channels 64 -> 16 + 16 */
    ConvTransposeBnRelu3 m_u32;         // ur64_out  -> u16_out   (shared memory A part 1)
                                        // u16_out + dr16_out -> u32_in

    /*! \brief residual block, channels 32 -> 32 */
    ResidualBlock3 m_ur32;               // u32_in    -> ur32_out

    /*! \brief output block, channels 32 -> 2 -> 2 */
    ConvBnRelu3 m_u2;                   // ur32_out  -> u2_out
    Conv3 m_final;                      // u2_out    -> outtensor

    // intermediate tensors
    FloatTensor5 m_d16_out, m_d32_out, m_dr32_out, m_d64_out, m_dr64_out, m_d128_out, m_dr128_out, m_d256_out, m_dr256_out;
    FloatTensor5 m_u128_out, m_u256_in, m_ur256_out, m_u64_out, m_u128_in, m_ur128_out, m_u32_out, m_u64_in, m_ur64_out;
    FloatTensor5 m_u16_out, m_u32_in, m_ur32_out, m_u2_out, m_final_out;
};

}

#endif

from easydict import EasyDict as edict
from md.segmentation3d.utils.vseg_helpers import SinglescaleCropper, FixedNormalizer
 
__C = edict()
 
cfg = __C
 
# general parameters
__C.general = {}
__C.general.imseg_list = 'train.txt'
__C.general.save_dir = 'fine'
__C.general.resume_epoch = -1
__C.general.num_gpus = 1
__C.general.seed = 0
 
# dataset parameters
__C.dataset = {}
__C.dataset.label = 2
__C.dataset.spacing = [1, 1, 1]
__C.dataset.cropsize = [96, 96, 96]
 
# sampling method
__C.dataset.sampling_method = 2
__C.dataset.box_pad_voxel = [0, 0, 0]
__C.dataset.crop_always_in = False
 
# data augmentation options
__C.dataset.cropper = SinglescaleCropper(__C.dataset.cropsize)
__C.dataset.crop_normalizer = FixedNormalizer(mean=50, stddev=250, clip=True)
 
# loss
__C.loss = {}
__C.loss.name = 'Dice'                                 # 'Dice', or 'Focal'
__C.loss.focal_obj_alpha = 0.5                         # class balancing weight for focal loss
__C.loss.focal_gamma = 2                               # gamma in pow(1-p,gamma) for focal loss
 
# net
__C.net = {}
__C.net.name = 'vbnet'
 
# training parameters
__C.train = {}
__C.train.epochs = 1001
__C.train.batchsize = 6
__C.train.num_threads = 8
__C.train.lr = 1e-4
__C.train.betas = (0.9, 0.999)
__C.train.plot_snapshot = 100
__C.train.save_epochs = 50
__C.train.save_inputs = False
__C.train.save_hard_start = 20000
__C.train.save_hard_dsc_loss = 0.9

import torch
import os
from seg.vnet_helpers import last_checkpoint
import md

path = '/home/ubuntu2/projects/organs/v2.0/spleen'

def adapt_model(checkpoint_folder):

    param_file = os.path.join(checkpoint_folder, 'params.pth')
    params = torch.load(param_file)
    normalizer = params['crop_normalizer']

    corrected_normalizer = {}

    if isinstance(normalizer, md.seg.vnet_helpers.FixedNormalizer):
        corrected_normalizer['type'] = 0
        corrected_normalizer['mean'] = normalizer.mean
        corrected_normalizer['stddev'] = normalizer.stddev
        corrected_normalizer['clip'] = True if normalizer.clip else False
    elif isinstance(normalizer, md.seg.vnet_helpers.AdaptiveNormalizer):
        corrected_normalizer['type'] = 1
        corrected_normalizer['min_p'] = normalizer.min_p
        corrected_normalizer['max_p'] = normalizer.max_p
        corrected_normalizer['clip'] = True if normalizer.clip else False
    else:
        raise ValueError('unknown normalizer type')

    params['crop_normalizer'] = corrected_normalizer
    torch.save(params, param_file)


chk_folder = last_checkpoint(os.path.join(path, 'coarse', 'checkpoints'))
adapt_model(chk_folder)

chk_folder = last_checkpoint(os.path.join(path, 'fine', 'checkpoints'))
adapt_model(chk_folder)

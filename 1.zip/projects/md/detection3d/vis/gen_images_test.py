import argparse
import numpy as np
import os
import pandas as pd
import sys
from md.detection3d.vis.gen_images import GenImagesOptions as Options
from md.detection3d.vis.gen_images import GeneratePlaneImages
from md.detection3d.vis.gen_html_report import GenHtmlReport
"""
Parse input arguments and raise error if invalid.
"""
def str2bool(v):
    if v.lower() in ('yes', 'true', 't', 'y', '1'):
        return True
    elif v.lower() in ('no', 'false', 'f', 'n', '0'):
        return False
    else:
        raise argparse.ArgumentTypeError('Unsupported value encountered.')

def ParseAndCheckArguments():
  parser = argparse.ArgumentParser(
    description='Snapshot three planes centered around landmarks.')

  # The unit testing data is stored on the server: 10.9.19.50
  data_path = '/mnt/disk/Data/unit_test_data/eval_landmark'

  parser.add_argument('--input_folder', type=str,
                      default=data_path,
                      help='Folder containing the source data.')

  parser.add_argument('--image_list_csv', type=str,
                      default=os.path.join(data_path, "filelist.csv"),
                      help='CSV file containing the image name list.')

  parser.add_argument('--labelled_list_csv', type=str,
                      default=os.path.join(data_path, "labelled.csv"),
                      help='CSV file containing labelled landmark coordinates.')

  parser.add_argument('--detected_list_csv', type=str,
                      default=os.path.join(data_path, "detected.csv"),
                      help='CSV file containing detected landmark coordinates.')

  parser.add_argument('--resolution', type=float, default=2.0,
                      help="Resolution of the snap shot images.")

  parser.add_argument('--contrast_min', type=int, default=-170,
                      help='Min value of contrast intensity window.')

  parser.add_argument('--contrast_max', type=int, default=230,
                      help='Max value of contrast intensity window.')

  parser.add_argument('--output_folder', type=str,
                      default=os.path.join(data_path, "output"),
                      help='Folder containing the generated snapshot images.')
  parser.add_argument('--for_label_checking', type=str2bool, default=False,
                      help='Deciding whether it is used for label checking or error analysis.')
  args = parser.parse_args()

  invalid_arguments = False

  if not args.image_list_csv:
    print "Please specify the image_list_csv"
    invalid_arguments = True
  elif not os.path.isfile(args.image_list_csv):
    print "The specified image_list_csv: {0} does not exist!".format(args.image_list_csv)
    invalid_arguments = True

  if not args.input_folder:
    print "Please specify the input_folder"
    invalid_arguments = True
  elif not os.path.isdir(args.input_folder):
    print "The specified input_folder: {0} does not exist!".format(args.image_folder)
    invalid_arguments = True

  if not args.labelled_list_csv:
    print "Please specify the labelled_list_csv"
    invalid_arguments = True
  elif not os.path.isfile(args.labelled_list_csv):
    print "The specified labelled_list_csv: {0} does not exist!".format(args.labelled_list_csv)
    invalid_arguments = True

  if not args.detected_list_csv:
    print "Please specify the detected_list_csv"
    invalid_arguments = True
  elif not os.path.isfile(args.detected_list_csv):
    print "The specified detected_list_csv: {0} does not exist!".format(args.detected_list_csv)
    invalid_arguments = True

  if not args.output_folder:
    print "Please specify the output_folder"
    invalid_arguments = True

  if args.resolution <= 0:
    print "The resolution must be a positive number."
    invalid_arguments = True

  if args.contrast_min >= args.contrast_max:
    print "The contrast min has to be smaller than contrast max."
    invalid_arguments = True

  if invalid_arguments:
    raise ValueError("Invalid input arguments!")

  return args


"""
Load coordinates (x,y,z) from CSV file and pack them into a two-dimensional array.

Input arguments:
  csv_file: CSV file path containing [x,y,z] coordinates in each row.

Return:
  Two dimensional array, [[x1,y1,z1], [x2,y2,z2], ... , [xn, yn, zn]], 
  where n is the number of the data.
"""
def LoadCoordinatesFromCSV(csv_file):
  df = pd.read_csv(csv_file)
  x = df['x'].tolist()
  y = df['y'].tolist()
  z = df['z'].tolist()

  points = []
  for i in range(len(x)):
    points.append([x[i], y[i], z[i]])

  return points

if __name__ == '__main__':
  print "current directory = {0}".format(os.getcwd())
  args = ParseAndCheckArguments()

  df = pd.read_csv(args.image_list_csv)
  num_data = len(df)
  print "{0} data found.".format(num_data)
  file_name_list = df['filename'].tolist()

  labelled_point_list = LoadCoordinatesFromCSV(args.labelled_list_csv)
  if (len(labelled_point_list) != num_data):
    raise ValueError("The number of entries do not "
                     "match between file list and labelled list.")

  detected_point_list = LoadCoordinatesFromCSV(args.detected_list_csv)
  if (len(detected_point_list) != num_data):
    raise ValueError("The number of entries do no match "
                     "between file list and detected list.")

  options = Options(resolution = args.resolution,
                    contrast_min = args.contrast_min,
                    contrast_max = args.contrast_max)

  print "Generating 2D plane images ..."
  labelled_image_list, detected_image_list = \
      GeneratePlaneImages(file_name_list, args.input_folder,
                          labelled_point_list,
                          detected_point_list,
                          os.path.join(args.output_folder, "images"),
                          options)

  print "Generating html report ..."
  GenHtmlReport(file_name_list, labelled_point_list, detected_point_list, labelled_image_list,
                detected_image_list, output_folder=args.output_folder,
                image_folder='./images',
                for_label_checking=args.for_label_checking)

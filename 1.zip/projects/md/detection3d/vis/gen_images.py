#coding:utf-8
import matplotlib.pyplot as plt
import md.image3d.python.image3d_io as cio
import numpy as np
import os

from collections import namedtuple
from scipy import interpolate as itp
from md.detection3d.vis.save_images import PlotCrossingAndSavePlanes

"""
The struct containing the 2D plane generation options.
"""
GenImagesOptions = namedtuple('GenImagesOption',
                              'resolution contrast_min contrast_max')

"""
Extract axial, coronal and sagittal planes crossing the input point 
 from a 3D volume data. The three planes are resampled to the specified resolution.

Input arguments:
  src_dimension:  Three dimensional vector of the data size.
  src_resolution: Three or one (isotropic) dimensional vector of the data resolution. 
  src_data:       The source 3D data volume.
  dst_dimension:  Three dimensional vector of the resampled data size.
  dst_resolution: Three or one (isotropic) dimensional vector of the resampled
                  data resolution.
  dst_point:      The point coordinate in the resampled data space.
Return:
  dst_axial:      Extracted (resampled) 2-D axial plane crossing the dst_point.
  dst_coronal:    Extracted (resampled) 2-D coronal plane crossing the dst_point.
  dst_sagittal:   Extracted (resampled) 2-D sagittal plane crossing the dst_point.
"""
def ExtractThreePlanesFrom3DVolume(src_dimension, src_resolution,
                                   dst_dimension, dst_resolution,
                                   src_data, dst_point):

  if (len(src_resolution) == 1):
    src_resolution = np.ones(3, dtype = float) * src_resolution[0]

  if (len(dst_resolution) == 1):
    dst_resolution = np.ones(3, dtype = float) * dst_resolution[0]

  src_x = np.arange(src_dimension[0])
  src_y = np.arange(src_dimension[1])
  src_z = np.arange(src_dimension[2])

  dst_x = np.linspace(0, src_dimension[0] - 1, dst_dimension[0])
  dst_y = np.linspace(0, src_dimension[1] - 1, dst_dimension[1])
  dst_z = np.linspace(0, src_dimension[2] - 1, dst_dimension[2])

  # Extract the axial plane from the source data passing through the dst point.
  # meshgrid() function scans the volume along Y-axis first, then X-axis,
  # then Z-axis. Hence, we switch the order of y and x to make sure the
  # grid point coordinates are in correct order of (x,y,z).
  dst_axial_y, dst_axial_x, dst_axial_z = np.meshgrid(
    dst_y, dst_x, [dst_point[2] * dst_resolution[2] / src_resolution[2]])

  dst_axial_interp = itp.interpn(
    (src_x, src_y, src_z), src_data, (dst_axial_x, dst_axial_y, dst_axial_z))

  dst_axial = dst_axial_interp[:,:,0]

  # Extract the coronal plane from the source data passing through the dst point.
  dst_coronal_y, dst_coronal_x, dst_coronal_z = np.meshgrid(
    [dst_point[1] * dst_resolution[1] / src_resolution[1]], dst_x, dst_z)

  dst_coronal_interp = itp.interpn(
    (src_x, src_y, src_z), src_data, (dst_coronal_x, dst_coronal_y, dst_coronal_z))

  dst_coronal = dst_coronal_interp[:,0,:]

  # Extract the sagittal plane from the source data passing through the dst point.
  dst_sagittal_y, dst_sagittal_x, dst_sagittal_z = np.meshgrid(
    dst_y, [dst_point[0] * dst_resolution[0] / src_resolution[0]], dst_z)

  dst_sagittal_interp = itp.interpn(
    (src_x, src_y, src_z), src_data, (dst_sagittal_x, dst_sagittal_y, dst_sagittal_z))

  dst_sagittal = dst_sagittal_interp[0,:,:]

  return dst_axial, dst_coronal, dst_sagittal



"""
Given a list of input 3D volumes, as well as labelled and detected points, extract
 the axial, coronal and sagittal planes crossing these points and save them as PNG
 images to the specified output folder.
Input arguments:
  file_name_list:      The list of 3D volume file names including postfix.
  input_folder:        The input folder containing the 3D volume data. 
  labelled_point_list: The 2D list of 3D labelled point in world coordinate.
  detected_point_list: The 2D list of 3D detected point in world coordinate.
  options:             The option of plane generation.
  output_folder:       The output folder containing the generated images.
Return:
  labelled_image_name_list: The 2D list of captured 2D image file names.
  detected_image_name_list: The 2D list of captured 2D image file names. 
"""
def GeneratePlaneImages(file_name_list, input_folder, labelled_point_list,
                        detected_point_list, output_folder, options):
  resolution = options.resolution
  contrast_min = options.contrast_min
  contrast_max = options.contrast_max

  if not os.path.isdir(output_folder):
    os.makedirs(output_folder)

  labelled_image_list = []
  detected_image_list = []

  for file_idx, file_name in enumerate(file_name_list):
    file_path = os.path.join(input_folder, file_name)
    if not os.path.isfile(file_path):
      print "Warning: {0} does not exist and is skipped.".format(file_path)
      continue

    image = cio.read_image(file_path)

    print "{0} loaded.".format(file_path)

    # Get source data resolution.
    voxel_size = image.spacing()

    # Get source data offset.
    offset = image.origin()

    # Get source data which is loaded in the order of [z,y,x].
    mhd_data = image.to_numpy().astype(np.int16)
    # Transpose to the order of [x, y, z]
    mhd_data = np.asarray(mhd_data, dtype='int16').transpose([2, 1, 0])

    # Get source data dimension.
    src_dimension = mhd_data.shape

    # Resampling to the desired resolution.
    dst_dimension = np.zeros(3, dtype=int)
    for i in range(3):
      dst_dimension[i] = int(np.floor(src_dimension[i] * voxel_size[i] / resolution))

    # Capture three orthogonal planes crossing the labelled point.
    frame = image.frame().deep_copy()
    frame.set_spacing([resolution, resolution, resolution])
    labelled_point = frame.world_to_voxel(labelled_point_list[file_idx])

    axial_plane, coronal_plane, sagittal_plane = ExtractThreePlanesFrom3DVolume(
      src_dimension, voxel_size, dst_dimension, [resolution], mhd_data, labelled_point)

    axial_plane = np.clip(axial_plane, contrast_min, contrast_max)
    coronal_plane = np.clip(coronal_plane, contrast_min, contrast_max)
    sagittal_plane = np.clip(sagittal_plane, contrast_min, contrast_max)

    axial_image_filename = "{0:03d}_labelled_axial.png".format(file_idx)
    PlotCrossingAndSavePlanes(
      axial_plane, [labelled_point[0], labelled_point[1]], 'labelled_axial',
      os.path.join(output_folder, axial_image_filename), 'g', 'g-.')

    coronal_image_filename = "{0:03d}_labelled_coronal.png".format(file_idx)
    PlotCrossingAndSavePlanes(
      coronal_plane, [labelled_point[0], labelled_point[2]], 'labelled_coronoal',
      os.path.join(output_folder, coronal_image_filename), 'g', 'g-.')

    sagittal_image_filename = "{0:03d}_labelled_sagittal.png".format(file_idx)
    PlotCrossingAndSavePlanes(
      sagittal_plane, [labelled_point[1], labelled_point[2]], 'labelled_sagittal',
      os.path.join(output_folder, sagittal_image_filename), 'g', 'g-.')

    labelled_image_list.append(
      [axial_image_filename, coronal_image_filename, sagittal_image_filename])

    # Capture three orthogonal planes crossing the detected point.
    detected_point = frame.world_to_voxel(detected_point_list[file_idx])

    axial_plane, coronal_plane, sagittal_plane = ExtractThreePlanesFrom3DVolume(
      src_dimension, voxel_size, dst_dimension, [resolution], mhd_data, detected_point)

    axial_plane = np.clip(axial_plane, contrast_min, contrast_max)
    coronal_plane = np.clip(coronal_plane, contrast_min, contrast_max)
    sagittal_plane = np.clip(sagittal_plane, contrast_min, contrast_max)

    axial_image_filename = "{0:03d}_detected_axial.png".format(file_idx)
    PlotCrossingAndSavePlanes(
      axial_plane, [detected_point[0], detected_point[1]], 'detected_axial',
      os.path.join(output_folder,axial_image_filename), 'r', 'r-.')

    coronal_image_filename = "{0:03d}_detected_coronal.png".format(file_idx)
    PlotCrossingAndSavePlanes(
      coronal_plane, [detected_point[0], detected_point[2]], 'detected_coronal',
      os.path.join(output_folder, coronal_image_filename), 'r', 'r-.')

    sagittal_image_filename = "{0:03d}_detected_sagittal.png".format(file_idx)
    PlotCrossingAndSavePlanes(
      sagittal_plane, [detected_point[1], detected_point[2]], 'detected_sagittal',
      os.path.join(output_folder, sagittal_image_filename), 'r', 'r-.')

    detected_image_list.append(
      [axial_image_filename, coronal_image_filename, sagittal_image_filename])

  return labelled_image_list, detected_image_list

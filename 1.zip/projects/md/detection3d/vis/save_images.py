# coding:utf-8

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np

mpl.rcParams['image.origin'] = u'lower'


"""
Plot horizontal and vertical crossing lines passing through the specified point on
 the image.
Input arguments:
  point_x: X coordinate of the point.
  point_t: Y coordinate of the point. 
  width:   The image width.
  height:  The image height.
  line_width: The width of the line in pixels.
  line_style: The style of the line.
"""
def PlotCrossing(point_x, point_y, width, height, line_style = 'r-.', line_width = 1):
    xx1 = np.arange(0, width)
    yy1 = np.ones(width) * point_y

    xx2 = np.ones(height) * point_x
    yy2 = np.arange(0, height)

    plt.plot(xx1, yy1, line_style, linewidth = line_width)
    plt.plot(xx2, yy2, line_style, linewidth = line_width)


"""
Plot crossing lines on a 2D plane image and save it to the specified path.
Input arguments:
  plane:      2-D plane image.
  point:      2-D dimensional point on the image space.
  image_path: The path to save the image.
  line_width: The width of the line in pixels.
  line_style: The style of the line.
"""
def PlotCrossingAndSavePlanes(plane, point, title, image_path, title_color,
                              line_style, line_width = 1):

  # Transpose the image and flip the image left and right.
  width = plane.shape[0]
  height = plane.shape[1]

  # Create a new figure
  fig = plt.figure(1)

  # handle the problem that patient is under the bed.
  if 'axial' in title:
    plane = np.fliplr(plane)
    point[1] = height - point[1]

  # The x, y coordinate are reverse on the plot figure.
  plt.imshow(np.transpose(plane), cmap='gray')
  PlotCrossing(point[0], point[1], width, height, line_style, line_width)

  plt.axis('off')
  plt.subplots_adjust(top=0.9, bottom=0, left=0, right=1, hspace=0, wspace=0)
  plt.title(title, fontsize=20, color=title_color)

  # Save and close the figure.
  fig.savefig(image_path)
  fig.clf()

import argparse
import glob
import os
import time

import md.image3d.python.image3d_io as cio
import md.image3d.python.image3d_tools as ctools
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from md.image3d.python.image3d import Image3d
from md.detection3d.dataset.multi_detection_dataset import read_image_list
from md.detection3d.vdnet_helpers import LoadConfig
from md.detection3d.vdnet_helpers import LoadModel
from md.mdpytorch.utils.tensor_tools import ToTensor, ToImage
from torch.autograd import Variable


def ParseAndCheckArguments():
  parser = argparse.ArgumentParser()

  parser.add_argument('--model_folder', type=str,
                      default = "/home/dijia_wu/projects/landmarks/model_0110_2018",
                      help='Folder containing the trained model folder.')
  parser.add_argument('--test_image_list', type=str,
                      default = "/mnt/disk/MI_project/MI_Aorta_mhd/label/validation_set/filenames.csv",
                      help='File path of the testing image list.')
  parser.add_argument('--test_image_folder', type=str,
                      default = "/mnt/disk/MI_project/MI_Aorta_mhd/data/res_4",
                      help='Folder containing the testing images.')
  parser.add_argument('--ckpt_index', type=int, default=0,
                      help="Index of the model checkpoint to load."
                           " By default, it's zero to load the latest checkpoint.")
  parser.add_argument('--output_folder', type=str,
                      default="/home/dijia_wu/projects/landmarks/model_0110_2018/validation_probmaps",
                      help='Folder containing the output probability maps.')

  args = parser.parse_args()

  invalid_arguments = False
  if not args.model_folder:
    print "Please specify the trained model folder."
    invalid_arguments = True
  elif not os.path.isdir(args.model_folder):
    print "The specified model folder: {0} does not exist!".format(args.config)
    invalid_arguments = True

  if not args.test_image_list:
    print "Please specify the testing image list."
    invalid_arguments = True
  elif not os.path.isfile(args.test_image_list):
    print "The specified image list: {0} does not exist!".format(args.test_image_list)
    invalid_arguments = True

  if not args.test_image_folder:
    print "Please specify the testing image folder."
    invalid_arguments = True
  elif not os.path.isdir(args.test_image_folder):
    print "The specified image folder: {0} does not exist!".format(args.test_image_folder)
    invalid_arguments = True

  if not args.output_folder:
    args.output_folder = os.path.join(args.model_folder, "probability_maps")
  if not invalid_arguments and not os.path.isdir(args.output_folder):
    os.makedirs(args.output_folder)

  if invalid_arguments:
    raise ValueError("Invalid input arguments!")

  return args


if __name__ == '__main__':
  args = ParseAndCheckArguments()

  config_file = os.path.join(args.model_folder, "config.py")
  cfg = LoadConfig(config_file)
  num_landmarks = len(cfg.general.label_list_files)

  model_file = os.path.join(args.model_folder, "net.py")
  model = LoadModel(model_file)

  ckpt_path = os.path.join(args.model_folder, "checkpoints")
  if args.ckpt_index == 0:
    ckpt_files = glob.glob(os.path.join(ckpt_path, "*.pth"))
    if len(ckpt_files) == 0:
      raise ValueError("There is no checkpoint files saved in the model folder.")
    ckpt_files.sort()
    ckpt_file = ckpt_files[-1]
  elif args.ckpt_index > 0:
    ckpt_file = os.path.join(ckpt_path, "ckpt_{0:06d}.pth".format(args.ckpt_index))
  else:
    raise ValueError("ckpt_index must be non-negative.")

  state = torch.load(ckpt_file)

  in_channels = 1
  run_regression = cfg.loss.regression.lamda > 0
  num_classes = num_landmarks + 1
  net = model.VNet(in_channels, num_classes, run_regression)
  max_stride = net.max_stride()
  gpu_ids = range(cfg.general.num_gpus)
  net = nn.parallel.DataParallel(net, device_ids = gpu_ids)
  net = net.cuda()
  net.load_state_dict(state['model_state_dict'])
  net.eval()

  image_list = read_image_list(os.path.dirname(args.test_image_list),
                               os.path.basename(args.test_image_list))

  # initialize landmark detection results.
  landmark_results = {}
  for i in range(num_landmarks):
    landmark_name = cfg.general.label_list_files[i]
    landmark_results[landmark_name] = {}
    landmark_results[landmark_name]['filenames'] = []
    landmark_results[landmark_name]['x'] = []
    landmark_results[landmark_name]['y'] = []
    landmark_results[landmark_name]['z'] = []

  image_index = 0
  for image_file in image_list:
    print "Processing {0} out of {1} images".format(image_index, len(image_list))
    image_index += 1

    image_path = os.path.join(args.test_image_folder, image_file)
    begin = time.time()
    image = cio.read_image(image_path, dtype=np.float32)
    read_time = time.time() - begin

    begin = time.time()
    # first, normalize and clip the voxel image intensities to [-1, 1].
    ctools.intensity_normalize(image,
                               cfg.dataset.normalization.mean,
                               cfg.dataset.normalization.stddev,
                               cfg.dataset.normalization.clip)

    image_spacing = image.spacing()
    padding_size = [None]*3
    for i in range(3):
      padding_size[i] = (cfg.dataset.cropping_size[i] - cfg.dataset.sampling_size[i])/2

    # second, resample and pad the volume to meet the requirement of multiple of max stride.
    image = ctools.resample_volume_nn_with_extra_padding_rai(
      image, cfg.dataset.voxel_spacing, padding_size, max_stride)

    processing_time = time.time() - begin

    begin = time.time()
    iso_frame = image.frame().deep_copy()
    # iso_image: [batch_num=1 , channel_num=1, dim_z, dim_y, dim_x]
    iso_image = ToTensor()(image).unsqueeze(0)
    iso_image = iso_image.cuda()
    iso_image_v = Variable(iso_image, volatile=True)


    # pred: [batch_num=1, channel_num=num_classes, dim_z, dim_y, dim_x]
    pred = net(iso_image_v)
    pred = ToImage()(pred[0].data)
    prediction_time = time.time() - begin

    begin = time.time()
    image_base, _ = os.path.splitext(image_file)
    for i in range(1, num_classes):
      prob_map = pred[i]
      prob_map.set_frame(iso_frame)

      # crop out the padded areas and save images for visualization and debugging
      voxel_sp = np.round(padding_size).astype(np.int32)
      voxel_ep = np.round(prob_map.size() - padding_size).astype(np.int32)
      cropped_prob_map = ctools.crop(prob_map, voxel_sp, voxel_ep)
      prob_path = os.path.join(args.output_folder,
                               '{0}_probmap_ldmrk_{1:02d}.mhd'.format(image_base, i))
      cio.write_image(cropped_prob_map, prob_path)

      voxel_sp = np.round(padding_size).astype(np.int32)
      voxel_ep = np.round(image.size() - padding_size).astype(np.int32)
      cropped_image = ctools.crop(image, voxel_sp, voxel_ep)
      imag_path = os.path.join(args.output_folder,
                               '{0}_padded.mhd'.format(image_base))
      cio.write_image(cropped_image, imag_path)

      cropped_prob_frame = cropped_prob_map.frame().deep_copy()
      # threshold the probability map to get the binary mask
      prob_threshold = 0.5
      cropped_prob_data = cropped_prob_map.to_numpy()
      cropped_mask_data = np.zeros_like(cropped_prob_data, dtype=np.int16)
      cropped_mask_data[cropped_prob_data >= prob_threshold] = 1
      cropped_mask_data[cropped_prob_data < prob_threshold] = 0

      # pick the largest connected component
      cropped_mask = Image3d()
      cropped_mask.from_numpy(cropped_mask_data)
      cropped_mask.set_frame(cropped_prob_frame)
      ctools.pick_largest_component(cropped_mask)

      # only keep probability of the largest connected component
      cropped_mask_data = cropped_mask.to_numpy()
      masked_prob_data = np.multiply(cropped_mask_data.astype(np.float), cropped_prob_data)

      # compute the weighted mass center of the probability map
      masked_prob_map = Image3d()
      masked_prob_map.from_numpy(masked_prob_data)
      masked_prob_map.set_frame(cropped_prob_frame)
      voxel_coordinate = ctools.weighted_mass_voxel_center(masked_prob_map, prob_threshold, 1.0)
      if voxel_coordinate is not None:
        world_coordinate = masked_prob_map.voxel_to_world(voxel_coordinate)
        print "world coordinate of volume {0} landmark {1} is:[{2},{3},{4}]".format(
          image_file, i, world_coordinate[0], world_coordinate[1], world_coordinate[2])

        landmark_name = cfg.general.label_list_files[i-1]
        landmark_results[landmark_name]['filenames'].append(image_file)
        landmark_results[landmark_name]['x'].append(world_coordinate[0])
        landmark_results[landmark_name]['y'].append(world_coordinate[1])
        landmark_results[landmark_name]['z'].append(world_coordinate[2])

    saving_time = time.time() - begin
    print 'read: {:.2f} s, processing: {:.2f} s, prediction: {:.2f} s,' \
          ' saving: {:.2f} s'.format(read_time, processing_time, prediction_time, saving_time)


  for i in range(num_landmarks):
    landmark_name = cfg.general.label_list_files[i]
    csv_path = os.path.join(args.output_folder, '{0}_detected.csv'.format(landmark_name))
    landmark_result = landmark_results[landmark_name]
    df = pd.DataFrame(data={'filenames': landmark_result['filenames'],
                            'x': landmark_result['x'],
                            'y': landmark_result['y'],
                            'z': landmark_result['z']})

    df.to_csv(csv_path)
import importlib
import os

def LoadConfig(config_file):
  config_path  = os.path.dirname(config_file)
  config_base = os.path.basename(config_file)
  config_name, _ = os.path.splitext(config_base)

  # To avoid duplicate config name with existing modules, add the specified path first.
  os.sys.path.insert(0, config_path)
  lib = importlib.import_module(config_name)
  os.sys.path.pop(0)

  return lib.cfg


def LoadModel(model_file):
  model_path = os.path.dirname(model_file)
  model_base = os.path.basename(model_file)
  model_name, _ = os.path.splitext(model_base)

  # To avoid duplicate model names with existing modules, add the specified path first.
  os.sys.path.insert(0, model_path)
  model = importlib.import_module(model_name)
  os.sys.path.pop(0)
  return model

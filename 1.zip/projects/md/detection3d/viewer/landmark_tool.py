from PyQt5.Qt import *
import os
from md.viewer.view_client import ViewClient
import numpy as np
import pandas as pd
import csv
from md.utils.python.file_tools import readlines
from md.detection3d.vdet_pyimpl import autodet_load_model, autodet_volume
import md.image3d.python.image3d_io as cio
import md.image3d.python.image3d_tools as ctools

class OptionDialog(QDialog):
    """
    Dialog for displaying option buttons
    """

    def __init__(self, options, fontsize=16):
        super(OptionDialog, self).__init__()

        self.selected_id = -1

        font = self.font()
        font.setPointSize(fontsize)

        self.button_ids = {}
        layout = QHBoxLayout()
        for i, option in enumerate(options):
            button = QPushButton(option)
            button.setFont(font)
            button.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Ignored)
            button.clicked.connect(self.buttonClicked)
            self.button_ids[button] = i
            layout.addWidget(button)

        self.setLayout(layout)

    def buttonClicked(self):
        button = self.sender()
        button_id = self.button_ids[button]
        self.selected_id = button_id
        self.accept()

class ConsoleToolbar(QMainWindow):
    """
    Detection Landmark Menu
    A convenient tool to load image and label landmark
    """
    def __init__(self, name):
        super(ConsoleToolbar, self).__init__()

        # view client
        self.viewclient_name = name
        self.viewclient = None
        self.Widget = None

        # image
        self.imlist = []
        self.imidx = -1
        self.imlist_status = [] # status: 'Done','In-progress','Empty'
        self.im3 = None
        self.im_type = None # type: 'Dicom', 'Non-Dicom'

        # detection model
        self.detmodel = None
        self.pre_annoted_files_folder = None

        # landmark
        self.lmlist = {}
        self.lmname = []
        self.lm_table_changed = False
        self.lm_table_created = False
        self.lm_text_visible = True

        # landmark table
        self.tabletitle = ['Index', 'Name', 'VoxelX', 'VoxelY', 'VoxelZ', 'WorldX', 'WorldY', 'WorldZ', 'AddLM']

        # image process params
        self.auto_wcww = False
        self.wc = 0
        self.ww = 1000
        self.alpha = 0.25
        self.auto_wc = None
        self.auto_ww = None

        # main frame
        self.titlename = 'Landmark Annotation Tool'
        self.setup_ui()

    def setup_ui(self):

        # Set-up view client
        self.viewclient = ViewClient(self.viewclient_name)
        self.viewclient.open()
        self.Widget = QWidget()

        # Menu Bar
        menu_bar = self.menuBar()

        # file menu
        file_menu = menu_bar.addMenu('File')
        open_nondicom_menu = QMenu('Open Image', self)
        load_nondicom_act = QAction('Open Single Image', self)
        load_nondicom_folder_act = QAction('Open Image From Folder', self)
        load_nondicom_list_act = QAction('Open Image From List', self)
        open_nondicom_menu.addAction(load_nondicom_act)
        open_nondicom_menu.addAction(load_nondicom_folder_act)
        open_nondicom_menu.addAction(load_nondicom_list_act)
        load_nondicom_act.triggered.connect(self.load_nondicom_clicked)
        load_nondicom_folder_act.triggered.connect(self.load_image_folder_clicked)
        load_nondicom_list_act.triggered.connect(self.load_image_list_clicked)

        open_dicom_menu = QMenu('Open Dicom series', self)
        load_dicom_act = QAction('Open Single Dicom', self)
        load_dicom_folder_act = QAction('Open Dicoms From Folder', self)
        open_dicom_menu.addAction(load_dicom_act)
        open_dicom_menu.addAction(load_dicom_folder_act)
        load_dicom_act.triggered.connect(self.load_dicom_clicked)
        load_dicom_folder_act.triggered.connect(self.load_dicom_folder_clicked)

        file_menu.addMenu(open_nondicom_menu)
        file_menu.addMenu(open_dicom_menu)

        # annotation menu
        annot_menu = menu_bar.addMenu('Annotation')
        manual_annot_menu = QMenu('Manual Annotation', self)
        create_template_menu = QAction('Step 1: Create Template', self)
        save_annot_menu = QAction('Step 2: Set Save Folder', self)
        open_annot_menu = QAction('Load Annotation Results', self)
        open_annot_menu.triggered.connect(self.open_annot)
        save_annot_menu.triggered.connect(self.save_annot)
        create_template_menu.triggered.connect(self.create_template_table)
        manual_annot_menu.addAction(create_template_menu)
        manual_annot_menu.addAction(save_annot_menu)
        annot_menu.addMenu(manual_annot_menu)
        annot_menu.addAction(open_annot_menu)

        # tools menu
        tools_menu = menu_bar.addMenu('Tools')
        image_contrast_menu = QMenu('Image Contrast', self)
        contrast_adjust_act = QAction('Contrast Adjustment...', self)
        auto_contrast_act = QAction('Auto-Adjust Contrast (all layers)', self)
        load_model_menu = QAction('AI Online Detection', self)
        image_contrast_menu.addAction(contrast_adjust_act)
        image_contrast_menu.addAction(auto_contrast_act)
        contrast_adjust_act.triggered.connect(self.adjust_contrast)
        auto_contrast_act.triggered.connect(self.auto_contrast)
        load_model_menu.triggered.connect(self.load_model_clicked)
        tools_menu.addMenu(image_contrast_menu)
        tools_menu.addAction(load_model_menu)

        # landmark table box
        self.lmtable_box = QVBoxLayout()
        lm_title_box = QHBoxLayout()
        lmtable_title = QLabel('Landmark Table')
        lmtable_title.setFont(QFont('Roman times', 8, QFont.StyleItalic))

        lm_title_box.addWidget(lmtable_title)
        self.dimension = np.array([0, 0], dtype=np.int)
        self.table = LandMarkTable(self.dimension)
        #self.table.clicked_button.connect(self.save_cursor)
        self.table.clicked_button.connect(self.save_lm_clicked)
        self.table.itemselected.connect(self.goto_cursor)
        self.lmtable_box.addLayout(lm_title_box)
        self.lmtable_box.addWidget(self.table)

        # AI model box
        self.model_box = QVBoxLayout()
        model_title = QLabel('AI Detection Model')
        model_title.setFont(QFont('Roman times', 8, QFont.StyleItalic))
        model_layout = QHBoxLayout()
        self.modelEdit = QLineEdit(self)
        self.modelEdit.setReadOnly(True)
        modelButton = QPushButton('Detect', self)
        modelButton.clicked.connect(self.det_button_clicked)
        model_layout.addWidget(self.modelEdit, 5)
        model_layout.addWidget(modelButton, 1)
        self.model_box.addWidget(model_title)
        self.model_box.addLayout(model_layout)

        # save annotation file (default: .csv) box
        save_annot_box = QVBoxLayout()
        save_annot_title = QLabel(' ')
        save_annot_title.setFont(QFont('Roman times', 8, QFont.StyleItalic))
        save_annot_layout = QHBoxLayout()
        self.save_annot_edit = QLineEdit(self)
        self.save_annot_edit.setReadOnly(False)
        save_annot_button = QPushButton('Save', self)
        save_annot_button.clicked.connect(self.save_annot_button_clicked)
        save_annot_layout.addWidget(self.save_annot_edit, 5)
        save_annot_layout.addWidget(save_annot_button, 1)
        save_annot_box.addWidget(save_annot_title)
        save_annot_box.addLayout(save_annot_layout)

        # image list box
        self.imlist_box = QVBoxLayout()
        imlist_title = QLabel('Image List')
        imlist_title.setFont(QFont('Roman times', 8, QFont.StyleItalic))
        self.imlist_model = QStandardItemModel()
        self.imlist_view = QListView(self)
        self.imlist_view.setModel(self.imlist_model)
        self.imlist_view.doubleClicked.connect(self.imlist_item_doubleclicked)
        self.imlist_view.clicked.connect(self.imlist_item_doubleclicked)
        self.imlist_view.installEventFilter(self)

        ctrl_layout = QHBoxLayout()
        prevButton = QPushButton('<<', self)
        nextButton = QPushButton('>>', self)
        prevButton.clicked.connect(self.prevButtonClicked)
        nextButton.clicked.connect(self.nextButtonClicked)
        ctrl_layout.addWidget(prevButton)
        ctrl_layout.addWidget(nextButton)

        self.imlist_box.addWidget(imlist_title)
        self.imlist_box.addWidget(self.imlist_view)
        self.imlist_box.addLayout(ctrl_layout)

        # landmark actions box
        lmactions_box = QVBoxLayout()
        save_delete_box = QHBoxLayout()
        savelmButton = QPushButton('V', self)
        inexistlmButton = QPushButton('-1', self)
        deletelmButton = QPushButton('X', self)
        lm_display_button = QPushButton('On/Off', self)
        savelmButton.clicked.connect(self.save_lm_clicked)
        inexistlmButton.clicked.connect(self.inexist_lm_clicked)
        deletelmButton.clicked.connect(self.delete_lm_clicked)
        lm_display_button.clicked.connect(self.display_lm_clicked)
        save_delete_box.addWidget(savelmButton)
        save_delete_box.addWidget(inexistlmButton)
        save_delete_box.addWidget(deletelmButton)
        save_delete_box.addWidget(lm_display_button)
        lmactions_box.addLayout(save_delete_box)

        # left plane
        self.left_box = QVBoxLayout()
        self.left_box.addLayout(self.lmtable_box)
        self.left_box.addLayout(lmactions_box)
        #self.left_box.addStretch(1)
        self.left_box.addLayout(self.model_box)

        # right plane
        self.right_box = QVBoxLayout()
        self.right_box.addLayout(self.imlist_box)
        #self.right_box.addStretch(1)
        self.right_box.addLayout(save_annot_box)

        # Define global layout
        self.Widget = QWidget()
        globalbox = QHBoxLayout(self.Widget)
        globalbox.addLayout(self.left_box)
        globalbox.addLayout(self.right_box)
        self.Widget.setLayout(globalbox)
        self.setCentralWidget(self.Widget)
        self.setWindowTitle(self.titlename)
        self.setGeometry(100, 100, 650, 400)

    def initialize(self):
        # image
        self.imlist = []
        self.imidx = -1
        self.imlist_status = []

        # model
        self.im3 = None

        # landmark
        self.lmlist = {}
        self.lmname = []
        self.lm_table_changed = False

        # annotation
        self.pre_annoted_files_folder = None

    def load_set_single_image(self, filename):
        assert len(filename) > 0

        try:
            self.im3 = cio.read_image(filename, dtype=np.float32)
        except Exception as e:
            print e
            QMessageBox.information(self, 'Error', 'Fail to load image: ' + filename)
            return

        # reset
        self.imlist = [filename]
        self.imidx = 0
        self.update_listview()
        self.setWindowTitle(os.path.basename(filename) + ' - ' + self.titlename)

        # load image and display
        self.viewclient.add_image(self.im3, 'Img', self.wc, self.ww, 0, 0.5, True)

    def update_listview(self):
        model = self.imlist_view.model()
        assert isinstance(model, QStandardItemModel)
        model.removeRows(0, model.rowCount())

        if len(self.imlist) == 1:
            basename = os.path.basename(self.imlist[0])
            item = QStandardItem(basename)
            item.setEditable(False)
            model.appendRow(item)
        else:
            digits = int(np.ceil(np.log10(len(self.imlist))))
            format_str = '{:0' + str(digits) + 'd}'
            for i, file in enumerate(self.imlist):
                basename = os.path.basename(file)
                item = QStandardItem(format_str.format(i) + ' ' + basename)
                item.setEditable(False)
                model.appendRow(item)

    def read_image_list(self, filename):
        lines = readlines(filename)
        if len(lines) < 2:
            QMessageBox.critical(self, 'Error', 'empty/wrong file? too few lines')
            return []

        lmlist = self.read_imlist_lines(lines)
        return lmlist

    def read_imlist_lines(self, lines):
        case_num = int(lines[0])

        if len(lines) >= case_num + 1 and ' ' in lines[1]:
            imlist, seglist = self.read_test_list(lines)
        else:
            QMessageBox.critical(self, 'Error', 'empty/wrong file? incorrect format')
            return []

        if len(imlist) == 0:
            return []
        else:
            return imlist

    def read_test_list(self, lines):
        imlist, seglist = [], []
        casenum = int(lines[0])

        for i in range(casenum):
            idx = lines[i + 1].index(' ')
            assert idx > 0
            im_path = lines[i + 1][idx + 1:]
            if not os.path.isfile(im_path):
                QMessageBox.critical(None, 'File Not Found', im_path)
                return [], []
            imlist.append(lines[i + 1][idx + 1:])

        return imlist, seglist

    def save_lm_table(self, filename):
        assert len(filename) > 0

        csvfile = file(filename, 'wb')
        writer = csv.writer(csvfile)
        list = self.tabletitle
        writer.writerow(list)
        for rowidx in range(self.dimension[0]):
            list = []
            for columnIndex in range(self.dimension[1]):
                item = self.table.item(rowidx, columnIndex)
                if item == None:
                    list.append(' ')
                else:
                    list.append(item.text())
            writer.writerow(list)
        csvfile.close()

    def save_lm_list(self, imagename):
        assert len(imagename) > 0

        self.lmlist[imagename] = {}
        for rowidx in range(self.dimension[0]):
            row_content = []
            for columnIndex in range(self.dimension[1]):
                item = self.table.item(rowidx, columnIndex)
                if item == None:
                    row_content.append(' ')
                else:
                    row_content.append(item.text())
            lm_name = row_content[1]
            self.lmlist[imagename][lm_name] = {}
            self.lmlist[imagename][lm_name]['name'] = lm_name
            self.lmlist[imagename][lm_name]['voxel_x'] = row_content[2]
            self.lmlist[imagename][lm_name]['voxel_y'] = row_content[3]
            self.lmlist[imagename][lm_name]['voxel_z'] = row_content[4]
            self.lmlist[imagename][lm_name]['x'] = row_content[5]
            self.lmlist[imagename][lm_name]['y'] = row_content[6]
            self.lmlist[imagename][lm_name]['z'] = row_content[7]

    def lm_list_is_finished(self, imagename):
        if imagename not in self.lmlist:
            return False

        for lmname in self.lmlist[imagename]:
            value = self.lmlist[imagename][lmname]['name']
            if value is None or len(value) == 0 or value == ' ':
                return False

            value = self.lmlist[imagename][lmname]['voxel_x']
            if value is None or len(value) == 0 or value == ' ':
                return False

            value = self.lmlist[imagename][lmname]['voxel_y']
            if value is None or len(value) == 0 or value == ' ':
                return False

            value = self.lmlist[imagename][lmname]['voxel_z']
            if value is None or len(value) == 0 or value == ' ':
                return False

            value = self.lmlist[imagename][lmname]['x']
            if value is None or len(value) == 0 or value == ' ':
                return False

            value = self.lmlist[imagename][lmname]['y']
            if value is None or len(value) == 0 or value == ' ':
                return False

            value = self.lmlist[imagename][lmname]['z']
            if value is None or len(value) == 0 or value == ' ':
                return False

        return True

    def set_lm_table(self):
        if not self.lm_table_created:
            return

        imagename = self.imlist[self.imidx]
        if imagename not in self.lmlist:
            self.clear_lm_table()
            return

        lmlist = self.lmlist[imagename]

        for rowidx in range(self.dimension[0]):
            item = self.table.item(rowidx, 1)
            lm_name = item.text()
            if lm_name in lmlist:
                x_v,y_v,z_v = lmlist[lm_name]['voxel_x'], lmlist[lm_name]['voxel_y'], lmlist[lm_name]['voxel_z']
                x,y,z = lmlist[lm_name]['x'], lmlist[lm_name]['y'], lmlist[lm_name]['z']
                self.table.setItem(rowidx, 2, QTableWidgetItem(str(x_v)))
                self.table.setItem(rowidx, 3, QTableWidgetItem(str(y_v)))
                self.table.setItem(rowidx, 4, QTableWidgetItem(str(z_v)))
                self.table.setItem(rowidx, 5, QTableWidgetItem(str(x)))
                self.table.setItem(rowidx, 6, QTableWidgetItem(str(y)))
                self.table.setItem(rowidx, 7, QTableWidgetItem(str(z)))

            lm_name = item.text().replace('\r','')
            if lm_name in lmlist:
                x_v,y_v,z_v = lmlist[lm_name]['voxel_x'], lmlist[lm_name]['voxel_y'], lmlist[lm_name]['voxel_z']
                x,y,z = lmlist[lm_name]['x'], lmlist[lm_name]['y'], lmlist[lm_name]['z']
                self.table.setItem(rowidx, 2, QTableWidgetItem(str(x_v)))
                self.table.setItem(rowidx, 3, QTableWidgetItem(str(y_v)))
                self.table.setItem(rowidx, 4, QTableWidgetItem(str(z_v)))
                self.table.setItem(rowidx, 5, QTableWidgetItem(str(x)))
                self.table.setItem(rowidx, 6, QTableWidgetItem(str(y)))
                self.table.setItem(rowidx, 7, QTableWidgetItem(str(z)))

    def clear_lm_table(self):
        if self.table is not None:
            for rowidx in range(self.dimension[0]):
                for colidx in range(2,self.dimension[1]):
                    self.table.setItem(rowidx, colidx, QTableWidgetItem(''))

    def set_lm_viewer(self):
        # if self.im3 is not None and self.imidx >= 0:
        #     for rowidx in range(self.dimension[0]):
        #         if self.table.item(rowidx,1) is not None:
        #             self.viewclient.marklm(self.table.item(rowidx, 1).text(), '')
        pass

    def clear_lm_viewer(self):
        for lm_name in self.viewclient.lms():
            self.viewclient.removelm(lm_name)

    def lm_table_is_finished(self):
        if self.table is None:
            return False
        if self.dimension[0] <= 0 or self.dimension[1] <= 0:
            return False

        table_has_empty_item = False
        for rowidx in range(self.dimension[0]):
            for colidx in range(self.dimension[1]-1):
                if self.table.item(rowidx, colidx) == None:
                    table_has_empty_item = True
                else:
                    item = self.table.item(rowidx, colidx).text()
                    if item == '' or item == 'nan' or item == None or item == ' ':
                        table_has_empty_item = True
                if table_has_empty_item:
                    break
        if table_has_empty_item:
            return False
        else:
            return True

    def check_lm_table_status(self):
        if self.table is None:
            return 'Empty'
        if self.dimension[0] <= 0 or self.dimension[1] <= 0:
            return 'Empty'

        empty_item_count = 0
        for rowidx in range(self.dimension[0]):
            item = self.table.item(rowidx, 2)
            if item == None:
                empty_item_count = empty_item_count + 1
            else:
                item_value = item.text()
                if item_value == '' or item_value == 'nan' \
                        or item_value == None or item_value == ' ':
                    empty_item_count = empty_item_count + 1

        if empty_item_count == 0:
            return 'Done'
        elif empty_item_count == self.dimension[0]:
            return 'Empty'
        else:
            return 'In-progress'

    def save_annot(self):
        foldername = QFileDialog.getExistingDirectory(
            self, 'Open Annotation Save Folder',
            options=QFileDialog.ShowDirsOnly | QFileDialog.DontResolveSymlinks)
        if len(foldername) == 0:
            return

        try:
            if self.im3 is not None and self.imidx >= 0:
                imagename = os.path.basename(self.imlist[self.imidx])
                imagename_list = imagename.split('.')
                name = imagename_list[0]
                if len(imagename_list) > 2:
                    for idx in range(1,len(imagename_list) - 1):
                        name = name + '.' + imagename_list[idx]
                filename = name + '.csv'
                self.save_annot_edit.setText(os.path.join(foldername, filename))
            else:
                self.save_annot_edit.setText(foldername)
        except Exception as e:
            print e
            self.save_annot_edit.setText('')
            QMessageBox.information(self, 'Info', 'Fail to load the annotation save folder')

        # test if there exists annoted files
        if len(self.imlist) > 0:
            filelist = [f for f in os.listdir(foldername) if f.endswith('.csv')]
            for imidx in range(len(self.imlist)):
                imagename = os.path.basename(self.imlist[imidx])
                imagename_list = imagename.split('.')
                name = imagename_list[0]
                if len(imagename_list) > 2:
                    for idx in range(1,len(imagename_list) - 1):
                        name = name + '.' + imagename_list[idx]
                csvfile = name + '.csv'
                if csvfile in filelist:
                    csvfilename = os.path.join(foldername, csvfile)
                    if self.load_csv_to_lmlist(csvfilename, imidx):
                        self.imlist_status[imidx] = 'Done'
                        self.set_imlist_color(imidx, 'Done')

    def open_annot(self):
        if not self.lm_table_created:
            QMessageBox.information(self, 'Info', 'Please create a template first.')
            return

        foldername = QFileDialog.getExistingDirectory(
            self, 'Open Annotation Folder',
            options=QFileDialog.ShowDirsOnly | QFileDialog.DontResolveSymlinks)
        if len(foldername) == 0:
            return

        self.pre_annoted_files_folder = foldername
        for imidx in range(len(self.imlist)):
            imagename = os.path.basename(self.imlist[imidx])
            imagename_list = imagename.split('.')
            name = imagename_list[0]
            if len(imagename_list) > 2:
                for idx in range(1, len(imagename_list) - 1):
                    name = name + '.' + imagename_list[idx]
            csvfile = name + '.csv'
            if self.imlist_status[imidx] == 'Empty':
                if self.load_csv_to_lmlist(csvfile, imidx):
                    self.imlist_status[imidx] = 'In-progress'
                    self.set_imlist_color(imidx, 'In-progress')

    def load_csv_to_lmlist(self, csvfile, imidx):
        if imidx < 0 or imidx >= len(self.imlist):
            return False

        if not os.path.exists(csvfile):
            return False

        data = pd.read_csv(csvfile)
        col_num = len(data.columns)
        row_num = len(data.index)
        if row_num != self.dimension[0] or col_num != self.dimension[1]:
            return False

        for rowidx in range(row_num):
            lm_name_table = self.table.item(rowidx, 1).text().replace('\r', '')
            lm_name_csv = str(data.iloc[rowidx, 1]).replace('\r', '')
            if lm_name_table != lm_name_csv:
                return False

        lm = {}
        for rowidx in range(row_num):
            lm_name = str(data.iloc[rowidx, 1])
            lm[lm_name] = {}
            lm[lm_name]['voxel_x'] = str(data.iloc[rowidx, 2])
            lm[lm_name]['voxel_y'] = str(data.iloc[rowidx, 3])
            lm[lm_name]['voxel_z'] = str(data.iloc[rowidx, 4])
            lm[lm_name]['x'] = str(data.iloc[rowidx, 5])
            lm[lm_name]['y'] = str(data.iloc[rowidx, 6])
            lm[lm_name]['z'] = str(data.iloc[rowidx, 7])

        self.lmlist[self.imlist[imidx]] = lm

        return True

    ## event handler ##
    def load_nondicom_clicked(self):
        # single image
        filename = QFileDialog.getOpenFileName(self, 'Open Image File',
                                               filter='Images (*.mhd *.mha *.hdr *.nii *.nii.gz)')
        if len(filename[0]) == 0:
            return

        self.initialize()
        self.im_type = 'Non-Dicom'

        self.load_set_single_image(filename[0])

        if len(self.imlist) == 0:
            return

        self.imlist_status = []
        self.imlist_status.append('Empty')

        # update save .csv path
        foldername = os.path.dirname(self.save_annot_edit.text())
        if len(foldername) > 0:
            imagename = os.path.basename(self.imlist[self.imidx])
            imagename_list = imagename.split('.')
            name = imagename_list[0]
            if len(imagename_list) > 2:
                for idx in range(1, len(imagename_list) - 1):
                    name = name + '.' + imagename_list[idx]
            filename = name + '.csv'
            self.save_annot_edit.setText(os.path.join(foldername, filename))

    def load_dicom_clicked(self):
        # single dicom folder
        folder = QFileDialog.getExistingDirectory(self,'Open Image Folder')

        if len(folder) <= 0:
            return

        self.initialize()
        self.im_type = 'Dicom'

        filename = folder
        try:
            dicom_series = [f for f in os.listdir(filename) if f.endswith('.dcm')]
            while(len(dicom_series) == 0):
                sub_folders = [f for f in os.listdir(filename) \
                               if os.path.isdir(os.path.join(filename, f))]
                if len(sub_folders) == 0:
                    QMessageBox.information(self, 'Error', 'Empty Folder: ' + filename)
                    return

                else:
                    filename = os.path.join(filename, sub_folders[0])
                    dicom_series = [f for f in os.listdir(filename) if f.endswith('.dcm')]
                self.im3, _ = cio.read_dicom_series(filename, dtype=np.float32)

        except Exception as e:
            print e
            QMessageBox.information(self, 'Error', 'Fail to load Dicom series from: ' + folder)
            return

        # reset
        self.imlist = [folder]
        self.imidx = 0
        self.update_listview()
        self.setWindowTitle(os.path.basename(folder) + ' - ' + self.titlename)

        # load image and display
        self.viewclient.add_image(self.im3, 'Img', self.wc, self.ww, 0, 0.5, True)

        self.imlist_status = []
        self.imlist_status.append('Empty')

    def load_image_list_clicked(self):
        # image list
        filename = QFileDialog.getOpenFileName(self, 'Open Image List',
                                               filter='Image List Files (*.txt)')
        if len(filename[0]) == 0:
            return

        self.im_type = 'Non-Dicom'

        self.initialize()
        self.imlist = self.read_image_list(filename[0])
        for imidx in range(len(self.imlist)):
            self.imlist_status.append('Empty')

        # update
        self.update_listview()

    def load_image_folder_clicked(self):
        folder = QFileDialog.getExistingDirectory(self,'Open Image Folder')

        if len(folder) <= 0:
            return

        filelist = [f for f in os.listdir(folder) if f.endswith('.mhd') \
                    or f.endswith('.mha') or f.endswith('.hdr') \
                    or f.endswith('.nii') or f.endswith('.nii.gz')]
        if len(filelist) == 0:
            return

        self.im_type = 'Non-Dicom'
        filelist.sort()

        self.initialize()
        for i in range(len(filelist)):
            self.imlist.append(os.path.join(folder, filelist[i]))
            self.imlist_status.append('Empty')

        # update
        self.update_listview()

    def load_dicom_folder_clicked(self):
        folder = QFileDialog.getExistingDirectory(self,'Open Image Folder')

        if len(folder) <= 0:
            return

        dicom_folder_list = [f for f in os.listdir(folder)]
        if len(dicom_folder_list) == 0:
            return

        self.im_type = 'Dicom'
        dicom_folder_list.sort()

        self.initialize()
        for i in range(len(dicom_folder_list)):
            self.imlist.append(os.path.join(folder, dicom_folder_list[i]))
            self.imlist_status.append('Empty')

        # update
        self.update_listview()

    def imlist_item_doubleclicked(self, idx):
        if len(self.imlist) == 1:
            imidx = 0
        else:
            data = self.imlist_model.data(idx)
            id = data.index(' ')
            imidx = int(data[:id])

        # check if info in previous table has been saved
        if self.lm_table_changed:
            if self.check_lm_table_status() == 'Done':
                save_lm_table = QMessageBox.question(self, 'Warning',
                                        "Save the changed Landmark table ?",
                                        QMessageBox.Yes | QMessageBox.No)

                if save_lm_table == QMessageBox.Yes:
                    self.save_annot_button_clicked()

        self.lm_table_changed = False

        # clear lm in previous image and viewer
        if self.imidx >= 0:
            self.clear_lm_table()
            self.clear_lm_viewer()

        filename = self.imlist[imidx]

        try:
            if self.im_type == 'Dicom':
                dicom_series = [f for f in os.listdir(filename) if f.endswith('.dcm')]
                while(len(dicom_series) == 0):
                    sub_folders = [f for f in os.listdir(filename) \
                                   if os.path.isdir(os.path.join(filename, f))]
                    if len(sub_folders) == 0:
                        QMessageBox.information(self, 'Error', 'Empty Folder: ' + filename)
                        return

                    else:
                        filename = os.path.join(filename, sub_folders[0])
                        dicom_series = [f for f in os.listdir(filename) if f.endswith('.dcm')]

                im3, _ = cio.read_dicom_series(filename, dtype=np.float32)
            else:
                im3 = cio.read_image(filename, dtype=np.float32)

        except Exception as e:
            print e
            QMessageBox.information(self, 'Error', 'Fail to load image: ' + filename)
            return

        self.im3 = im3
        self.imidx = imidx
        self.imlist_view.setCurrentIndex(idx)
        self.viewclient.add_image(self.im3, 'Img', self.wc, self.ww, 0, 0.5, True)
        self.setWindowTitle(os.path.basename(self.imlist[self.imidx]) + ' - ' + self.titlename)

        # update save .csv path
        foldername = os.path.dirname(self.save_annot_edit.text())
        if len(foldername) > 0:
            imagename = os.path.basename(self.imlist[self.imidx])
            imagename_list = imagename.split('.')
            name = imagename_list[0]
            if len(imagename_list) > 2:
                for idx in range(1, len(imagename_list) - 1):
                    name = name + '.' + imagename_list[idx]
            filename = name + '.csv'
            self.save_annot_edit.setText(os.path.join(foldername, filename))

        # update landmark table
        self.set_lm_table()

        # show landmarks on view3
        self.set_lm_viewer()

    def save_annot_button_clicked(self):

        if not self.check_lm_table_status() == 'Done':
            QMessageBox.warning(self, 'Warning', 'The landmark table is not finished')
            return

        filename = self.save_annot_edit.text()
        if len(filename) == 0 or os.path.isdir(filename):
            QMessageBox.warning(self, 'Warning', 'The saved path is invalid')
            return

        imagename = self.imlist[self.imidx]
        self.save_lm_list(imagename)
        self.save_lm_table(filename)
        self.imlist_status[self.imidx] = 'Done'
        self.set_imlist_color(self.imidx, 'Done')
        self.lm_table_changed = False

    def prevButtonClicked(self):
        rows = self.imlist_model.rowCount()
        if rows <= 0:
            return

        if self.imidx <= 0:
            return

        imidx = (self.imidx - 1) % rows
        idx = self.imlist_model.index(imidx, 0)
        self.imlist_item_doubleclicked(idx)

    def nextButtonClicked(self):
        rows = self.imlist_model.rowCount()
        if rows <= 0:
            return

        if self.imidx >= rows - 1:
            return

        imidx = (self.imidx + 1) % rows
        idx = self.imlist_model.index(imidx, 0)
        self.imlist_item_doubleclicked(idx)

    def display_lm_clicked(self):
        self.lm_text_visible = not self.lm_text_visible

        lms = self.viewclient.lms()
        for lm in lms:
            world = lms[lm]['coord']
            world=np.array(world, dtype=np.double)
            self.viewclient.marklm_cursor(world[0], world[1], world[2], lm, '', True, self.lm_text_visible)

    def save_lm_clicked(self):
        if self.lm_table_created:
            rowidx = self.table.currentRow()
            self.save_cursor(rowidx)

    def delete_lm_clicked(self):
        if not self.lm_table_created:
            return

        if self.imidx < 0:
            return

        rowidx = self.table.currentRow()
        if rowidx is -1:
            QMessageBox.warning(self, 'Warning', 'Please select a row to delete')
            return
        else:
            lmname = self.table.item(rowidx, 1).text()
            if lmname in self.viewclient.lms():
                self.viewclient.removelm(lmname)

            for index in range(6):
                self.table.setItem(rowidx, index + 2, QTableWidgetItem(''))

        self.lm_table_changed = True

        self.save_lm_list(self.imlist[self.imidx])

        status = self.check_lm_table_status()
        if status == 'Done' or status == 'In-progress':
            self.set_imlist_color(self.imidx, 'In-progress')
        else:
            self.set_imlist_color(self.imidx, 'Empty')

    def inexist_lm_clicked(self):
        if not self.lm_table_created:
            return

        if self.imidx < 0:
            return

        rowidx = self.table.currentRow()
        if self.table.item(rowidx, 1) == None:
            return

        lmname = self.table.item(rowidx, 1).text()
        if lmname in self.viewclient.lms():
            self.viewclient.removelm(lmname)

        # reset landmark value in table
        for index in range(6):
            self.table.setItem(rowidx, index + 2, QTableWidgetItem('-1'))

        self.lm_table_changed = True

        self.save_lm_list(self.imlist[self.imidx])

        status = self.check_lm_table_status()
        if status == 'Done' or status == 'In-progress':
            self.set_imlist_color(self.imidx, 'In-progress')
        else:
            self.set_imlist_color(self.imidx, 'Empty')

    def set_imlist_color(self, imidx, status):
        list_item = self.imlist_model.item(imidx, 0)
        UIH_BLUE = QColor(0, 72, 94)
        GRAY = QColor(128, 128, 128)
        WHITE = QColor(255, 255, 255)
        BLACK = QColor(0, 0, 0)
        if status == 'Done':
            list_item.setBackground(UIH_BLUE)
            list_item.setForeground(WHITE)
        elif status == 'In-progress':
            list_item.setBackground(GRAY)
            list_item.setForeground(WHITE)
        elif status == 'Empty':
            list_item.setBackground(WHITE)
            list_item.setForeground(BLACK)

    def create_template_table(self):
        # image list
        lm_names_file = QFileDialog.getOpenFileName(self, 'Open Image List',
                                               filter='Image List Files (*.txt)')
        if len(lm_names_file[0]) == 0:
            return

        self.lmname = readlines(lm_names_file[0])
        if len(self.lmname) == 0:
            return

        rowNumber = len(self.lmname)
        columnNumber = len(self.tabletitle)
        self.dimension = np.array([rowNumber, columnNumber])

        self.lmtable_box.removeWidget(self.table)
        self.table.deleteLater()
        self.table = LandMarkTable(self.dimension)

        # Change the table editable
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setHorizontalHeaderLabels(self.tabletitle)

        header = self.table.horizontalHeader()
        for i in range(self.dimension[1]):
            header.setSectionResizeMode(i, QHeaderView.ResizeToContents)

        self.table.itemDoubleClicked.connect(self.lm_table_item_clicked)
        self.lmtable_box.addWidget(self.table)
        self.table.clicked_button.connect(self.save_lm_clicked)
        self.table.itemselected.connect(self.goto_cursor)
        for rowidx in range(self.dimension[0]):
            lm_name = self.lmname[rowidx]
            lm_name.replace('\r', '')
            self.table.setItem(rowidx, 0, QTableWidgetItem(str(rowidx)))
            self.table.setItem(rowidx, 1, QTableWidgetItem(lm_name))

        self.lm_table_created = True

    def load_model_clicked(self):
        foldername = QFileDialog.getExistingDirectory(self, 'Open Detection Model Folder',
                                                      options=QFileDialog.ShowDirsOnly | QFileDialog.DontResolveSymlinks)
        if len(foldername) == 0:
            return

        try:
            self.detmodel = autodet_load_model(foldername)
            self.modelEdit.setText(foldername)
        except Exception as e:
            print e
            self.detmodel = {}
            self.modelEdit.setText('')
            QMessageBox.information(self, 'Info', 'Fail to load the detection model')

    def det_button_clicked(self):
        if self.im3 is None or self.imidx < 0:
            QMessageBox.information(self, 'Info', 'Please open an image')
            return

        if len(self.modelEdit.text()) == 0:
            QMessageBox.information(self, 'Info', 'Please open a model')
            return

        if not self.lm_table_created:
            QMessageBox.information(self, 'Info', 'Please create a template')
            return

        if self.detmodel == None:
            QMessageBox.information(self, 'Info', 'The detection model is invalid.')
            return

        # detection
        im3_copy = self.im3.deep_copy()
        _, lmlist, test_time = autodet_volume(im3_copy, self.detmodel)

        for lm_name in lmlist:
            world = [lmlist[lm_name]['x'], lmlist[lm_name]['y'], lmlist[lm_name]['z']]
            voxel = self.im3.world_to_voxel([float(world[0]), float(world[1]), float(world[2])])
            lmlist[lm_name]['voxel_x'] = int(voxel[0])
            lmlist[lm_name]['voxel_y'] = int(voxel[1])
            lmlist[lm_name]['voxel_z'] = int(voxel[2])
        self.lmlist[self.imlist[self.imidx]] = lmlist

        # update table
        self.set_lm_table()
        self.imlist_status[self.imidx] = 'In-progress'
        self.set_imlist_color(self.imidx, 'In-progress')
        self.lm_table_changed = True

    def save_cursor(self, rowidx):
        if not self.lm_table_created:
            return

        if self.imidx < 0:
            return

        if self.table.item(rowidx, 1) == None:
            QMessageBox.warning(self, 'Warning', 'Please define landmark name')
            return

        world = self.viewclient.get_cursor()
        voxel = self.viewclient.get_voxel('Img')

        world = np.round(world, 3)
        voxel = np.round(voxel, 0)

        for index in range(3):
            self.table.setItem(rowidx, index + 2, QTableWidgetItem(str(int(voxel[index]))))
            self.table.setItem(rowidx, index + 5, QTableWidgetItem(str(world[index])))

        self.save_lm_list(self.imlist[self.imidx])

        # if viewer has image
        lm_name = self.table.item(rowidx, 1).text()
        self.viewclient.marklm(lm_name, '', True, self.lm_text_visible)

        self.lm_table_changed = True

        status = self.check_lm_table_status()
        if status == 'Done' or status == 'In-progress':
            self.set_imlist_color(self.imidx, 'In-progress')
        else:
            self.set_imlist_color(self.imidx, 'Empty')

    def goto_cursor(self, rowidx):
        if rowidx < 0 or rowidx >= self.dimension[0]:
            return

        voxel = [0.0, 0.0, 0.0]
        world = [0.0, 0.0, 0.0]
        for index in range(3):
            item_w = self.table.item(rowidx, index + 5)
            if item_w == None:
                return
            world[index] = item_w.text()

        if world[0] == '' or world[0] == 'nan' or world[0] == ' ':
            return

        for index in range(3):
            item_v = self.table.item(rowidx, index + 2)
            if item_v is not None:
                voxel[index] = item_v.text()

        if voxel[0] == '-1.0':
            QMessageBox.warning(self, 'Warning', 'Landmark is not exist in image')
            return

        self.viewclient.goto(world)
        if self.table.item(rowidx,1) is not None:
            lm_name = self.table.item(rowidx, 1).text()
            self.viewclient.marklm(lm_name, '', True, self.lm_text_visible)

    def lm_table_item_clicked(self, Item=None):
        if Item == None:
            return
        rowidx = Item.row()

        self.goto_cursor(rowidx)

    def adjust_contrast(self):
        if self.imidx < 0:
            return

        contrast_plane = QDialog()

        self.alpha_box = QCheckBox('alpha')
        self.alpha_box.setChecked(True)
        self.alpha_box.stateChanged.connect(self.alphaClicked)

        self.alpha_bar = QSlider(Qt.Horizontal, self)
        self.alpha_bar.setSingleStep(1)
        self.alpha_bar.setPageStep(2)
        self.alpha_bar.setMinimum(0)
        self.alpha_bar.setMaximum(100)
        self.alpha_bar.setValue(25)
        self.alpha_bar.valueChanged.connect(self.alphaChanged)

        alpha_layout = QHBoxLayout()
        alpha_layout.addWidget(self.alpha_box)
        alpha_layout.addWidget(self.alpha_bar)

        wc_text = QLabel('wc:')
        wc_edit = QLineEdit(self)
        wc_edit.setText('{}'.format(self.wc))
        wc_edit.editingFinished.connect(self.wcEditingFinished)

        ww_text = QLabel('ww:')
        ww_edit = QLineEdit(self)
        ww_edit.setText('{}'.format(self.ww))
        ww_edit.editingFinished.connect(self.wwEditingFinished)

        win_layout = QHBoxLayout()
        win_layout.addWidget(wc_text)
        win_layout.addWidget(wc_edit)

        win_layout.addWidget(ww_text)
        win_layout.addWidget(ww_edit)

        contrast_layout = QVBoxLayout()
        #contrast_layout.addLayout(alpha_layout)
        contrast_layout.addLayout(win_layout)

        contrast_plane.setLayout(contrast_layout)
        contrast_plane.resize(300, 200)
        contrast_plane.exec_()

    def auto_contrast(self):
        if self.im3 is not None:
            if self.auto_ww is not None and self.auto_wc is not None:
                # use cached value if possible
                wc, ww = self.auto_wc, self.auto_ww
            else:
                # compute wc, ww
                minv, maxv = ctools.percentiles(self.im3, [0.001, 0.999])
                wc, ww = (minv + maxv) / 2.0, maxv - minv
                self.auto_wc, self.auto_ww = wc, ww

            self.wc, self.ww = int(wc), int(ww)
            self.viewclient.adjust_wcww('Img', wc, ww)

    def wcEditingFinished(self):

        edit = self.sender()
        try:
            self.wc = int(edit.text())

            if self.imidx >= 0:
                self.viewclient.adjust_wcww('Img', self.wc, self.ww)

        except:
            edit.setText('{}'.format(self.wc))
            QMessageBox.critical(self, 'Error', 'incorrect integer for wc')

    def wwEditingFinished(self):

        edit = self.sender()
        try:
            self.ww = int(edit.text())

            if self.imidx >= 0:
                self.viewclient.adjust_wcww('Img', self.wc, self.ww)

        except:
            edit.setText('{}'.format(self.ww))
            QMessageBox.critical(self, 'Error', 'incorrect integer for ww')

    def closeEvent(self, event):
        if not self.lm_table_created:
            event.accept()
            self.viewclient.close()
            return
        else:
            status = self.check_lm_table_status()
            if status != 'Empty' and self.lm_table_changed:
                reply = QMessageBox.question(self, 'Warning',
                                             "You have not saved landmarks, are you sure to quit?",
                                             QMessageBox.Yes | QMessageBox.No)
                if reply == QMessageBox.Yes:
                    event.accept()
                    self.viewclient.close()
                    return
                else:
                    event.ignore()
                    return
            else:
                event.accept()
                self.viewclient.close()
                return

    def alphaClicked(self):

        if self.alpha_box.isChecked():
            self.alpha_bar.setEnabled(True)
            value = self.alpha_bar.value()
            self.alphaChanged(value)
        else:
            self.alpha_bar.setEnabled(False)
            self.alphaChanged(0)

    def alphaChanged(self, value):

        self.alpha = value / 100.0

        if self.imidx >= 0:
            self.viewclient.adjust_opacity('Img', self.alpha)

class LandMarkTable(QTableWidget):

    clicked_button = pyqtSignal(int)
    itemselected = pyqtSignal(int)

    def __init__(self, dimension):
        super(LandMarkTable, self).__init__()
        self.setRowCount(dimension[0])
        self.setColumnCount(dimension[1])
        self.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.setSelectionBehavior(QAbstractItemView.SelectRows)

        for index in range(dimension[0]):
            self.AddButton = QPushButton('V',self)
            self.AddButton.clicked.connect(self.save_lm_button)
            self.setCellWidget(index,dimension[1]-1,self.AddButton)

        self.itemClicked.connect(self.item_selected)
    def save_lm_button(self):
        button = self.sender()
        index = self.indexAt(button.pos())
        self.clicked_button.emit(index.row())

    def item_selected(self):
        rowidx = self.currentRow()
        self.itemselected.emit(rowidx)


if __name__ == '__main__':
    import sys

    app = QApplication(sys.argv)
    viewer = ConsoleToolbar('Landmark Viewer Server-q')
    viewer.show()
    sys.exit(app.exec_())
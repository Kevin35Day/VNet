import argparse
import glob
import importlib
import logging
import os
import shutil
import time

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from md.detection3d.dataset.multi_detection_dataset import MultipleDetectionDataset
from md.detection3d.dataset.multi_detection_dataset import read_image_list
from md.detection3d.dataset.multi_detection_dataset import read_label_list
from md.mdpytorch.loss.focal_loss import FocalLoss
from md.detection3d.vdnet_helpers import LoadConfig
from md.mdpytorch.utils.train_tools import EpochConcateSampler
from md.utils.python.plotly_tools import plot_loss
from torch.autograd import Variable
from torch.backends import cudnn
from torch.utils.data import DataLoader


def LoadLatestCheckpoint(checkpoint_dir, net, optimizer):
  # Assume that all checkpoint files are saved in the names as
  # "ckpt_{0:%06d}.pth".format{epoch_index}
  checkpoint_file_list = glob.glob(os.path.join(checkpoint_dir, "ckpt_*.pth"))

  if not checkpoint_file_list:
    print "No checkpoint files are found. Start training from scratch."
    return 0

  # sort the file lists alphabetically
  checkpoint_file_list.sort()

  # pick the latest checkpoint
  latest_checkpoint_file = checkpoint_file_list[-1]

  ckpt = torch.load(latest_checkpoint_file)
  net.load_state_dict(ckpt['model_state_dict'])
  optimizer.load_state_dict(ckpt['optimizer_state_dict'])

  # return the index of the next batch.
  return ckpt['batch_index'] + 1


def SaveCheckpoint(checkpoint_dir, net, optimizer, epoch_index, batch_index):
  ckpt = {'epoch_index': epoch_index,
          'batch_index': batch_index,
          'model_state_dict': net.state_dict(),
          'optimizer_state_dict': optimizer.state_dict()}

  latest_checkpoint_file = os.path.join(checkpoint_dir,
                                        "ckpt_{0:06d}.pth".format(batch_index))
  torch.save(ckpt, latest_checkpoint_file)


def SetupLogger(log_file):
  logging_dir = os.path.dirname(log_file)
  if not os.path.isdir(logging_dir):
    os.makedirs(logging_dir)

  logger = logging.getLogger('vdnet')
  logger.setLevel(logging.DEBUG)
  formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

  # create console handler
  h1 = logging.StreamHandler()
  h1.setLevel(logging.DEBUG)
  h1.setFormatter(formatter)
  logger.addHandler(h1)

  # create file handler
  h2 = logging.FileHandler(log_file)
  h2.setLevel(logging.DEBUG)
  h2.setFormatter(formatter)
  logger.addHandler(h2)

  return logger

def ParseAndCheckArguments():
  parser = argparse.ArgumentParser()

  default_config = os.path.join(os.getcwd(), 'config',
                                'mi_aorta_detection_config.py')

  print "default config = {0}".format(default_config)

  parser.add_argument('--config', type=str, default = default_config,
                      help='Folder containing the detection training config file.')

  args = parser.parse_args()

  invalid_arguments = False
  if not args.config:
    print "Please specify the configuration file."
    invalid_arguments = True
  elif not os.path.isfile(args.config):
    print "The specified config: {0} does not exist!".format(args.config)
    invalid_arguments = True

  if invalid_arguments:
    raise ValueError("Invalid input arguments!")

  return args

def Train(config_file):
  cfg = LoadConfig(config_file)

  # convert to absolute path since cfg use relative path
  cfg.general.label_dir = os.path.join(cfg.general.root_dir, cfg.general.label_dir)
  assert os.path.isdir(cfg.general.label_dir)

  cfg.general.image_dir = os.path.join(cfg.general.root_dir, cfg.general.image_dir)
  assert os.path.isdir(cfg.general.image_dir)

  cfg.general.save_dir = os.path.join(cfg.general.root_dir, cfg.general.save_dir)
  if not os.path.isdir(cfg.general.save_dir):
    os.makedirs(cfg.general.save_dir)

  # copy config file
  shutil.copy(config_file, os.path.join(cfg.general.save_dir, "config.py"))

  # control randomness during training
  np.random.seed(cfg.general.seed)
  torch.manual_seed(cfg.general.seed)
  torch.cuda.manual_seed(cfg.general.seed)

  # clean up the existing folder if not resume training
  if not cfg.general.resume_epoch:
    shutil.rmtree(cfg.general.save_dir)

  # enable logging
  log_file = os.path.join(cfg.general.save_dir, 'logging', 'train_log.txt')
  logger = SetupLogger(log_file)

  # enable cudnn
  cudnn.benchmark = True
  if not torch.cuda.is_available():
    raise EnvironmentError('CUDA is not available! Please check nvidia driver!')

  # create dataset and dataloader
  label_list = read_label_list(cfg.general.label_dir,
                               cfg.general.label_list_files)
  image_list = read_image_list(cfg.general.label_dir,
                               cfg.general.image_list_file)

  run_regression = cfg.loss.regression.lamda > 0

  dataset = MultipleDetectionDataset(
    cfg.general.image_dir,
    image_list,
    label_list,
    cfg.dataset.voxel_spacing,
    cfg.dataset.cropping_size,
    cfg.dataset.sampling_size,
    cfg.dataset.positive_upper_bound,
    cfg.dataset.negative_lower_bound,
    cfg.dataset.num_pos_patches_per_image,
    cfg.dataset.neg_to_pos_patches_ratio,
    cfg.dataset.normalization.mean,
    cfg.dataset.normalization.stddev,
    cfg.dataset.normalization.clip,
    run_regression)

  sampler = EpochConcateSampler(dataset, cfg.train.num_epochs)

  dataloader = DataLoader(
    dataset,
    batch_size=cfg.train.batch_size,
    sampler=sampler,
    num_workers=cfg.train.num_threads,
    pin_memory=True,
    shuffle=False)

  # define network
  net_module = importlib.import_module('md.detection3d.network.' + cfg.net.name)
  net_file, _ = os.path.splitext(net_module.__file__)
  net_file += ".py"
  shutil.copy(net_file, os.path.join(cfg.general.save_dir, "net.py"))


  in_channels = 1
  num_classes = dataset.num_classes

  net = net_module.VNet(in_channels, num_classes, run_regression)
  net_module.ApplyKaimingInit(net)
  max_stride = net.max_stride()

  gpu_ids = range(cfg.general.num_gpus)
  net = nn.parallel.DataParallel(net, device_ids = gpu_ids)
  net = net.cuda()

  if (cfg.dataset.cropping_size[0] % max_stride != 0) \
          or (cfg.dataset.cropping_size[1] % max_stride != 0) \
          or (cfg.dataset.cropping_size[2] % max_stride != 0):
    raise ValueError('cropping size not divisible by max_stride')

  # create optimizer.
  optimizer = optim.Adam(net.parameters(), lr=cfg.train.lr, betas=cfg.train.betas)

  # load checkpoint if resume epoch = True
  checkpoint_dir = os.path.join(cfg.general.save_dir, 'checkpoints')
  if not os.path.isdir(checkpoint_dir):
    os.makedirs(checkpoint_dir)

  if cfg.general.resume_epoch:
    batch_start = LoadLatestCheckpoint(checkpoint_dir, net, optimizer)
  else:
    batch_start = 0

  # training buffer
  input_size = cfg.dataset.cropping_size
  dim_x = input_size[0]
  dim_y = input_size[1]
  dim_z = input_size[2]

  num_patches_per_image = cfg.dataset.num_pos_patches_per_image * (
    1 + cfg.dataset.neg_to_pos_patches_ratio)
  num_patches_per_batch = num_patches_per_image * cfg.train.batch_size
  num_input_channels = 1
  num_target_channels = 1
  num_output_channels = dataset.num_classes
  if (cfg.loss.regression.lamda > 0):
    num_target_channels = 4
    num_output_channels += 3 * (dataset.num_classes - 1)

  input = torch.FloatTensor(
    num_patches_per_batch,
    num_input_channels,
    dim_z,
    dim_y,
    dim_x)

  target = torch.FloatTensor(
    num_patches_per_batch,
    num_target_channels,
    dim_z,
    dim_y,
    dim_x)

  input = input.cuda()
  target = target.cuda()
  batch_idx = batch_start

  # define loss function
  if cfg.loss.classification.name == 'Focal':
    alpha = [None] * dataset.num_classes
    alpha[0] = 1 - cfg.loss.classification.focal_obj_alpha
    for i in range(1, num_classes):
      alpha[i] = cfg.loss.classification.focal_obj_alpha

    gamma = cfg.loss.classification.focal_gamma
    loss_func = FocalLoss(class_num=dataset.num_classes, alpha=alpha, gamma=gamma)
  else:
    raise ValueError('Unsupported loss function.')

  data_iter = iter(dataloader)
  for i in range(len(dataloader)):
    begin_t = time.time()
    crops, masks, _, _ = data_iter.next()
    crops = crops.view(-1, num_input_channels, dim_z, dim_y, dim_x)
    masks = masks.view(-1, num_target_channels, dim_z, dim_y, dim_x)

    input.resize_(crops.size())
    input.copy_(crops)

    target.resize_(masks.size())
    target.copy_(masks)

    # clear previous gradients
    optimizer.zero_grad()

    # network forward
    input_v = Variable(input)
    predictions = net(input_v)

    # both 'predictions' and 'targets' are of shape
    # [batch * patch, channels, dim_z, dim_y, dim_x]
    predictions = predictions.permute(0, 2, 3, 4, 1).contiguous()
    target = target.permute(0, 2, 3, 4, 1).contiguous()

    # reshape 'predictions' and 'targets' to [samples, channels]
    predictions = predictions.view(-1, num_output_channels)
    target = target.view(-1, num_target_channels)

    # only select those samples whose label is not -1.
    selected_sample_indices = torch.nonzero(target[:,0] != -1).squeeze()
    target = torch.index_select(target, 0, selected_sample_indices)
    selected_sample_indices_v = Variable(selected_sample_indices, requires_grad=False)
    predictions = torch.index_select(predictions, 0, selected_sample_indices_v)

    # compute training loss (ignore the regression loss)
    target_v = Variable(target, requires_grad=False)
    train_loss = loss_func(predictions[:, 0:num_classes], target_v[:, 0])

    _, predicted_labels = torch.max(predictions[:,0:num_classes].data, 1)
    ground_truth_labels = target_v[:,0].data
    train_error = float(torch.sum(predicted_labels.int() != ground_truth_labels.int())) \
                  / predicted_labels.size()[0]

    # backward propagation
    train_loss.backward()

    # update weights
    optimizer.step()

    batch_duration = time.time() - begin_t
    sample_duration = batch_duration * 1.0 / cfg.train.batch_size

    # approximate epoch_idx because len(dataset) is not necessarily divisible
    # by cfg.train.batch_size.
    epoch_idx = batch_idx * cfg.train.batch_size // len(dataset)
    # print loss per batch
    if cfg.loss.classification.name == 'Focal':
      msg = 'epoch: {}, batch: {}, floss: {:.4f}, error: {:.4f}, time: {:.4f} s/vol'
      msg = msg.format(epoch_idx, batch_idx, train_loss.data[0],
                       train_error, sample_duration)
    logger.info(msg)

    if batch_idx % cfg.train.plot_snapshot == 0:
      if cfg.loss.classification.name == 'Focal':
        floss_plot_file = os.path.join(cfg.general.save_dir, 'floss.html')
        plot_loss(log_file, floss_plot_file, name='floss', display='Focal loss')

    if epoch_idx % cfg.train.save_epochs == 0:
      SaveCheckpoint(checkpoint_dir, net, optimizer, epoch_idx, batch_idx)


    batch_idx += 1


if __name__ == '__main__':
    args = ParseAndCheckArguments()
    Train(args.config)



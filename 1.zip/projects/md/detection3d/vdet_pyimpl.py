# python implementation of vnet segmentation

import os, glob
import ConfigParser
import torch
import torch.nn as nn
from torch.autograd import Variable
import md.image3d.python.image3d_tools as imtools
from md.image3d.python.image3d import Image3d
from md.mdpytorch.utils.tensor_tools import ToTensor, ToImage
import time
import numpy as np
import importlib, sys
from md.detection3d.vdnet_helpers import LoadModel, LoadConfig
import md.image3d.python.image3d_io as cio


def last_checkpoint(chk_root):

    last_epoch = -1
    last_epoch_name = ''
    chk_folders = os.path.join(chk_root, 'ckpt_*')
    for folder in glob.glob(chk_folders):
        folder_name = os.path.basename(folder)
        epoch = int(folder_name[5:11]) # default name: ckpt_XXXXXX.pth
        if epoch > last_epoch:
            last_epoch = epoch
            last_epoch_name = folder_name

    if last_epoch == -1:
        raise OSError('No checkpoint folder found!')

    return os.path.join(chk_root, last_epoch_name)


def load_net_module(net_file):

    dirname = os.path.dirname(net_file)
    basename = os.path.basename(net_file)
    modulename, _ = os.path.splitext(basename)

    need_reload = modulename in sys.modules

    os.sys.path.append(dirname)
    lib = importlib.import_module(modulename)
    if need_reload:
        reload(lib)
    del os.sys.path[-1]

    return lib


def load_model(model_dir, resolution, gpu_id):

    resolution_dir = os.path.join(model_dir, resolution)

    if not os.path.isdir(resolution_dir):
        raise ValueError('resolution dir not found: {}'.format(resolution_dir))

    checkpoint_dir = last_checkpoint(os.path.join(resolution_dir, 'checkpoints'))
    param_file = os.path.join(checkpoint_dir, 'params.pth')
    net_file = os.path.join(checkpoint_dir, 'net.py')

    if not os.path.isfile(param_file):
        raise ValueError('param file not found: {}'.format(param_file))

    if not os.path.isfile(net_file):
        raise ValueError('net file not found: {}'.format(net_file))

    # load network parameters
    state = torch.load(param_file)
    spacing = np.array(state['spacing'], dtype=np.double)
    assert spacing.ndim == 2, 'multi-scale spacing must be 2-dimensional'
    scales = len(spacing)

    crop_normalizer = None
    if 'crop_normalizer' in state:
        crop_normalizer = state['crop_normalizer']

    # load network structure
    net_module = load_net_module(net_file)
    net = net_module.VNet(scales)
    max_stride = net.max_stride()
    net = nn.parallel.DataParallel(net, device_ids=[gpu_id])
    net = net.cuda()
    net.load_state_dict(state['state_dict'])
    net.eval()

    return {'net': net,
            'spacing': spacing,
            'max_stride': max_stride,
            'crop_normalizer': crop_normalizer}

def load_model_det(model_dir, gpu_id):
    if not os.path.isdir(model_dir):
        raise ValueError('model dir not found: {}'.format(model_dir))

    param_file = last_checkpoint(os.path.join(model_dir, 'checkpoints'))
    if not os.path.isfile(param_file):
        raise ValueError('param file not found: {}'.format(param_file))

    net_file = os.path.join(model_dir, 'net.py')
    if not os.path.isfile(net_file):
        raise ValueError('net file not found: {}'.format(net_file))

    config_file = os.path.join(model_dir, "config.py")
    if not os.path.isfile(config_file):
        raise ValueError('config file not found: {}'.format(config_file))


    # load config file
    cfg = LoadConfig(config_file)

    # load network structure
    model = LoadModel(net_file)

    # load network parameters
    state = torch.load(param_file)

    in_channels = 1
    num_landmarks = len(cfg.general.label_list_files)
    run_regression = cfg.loss.regression.lamda > 0
    num_classes = num_landmarks + 1
    net = model.VNet(in_channels, num_classes, run_regression)
    max_stride = net.max_stride()
    gpu_ids = range(cfg.general.num_gpus)
    net = nn.parallel.DataParallel(net, device_ids=gpu_ids)
    net = net.cuda()
    net.load_state_dict(state['model_state_dict'])
    net.eval()



    return {'net': net,
            'max_stride': max_stride,
            'config': cfg}


def autoseg_load_model(folder, gpu_id=0):

    model = {}
    param_file = os.path.join(folder, 'params.ini')

    conf = ConfigParser.ConfigParser()
    if not conf.read(param_file):
        raise OSError('{} does not exist!'.format(param_file))

    padmm_str = conf.get('General', 'pad_mm')
    if ',' not in padmm_str:
        padmm = float(padmm_str)
        model['pad_mm'] = [padmm, padmm, padmm]
    else:
        model['pad_mm'] = [float(i) for i in padmm_str.split(',')]
        assert len(model['pad_mm']) == 3

    maxsize_str = conf.get('General', 'maxsize')
    maxsize = [float(i) for i in maxsize_str.split(',')]

    if len(maxsize) != 3:
        return {}

    model['maxsize'] = maxsize
    model['coarse'] = load_model(folder, 'coarse', gpu_id)
    model['fine'] = load_model(folder, 'fine', gpu_id)

    return model

def autodet_load_model(folder, gpu_id=0):

    model = load_model_det(folder, gpu_id)

    return model

def vnet_seg(image, prev_pred, model, pad_mm, maxsize):

    net = model['net']
    max_stride = model['max_stride']

    spacings = model['spacing']
    assert isinstance(spacings, np.ndarray) and spacings.ndim == 2 and len(spacings) >= 1
    assert len(spacings) == 1, 'multi-spacing no longer supported'
    spacing = spacings[0]

    if prev_pred is None:
        assert len(spacings) == 1, 'coarse resolution should always use single-scale'
        iso_image = imtools.resample_volume_nn_with_padding_rai(image, spacing, max_stride)
        iso_frame = iso_image.frame().deep_copy()
    else:
        minbox, maxbox = imtools.bounding_box_voxel(prev_pred, 1, 1)
        # if no segmentation, no need to refine
        if minbox is None or maxbox is None:
            return prev_pred

        # box pad mms in case coarse is not accurate
        box_pad = pad_mm
        minbox_world = prev_pred.voxel_to_world(minbox)
        maxbox_world = prev_pred.voxel_to_world(maxbox)
        minbox_world -= box_pad
        maxbox_world += box_pad

        iso_frame = prev_pred.frame().deep_copy()
        iso_frame.set_origin(minbox_world)
        iso_frame.set_spacing(spacing)

        box_size = np.round((maxbox_world - minbox_world) / spacing).astype(np.int32)
        iso_image = imtools.resample_nn_with_padding(image, iso_frame, box_size, max_stride)


    # check whether crop is beyond maximum crop size
    if maxsize[0] > 0 and maxsize[1] > 0 and maxsize[2] > 0:
        iso_imsize = iso_image.size()
        # if something is wrong (too big), output an empty image
        if iso_imsize[0] > maxsize[0] and iso_imsize[1] > maxsize[1] and iso_imsize[2] > maxsize[2]:
            pred = imtools.create_image3d_like(iso_image, fill_value=0)
            print('Case skiped. Iso_image size exceeds max size!')
            return pred


    if model['crop_normalizer'] is not None:
        model['crop_normalizer'](iso_image)

    # convert to tensor
    iso_image = ToTensor()(iso_image).unsqueeze(0)
    iso_image = iso_image.cuda()
    iso_image_v = Variable(iso_image, volatile=True)

    pred = net(iso_image_v)
    _, pred = pred.max(1)
    pred = pred.short()

    pred = ToImage()(pred[0].data)
    pred.set_frame(iso_frame)

    imtools.pick_largest_component(pred)

    return pred


def seg_volume(image, coarse_model, fine_model, pad_mm, maxsize):

    pred = vnet_seg(image, None, coarse_model, pad_mm, maxsize)
    if 'net' in fine_model:
        pred = vnet_seg(image, pred, fine_model, pad_mm, maxsize)

    return pred


def autoseg_volume(image, model):

    assert isinstance(image, Image3d)

    coarse_model = model['coarse']
    fine_model = model['fine']
    pad_mm = model['pad_mm']
    maxsize = model['maxsize']

    if image.pixel_type() != np.float32:
        image = image.deep_copy()
        image.cast(np.float32)

    begin = time.time()
    # segmentation
    pred = seg_volume(image, coarse_model, fine_model, pad_mm, maxsize)

    # compute organ localization and size for visualization
    minb, maxb = imtools.bounding_box_voxel(pred, 1, 1)
    if minb is None or maxb is None:
        min_coord, max_coord = image.world_box()
        box_size = max_coord - min_coord
        box_center = image.center()
    else:
        spacing = pred.spacing()
        box_size = (maxb - minb) * spacing
        box_center = (maxb + minb) / 2.0
        box_center = pred.voxel_to_world(box_center)

    # resample mask back to original image space
    pred = imtools.resample_mask_as_ref(pred, 1, 1, image)
    test_time = time.time() - begin

    return pred, box_center, box_size, test_time

def autodet_volume(image, model):

    assert isinstance(image, Image3d)
    assert image.pixel_type() == np.float32

    net = model['net']
    cfg = model['config']
    max_stride = model['max_stride']

    begin = time.time()
    # first, normalize and clip the voxel image intensities to [-1, 1].
    imtools.intensity_normalize(image,
                               cfg.dataset.normalization.mean,
                               cfg.dataset.normalization.stddev,
                               cfg.dataset.normalization.clip)

    image_spacing = image.spacing()
    padding_size = [None] * 3
    for i in range(3):
      padding_size[i] = (cfg.dataset.cropping_size[i] - cfg.dataset.sampling_size[i]) / 2

    # second, resample and pad the volume to meet the requirement of multiple of max stride.
    image = imtools.resample_volume_nn_with_extra_padding_rai(
      image, cfg.dataset.voxel_spacing, padding_size, max_stride)

    processing_time = time.time() - begin

    begin = time.time()
    iso_frame = image.frame().deep_copy()
    # iso_image: [batch_num=1 , channel_num=1, dim_z, dim_y, dim_x]
    iso_image = ToTensor()(image).unsqueeze(0)
    iso_image = iso_image.cuda()
    iso_image_v = Variable(iso_image, volatile=True)

    # pred: [batch_num=1, channel_num=num_classes, dim_z, dim_y, dim_x]
    pred = net(iso_image_v)
    pred = ToImage()(pred[0].data)
    prediction_time = time.time() - begin

    begin = time.time()
    output_folder = "/home/qinliu/work/test"
    image_base = "testimage"

    num_landmarks = len(cfg.general.label_list_files)
    num_classes = num_landmarks + 1

    # initialize landmark detection results.
    landmark_results = {}
    for i in range(num_landmarks):
        key = cfg.general.label_list_files[i][:-4]
        landmark_results[key] = {}
        landmark_results[key]['name'] = []
        landmark_results[key]['x'] = []
        landmark_results[key]['y'] = []
        landmark_results[key]['z'] = []

    run_regression = cfg.loss.regression.lamda > 0
    for i in range(1, num_classes):
      prob_map = pred[i]
      prob_map.set_frame(iso_frame)

      # crop out the padded areas and save images for visualization and debugging
      voxel_sp = np.round(padding_size).astype(np.int32)
      voxel_ep = np.round(prob_map.size() - padding_size).astype(np.int32)
      cropped_prob_map = imtools.crop(prob_map, voxel_sp, voxel_ep)
      prob_path = os.path.join(output_folder,
                               '{0}_probmap_ldmrk_{1:02d}.mhd'.format(image_base, i))
      #cio.write_image(cropped_prob_map, prob_path)

      voxel_sp = np.round(padding_size).astype(np.int32)
      voxel_ep = np.round(image.size() - padding_size).astype(np.int32)
      cropped_image = imtools.crop(image, voxel_sp, voxel_ep)
      imag_path = os.path.join(output_folder,
                               '{0}_padded.mhd'.format(image_base))
      #cio.write_image(cropped_image, imag_path)

      cropped_prob_frame = cropped_prob_map.frame().deep_copy()
      # threshold the probability map to get the binary mask
      prob_threshold = 0.5
      cropped_prob_data = cropped_prob_map.to_numpy()
      cropped_mask_data = np.zeros_like(cropped_prob_data, dtype=np.int16)
      cropped_mask_data[cropped_prob_data >= prob_threshold] = 1
      cropped_mask_data[cropped_prob_data < prob_threshold] = 0

      # pick the largest connected component
      cropped_mask = Image3d()
      cropped_mask.from_numpy(cropped_mask_data)
      cropped_mask.set_frame(cropped_prob_frame)
      imtools.pick_largest_component(cropped_mask)

      # only keep probability of the largest connected component
      cropped_mask_data = cropped_mask.to_numpy()
      masked_prob_data = np.multiply(cropped_mask_data.astype(np.float), cropped_prob_data)

      # compute the weighted mass center of the probability map
      masked_prob_map = Image3d()
      masked_prob_map.from_numpy(masked_prob_data)
      masked_prob_map.set_frame(cropped_prob_frame)
      voxel_coordinate = imtools.weighted_mass_voxel_center(masked_prob_map, prob_threshold, 1.0)

      if run_regression:
        reg_dx_map = pred[num_classes + (i - 1) * 3 + 0]
        reg_dx_map.set_frame(iso_frame)
        reg_dy_map = pred[num_classes + (i - 1) * 3 + 1]
        reg_dy_map.set_frame(iso_frame)
        reg_dz_map = pred[num_classes + (i - 1) * 3 + 2]
        reg_dz_map.set_frame(iso_frame)

        # crop out the padded areas and save images for visualization and debuging
        cropped_reg_dx_map = imtools.crop(reg_dx_map, voxel_sp, voxel_ep)
        reg_dx_path = os.path.join(output_folder,
                                 '{0}_probmap_ldmrk_{1:02d}_dx.mhd'.format(image_base, i))
        #cio.write_image(cropped_reg_dx_map, reg_dx_path)

        cropped_reg_dy_map = imtools.crop(reg_dy_map, voxel_sp, voxel_ep)
        reg_dy_path = os.path.join(output_folder,
                                 '{0}_probmap_ldmrk_{1:02d}_dy.mhd'.format(image_base, i))
        #cio.write_image(cropped_reg_dy_map, reg_dy_path)

        cropped_reg_dz_map = imtools.crop(reg_dz_map, voxel_sp, voxel_ep)
        reg_dz_path = os.path.join(output_folder,
                                 '{0}_probmap_ldmrk_{1:02d}_dz.mhd'.format(image_base, i))
        #cio.write_image(cropped_reg_dz_map, reg_dz_path)

        # only keep regression value of the largest connected component
        cropped_reg_dx_data = cropped_reg_dx_map.to_numpy()
        masked_reg_dx_data = np.multiply(cropped_mask_data.astype(np.float), cropped_reg_dx_data)


        cropped_reg_dy_data = cropped_reg_dy_map.to_numpy()
        masked_reg_dy_data = np.multiply(cropped_mask_data.astype(np.float), cropped_reg_dy_data)

        cropped_reg_dz_data = cropped_reg_dy_map.to_numpy()
        masked_reg_dz_data = np.multiply(cropped_mask_data.astype(np.float), cropped_reg_dz_data)

        prob_sum = masked_prob_data.sum()
        world_coordinate_dx = np.sum(np.multiply(masked_prob_data, cropped_reg_dx_data)) / prob_sum
        world_coordinate_dy = np.sum(np.multiply(masked_prob_data, cropped_reg_dy_data)) / prob_sum
        world_coordinate_dz = np.sum(np.multiply(masked_prob_data, cropped_reg_dz_data)) / prob_sum

        pos_bound = cfg.dataset.positive_upper_bound
        world_coordinate_dx *= (pos_bound * cfg.dataset.voxel_spacing[0])
        world_coordinate_dy *= (pos_bound * cfg.dataset.voxel_spacing[1])
        world_coordinate_dz *= (pos_bound * cfg.dataset.voxel_spacing[2])

        # debug code
        print "diff: ", pos_bound, world_coordinate_dx, world_coordinate_dy, world_coordinate_dz

      if voxel_coordinate is not None:
        world_coordinate = masked_prob_map.voxel_to_world(voxel_coordinate)
        if run_regression:
          world_coordinate[0] -= world_coordinate_dx
          world_coordinate[1] -= world_coordinate_dy
          world_coordinate[2] -= world_coordinate_dz

        print "world coordinate of landmark {0} is:[{1},{2},{3}]".format(
          i, world_coordinate[0], world_coordinate[1], world_coordinate[2])

        landmark_name = cfg.general.label_list_files[i-1]
        landmark_name = landmark_name[:-4]
        key = landmark_name
        landmark_results[key]['name'] = landmark_name
        landmark_results[key]['x'] = world_coordinate[0]
        landmark_results[key]['y'] = world_coordinate[1]
        landmark_results[key]['z'] = world_coordinate[2]

    saving_time = time.time() - begin
    print 'processing: {:.2f} s, prediction: {:.2f} s,' \
          ' saving: {:.2f} s'.format(processing_time, prediction_time, saving_time)

    return pred, landmark_results, prediction_time


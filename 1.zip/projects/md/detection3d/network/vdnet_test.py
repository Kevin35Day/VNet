import torch
from md.detection3d.network import vdnet

kMega = 1e6

def TestVdNetOutputChannels(batch_size, num_classes, use_regression):
  assert num_classes > 1

  in_channels = 1
  dim_x = 48
  dim_y = 48
  dim_z = 48

  model = vdnet.VNet(in_channels, num_classes, use_regression)
  print('Total params: %.2fM' % (sum(p.numel() for p in model.parameters()) / kMega))

  inputs = torch.rand([batch_size, in_channels, dim_z, dim_y, dim_x])
  inputs = torch.autograd.Variable(inputs)

  outputs = model(inputs)
  print "outputs size = {0}".format(outputs.size())

  assert outputs.size()[0] == batch_size

  if use_regression:
    assert outputs.size()[1] == num_classes + (num_classes - 1) * 3
  else:
    assert outputs.size()[1] == num_classes

  assert outputs.size()[2] == dim_z
  assert outputs.size()[3] == dim_y
  assert outputs.size()[4] == dim_x


if __name__ == '__main__':
  TestVdNetOutputChannels(3, 2, True)

  TestVdNetOutputChannels(3, 2, False)

  TestVdNetOutputChannels(3, 5, True)

  TestVdNetOutputChannels(3, 5, False)
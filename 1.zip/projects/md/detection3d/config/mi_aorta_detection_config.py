from easydict import EasyDict as edict

__C = edict()
cfg = __C

# general parameters
__C.general = {}
__C.general.root_dir = '/mnt/disk/MI_project/MI_Aorta_mhd'
__C.general.image_dir = 'data/res_4'
__C.general.label_dir = 'label/training_set'
__C.general.image_list_file = 'filenames.csv'
__C.general.label_list_files = [
    'ascending_aorta_left_heart_chamber.csv',
    'aortic_arch_upward_bifurcation.csv',
    'descending_aorta_hilus_bronchus.csv',
    'descending_aorta_diaphragm.csv',
    'descending_aorta_renal_artery.csv',
    'descending_aorta_bifurcation.csv'] # Each landmark is saved as a separate file.

__C.general.save_dir = 'model_0110_2018'
__C.general.resume_epoch = True
__C.general.num_gpus = 1
__C.general.seed = 0

# dataset parameters
__C.dataset = {}
__C.dataset.voxel_spacing = [4, 4, 4]      # mm
__C.dataset.cropping_size = [48, 48, 48]   # voxel
__C.dataset.sampling_size = [6, 6, 6]      # voxel

# sampling method
__C.dataset.neg_to_pos_patches_ratio = 5
__C.dataset.num_pos_patches_per_image = 2
__C.dataset.positive_upper_bound = 3    # voxel
__C.dataset.negative_lower_bound = 6    # voxel

# data augmentation options
__C.dataset.normalization = {}
__C.dataset.normalization.mean = 50
__C.dataset.normalization.stddev = 250
__C.dataset.normalization.clip = True


# loss
__C.loss = {}
__C.loss.classification = {}
__C.loss.classification.name = 'Focal'          # 'Dice', or 'Focal'
__C.loss.classification.focal_obj_alpha = 0.75  # class balancing weight for focal loss
__C.loss.classification.focal_gamma = 2         # gamma in pow(1-p,gamma) for focal loss
__C.loss.regression = {}
__C.loss.regression.lamda = 0                   # lambda = 0 will turn off position regression.

# net
__C.net = {}
__C.net.name = 'vdnet'

# training parameters
__C.train = {}
__C.train.epochs = 20001
__C.train.batch_size = 6
__C.train.num_threads = 8
__C.train.lr = 1e-4
__C.train.betas = (0.9, 0.999)
__C.train.plot_snapshot = 100
__C.train.num_epochs = 2000
__C.train.save_epochs = 50
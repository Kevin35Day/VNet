# frequently used classes
from image3d.python.image3d import Image3d
from image3d.python.frame3d import Frame3d


# frequently used modules
import image3d.python.image3d_io as image3d_io
import image3d.python.image3d_tools as image3d_tools
import image3d.python.image3d_morph as image3d_morph
import image3d.python.image3d_filter as image3d_filter


# frequently used functions
from image3d.python.image3d_io import \
    read_image, write_image, read_frame_and_size, \
    read_dicom_series, get_dicom_series, write_dicom_series, read_dicom_rt_contours


# viewers
def open_segviewer(gpu_id=0):
    import os
    import subprocess
    server_file = os.path.join(os.path.dirname(__file__), 'segmentation3d', 'viewer', 'segviewer.py')
    subprocess.Popen(['python', server_file, '{}'.format(gpu_id)])

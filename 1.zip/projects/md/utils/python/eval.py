"""
python wrapper for image3d_eval library

"""

import ctypes
import _ctypes
from find_dll import find_dll
import platform
import os
from md.image3d.python.image3d import Image3d

# dynamic library
lib = None

# function pointer dictionary
fun_dict = {}


def __get_library_path():

    dll_file = find_dll('pyeval')
    if dll_file is None:
        raise OSError('dll not found')
    return dll_file


def __load_c_functions():

    global lib, fun_dict

    lib = ctypes.cdll.LoadLibrary(__get_library_path())

    lib.image3d_cal_dsc.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int32]
    lib.image3d_cal_dsc.restype = ctypes.c_double
    fun_dict['image3d_cal_dsc'] = lib.image3d_cal_dsc


def unload():

    global lib, fun_dict

    try:
        while lib is not None:
            if platform.system() == 'Windows':
                _ctypes.FreeLibrary(lib._handle)
            else:
                _ctypes.dlclose(lib._handle)
    except:
        lib = None
        fun_dict = {}


def load():

    unload()
    __load_c_functions()


# load dynamic library and function pointers
load()


def load_c_functions_if_necesary():

    if len(fun_dict) == 0:
        print '[info] pyeval dll reloaded'
        __load_c_functions()


def call_func(func_name, *args):

    load_c_functions_if_necesary()

    if len(args) == 0:
        return fun_dict[func_name]()
    else:
        return fun_dict[func_name](*args)


def cal_dsc(im1, im2, label):
    """
    compute dsc between two masks
    :param im1: seg image 1
    :param im2: seg image 2
    :param label: target label
    :return: dsc score
    """
    assert isinstance(im1, Image3d) and isinstance(im2, Image3d)
    label = ctypes.c_int32(label)

    dsc = call_func('image3d_cal_dsc', im1.ptr, im2.ptr, label)
    return dsc

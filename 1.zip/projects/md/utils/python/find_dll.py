import os
import platform


def find_lib_folder():

    filepath = os.path.realpath(__file__)
    rootdir = os.path.abspath(os.sep)

    while filepath != rootdir and os.path.basename(filepath) != 'md':
        filepath = os.path.dirname(filepath)

    if filepath != rootdir:
        return os.path.join(filepath, 'lib', 'Release')
    else:
        return None


def find_dll(dll_name, search_folders=None):

    if platform.system() == 'Linux':
        dll_fullname = 'lib' + dll_name + '.so'
    elif platform.system() == 'Darwin':
        dll_fullname = 'lib' + dll_name + '.dylib'
    elif platform.system() == 'Windows':
        dll_fullname = dll_name + '.dll'
    else:
        raise OSError('Unknown OS for searching dll')

    if search_folders is None:
        search_folders = [find_lib_folder()]

    if search_folders is None:
        return None

    for folder in search_folders:
        dll_file = os.path.join(folder, dll_fullname)
        if os.path.isfile(dll_file):
            return dll_file

    return None

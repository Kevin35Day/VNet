#ifndef STRING_UTILS_H
#define STRING_UTILS_H

#include <vector>
#include <string>
#include <cstring>
#include <sstream>

namespace medvision {

template <typename T>
std::vector<T> split_numbers(const char* str, char split=',')
{
    std::vector<T> numbers;
    std::stringstream ss;

    int sp = 0;
    T val = T();

    for(int i = 0; i < strlen(str); ++i) {
        if(str[i] == split) {
            if(i > sp) {
                std::string token(str + sp, i - sp);
                ss.str(token);
                ss.seekg(0, ss.beg);
                ss >> val;
                numbers.push_back(val);
            }
            sp = i + 1;
        }
    }

    if(sp < strlen(str)) {
        ss.str(std::string(str + sp));
        ss.seekg(0, ss.beg);
        ss >> val;
        numbers.push_back(val);
    }

    return numbers;
}


}

#endif

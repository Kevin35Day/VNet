#ifndef TEMPLATE_MACROS_H
#define TEMPLATE_MACROS_H

#include <stdexcept>

#define ptypecall_1(func, ptype, ...)                                         \
do {                                                                          \
    switch(ptype) {                                                           \
    case PT_UCHAR:    func<unsigned char>(__VA_ARGS__); break;					  \
    case PT_CHAR:     func<char>(__VA_ARGS__); break;							  \
    case PT_USHORT:   func<unsigned short>(__VA_ARGS__); break;				  \
    case PT_SHORT:    func<short>(__VA_ARGS__); break;							  \
    case PT_UINT:     func<unsigned int>(__VA_ARGS__); break;					  \
    case PT_INT:      func<int>(__VA_ARGS__); break;							  \
    case PT_ULONG:    func<unsigned long>(__VA_ARGS__); break;					  \
    case PT_LONG:     func<long>(__VA_ARGS__); break;							  \
    case PT_FLOAT:    func<float>(__VA_ARGS__); break;							  \
    case PT_DOUBLE:   func<double>(__VA_ARGS__); break;						  \
    }                                                                         \
} while(0)


#define ptypeassign_1(func, ptype, ret, ...)                                      \
do {                                                                              \
    switch(ptype) {                                                               \
    case PT_UCHAR:    ret = func<unsigned char>(__VA_ARGS__); break;				  \
    case PT_CHAR:     ret = func<char>(__VA_ARGS__); break;						  \
    case PT_USHORT:   ret = func<unsigned short>(__VA_ARGS__); break;				  \
    case PT_SHORT:    ret = func<short>(__VA_ARGS__); break;						  \
    case PT_UINT:     ret = func<unsigned int>(__VA_ARGS__); break;				  \
    case PT_INT:      ret = func<int>(__VA_ARGS__); break;							  \
    case PT_ULONG:    ret = func<unsigned long>(__VA_ARGS__); break;				  \
    case PT_LONG:     ret = func<long>(__VA_ARGS__); break;						  \
    case PT_FLOAT:    ret = func<float>(__VA_ARGS__); break;						  \
    case PT_DOUBLE:   ret = func<double>(__VA_ARGS__); break;						  \
    }                                                                             \
} while(0)



#define ptypecall_2(func, ptype1, ptype2, ...)                                     \
do {                                                                               \
    switch(ptype1) {                                                               \
    case PT_UCHAR:																	   \
        switch(ptype2) {                                                           \
        case PT_UCHAR:    func<unsigned char, unsigned char>(__VA_ARGS__); break;	   \
        case PT_CHAR:     func<unsigned char, char>(__VA_ARGS__); break;              \
        case PT_USHORT:   func<unsigned char, unsigned short>(__VA_ARGS__); break;    \
        case PT_SHORT:    func<unsigned char, short>(__VA_ARGS__); break;             \
        case PT_UINT:     func<unsigned char, unsigned int>(__VA_ARGS__); break;      \
        case PT_INT:      func<unsigned char, int>(__VA_ARGS__); break;               \
        case PT_ULONG:    func<unsigned char, unsigned long>(__VA_ARGS__); break;     \
        case PT_LONG:     func<unsigned char, long>(__VA_ARGS__); break;              \
        case PT_FLOAT:    func<unsigned char, float>(__VA_ARGS__); break;             \
        case PT_DOUBLE:   func<unsigned char, double>(__VA_ARGS__); break;            \
        }                                                                          \
        break;                                                                     \
    case PT_CHAR:                                                                     \
        switch(ptype2) {                                                           \
        case PT_UCHAR:    func<char, unsigned char>(__VA_ARGS__); break;              \
        case PT_CHAR:     func<char, char>(__VA_ARGS__); break;                       \
        case PT_USHORT:   func<char, unsigned short>(__VA_ARGS__); break;             \
        case PT_SHORT:    func<char, short>(__VA_ARGS__); break;                      \
        case PT_UINT:     func<char, unsigned int>(__VA_ARGS__); break;               \
        case PT_INT:      func<char, int>(__VA_ARGS__); break;                        \
        case PT_ULONG:    func<char, unsigned long>(__VA_ARGS__); break;              \
        case PT_LONG:     func<char, long>(__VA_ARGS__); break;                       \
        case PT_FLOAT:    func<char, float>(__VA_ARGS__); break;                      \
        case PT_DOUBLE:   func<char, double>(__VA_ARGS__); break;                     \
        }                                                                          \
        break;                                                                     \
    case PT_USHORT:                                                                   \
        switch(ptype2) {                                                           \
        case PT_UCHAR:    func<unsigned short, unsigned char>(__VA_ARGS__); break;    \
        case PT_CHAR:     func<unsigned short, char>(__VA_ARGS__); break;             \
        case PT_USHORT:   func<unsigned short, unsigned short>(__VA_ARGS__); break;   \
        case PT_SHORT:    func<unsigned short, short>(__VA_ARGS__); break;            \
        case PT_UINT:     func<unsigned short, unsigned int>(__VA_ARGS__); break;     \
        case PT_INT:      func<unsigned short, int>(__VA_ARGS__); break;              \
        case PT_ULONG:    func<unsigned short, unsigned long>(__VA_ARGS__); break;    \
        case PT_LONG:     func<unsigned short, long>(__VA_ARGS__); break;             \
        case PT_FLOAT:    func<unsigned short, float>(__VA_ARGS__); break;            \
        case PT_DOUBLE:   func<unsigned short, double>(__VA_ARGS__); break;           \
        }                                                                          \
        break;                                                                     \
    case PT_SHORT:                                                                    \
        switch(ptype2) {                                                           \
        case PT_UCHAR:    func<short, unsigned char>(__VA_ARGS__); break;             \
        case PT_CHAR:     func<short, char>(__VA_ARGS__); break;                      \
        case PT_USHORT:   func<short, unsigned short>(__VA_ARGS__); break;            \
        case PT_SHORT:    func<short, short>(__VA_ARGS__); break;                     \
        case PT_UINT:     func<short, unsigned int>(__VA_ARGS__); break;              \
        case PT_INT:      func<short, int>(__VA_ARGS__); break;                       \
        case PT_ULONG:    func<short, unsigned long>(__VA_ARGS__); break;             \
        case PT_LONG:     func<short, long>(__VA_ARGS__); break;                      \
        case PT_FLOAT:    func<short, float>(__VA_ARGS__); break;                     \
        case PT_DOUBLE:   func<short, double>(__VA_ARGS__); break;                    \
        }                                                                          \
        break;                                                                     \
    case PT_UINT:                                                                     \
        switch(ptype2) {                                                           \
        case PT_UCHAR:    func<unsigned int, unsigned char>(__VA_ARGS__); break;      \
        case PT_CHAR:     func<unsigned int, char>(__VA_ARGS__); break;               \
        case PT_USHORT:   func<unsigned int, unsigned short>(__VA_ARGS__); break;     \
        case PT_SHORT:    func<unsigned int, short>(__VA_ARGS__); break;              \
        case PT_UINT:     func<unsigned int, unsigned int>(__VA_ARGS__); break;       \
        case PT_INT:      func<unsigned int, int>(__VA_ARGS__); break;                \
        case PT_ULONG:    func<unsigned int, unsigned long>(__VA_ARGS__); break;      \
        case PT_LONG:     func<unsigned int, long>(__VA_ARGS__); break;               \
        case PT_FLOAT:    func<unsigned int, float>(__VA_ARGS__); break;              \
        case PT_DOUBLE:   func<unsigned int, double>(__VA_ARGS__); break;             \
        }                                                                          \
        break;                                                                     \
    case PT_INT:                                                                      \
        switch(ptype2) {                                                           \
        case PT_UCHAR:    func<int, unsigned char>(__VA_ARGS__); break;               \
        case PT_CHAR:     func<int, char>(__VA_ARGS__); break;                        \
        case PT_USHORT:   func<int, unsigned short>(__VA_ARGS__); break;              \
        case PT_SHORT:    func<int, short>(__VA_ARGS__); break;                       \
        case PT_UINT:     func<int, unsigned int>(__VA_ARGS__); break;                \
        case PT_INT:      func<int, int>(__VA_ARGS__); break;                         \
        case PT_ULONG:    func<int, unsigned long>(__VA_ARGS__); break;               \
        case PT_LONG:     func<int, long>(__VA_ARGS__); break;                        \
        case PT_FLOAT:    func<int, float>(__VA_ARGS__); break;                       \
        case PT_DOUBLE:   func<int, double>(__VA_ARGS__); break;                      \
        }                                                                          \
        break;                                                                     \
    case PT_ULONG:                                                                    \
        switch(ptype2) {                                                           \
        case PT_UCHAR:    func<unsigned long, unsigned char>(__VA_ARGS__); break;     \
        case PT_CHAR:     func<unsigned long, char>(__VA_ARGS__); break;              \
        case PT_USHORT:   func<unsigned long, unsigned short>(__VA_ARGS__); break;    \
        case PT_SHORT:    func<unsigned long, short>(__VA_ARGS__); break;             \
        case PT_UINT:     func<unsigned long, unsigned int>(__VA_ARGS__); break;      \
        case PT_INT:      func<unsigned long, int>(__VA_ARGS__); break;               \
        case PT_ULONG:    func<unsigned long, unsigned long>(__VA_ARGS__); break;     \
        case PT_LONG:     func<unsigned long, long>(__VA_ARGS__); break;              \
        case PT_FLOAT:    func<unsigned long, float>(__VA_ARGS__); break;             \
        case PT_DOUBLE:   func<unsigned long, double>(__VA_ARGS__); break;            \
        }                                                                          \
        break;                                                                     \
    case PT_LONG:                                                                     \
        switch(ptype2) {                                                           \
        case PT_UCHAR:    func<long, unsigned char>(__VA_ARGS__); break;              \
        case PT_CHAR:     func<long, char>(__VA_ARGS__); break;                       \
        case PT_USHORT:   func<long, unsigned short>(__VA_ARGS__); break;             \
        case PT_SHORT:    func<long, short>(__VA_ARGS__); break;                      \
        case PT_UINT:     func<long, unsigned int>(__VA_ARGS__); break;               \
        case PT_INT:      func<long, int>(__VA_ARGS__); break;                        \
        case PT_ULONG:    func<long, unsigned long>(__VA_ARGS__); break;              \
        case PT_LONG:     func<long, long>(__VA_ARGS__); break;                       \
        case PT_FLOAT:    func<long, float>(__VA_ARGS__); break;                      \
        case PT_DOUBLE:   func<long, double>(__VA_ARGS__); break;                     \
        }                                                                          \
        break;                                                                     \
    case PT_FLOAT:                                                                    \
        switch(ptype2) {                                                           \
        case PT_UCHAR:    func<float, unsigned char>(__VA_ARGS__); break;             \
        case PT_CHAR:     func<float, char>(__VA_ARGS__); break;                      \
        case PT_USHORT:   func<float, unsigned short>(__VA_ARGS__); break;            \
        case PT_SHORT:    func<float, short>(__VA_ARGS__); break;                     \
        case PT_UINT:     func<float, unsigned int>(__VA_ARGS__); break;              \
        case PT_INT:      func<float, int>(__VA_ARGS__); break;                       \
        case PT_ULONG:    func<float, unsigned long>(__VA_ARGS__); break;             \
        case PT_LONG:     func<float, long>(__VA_ARGS__); break;                      \
        case PT_FLOAT:    func<float, float>(__VA_ARGS__); break;                     \
        case PT_DOUBLE:   func<float, double>(__VA_ARGS__); break;                    \
        }                                                                          \
        break;                                                                     \
    case PT_DOUBLE:                                                                   \
        switch(ptype2) {                                                           \
        case PT_UCHAR:    func<double, unsigned char>(__VA_ARGS__); break;            \
        case PT_CHAR:     func<double, char>(__VA_ARGS__); break;                     \
        case PT_USHORT:   func<double, unsigned short>(__VA_ARGS__); break;           \
        case PT_SHORT:    func<double, short>(__VA_ARGS__); break;                    \
        case PT_UINT:     func<double, unsigned int>(__VA_ARGS__); break;             \
        case PT_INT:      func<double, int>(__VA_ARGS__); break;                      \
        case PT_ULONG:    func<double, unsigned long>(__VA_ARGS__); break;            \
        case PT_LONG:     func<double, long>(__VA_ARGS__); break;                     \
        case PT_FLOAT:    func<double, float>(__VA_ARGS__); break;                    \
        case PT_DOUBLE:   func<double, double>(__VA_ARGS__); break;                   \
        }                                                                          \
        break;                                                                     \
    }                                                                              \
} while(0)


#define ptypeassign_2(func, ptype1, ptype2, ret, ...)                                    \
do {                                                                                     \
    switch(ptype1) {                                                                     \
    case PT_UCHAR:																			 \
        switch(ptype2) {                                                                 \
        case PT_UCHAR:    ret = func<unsigned char, unsigned char>(__VA_ARGS__); break;     \
        case PT_CHAR:     ret = func<unsigned char, char>(__VA_ARGS__); break;              \
        case PT_USHORT:   ret = func<unsigned char, unsigned short>(__VA_ARGS__); break;    \
        case PT_SHORT:    ret = func<unsigned char, short>(__VA_ARGS__); break;             \
        case PT_UINT:     ret = func<unsigned char, unsigned int>(__VA_ARGS__); break;      \
        case PT_INT:      ret = func<unsigned char, int>(__VA_ARGS__); break;               \
        case PT_ULONG:    ret = func<unsigned char, unsigned long>(__VA_ARGS__); break;     \
        case PT_LONG:     ret = func<unsigned char, long>(__VA_ARGS__); break;              \
        case PT_FLOAT:    ret = func<unsigned char, float>(__VA_ARGS__); break;             \
        case PT_DOUBLE:   ret = func<unsigned char, double>(__VA_ARGS__); break;            \
        }                                                                                \
        break;                                                                           \
    case PT_CHAR:																			 \
        switch(ptype2) {                                                                 \
        case PT_UCHAR:    ret = func<char, unsigned char>(__VA_ARGS__); break;              \
        case PT_CHAR:     ret = func<char, char>(__VA_ARGS__); break;                       \
        case PT_USHORT:   ret = func<char, unsigned short>(__VA_ARGS__); break;             \
        case PT_SHORT:    ret = func<char, short>(__VA_ARGS__); break;                      \
        case PT_UINT:     ret = func<char, unsigned int>(__VA_ARGS__); break;               \
        case PT_INT:      ret = func<char, int>(__VA_ARGS__); break;                        \
        case PT_ULONG:    ret = func<char, unsigned long>(__VA_ARGS__); break;              \
        case PT_LONG:     ret = func<char, long>(__VA_ARGS__); break;                       \
        case PT_FLOAT:    ret = func<char, float>(__VA_ARGS__); break;                      \
        case PT_DOUBLE:   ret = func<char, double>(__VA_ARGS__); break;                     \
        }                                                                                \
        break;                                                                           \
    case PT_USHORT:                                                                         \
        switch(ptype2) {                                                                 \
        case PT_UCHAR:    ret = func<unsigned short, unsigned char>(__VA_ARGS__); break;    \
        case PT_CHAR:     ret = func<unsigned short, char>(__VA_ARGS__); break;             \
        case PT_USHORT:   ret = func<unsigned short, unsigned short>(__VA_ARGS__); break;   \
        case PT_SHORT:    ret = func<unsigned short, short>(__VA_ARGS__); break;            \
        case PT_UINT:     ret = func<unsigned short, unsigned int>(__VA_ARGS__); break;     \
        case PT_INT:      ret = func<unsigned short, int>(__VA_ARGS__); break;              \
        case PT_ULONG:    ret = func<unsigned short, unsigned long>(__VA_ARGS__); break;    \
        case PT_LONG:     ret = func<unsigned short, long>(__VA_ARGS__); break;             \
        case PT_FLOAT:    ret = func<unsigned short, float>(__VA_ARGS__); break;            \
        case PT_DOUBLE:   ret = func<unsigned short, double>(__VA_ARGS__); break;           \
        }                                                                                \
        break;                                                                           \
    case PT_SHORT:                                                                          \
        switch(ptype2) {                                                                 \
        case PT_UCHAR:    ret = func<short, unsigned char>(__VA_ARGS__); break;             \
        case PT_CHAR:     ret = func<short, char>(__VA_ARGS__); break;                      \
        case PT_USHORT:   ret = func<short, unsigned short>(__VA_ARGS__); break;            \
        case PT_SHORT:    ret = func<short, short>(__VA_ARGS__); break;                     \
        case PT_UINT:     ret = func<short, unsigned int>(__VA_ARGS__); break;              \
        case PT_INT:      ret = func<short, int>(__VA_ARGS__); break;                       \
        case PT_ULONG:    ret = func<short, unsigned long>(__VA_ARGS__); break;             \
        case PT_LONG:     ret = func<short, long>(__VA_ARGS__); break;                      \
        case PT_FLOAT:    ret = func<short, float>(__VA_ARGS__); break;                     \
        case PT_DOUBLE:   ret = func<short, double>(__VA_ARGS__); break;                    \
        }                                                                                \
        break;                                                                           \
    case PT_UINT:                                                                           \
        switch(ptype2) {                                                                 \
        case PT_UCHAR:    ret = func<unsigned int, unsigned char>(__VA_ARGS__); break;      \
        case PT_CHAR:     ret = func<unsigned int, char>(__VA_ARGS__); break;               \
        case PT_USHORT:   ret = func<unsigned int, unsigned short>(__VA_ARGS__); break;     \
        case PT_SHORT:    ret = func<unsigned int, short>(__VA_ARGS__); break;              \
        case PT_UINT:     ret = func<unsigned int, unsigned int>(__VA_ARGS__); break;       \
        case PT_INT:      ret = func<unsigned int, int>(__VA_ARGS__); break;                \
        case PT_ULONG:    ret = func<unsigned int, unsigned long>(__VA_ARGS__); break;      \
        case PT_LONG:     ret = func<unsigned int, long>(__VA_ARGS__); break;               \
        case PT_FLOAT:    ret = func<unsigned int, float>(__VA_ARGS__); break;              \
        case PT_DOUBLE:   ret = func<unsigned int, double>(__VA_ARGS__); break;             \
        }                                                                                \
        break;                                                                           \
    case PT_INT:                                                                            \
        switch(ptype2) {                                                                 \
        case PT_UCHAR:    ret = func<int, unsigned char>(__VA_ARGS__); break;               \
        case PT_CHAR:     ret = func<int, char>(__VA_ARGS__); break;                        \
        case PT_USHORT:   ret = func<int, unsigned short>(__VA_ARGS__); break;              \
        case PT_SHORT:    ret = func<int, short>(__VA_ARGS__); break;                       \
        case PT_UINT:     ret = func<int, unsigned int>(__VA_ARGS__); break;                \
        case PT_INT:      ret = func<int, int>(__VA_ARGS__); break;                         \
        case PT_ULONG:    ret = func<int, unsigned long>(__VA_ARGS__); break;               \
        case PT_LONG:     ret = func<int, long>(__VA_ARGS__); break;                        \
        case PT_FLOAT:    ret = func<int, float>(__VA_ARGS__); break;                       \
        case PT_DOUBLE:   ret = func<int, double>(__VA_ARGS__); break;                      \
        }                                                                                \
        break;                                                                           \
    case PT_ULONG:                                                                          \
        switch(ptype2) {                                                                 \
        case PT_UCHAR:    ret = func<unsigned long, unsigned char>(__VA_ARGS__); break;     \
        case PT_CHAR:     ret = func<unsigned long, char>(__VA_ARGS__); break;              \
        case PT_USHORT:   ret = func<unsigned long, unsigned short>(__VA_ARGS__); break;    \
        case PT_SHORT:    ret = func<unsigned long, short>(__VA_ARGS__); break;             \
        case PT_UINT:     ret = func<unsigned long, unsigned int>(__VA_ARGS__); break;      \
        case PT_INT:      ret = func<unsigned long, int>(__VA_ARGS__); break;               \
        case PT_ULONG:    ret = func<unsigned long, unsigned long>(__VA_ARGS__); break;     \
        case PT_LONG:     ret = func<unsigned long, long>(__VA_ARGS__); break;              \
        case PT_FLOAT:    ret = func<unsigned long, float>(__VA_ARGS__); break;             \
        case PT_DOUBLE:   ret = func<unsigned long, double>(__VA_ARGS__); break;            \
        }                                                                                \
        break;                                                                           \
    case PT_LONG:																			 \
        switch(ptype2) {                                                                 \
        case PT_UCHAR:    ret = func<long, unsigned char>(__VA_ARGS__); break;              \
        case PT_CHAR:     ret = func<long, char>(__VA_ARGS__); break;                       \
        case PT_USHORT:   ret = func<long, unsigned short>(__VA_ARGS__); break;             \
        case PT_SHORT:    ret = func<long, short>(__VA_ARGS__); break;                      \
        case PT_UINT:     ret = func<long, unsigned int>(__VA_ARGS__); break;               \
        case PT_INT:      ret = func<long, int>(__VA_ARGS__); break;                        \
        case PT_ULONG:    ret = func<long, unsigned long>(__VA_ARGS__); break;              \
        case PT_LONG:     ret = func<long, long>(__VA_ARGS__); break;                       \
        case PT_FLOAT:    ret = func<long, float>(__VA_ARGS__); break;                      \
        case PT_DOUBLE:   ret = func<long, double>(__VA_ARGS__); break;                     \
        }                                                                                \
        break;                                                                           \
    case PT_FLOAT:																			 \
        switch(ptype2) {                                                                 \
        case PT_UCHAR:    ret = func<float, unsigned char>(__VA_ARGS__); break;             \
        case PT_CHAR:     ret = func<float, char>(__VA_ARGS__); break;                      \
        case PT_USHORT:   ret = func<float, unsigned short>(__VA_ARGS__); break;            \
        case PT_SHORT:    ret = func<float, short>(__VA_ARGS__); break;                     \
        case PT_UINT:     ret = func<float, unsigned int>(__VA_ARGS__); break;              \
        case PT_INT:      ret = func<float, int>(__VA_ARGS__); break;                       \
        case PT_ULONG:    ret = func<float, unsigned long>(__VA_ARGS__); break;             \
        case PT_LONG:     ret = func<float, long>(__VA_ARGS__); break;                      \
        case PT_FLOAT:    ret = func<float, float>(__VA_ARGS__); break;                     \
        case PT_DOUBLE:   ret = func<float, double>(__VA_ARGS__); break;                    \
        }                                                                                \
        break;                                                                           \
    case PT_DOUBLE:																		 \
        switch(ptype2) {                                                                 \
        case PT_UCHAR:    ret = func<double, unsigned char>(__VA_ARGS__); break;            \
        case PT_CHAR:     ret = func<double, char>(__VA_ARGS__); break;                     \
        case PT_USHORT:   ret = func<double, unsigned short>(__VA_ARGS__); break;           \
        case PT_SHORT:    ret = func<double, short>(__VA_ARGS__); break;                    \
        case PT_UINT:     ret = func<double, unsigned int>(__VA_ARGS__); break;             \
        case PT_INT:      ret = func<double, int>(__VA_ARGS__); break;                      \
        case PT_ULONG:    ret = func<double, unsigned long>(__VA_ARGS__); break;            \
        case PT_LONG:     ret = func<double, long>(__VA_ARGS__); break;                     \
        case PT_FLOAT:    ret = func<double, float>(__VA_ARGS__); break;                    \
        case PT_DOUBLE:   ret = func<double, double>(__VA_ARGS__); break;                   \
        }                                                                                \
        break;                                                                           \
    }                                                                                    \
} while(0)


#endif // TEMPLATE_MACROS_H

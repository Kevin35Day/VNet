import torch
from md.image3d.python.image3d import Image3d


class ToImage(object):
    """ convert tensor to image3d object """

    def __call__(self, tensor, dtype=None):

        assert isinstance(tensor, torch._TensorBase), 'input must be a tensor'

        if tensor.dim() == 3:
            # single channel 3d image volume
            data = tensor.cpu().numpy()
            image = Image3d()
            if dtype is None:
                image.from_numpy(data, dtype=data.dtype)
            else:
                image.from_numpy(data, dtype=dtype)

        elif tensor.dim() == 4:
            # multi-channel 3d image volume
            data = tensor.cpu().numpy()
            image = []
            for i in range(data.shape[0]):
                tmp = Image3d()
                if dtype is None:
                    tmp.from_numpy(data[i], dtype=data.dtype)
                else:
                    tmp.from_numpy(data[i], dtype=dtype)
                image.append(tmp)

        else:
            raise ValueError('ToImage() only supports 3-dimsional or 4-dimensional image volume')

        return image


class ToTensor(object):
    """ Convert an image3d object to float tensor

    Note: the value range is NOT normalized to [0.0, 1.0]
    """
    def __call__(self, image):

        if isinstance(image, Image3d):
            img = torch.from_numpy(image.to_numpy())
            img = torch.unsqueeze(img, 0)
            img = img.float()

        elif isinstance(image, list):
            img = []
            for i in range(len(image)):
                assert isinstance(image[i], Image3d)
                tmp = torch.from_numpy(image[i].to_numpy())
                tmp = torch.unsqueeze(tmp, 0)
                tmp = tmp.float()
                img.append(tmp)
            img = torch.cat(img, 0)

        else:
            raise ValueError('unknown input type')

        return img

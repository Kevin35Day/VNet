#ifndef FILTER_H
#define FILTER_H

#include <cudnn.h>
#include <cstring>
#include "neuro/csrc/errors.h"

namespace medvision {


/*! \brief filter base class */
class Filter
{
public:
    virtual ~Filter();

    virtual cudnnFilterDescriptor_t desc() const = 0;
    virtual void* ptr() = 0;
    virtual const void* ptr() const = 0;
    virtual const int* size() const = 0;
    virtual const int* stride() const = 0;
    virtual int dim() const = 0;

    virtual void set_size(const int* size) = 0;
    virtual void create_desc() = 0;
    virtual void set_ptr(void* ptr, bool managed=false) = 0;
    virtual void allocate() = 0;

    virtual size_t bytes() const = 0;
    virtual void cpu(void* buffer) const = 0;
};


/*! \brief 5-dimensional float filter */
class FloatFilter5: public Filter
{
public:
    FloatFilter5();
    FloatFilter5(int o, int i, int d, int h, int w);
    ~FloatFilter5();

    virtual cudnnFilterDescriptor_t desc() const { return m_desc; }
    virtual void* ptr() { return m_dptr; }
    virtual const void* ptr() const { return m_dptr; }
    virtual const int* size() const { return m_size; }
    virtual const int* stride() const { return m_stride; }
    virtual int dim() const { return 5; }

    virtual void set_size(const int* size);
    virtual void create_desc();
    virtual void set_ptr(void* ptr, bool managed=false);
    virtual void allocate();

    virtual size_t bytes() const;
    virtual void cpu(void* buffer) const;

private:
    void compute_stride();

    cudnnFilterDescriptor_t m_desc;
    int m_size[5];
    int m_stride[5];
    void* m_dptr;
    bool m_managed;
};

std::ostream& operator<< (std::ostream& os, const FloatFilter5& filter);


/*! \brief 4-dimensional float filter */
class FloatFilter4: public Filter
{
public:
    FloatFilter4();
    FloatFilter4(int o, int i, int h, int w);
    ~FloatFilter4();

    virtual cudnnFilterDescriptor_t desc() const { return m_desc; }
    virtual void* ptr() { return m_dptr; }
    virtual const void* ptr() const { return m_dptr; }
    virtual const int* size() const { return m_size; }
    virtual const int* stride() const { return m_stride; }
    virtual int dim() const { return 4; }

    virtual void set_size(const int* size);
    virtual void create_desc();
    virtual void set_ptr(void* ptr, bool managed=false);
    virtual void allocate();

    virtual size_t bytes() const;
    virtual void cpu(void* buffer) const;

private:
    void compute_stride();

    cudnnFilterDescriptor_t m_desc;
    int m_size[4];
    int m_stride[4];
    void* m_dptr;
    bool m_managed;
};

std::ostream& operator<< (std::ostream& os, const FloatFilter4& filter);


}

#endif

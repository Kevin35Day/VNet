#include "neuro/csrc/filter.h"
#include "neuro/csrc/errors.h"
#include "neuro/csrc/tensor_utils.h"

using namespace medvision;

Filter::~Filter() {}


FloatFilter5::FloatFilter5()
{
    m_desc = nullptr;
    m_size[0] = m_size[1] = m_size[2] = m_size[3] = m_size[4] = 0;
    m_stride[0] = m_stride[1] = m_stride[2] = m_stride[3] = m_stride[4] = 0;
    m_dptr = nullptr;
    m_managed = false;
}


FloatFilter5::FloatFilter5(int o, int i, int d, int h, int w)
{
    m_desc = nullptr;
    m_size[0] = o;
    m_size[1] = i;
    m_size[2] = d;
    m_size[3] = h;
    m_size[4] = w;
    m_dptr = nullptr;
    m_managed = false;

    compute_stride();
}


FloatFilter5::~FloatFilter5()
{
   if(m_desc != nullptr) {
       cudnnThrowError(cudnnDestroyFilterDescriptor(m_desc));
       m_desc = nullptr;
   }
   m_size[0] = m_size[1] = m_size[2] = m_size[3] = m_size[4] = 0;

   if(m_managed && m_dptr != nullptr) {
       cudaThrowError(cudaFree(m_dptr));
   }
   m_dptr = nullptr;
   m_managed = false;
}


void FloatFilter5::set_size(const int* size)
{
    for(int i = 0; i < 5; ++i)
        m_size[i] = size[i];

    compute_stride();
}


void FloatFilter5::compute_stride()
{
    for(int i = 4; i >=0; --i) {
        if(i == 4)
            m_stride[i] = 1;
        else
            m_stride[i] = m_stride[i+1] * m_size[i+1];
    }
}


void FloatFilter5::create_desc()
{
    if(m_desc != nullptr) {
        cudnnThrowError(cudnnDestroyFilterDescriptor(m_desc));
        m_desc = nullptr;
    }

    cudnnThrowError(cudnnCreateFilterDescriptor(&m_desc));
    cudnnThrowError(cudnnSetFilterNdDescriptor(m_desc, CUDNN_DATA_FLOAT, CUDNN_TENSOR_NCHW, 5, m_size));
}


void FloatFilter5::set_ptr(void* ptr, bool managed)
{
    if(m_managed && m_dptr != nullptr) {
        cudaThrowError(cudaFree(m_dptr));
        m_dptr = nullptr;
    }

    m_managed = managed;
    m_dptr = ptr;
}


void FloatFilter5::allocate()
{
    if(m_desc == nullptr) {
        neuroThrowError(Neuro_EmptyDesc);
    }

    if(m_managed && m_dptr != nullptr) {
        cudaThrowError(cudaFree(m_dptr));
        m_dptr = nullptr;
    }

    m_managed = true;

    size_t data_bytes = bytes();
    cudaThrowError(cudaMalloc(&m_dptr, data_bytes));
}


size_t FloatFilter5::bytes() const
{
    if(m_desc == nullptr) {
        neuroThrowError(Neuro_EmptyDesc);
    }

    size_t bytes = sizeof(float);
    for(int i = 0; i < 5; ++i)
        bytes *= static_cast<size_t>(m_size[i]);

    return bytes;
}


void FloatFilter5::cpu(void* buffer) const
{
    if(m_dptr == nullptr) {
        std::cerr << "FLoatFilter5: empty device pointer when calling cpu()" << std::endl;
        neuroThrowError(Neuro_EmptyTensor);
    }

    size_t data_bytes = bytes();
    cudaThrowError(cudaMemcpy(buffer, m_dptr, data_bytes, cudaMemcpyDeviceToHost));
}


std::ostream& operator<< (std::ostream& os, const FloatFilter5& filter)
{
    print_filter(os, filter);
    return os;
}


// FloatFilter4

FloatFilter4::FloatFilter4()
{
    m_desc = nullptr;
    m_size[0] = m_size[1] = m_size[2] = m_size[3] = 0;
    m_stride[0] = m_stride[1] = m_stride[2] = m_stride[3] = 0;
    m_dptr = nullptr;
    m_managed = false;
}


FloatFilter4::FloatFilter4(int o, int i, int h, int w)
{
    m_desc = nullptr;
    m_size[0] = o;
    m_size[1] = i;
    m_size[2] = h;
    m_size[3] = w;
    m_dptr = nullptr;
    m_managed = false;

    compute_stride();
}


FloatFilter4::~FloatFilter4()
{
   if(m_desc != nullptr) {
       cudnnThrowError(cudnnDestroyFilterDescriptor(m_desc));
       m_desc = nullptr;
   }
   m_size[0] = m_size[1] = m_size[2] = m_size[3] = 0;

   if(m_managed && m_dptr != nullptr) {
       cudaThrowError(cudaFree(m_dptr));
   }
   m_dptr = nullptr;
   m_managed = false;
}


void FloatFilter4::set_size(const int* size)
{
    for(int i = 0; i < 4; ++i)
        m_size[i] = size[i];

    compute_stride();
}


void FloatFilter4::compute_stride()
{
    for(int i = 3; i >=0; --i) {
        if(i == 3)
            m_stride[i] = 1;
        else
            m_stride[i] = m_stride[i+1] * m_size[i+1];
    }
}


void FloatFilter4::create_desc()
{
    if(m_desc != nullptr) {
        cudnnThrowError(cudnnDestroyFilterDescriptor(m_desc));
        m_desc = nullptr;
    }

    cudnnThrowError(cudnnCreateFilterDescriptor(&m_desc));
    cudnnThrowError(cudnnSetFilter4dDescriptor(m_desc, CUDNN_DATA_FLOAT, CUDNN_TENSOR_NCHW, m_size[0], m_size[1], m_size[2], m_size[3]));
}


void FloatFilter4::set_ptr(void* ptr, bool managed)
{
    if(m_managed && m_dptr != nullptr) {
        cudaThrowError(cudaFree(m_dptr));
        m_dptr = nullptr;
    }

    m_managed = managed;
    m_dptr = ptr;
}


void FloatFilter4::allocate()
{
    if(m_desc == nullptr) {
        neuroThrowError(Neuro_EmptyDesc);
    }

    if(m_managed && m_dptr != nullptr) {
        cudaThrowError(cudaFree(m_dptr));
        m_dptr = nullptr;
    }

    m_managed = true;

    size_t data_bytes = bytes();
    cudaThrowError(cudaMalloc(&m_dptr, data_bytes));
}


size_t FloatFilter4::bytes() const
{
    if(m_desc == nullptr) {
        neuroThrowError(Neuro_EmptyDesc);
    }

    size_t bytes = sizeof(float);
    for(int i = 0; i < 4; ++i)
        bytes *= static_cast<size_t>(m_size[i]);

    return bytes;
}


void FloatFilter4::cpu(void* buffer) const
{
    if(m_dptr == nullptr) {
        std::cerr << "FLoatFilter4: empty device pointer when calling cpu()" << std::endl;
        neuroThrowError(Neuro_EmptyTensor);
    }

    size_t data_bytes = bytes();
    cudaThrowError(cudaMemcpy(buffer, m_dptr, data_bytes, cudaMemcpyDeviceToHost));
}


std::ostream& operator<< (std::ostream& os, const FloatFilter4& filter)
{
    print_filter(os, filter);
    return os;
}

#ifndef TENSOR_UTILS_H
#define TENSOR_UTILS_H

#include "image3d/csrc/image3d.h"
#include "neuro/csrc/tensor.h"
#include "neuro/csrc/filter.h"
#include "neuro/csrc/errors.h"
#include <iostream>

namespace medvision {

/*! \brief copy a list of float image3ds to float tensor 5
 *
 *  \param floatims     the float image3d objects
 *  \param num          the number of image3d objects
 *  \param out          the output float tensor (caller is responsible for allocating gpu memory)
 *  \return neuro error code
 */
neuroError_t copy_floatims_to_tensor(const Image3d* floatims, int num, Tensor& out);


/*! \brief copy a binary probability tensor with batchsize 1 to float image
 *
 *  \param in       the input binary probability tensor (batch size = 1)
 *  \param out      the output float image3d of one channel
 *  \param ptype    the output pixel type
 */
neuroError_t convert_binaryProbTensor_to_mask(const Tensor& in, Image3d& out);


/*! \brief image2d filter using cudnn
 *
 *  \param float_im     the float-type image with only 1 slice (in/out)
 *  \param kernel       the float-type kernel data
 *  \param kw           the kernel width
 *  \param kh           the kernel height
 *  \param pw           the padding in width direction
 *  \param ph           the padding in height direction
 */
neuroError_t imfilt2d_cudnn(cudnnHandle_t handle, Image3d& float_im, const float* kernel, int kw, int kh, int pw, int ph);


/*! \brief output tensor in python format using raw ptr
 *
 *  \param os           the output stream
 *  \param data_ptr     the device data ptr for tensor
 *  \param size         the tensor size
 *  \param stride       the tensor stride
 *  \param len          the tensor dim
 *  \param depth        use 0. this parameter is for recursive calls.
 */
void output_tensor_ptr(std::ostream& os, const float* data_ptr, const int* size, const int* stride, int len, int depth);


/*! \brief print float tensor in python format
 *
 *  \param os           the output stream
 *  \param tensor       the tensor to print
 */
void print_tensor(std::ostream& os, const Tensor& tensor);


/*! \brief print filter in python format
 *
 *  \param os           the output stream
 *  \param tensor       the tensor to print
 */
void print_filter(std::ostream& os, const Filter& filter);


/*! \brief compute mean value
 *
 *  \param tensor       the input tensor
 *  \return the float mean value
 */
double compute_tensor_mean(const Tensor& tensor);


/*! \brief print tensor mean value
 *
 *  \param tensor       the input tensor
 */
void print_tensor_mean(const Tensor& tensor);

}


#endif

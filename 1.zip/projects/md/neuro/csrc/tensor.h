#ifndef TENSOR_H
#define TENSOR_H

#include <cudnn.h>
#include <cstring>
#include <iostream>
#include "neuro/csrc/errors.h"

namespace medvision {


/*! \brief Tensor base class representing ND Tensor */
class Tensor
{
public:
    virtual ~Tensor();

    virtual cudnnTensorDescriptor_t desc() const = 0;
    virtual void* ptr() = 0;
    virtual const void* ptr() const = 0;
    virtual const int* size() const = 0;
    virtual const int* stride() const = 0;
    virtual int dim() const = 0;

    virtual void set_size(const int*)= 0;
    virtual void create_desc() = 0;
    virtual void set_ptr(void* ptr, bool managed = false) = 0;
    virtual void allocate() = 0;

    virtual size_t bytes() const = 0;
    virtual void cpu(void* buffer) const = 0;
};

std::ostream& operator<< (std::ostream& os, const Tensor& tensor);


/*! \brief 5-dimensional float tensor
 *
 *  Tensor class manages cudnn float tensor descriptor and device memory.
 */
class FloatTensor5: public Tensor
{
public:
    FloatTensor5();
    FloatTensor5(int b, int c, int d, int h, int w);
    ~FloatTensor5();

    virtual cudnnTensorDescriptor_t desc() const { return m_desc; }
    virtual void* ptr() { return m_dptr; }
    virtual const void* ptr() const { return m_dptr; }
    virtual const int* size() const { return m_size; }
    virtual const int* stride() const { return m_stride; }
    virtual int dim() const { return 5; }

    virtual void set_size(const int* size);
    virtual void create_desc();
    virtual void set_ptr(void* ptr, bool managed=false);
    virtual void allocate();

    virtual size_t bytes() const;
    virtual void cpu(void* buffer) const;

    friend std::ostream& operator<< (std::ostream& os, const FloatTensor5& tensor);

private:

    void compute_stride();

    cudnnTensorDescriptor_t m_desc;
    int m_size[5];
    int m_stride[5];
    void* m_dptr;
    bool m_managed;
};

std::ostream& operator<< (std::ostream& os, const FloatTensor5& tensor);


/*! \brief 4-dimensional float tensor
 *
 *  Tensor class manages cudnn float tensor descriptor and device memory.
 */
class FloatTensor4: public Tensor
{
public:
    FloatTensor4();
    FloatTensor4(int b, int c, int h, int w);
    virtual ~FloatTensor4();

    virtual cudnnTensorDescriptor_t desc() const { return m_desc; }
    virtual void* ptr() { return m_dptr; }
    virtual const void* ptr() const { return m_dptr; }
    virtual const int* size() const { return m_size; }
    virtual const int* stride() const { return m_stride; }
    virtual int dim() const { return 4; }

    virtual void set_size(const int* size);
    virtual void create_desc();
    virtual void set_ptr(void* ptr, bool managed=false);
    virtual void allocate();

    virtual size_t bytes() const;
    virtual void cpu(void* buffer) const;

    friend std::ostream& operator<< (std::ostream& os, const FloatTensor4& tensor);

private:

    void compute_stride();

    cudnnTensorDescriptor_t m_desc;
    int m_size[4];
    int m_stride[4];
    void* m_dptr;
    bool m_managed;
};


std::ostream& operator<< (std::ostream& os, const FloatTensor4& tensor);



}
#endif

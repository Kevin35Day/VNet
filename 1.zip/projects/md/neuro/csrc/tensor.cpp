#include "neuro/csrc/tensor.h"
#include "neuro/csrc/tensor_utils.h"
#include <memory>

namespace medvision {

Tensor::~Tensor()
{

}

std::ostream& operator<< (std::ostream& os, const Tensor& tensor)
{
    print_tensor(os, tensor);
    return os;
}

// float tensor 5
FloatTensor5::FloatTensor5()
{
    m_desc = nullptr;
    m_size[0] = m_size[1] = m_size[2] = m_size[3] = m_size[4] = 0;
    m_stride[0] = m_stride[1] = m_stride[2] = m_stride[3] = m_stride[4] = 0;
    m_dptr = nullptr;
    m_managed = false;
}


FloatTensor5::FloatTensor5(int b, int c, int d, int h, int w)
{
    m_desc = nullptr;
    m_size[0] = b;
    m_size[1] = c;
    m_size[2] = d;
    m_size[3] = h;
    m_size[4] = w;
    m_dptr = nullptr;
    m_managed = false;

    compute_stride();
}


FloatTensor5::~FloatTensor5()
{
   if(m_desc != nullptr) {
       cudnnThrowError(cudnnDestroyTensorDescriptor(m_desc));
       m_desc = nullptr;
   }

   if(m_managed && m_dptr != nullptr) {
       cudaThrowError(cudaFree(m_dptr));
   }
   m_dptr = nullptr;
   m_managed = false;
}


void FloatTensor5::compute_stride()
{
    for(int i = 4; i >=0; --i) {
        if(i == 4)
            m_stride[i] = 1;
        else
            m_stride[i] = m_stride[i+1] * m_size[i+1];
    }
}


void FloatTensor5::set_size(const int* size)
{
    for(int i = 0; i < 5; ++i)
        m_size[i] = size[i];

    compute_stride();
}


void FloatTensor5::create_desc()
{
    if(m_desc != nullptr) {
        cudnnThrowError(cudnnDestroyTensorDescriptor(m_desc));
        m_desc = nullptr;
    }

    cudnnThrowError(cudnnCreateTensorDescriptor(&m_desc));
    cudnnThrowError(cudnnSetTensorNdDescriptor(m_desc, CUDNN_DATA_FLOAT, 5, m_size, m_stride));
}


void FloatTensor5::set_ptr(void* ptr, bool managed)
{
    if(m_managed && m_dptr != nullptr) {
        cudaThrowError(cudaFree(m_dptr));
        m_dptr = nullptr;
    }

    m_managed = managed;
    m_dptr = ptr;
}


void FloatTensor5::allocate()
{
    if(m_desc == nullptr) {
        std::cerr << "FloatTensor5: empty descriptor when calling allocate()" << std::endl;
        neuroThrowError(Neuro_EmptyDesc);
    }

    if(m_managed && m_dptr != nullptr) {
        cudaThrowError(cudaFree(m_dptr));
        m_dptr = nullptr;
    }

    m_managed = true;

    size_t data_bytes = bytes();
    cudaThrowError(cudaMalloc(&m_dptr, data_bytes));
}


size_t FloatTensor5::bytes() const
{
    if(m_desc == nullptr) {
        std::cerr << "FloatTensor5: empty descriptor when calling bytes()" << std::endl;
        neuroThrowError(Neuro_EmptyDesc);
    }

    size_t bytes = 0;
    cudnnThrowError(cudnnGetTensorSizeInBytes(m_desc, &bytes));
    return bytes;
}


void FloatTensor5::cpu(void* buffer) const
{
    if(m_dptr == nullptr) {
        std::cerr << "FLoatTensor5: empty device pointer when calling cpu()" << std::endl;
        neuroThrowError(Neuro_EmptyTensor);
    }

    size_t data_bytes = bytes();
    cudaThrowError(cudaMemcpy(buffer, m_dptr, data_bytes, cudaMemcpyDeviceToHost));
}


std::ostream& operator<< (std::ostream& os, const FloatTensor5& tensor)
{
    print_tensor(os, tensor);
    return os;
}


// float tensor 4
FloatTensor4::FloatTensor4()
{
    m_desc = nullptr;
    m_size[0] = m_size[1] = m_size[2] = m_size[3] = 0;
    m_stride[0] = m_stride[1] = m_stride[2] = m_stride[3] = 0;
    m_dptr = nullptr;
    m_managed = false;
}

FloatTensor4::FloatTensor4(int b, int c, int h, int w)
{
    m_desc = nullptr;
    m_size[0] = b;
    m_size[1] = c;
    m_size[2] = h;
    m_size[3] = w;
    m_dptr = nullptr;
    m_managed = false;

    compute_stride();
}

FloatTensor4::~FloatTensor4()
{
   if(m_desc != nullptr) {
       cudnnThrowError(cudnnDestroyTensorDescriptor(m_desc));
       m_desc = nullptr;
   }

   if(m_managed && m_dptr != nullptr) {
       cudaThrowError(cudaFree(m_dptr));
   }
   m_dptr = nullptr;
   m_managed = false;
}


void FloatTensor4::compute_stride()
{
    for(int i = 3; i >=0; --i) {
        if(i == 3)
            m_stride[i] = 1;
        else
            m_stride[i] = m_stride[i+1] * m_size[i+1];
    }
}


void FloatTensor4::set_size(const int* size)
{
    for(int i = 0; i < 4; ++i)
        m_size[i] = size[i];

    compute_stride();
}


void FloatTensor4::create_desc()
{
    if(m_desc != nullptr) {
        cudnnThrowError(cudnnDestroyTensorDescriptor(m_desc));
        m_desc = nullptr;
    }

    cudnnThrowError(cudnnCreateTensorDescriptor(&m_desc));
    cudnnThrowError(cudnnSetTensor4dDescriptor(m_desc, CUDNN_TENSOR_NCHW, CUDNN_DATA_FLOAT, m_size[0], m_size[1], m_size[2], m_size[3]));
}


void FloatTensor4::set_ptr(void* ptr, bool managed)
{
    if(m_managed && m_dptr != nullptr) {
        cudaThrowError(cudaFree(m_dptr));
        m_dptr = nullptr;
    }

    m_managed = managed;
    m_dptr = ptr;
}


void FloatTensor4::allocate()
{
    if(m_desc == nullptr) {
        std::cerr << "FloatTensor4: empty descriptor when calling allocate()" << std::endl;
        neuroThrowError(Neuro_EmptyDesc);
    }

    if(m_managed && m_dptr != nullptr) {
        cudaThrowError(cudaFree(m_dptr));
        m_dptr = nullptr;
    }

    m_managed = true;

    size_t data_bytes = bytes();
    cudaThrowError(cudaMalloc(&m_dptr, data_bytes));
}


size_t FloatTensor4::bytes() const
{
    if(m_desc == nullptr) {
        std::cerr << "FloatTensor4: empty descriptor when calling bytes()" << std::endl;
        neuroThrowError(Neuro_EmptyDesc);
    }

    size_t bytes = 0;
    cudnnThrowError(cudnnGetTensorSizeInBytes(m_desc, &bytes));
    return bytes;
}


void FloatTensor4::cpu(void* buffer) const
{
    if(m_dptr == nullptr) {
        std::cerr << "FLoatTensor4: empty device pointer when calling cpu()" << std::endl;
        neuroThrowError(Neuro_EmptyTensor);
    }

    size_t data_bytes = bytes();
    cudaThrowError(cudaMemcpy(buffer, m_dptr, data_bytes, cudaMemcpyDeviceToHost));
}


std::ostream& operator<< (std::ostream& os, const FloatTensor4& tensor)
{
    print_tensor(os, tensor);
    return os;
}

}


#include "neuro/csrc/layers/relu.h"

namespace medvision {

// Relu activation
Relu::Relu()
{
    m_cudnn_handle = nullptr;
    m_act_desc = nullptr;
}

Relu::~Relu()
{
    if(m_act_desc != nullptr) {
        cudnnThrowError(cudnnDestroyActivationDescriptor(m_act_desc));
        m_act_desc = nullptr;
    }
}

neuroError_t Relu::set_param_ptrs(const ParamDictType& param_dict)
{
    return Neuro_Success;
}

neuroError_t Relu::create_descs(cudnnHandle_t handle,
                                const Tensor& intensor,
                                Tensor& outtensor,
                                bool infer_shape,
                                size_t& max_layer_size,
                                size_t& workspace_size)
{
    m_cudnn_handle = handle;

    if(m_act_desc != nullptr) {
        cudnnThrowError(cudnnDestroyActivationDescriptor(m_act_desc));
        m_act_desc = nullptr;
    }

    if(infer_shape) {
        outtensor.set_size(intensor.size());
        outtensor.create_desc();
    }

    cudnnThrowError(cudnnCreateActivationDescriptor(&m_act_desc));
    cudnnThrowError(cudnnSetActivationDescriptor(m_act_desc, CUDNN_ACTIVATION_RELU, CUDNN_PROPAGATE_NAN, 0.0));

    max_layer_size = std::max<size_t>(max_layer_size, intensor.bytes());

    return Neuro_Success;
}

neuroError_t Relu::forward(Tensor& intensor, Tensor& outtensor, void* workspace_size)
{
    if(intensor.desc() == nullptr || outtensor.desc() == nullptr)
        return Neuro_EmptyDesc;

    float alpha = 1.0f, beta = 0.0f;
    cudnnThrowError(cudnnActivationForward(m_cudnn_handle, m_act_desc, &alpha, intensor.desc(), intensor.ptr(),
                                           &beta, outtensor.desc(), outtensor.ptr()));

    return Neuro_Success;
}

}

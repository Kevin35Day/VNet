#include "neuro/csrc/layers/conv_bn_relu3.h"
#include <sstream>

namespace medvision {

// ConvBnRelu3
ConvBnRelu3::ConvBnRelu3()
{
    m_cudnn_handle = nullptr;
}

ConvBnRelu3::ConvBnRelu3(const std::string& name,
                         const std::string& conv_name,
                         const std::string& bn_name,
                         int in_channels,
                         int out_channels,
                         const vec3d<int>& ksize3,
                         const vec3d<int>& stride3,
                         const vec3d<int>& pad3,
                         const vec3d<int>& dilate3,
                         int num_groups,
                         bool enable_bias,
                         bool do_act,
                         float alpha,
                         float beta)
{
    initialize(name, conv_name, bn_name, in_channels, out_channels, ksize3, stride3, pad3, dilate3, num_groups, enable_bias, do_act, alpha, beta);
}

void ConvBnRelu3::initialize(const std::string& name,
                             const std::string& conv_name,
                             const std::string& bn_name,
                             int in_channels,
                             int out_channels,
                             const vec3d<int>& ksize3,
                             const vec3d<int>& stride3,
                             const vec3d<int>& pad3,
                             const vec3d<int>& dilate3,
                             int num_groups,
                             bool enable_bias,
                             bool do_act,
                             float alpha,
                             float beta)
{
    m_name = name;
    m_conv_name = conv_name;
    m_bn_name = bn_name;
    m_do_act = do_act;

    std::stringstream ss;
    ss << name << "." << conv_name;
    m_conv.initialize(ss.str(), in_channels, out_channels, ksize3, stride3, pad3, dilate3, num_groups, enable_bias, alpha, beta);

    ss.clear();
    ss.str(std::string(""));

    ss << name << "." << bn_name;
    m_bn.initialize(ss.str());

    m_cudnn_handle = nullptr;
}

neuroError_t ConvBnRelu3::set_param_ptrs(const ParamDictType& param_dict)
{
    checkNeuro(m_conv.set_param_ptrs(param_dict));
    checkNeuro(m_bn.set_param_ptrs(param_dict));
    return Neuro_Success;
}

neuroError_t ConvBnRelu3::create_descs(cudnnHandle_t cudnn_handle, const Tensor& intensor, Tensor& outtensor,
                                       bool infer_shape, size_t& max_layer_size, size_t& workspace_size)
{
    m_cudnn_handle = cudnn_handle;
    checkNeuro(m_conv.create_descs(cudnn_handle, intensor, outtensor, infer_shape, max_layer_size, workspace_size));
    checkNeuro(m_bn.create_descs(cudnn_handle, outtensor, outtensor, false, max_layer_size, workspace_size));
    if(m_do_act)
        checkNeuro(m_act.create_descs(cudnn_handle, outtensor, outtensor, false, max_layer_size, workspace_size));
    return Neuro_Success;
}

neuroError_t ConvBnRelu3::forward(Tensor& intensor, Tensor& outtensor, void* workspace)
{
    checkNeuro(m_conv.forward(intensor, outtensor, workspace));
    checkNeuro(m_bn.forward(outtensor, outtensor, workspace));
    if(m_do_act)
        checkNeuro(m_act.forward(outtensor, outtensor, workspace));
    return Neuro_Success;
}

}

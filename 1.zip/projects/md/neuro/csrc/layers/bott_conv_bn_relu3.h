#ifndef BOTT_CONV_BN_RELU3_H
#define BOTT_CONV_BN_RELU3_H

#include <cudnn.h>
#include "math/vec3d.h"
#include <vector>
#include "neuro/csrc/filter.h"
#include "neuro/csrc/tensor.h"
#include "neuro/csrc/errors.h"
#include "neuro/csrc/layers/network_module.h"
#include "neuro/csrc/layers/conv_bn_relu3.h"

namespace medvision {

// bottle neck ConvBnRelu3
class BottConvBnRelu3: public NetworkModule
{
public:
    /*! \brief default constructor */
    BottConvBnRelu3();

    /*! \brief parametric constructor
     *
     *  \param name                 the module name
     *  \param downsample_name      downsample module name
     *  \param conv_name            middle convolution name
     *  \param upsample_name        upsample module name
     *  \param in_channels          the number of input channels
     *  \param out_channels         the number of output channels
     *  \param ratio                determine channels used in bottle neck block, i.e., outchannels/ratio
     *  \param ksize3               the 3d kernel size ordered by depth-height-width
     *  \param stride3              the 3d stride ordered by depth-height-width
     *  \param pad3                 the 3d padding ordered by depth-height-width
     *  \param dilate3              the 3d dilation ordered by depth-height-width
     *  \param num_groups           the number of groups in group convolutions
     *  \param enable_bias          whether to use bias in convolution
     *  \param do_act               whether to apply non-linear activation after convolution
     */
    BottConvBnRelu3(const std::string& name,
                    const std::string& downsample_name,
                    const std::string& conv_name,
                    const std::string& upsample_name,
                    int in_channels,
                    int out_channels,
                    float ratio = 4,
                    const vec3d<int>& ksize3 = vec3d<int>(3, 3, 3),
                    const vec3d<int>& stride3 = vec3d<int>(1, 1, 1),
                    const vec3d<int>& pad3 = vec3d<int>(1, 1, 1),
                    const vec3d<int>& dilate3 = vec3d<int>(1, 1, 1),
                    int num_groups = 1,
                    bool enable_bias = true,
                    bool do_act = true);

    /*! \brief initialization function
     *
     *  \param name                 the module name
     *  \param downsample_name      downsample module name
     *  \param conv_name            middle convolution name
     *  \param upsample_name        upsample module name
     *  \param in_channels          the number of input channels
     *  \param out_channels         the number of output channels
     *  \param ratio                determine channels used in bottle neck block, i.e., outchannels/ratio
     *  \param ksize3               the 3d kernel size ordered by depth-height-width
     *  \param stride3              the 3d stride ordered by depth-height-width
     *  \param pad3                 the 3d padding ordered by depth-height-width
     *  \param dilate3              the 3d dilation ordered by depth-height-width
     *  \param num_groups           the number of groups in group convolutions
     *  \param enable_bias          whether to use bias in convolution
     *  \param do_act               whether to apply non-linear activation after convolution
     */
    void initialize(const std::string& name,
                    const std::string& downsample_name,
                    const std::string& conv_name,
                    const std::string& upsample_name,
                    int in_channels,
                    int out_channels,
                    float ratio = 4,
                    const vec3d<int>& ksize3 = vec3d<int>(3, 3, 3),
                    const vec3d<int>& stride3 = vec3d<int>(1, 1, 1),
                    const vec3d<int>& pad3 = vec3d<int>(1, 1, 1),
                    const vec3d<int>& dilate3 = vec3d<int>(1, 1, 1),
                    int num_groups = 1,
                    bool enable_bias = true,
                    bool do_act = true);

    /*! \brief detailed implementation of set_param_ptrs */
    virtual neuroError_t set_param_ptrs(const ParamDictType& param_dict);

    /*! \brief detailed implementation of create_descs */
    virtual neuroError_t create_descs(cudnnHandle_t cudnn_handle, const Tensor& intensor, Tensor& outtensor,
                              bool infer_shape, size_t& max_layer_size, size_t& workspace_size);

    /*! \brief detailed implementation of forward */
    virtual neuroError_t forward(Tensor& intensor, Tensor& outtensor, void* workspace);

private:

    std::string m_name;
    std::string m_downsample_name;
    std::string m_conv_name;
    std::string m_upsample_name;

    cudnnHandle_t m_cudnn_handle;
    ConvBnRelu3 m_conv_bn_relu1, m_conv_bn_relu2, m_conv_bn_relu3;
    FloatTensor5 m_temp_tensor1, m_temp_tensor2;

};

}

#endif

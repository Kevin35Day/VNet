#include "neuro/csrc/layers/conv2.h"
#include "neuro/csrc/layers/tensor_ops.h"

namespace medvision {

// convolution 3d
Conv2::Conv2() {
    initialize("", 0, 0, vec2d<int>(1, 1), vec2d<int>(1, 1), vec2d<int>(0, 0));
}

Conv2::Conv2(const std::string& name,
             int in_channels,
             int out_channels,
             const vec2d<int>& ksize2,
             const vec2d<int>& stride2,
             const vec2d<int>& pad2,
             const vec2d<int>& dilate2,
             int num_groups,
             bool enable_bias,
             float alpha,
             float beta)
{
    initialize(name, in_channels, out_channels, ksize2, stride2, pad2, dilate2, num_groups, enable_bias, alpha, beta);
}

void Conv2::initialize(const std::string& name,
                       int in_channels,
                       int out_channels,
                       const vec2d<int>& ksize2,
                       const vec2d<int>& stride2,
                       const vec2d<int>& pad2,
                       const vec2d<int>& dilate2,
                       int num_groups,
                       bool enable_bias,
                       float alpha,
                       float beta)
{
    m_name = name;
    m_inchannels = in_channels;
    m_outchannels = out_channels;
    m_ksize2 = ksize2;
    m_stride2 = stride2;
    m_pad2 = pad2;
    m_dilate2 = dilate2;
    m_num_groups = num_groups;
    m_enable_bias = enable_bias;
    m_convdesc = nullptr;
    m_alpha = alpha;
    m_beta = beta;

    int filter_size[] = {out_channels, in_channels, ksize2[0], ksize2[1]};
    m_filter.set_size(filter_size);

    if(m_enable_bias) {
        int bias_size[] = {1, out_channels, 1, 1};
        m_bias.set_size(bias_size);
    }

    m_fwdalg = CUDNN_CONVOLUTION_FWD_ALGO_IMPLICIT_GEMM;
    m_cudnn_handle = nullptr;
    m_workspace_size = 0;
}

Conv2::~Conv2()
{
    if(m_convdesc != nullptr) {
        cudnnThrowError(cudnnDestroyConvolutionDescriptor(m_convdesc));
        m_convdesc = nullptr;
    }
}

neuroError_t Conv2::set_param_ptrs(const ParamDictType& param_dict)
{
    std::string weight_name = m_name + std::string(".weight");
    std::string bias_name = m_name + std::string(".bias");

    auto it = param_dict.find(weight_name);
    if(it == param_dict.end()) {
        std::cerr << "Conv2: " << weight_name << " not found!" << std::endl;
        return Neuro_ParamNotFound;
    } else {
        m_filter.set_ptr(it->second);
    }

    if(m_enable_bias) {
        it = param_dict.find(bias_name);
        if(it == param_dict.end()) {
            std::cerr << "Conv2: " << bias_name << " not found!" << std::endl;
            return Neuro_ParamNotFound;
        } else {
            m_bias.set_ptr(it->second);
        }
    }

    return Neuro_Success;
}

neuroError_t Conv2::create_descs(cudnnHandle_t handle, const Tensor& intensor, Tensor& outtensor,
                                 bool infer_shape, size_t& max_lay_size, size_t& workspace_size)
{
    if(intensor.desc() == nullptr)
        return Neuro_EmptyDesc;

    m_cudnn_handle = handle;

    if(m_convdesc != nullptr) {
        cudnnThrowError(cudnnDestroyConvolutionDescriptor(m_convdesc));
        m_convdesc = nullptr;
    }

    // cuda init for filter and bias
    m_filter.create_desc();
    if(m_enable_bias)
        m_bias.create_desc();

    // setup convolution descriptor
    cudnnThrowError(cudnnCreateConvolutionDescriptor(&m_convdesc));
    cudnnThrowError(cudnnSetConvolution2dDescriptor(m_convdesc, m_pad2[0], m_pad2[1], m_stride2[0], m_stride2[1],
                                                    m_dilate2[0], m_dilate2[1], CUDNN_CROSS_CORRELATION, CUDNN_DATA_FLOAT));

#if CUDNN_MAJOR == 7
    if(m_num_groups != 1)
        cudnnThrowError(cudnnSetConvolutionGroupCount(m_convdesc, m_num_groups));
    cudnnThrowError(cudnnSetConvolutionMathType(m_convdesc, CUDNN_TENSOR_OP_MATH));
#endif

    // setup output tensor descriptor
    if(infer_shape) {
        int out_dims[4];
        cudnnThrowError(cudnnGetConvolution2dForwardOutputDim(m_convdesc, intensor.desc(), m_filter.desc(), out_dims, out_dims+1, out_dims+2, out_dims+3));
        outtensor.set_size(out_dims);
        outtensor.create_desc();
    }

    if(outtensor.desc() == nullptr)
        return Neuro_EmptyDesc;

    // choose best forward algorithm
#if CUDNN_MAJOR == 7

    int num_alg = 0;
    cudnnConvolutionFwdAlgoPerf_t alg_perf;
    cudnnThrowError(cudnnGetConvolutionForwardAlgorithm_v7(handle, intensor.desc(), m_filter.desc(),
                                                           m_convdesc, outtensor.desc(), 1, &num_alg, &alg_perf));
    if(num_alg != 1)
        return Neuro_NoFwdAlg;

    m_fwdalg = alg_perf.algo;

#else

    cudnnThrowError(cudnnGetConvolutionForwardAlgorithm(handle, intensor.desc(), m_filter.desc(), m_convdesc,
                                                        outtensor.desc(), CUDNN_CONVOLUTION_FWD_PREFER_FASTEST,
                                                        0, &m_fwdalg));
#endif

    // compute workspace size and update if necessary
    cudnnThrowError(cudnnGetConvolutionForwardWorkspaceSize(handle, intensor.desc(), m_filter.desc(), m_convdesc,
                                                            outtensor.desc(), m_fwdalg, &m_workspace_size));
    workspace_size = std::max<size_t>(workspace_size, m_workspace_size);

    // compute max layer size and update if necessary
    size_t local_max_layer_size = std::max<size_t>(intensor.bytes(), outtensor.bytes());
    max_lay_size = std::max<size_t>(max_lay_size, local_max_layer_size);

    return Neuro_Success;
}

neuroError_t Conv2::forward(Tensor& intensor, Tensor& outtensor, void* workspace)
{
    if(m_cudnn_handle == nullptr) {
        std::cerr << "Conv2: m_cudnn_handle == nullptr" << std::endl;
        return Neuro_InvalidContext;
    }

    if(intensor.desc() == nullptr || outtensor.desc() == nullptr)
        return Neuro_EmptyDesc;

    cudnnThrowError(cudnnConvolutionForward(m_cudnn_handle, &m_alpha,
                                            intensor.desc(), intensor.ptr(),
                                            m_filter.desc(), m_filter.ptr(),
                                            m_convdesc, m_fwdalg, workspace, m_workspace_size,
                                            &m_beta, outtensor.desc(), outtensor.ptr()));
    if(m_enable_bias)
        checkNeuro(TensorOps::add(m_cudnn_handle, 1.0f, m_bias, 1.0f, outtensor));
    return Neuro_Success;
}


}

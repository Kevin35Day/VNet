#ifndef NEURO_CONV3_H
#define NEURO_CONV3_H

#include <cudnn.h>
#include "math/vec3d.h"
#include <unordered_map>
#include "neuro/csrc/filter.h"
#include "neuro/csrc/tensor.h"
#include "neuro/csrc/errors.h"
#include "neuro/csrc/layers/network_module.h"

namespace medvision {

/*! \brief Convolution 3D module */
class Conv3: public NetworkModule
{
public:

    /*! \brief default constructor
     *
     *  initialize() can be called later to initialize the module.
     */
    Conv3();

    /*! \brief parameteric constructor
     *
     *  \param name             the name of this module
     *  \param in_channels      the number of input channels
     *  \param out_channels     the number of output channels
     *  \param ksize3           the 3d kernel size, Depth-Height-Width ordered
     *  \param stride3          the 3d stride, Depth-Height-Width ordered
     *  \param pad3             the 3d padding, Depth-Height-Width ordered
     *  \param dilate3          the 3d kernel dilation, Depth-Height-Width ordered
     *  \param num_groups       the number of group convolutions in 3d convolution
     *  \param enable_bias      whether to use bias in convolution 3d
     *  \param alpha            the alpha value in cudnn for convolution
     *  \param beta             the beta value in cudnn for convolution
     */
    Conv3(const std::string& name,
          int in_channels,
          int out_channels,
          const vec3d<int>& ksize3,
          const vec3d<int>& stride3,
          const vec3d<int>& pad3 = vec3d<int>(0, 0, 0),
          const vec3d<int>& dilate3 = vec3d<int>(1, 1, 1),
          int num_groups = 1,
          bool enable_bias = true,
          float alpha = 1.0f,
          float beta = 0.0f);

    /*! \brief deconstructor */
    virtual ~Conv3();

    /*! \brief initialization function
     *
     *  \param name             the name of this module
     *  \param in_channels      the number of input channels
     *  \param out_channels     the number of output channels
     *  \param ksize3           the 3d kernel size, Depth-Height-Width ordered
     *  \param stride3          the 3d stride, Depth-Height-Width ordered
     *  \param pad3             the 3d padding, Depth-Height-Width ordered
     *  \param dilate3          the 3d kernel dilation, Depth-Height-Width ordered
     *  \param num_groups       the number of group convolutions in 3d convolution
     *  \param enable_bias      whether to use bias in convolution 3d
     *  \param alpha            the alpha value in cudnn for convolution
     *  \param beta             the beta value in cudnn for convolution
     */
    void initialize(const std::string& name,
                    int in_channels,
                    int out_channels,
                    const vec3d<int>& ksize3,
                    const vec3d<int>& stride3,
                    const vec3d<int>& pad3 = vec3d<int>(0, 0, 0),
                    const vec3d<int>& dilate3 = vec3d<int>(1, 1, 1),
                    int num_groups = 1,
                    bool enable_bias = true,
                    float alpha = 1.0f,
                    float beta = 0.0f);

    /*! \brief detailed implementation of virtual function set_param_ptrs */
    virtual neuroError_t set_param_ptrs(const ParamDictType& param_dict);

    /*! \brief detailed implementation of virtual function create_descs */
    virtual neuroError_t create_descs(cudnnHandle_t handle,
                                      const Tensor& intensor,
                                      Tensor& outtensor,
                                      bool infer_shape,
                                      size_t& max_layer_size,
                                      size_t& workspace_size);

    /*! \brief detailed implementation of virtual function forward */
    virtual neuroError_t forward(Tensor& intensor, Tensor& outtensor, void* workspace);

private:

    std::string m_name;

    int m_inchannels;
    int m_outchannels;
    vec3d<int> m_ksize3;
    vec3d<int> m_stride3;
    vec3d<int> m_pad3;
    vec3d<int> m_dilate3;
    int m_num_groups;
    bool m_enable_bias;
    float m_alpha;
    float m_beta;

    FloatFilter5 m_filter;
    FloatTensor5 m_bias;

    cudnnConvolutionDescriptor_t m_convdesc;
    cudnnConvolutionFwdAlgo_t m_fwdalg;
    size_t m_workspace_size;

    cudnnHandle_t m_cudnn_handle;
};

}

#endif

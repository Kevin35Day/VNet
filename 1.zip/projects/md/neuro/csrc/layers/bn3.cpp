#include "neuro/csrc/layers/bn3.h"

namespace medvision {

// batch normalization 3D
BN3::BN3()
{
    initialize("");
}

BN3::BN3(const std::string& name, double epsilon)
{
    initialize(name, epsilon);
}

void BN3::initialize(const std::string &name, double epsilon)
{
    m_name = name;
    m_epsilon = epsilon;
    m_cudnn_handle = nullptr;

    m_weight = nullptr;
    m_bias = nullptr;
    m_mean = nullptr;
    m_var = nullptr;
}

neuroError_t BN3::set_param_ptrs(const ParamDictType& param_dict)
{
    std::string weight_name = m_name + std::string(".weight");
    std::string bias_name = m_name + std::string(".bias");
    std::string mean_name = m_name + std::string(".running_mean");
    std::string var_name = m_name + std::string(".running_var");

    auto it = param_dict.find(weight_name);
    if(it == param_dict.end()) {
        std::cerr << "BN3: " << weight_name << " not found!" << std::endl;
        return Neuro_ParamNotFound;
    } else {
        m_weight = it->second;
    }

    it = param_dict.find(bias_name);
    if(it == param_dict.end()) {
        std::cerr << "BN3: " << bias_name << " not found in parameter map" << std::endl;
        return Neuro_ParamNotFound;
    } else {
        m_bias = it->second;
    }

    it = param_dict.find(mean_name);
    if(it == param_dict.end()) {
        std::cerr << "BN3: " << bias_name << " not found in parameter map" << std::endl;
        return Neuro_ParamNotFound;
    } else {
        m_mean = it->second;
    }

    it = param_dict.find(var_name);
    if(it == param_dict.end()) {
        std::cerr << "BN3: " << bias_name << " not found in parameter map" << std::endl;
        return Neuro_ParamNotFound;
    } else {
        m_var = it->second;
    }

    return Neuro_Success;
}

neuroError_t BN3::create_descs(cudnnHandle_t handle,
                               const Tensor& intensor,
                               Tensor& outtensor,
                               bool infer_shape,
                               size_t& max_layer_size,
                               size_t& workspace_size)
{
    m_cudnn_handle = handle;

    if(infer_shape) {
        outtensor.set_size(intensor.size());
        outtensor.create_desc();
    }

    int channels = outtensor.size()[1];
    int size[] = {1, channels, 1, 1, 1};
    m_desc.set_size(size);
    m_desc.create_desc();

    max_layer_size = std::max<size_t>(max_layer_size, intensor.bytes());

    return Neuro_Success;
}

neuroError_t BN3::forward(Tensor &intensor, Tensor &outtensor, void* workspace)
{
    if(intensor.desc() == nullptr || outtensor.desc() == nullptr)
        return Neuro_EmptyDesc;

    float alpha = 1.0, beta = 0.0;
    cudnnThrowError(cudnnBatchNormalizationForwardInference(m_cudnn_handle, CUDNN_BATCHNORM_SPATIAL, &alpha,
                                                            &beta, intensor.desc(), intensor.ptr(),
                                                            outtensor.desc(), outtensor.ptr(),
                                                            m_desc.desc(), m_weight, m_bias, m_mean, m_var, m_epsilon));

    return Neuro_Success;
}

}

#include "neuro/csrc/layers/network_module.h"

namespace medvision {

NetworkModule::~NetworkModule() {}

}

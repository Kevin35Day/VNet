#ifndef NEURO_ELU_H
#define NEURO_ELU_H

#include <cudnn.h>
#include "neuro/csrc/filter.h"
#include "neuro/csrc/tensor.h"
#include "neuro/csrc/errors.h"
#include "neuro/csrc/layers/network_module.h"

namespace medvision {

/*! \brief ELU activation network module */
class Elu: public NetworkModule
{
public:
    /*! \brief default constructor */
    Elu(double alpha = 1.0);

    /*! \brief destructor */
    virtual ~Elu();

    /*! \brief detailed implementation of set_param_ptrs */
    virtual neuroError_t set_param_ptrs(const ParamDictType &param_dict);

    /*! \brief detailed implementation of create_descs */
    virtual neuroError_t create_descs(cudnnHandle_t handle,
                                      const Tensor &intensor,
                                      Tensor &outtensor,
                                      bool infer_shape,
                                      size_t &max_layer_size,
                                      size_t &workspace_size);

    /*! \brief detailed implementation of forward */
    virtual neuroError_t forward(Tensor& intensor, Tensor& outtensor, void* workspace);

private:
    cudnnHandle_t m_cudnn_handle;
    cudnnActivationDescriptor_t m_act_desc;
    double m_alpha;
};

}

#endif

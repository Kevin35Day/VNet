#ifndef NEURO_TENSOR_OPS_H
#define NEURO_TENSOR_OPS_H

#include <cudnn.h>
#include "neuro/csrc/filter.h"
#include "neuro/csrc/tensor.h"
#include "neuro/csrc/errors.h"
#include <iostream>

namespace medvision {

/*! \brief frequently used tensor operations */
class TensorOps
{
public:
    /*! \brief add two tensors with same dimensions
     *
     *  op2 = alpha * op1 + beta * op2
     *
     *  \param cudnn_handle         the cudnn handle
     *  \param alpha                const coefficient of op1
     *  \param op1                  one operand (input)
     *  \param beta                 const coefficient of op2
     *  \param op2                  one operand (input and output)
     *  \return neuro error code
     */
    static neuroError_t add(cudnnHandle_t cudnn_handle, float alpha, const Tensor& op1, float beta, Tensor& op2);

    /*! \brief copy one tensor to the other
     *
     *  \param cudnn_handle         the cudnn handle
     *  \param src                  the source tensor
     *  \param dst                  the dst tensor
     *  \return neuro error code
     */
    static neuroError_t copy(cudnnHandle_t cudnn_handle, const Tensor& src, Tensor& dst);

    /*! \brief apply softmax non-linear activation on channels
     *
     *  \param cudnn_handle         the cudnn handle
     *  \param in                   the input and output tensor
     */
    static neuroError_t softmax_spatial(cudnnHandle_t cudnn_handle, Tensor& in, cudnnSoftmaxAlgorithm_t alg = CUDNN_SOFTMAX_FAST);
};


/*! \brief tensor add op */
class TensorAddOp
{
public:
    /*! \brief parametric constructor */
    TensorAddOp();

    /*! \brief destructor */
    ~TensorAddOp();

    /*! \brief create descriptor of tensor op */
    void create_desc(cudnnHandle_t handle);

    /*! \brief perform operation */
    neuroError_t operator() (float alpha1, const Tensor& op1, float alpha2, const Tensor& op2, float beta, Tensor& op3);

private:

    cudnnOpTensorDescriptor_t m_op_desc;
    cudnnHandle_t m_cudnn_handle;
};


/*! \brief tensor mult op */
class TensorMultOp
{
public:
    /*! \brief parametric constructor */
    TensorMultOp();

    /*! \brief destructor */
    ~TensorMultOp();

    /*! \brief create descriptor of tensor op */
    void create_desc(cudnnHandle_t handle);

    /*! \brief perform operation */
    neuroError_t operator() (float alpha1, const Tensor& op1, float alpha2, const Tensor& op2, float beta, Tensor& op3);

private:

    cudnnOpTensorDescriptor_t m_op_desc;
    cudnnHandle_t m_cudnn_handle;
};


/*! \brief tensor min op */
class TensorMinOp
{
public:
    /*! \brief parametric constructor */
    TensorMinOp();

    /*! \brief destructor */
    ~TensorMinOp();

    /*! \brief create descriptor of tensor op */
    void create_desc(cudnnHandle_t handle);

    /*! \brief perform operation */
    neuroError_t operator() (float alpha1, const Tensor& op1, float alpha2, const Tensor& op2, float beta, Tensor& op3);

private:

    cudnnOpTensorDescriptor_t m_op_desc;
    cudnnHandle_t m_cudnn_handle;
};


/*! \brief tensor max op */
class TensorMaxOp
{
public:
    /*! \brief parametric constructor */
    TensorMaxOp();

    /*! \brief destructor */
    ~TensorMaxOp();

    /*! \brief create descriptor of tensor op */
    void create_desc(cudnnHandle_t handle);

    /*! \brief perform operation */
    neuroError_t operator() (float alpha1, const Tensor& op1, float alpha2, const Tensor& op2, float beta, Tensor& op3);

private:

    cudnnOpTensorDescriptor_t m_op_desc;
    cudnnHandle_t m_cudnn_handle;
};


}

#endif

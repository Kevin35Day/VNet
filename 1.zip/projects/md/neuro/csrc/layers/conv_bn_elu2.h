#ifndef NEURO_CONV_BN_ELU2_H
#define NEURO_CONV_BN_ELU2_H

#include <cudnn.h>
#include "math/vec2d.h"
#include "neuro/csrc/filter.h"
#include "neuro/csrc/tensor.h"
#include "neuro/csrc/errors.h"
#include "neuro/csrc/layers/network_module.h"
#include "neuro/csrc/layers/conv2.h"
#include "neuro/csrc/layers/bn2.h"
#include "neuro/csrc/layers/elu.h"

namespace medvision {

/*! \brief ConvBnRelu2 network module
 *
 * the serial combination of convolution 2d, batch normalization 2d and Elu
 */
class ConvBnElu2: public NetworkModule
{
public:
    /*! \brief default constructor */
    ConvBnElu2();

    /*! \brief parametric constructor
     *
     *  \param name         the module name
     *  \param conv_name    the name of convolution module
     *  \param bn_name      the name of batch-normalization module
     *  \param postfix      the postfix of sub-module name, e.g., conv, bn
     *  \param in_channels  the number of input channels
     *  \param out_channels the number of output channels
     *  \param ksize2       the 2d kernel size ordered by height-width
     *  \param stride2      the 2d stride ordered by height-width
     *  \param pad2         the 2d padding ordered by height-width
     *  \param dilate2      the 2d dilation ordered by height-width
     *  \param num_groups   the number of groups in group convolution
     *  \param enable_bias  whether to use bias
     *  \param do_act       whether to perform non-linear activation
     *  \param alpha        the alpha value in cudnn for convolution
     *  \param beta         the beta value in cudnn for convolution
     */
    ConvBnElu2(const std::string& name,
                const std::string& conv_name,
                const std::string& bn_name,
                int in_channels,
                int out_channels,
                const vec2d<int>& ksize2,
                const vec2d<int>& stride2,
                const vec2d<int>& pad2 = vec2d<int>(0, 0),
                const vec2d<int>& dilate2 = vec2d<int>(1, 1),
                int num_groups = 1,
                bool enable_bias = true,
                bool do_act = true,
                float alpha = 1.0f,
                float beta = 0.0f);


    /*! \brief initialization function
     *
     *  \param name         the module name
     *  \param conv_name    the name of convolution module
     *  \param bn_name      the name of batch-normalization module
     *  \param in_channels  the number of input channels
     *  \param out_channels the number of output channels
     *  \param ksize2       the 2d kernel size ordered by height-width
     *  \param stride2      the 2d stride ordered by height-width
     *  \param pad2         the 2d padding ordered by height-width
     *  \param dilate2      the 2d dilation ordered by height-width
     *  \param num_groups   the number of groups in group convolution
     *  \param enable_bias  whether to use bias
     *  \param do_act       whether to perform non-linear activation
     *  \param alpha        the alpha value in cudnn for convolution
     *  \param beta         the beta value in cudnn for convolution
     */
    void initialize(const std::string& name,
                    const std::string& conv_name,
                    const std::string& bn_name,
                    int in_channels,
                    int out_channels,
                    const vec2d<int>& ksize2,
                    const vec2d<int>& stride2,
                    const vec2d<int>& pad2 = vec2d<int>(0, 0),
                    const vec2d<int>& dilate2 = vec2d<int>(1, 1),
                    int num_groups = 1,
                    bool enable_bias = true,
                    bool do_act = true,
                    float alpha = 1.0f,
                    float beta = 0.0f);

    /*! \brief detailed implementation of set_param_ptrs */
    virtual neuroError_t set_param_ptrs(const ParamDictType& param_dict);

    /*! \brief detailed implementation of create_descs */
    virtual neuroError_t create_descs(cudnnHandle_t handle,
                              const Tensor& intensor,
                              Tensor& outtensor,
                              bool infer_shape,
                              size_t& max_layer_size,
                              size_t& workspace_size);

    /*! \brief detailed implementation of forward */
    virtual neuroError_t forward(Tensor& intensor, Tensor& outtensor, void* workspace);

private:

    std::string m_name, m_conv_name, m_bn_name;
    cudnnHandle_t m_cudnn_handle;
    bool m_do_act;

    Conv2 m_conv;
    BN2 m_bn;
    Elu m_act;
};


}

#endif

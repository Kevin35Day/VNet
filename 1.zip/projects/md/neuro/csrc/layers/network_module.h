#ifndef NEURO_NETWORK_MODULE_H
#define NEURO_NETWORK_MODULE_H

#include <cudnn.h>
#include <unordered_map>
#include "neuro/csrc/filter.h"
#include "neuro/csrc/tensor.h"
#include "neuro/csrc/errors.h"

namespace medvision {

/*! \brief the interface for all network module
 *
 *  1. Use set_param_ptrs to setup parameter pointers from loaded parameter dictionary.
 *  2. Use create_descs to create cudnn descriptors and estimate gpu memory usage.
 *  3. Use forward to perform forward propagation.
 */
class NetworkModule
{
public:
    /*! \brief parameter-to-pointer dictionary type */
    typedef std::unordered_map<std::string, void*> ParamDictType;

    /*! \brief virtual destructor */
    virtual ~NetworkModule();

    /*! \brief setup module parameter pointers using loaded parameter dictionary
     *
     *  All network parameters are loaded once in a big chunk. The parameter dictionary
     *  records the mapping between parameter name to their device pointers.
     *
     *  In this function, the implementer needs to use their module parameter names to
     *  find out the location of parameter values, e.g., device pointers.
     *
     *  \param param_dict       the parameter dictionary
     *  \return a neuro error code
     */
    virtual neuroError_t set_param_ptrs(const ParamDictType& param_dict) = 0;

    /*! \brief create cudnn descriptors and estimate gpu memory usage
     *
     *  Given a valid input tensor with or without device pointer set,
     *  this function can create the right descriptor for output tensor.
     *
     *  Besides, it also estimates the maximum byte size of input and
     *  output layers in this module, as well as the maximum workspace size
     *  required by cudnn library to perform operations, e.g., convolution,
     *  transposed-convolution.
     *
     *  \param handle           a cudnn handle
     *  \param intensor         the input tensor (must have a valid descriptor)
     *                          no need to setup its pointer.
     *  \param outtensor        the output tensor
     *                          if infer_shape is true, its descriptor will be created by function.
     *                          if infer_shape is false, the tensor must have a valid descriptor
     *  \param infer_shape      whether to create descriptor for output tensor
     *  \param max_layer_size   current max layer size. If the module needs larger layer size,
     *                          it will update this value.
     *  \param workspace_size   current max workspace size. If the module needs larger workspace size,
     *                          it will update this value.
     */
    virtual neuroError_t create_descs(cudnnHandle_t handle,
                                      const Tensor& intensor,
                                      Tensor& outtensor,
                                      bool infer_shape,
                                      size_t& max_layer_size,
                                      size_t& workspace_size) = 0;

    /*! \brief forward propagation of network module
     *
     *  Given input and output tensor with device memory setup, this function
     *  performs forward propagation to get right value in the output tensor.
     *
     *  \param intensor        the input tensor with device pointer setup
     *  \param outtensor       the output tensor with device pointer setup
     *  \param workspace       the device pointer to workspace memory
     */
    virtual neuroError_t forward(Tensor& intensor, Tensor& outtensor, void* workspace) = 0;

};

}

#endif

#include "neuro/csrc/layers/bott_conv_bn_relu3.h"
#include <sstream>

namespace medvision {

//bottle neck conv bn relu implementation
BottConvBnRelu3::BottConvBnRelu3()
{
    m_cudnn_handle = nullptr;
}

BottConvBnRelu3::BottConvBnRelu3(const std::string& name,
                                 const std::string& downsample_name,
                                 const std::string& conv_name,
                                 const std::string& upsample_name,
                                 int in_channels,
                                 int out_channels,
                                 float ratio,
                                 const vec3d<int>& ksize3,
                                 const vec3d<int>& stride3,
                                 const vec3d<int>& pad3,
                                 const vec3d<int>& dilate3,
                                 int num_groups,
                                 bool enable_bias,
                                 bool do_act)
{
    initialize(name, downsample_name, conv_name, upsample_name, in_channels, out_channels, ratio,
               ksize3, stride3, pad3, dilate3, num_groups, enable_bias, do_act);
}

void BottConvBnRelu3::initialize(const std::string& name,
                                 const std::string& downsample_name,
                                 const std::string& conv_name,
                                 const std::string& upsample_name,
                                 int in_channels,
                                 int out_channels,
                                 float ratio,
                                 const vec3d<int> &ksize3,
                                 const vec3d<int> &stride3,
                                 const vec3d<int> &pad3,
                                 const vec3d<int> &dilate3,
                                 int num_groups,
                                 bool enable_bias,
                                 bool do_act)
{
    m_name = name;
    m_downsample_name = downsample_name;
    m_conv_name = conv_name;
    m_upsample_name = upsample_name;

    vec3d<int> bott_ksize3(1, 1, 1);
    vec3d<int> bott_stride3(1, 1, 1);
    vec3d<int> bott_pad3(0, 0, 0);
    vec3d<int> bott_dilate3(1, 1, 1);
    int bott_num_groups = 1;
    bool bott_enable_bias = true;
    int mid_channels = int(out_channels/ratio + 0.5f);

    std::stringstream ss;
    ss << name << "." << m_downsample_name;
    m_conv_bn_relu1.initialize(ss.str(), "conv", "bn", in_channels, mid_channels,
                       bott_ksize3, bott_stride3, bott_pad3, bott_dilate3, bott_num_groups, bott_enable_bias, true);

    ss.clear();
    ss.str(std::string(""));
    ss << name << "."  << m_conv_name;
    m_conv_bn_relu2.initialize(ss.str(), "conv", "bn", mid_channels, mid_channels,
                               ksize3, stride3, pad3, dilate3, num_groups, enable_bias, true);

    ss.clear();
    ss.str(std::string(""));
    ss << name << "." << m_upsample_name;
    m_conv_bn_relu3.initialize(ss.str(), "conv", "bn", mid_channels, out_channels,
                       bott_ksize3, bott_stride3, bott_pad3, bott_dilate3, bott_num_groups, bott_enable_bias, do_act);

    m_cudnn_handle = nullptr;

}

neuroError_t BottConvBnRelu3::set_param_ptrs(const ParamDictType& param_dict)
{
    checkNeuro(m_conv_bn_relu1.set_param_ptrs(param_dict));
    checkNeuro(m_conv_bn_relu2.set_param_ptrs(param_dict));
    checkNeuro(m_conv_bn_relu3.set_param_ptrs(param_dict));
    return Neuro_Success;
}

neuroError_t BottConvBnRelu3::create_descs(cudnnHandle_t cudnn_handle, const Tensor &intensor, Tensor &outtensor, bool infer_shape,
                              size_t &max_layer_size, size_t &workspace_size)
{
    m_cudnn_handle = cudnn_handle;
    checkNeuro(m_conv_bn_relu1.create_descs(cudnn_handle, intensor, m_temp_tensor1, true, max_layer_size, workspace_size));
    checkNeuro(m_conv_bn_relu2.create_descs(cudnn_handle, m_temp_tensor1, m_temp_tensor2, true, max_layer_size, workspace_size));
    checkNeuro(m_conv_bn_relu3.create_descs(cudnn_handle, m_temp_tensor2, outtensor, infer_shape, max_layer_size, workspace_size));
    return Neuro_Success;
}

neuroError_t BottConvBnRelu3::forward(Tensor &intensor, Tensor &outtensor, void *workspace)
{
    if (m_temp_tensor1.desc() == nullptr || m_temp_tensor2.desc() == nullptr || intensor.desc() == nullptr || outtensor.desc() == nullptr)
        return Neuro_EmptyDesc;

    m_temp_tensor1.set_ptr(outtensor.ptr());
    checkNeuro(m_conv_bn_relu1.forward(intensor, m_temp_tensor1, workspace));

    m_temp_tensor2.set_ptr(intensor.ptr());
    checkNeuro(m_conv_bn_relu2.forward(m_temp_tensor1, m_temp_tensor2, workspace));

    checkNeuro(m_conv_bn_relu3.forward(m_temp_tensor2, outtensor, workspace));

    return Neuro_Success;
}

}

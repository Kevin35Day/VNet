#include "neuro/csrc/layers/conv_bn_elu2.h"
#include <sstream>

namespace medvision {

// ConvBnElu2
ConvBnElu2::ConvBnElu2()
{
    m_cudnn_handle = nullptr;
}

ConvBnElu2::ConvBnElu2(const std::string& name,
                       const std::string& conv_name,
                       const std::string& bn_name,
                       int in_channels,
                       int out_channels,
                       const vec2d<int>& ksize2,
                       const vec2d<int>& stride2,
                       const vec2d<int>& pad2,
                       const vec2d<int>& dilate2,
                       int num_groups,
                       bool enable_bias,
                       bool do_act,
                       float alpha,
                       float beta)
{
    initialize(name, conv_name, bn_name, in_channels, out_channels, ksize2, stride2, pad2, dilate2, num_groups, enable_bias, do_act, alpha, beta);
}

void ConvBnElu2::initialize(const std::string& name,
                             const std::string& conv_name,
                             const std::string& bn_name,
                             int in_channels,
                             int out_channels,
                             const vec2d<int>& ksize2,
                             const vec2d<int>& stride2,
                             const vec2d<int>& pad2,
                             const vec2d<int>& dilate2,
                             int num_groups,
                             bool enable_bias,
                             bool do_act,
                             float alpha,
                             float beta)
{
    m_name = name;
    m_conv_name = conv_name;
    m_bn_name = bn_name;
    m_do_act = do_act;

    std::stringstream ss;
    ss << name << "." << conv_name;
    m_conv.initialize(ss.str(), in_channels, out_channels, ksize2, stride2, pad2, dilate2, num_groups, enable_bias, alpha, beta);

    ss.clear();
    ss.str(std::string(""));

    ss << name << "." << bn_name;
    m_bn.initialize(ss.str());

    m_cudnn_handle = nullptr;
}

neuroError_t ConvBnElu2::set_param_ptrs(const ParamDictType& param_dict)
{
    checkNeuro(m_conv.set_param_ptrs(param_dict));
    checkNeuro(m_bn.set_param_ptrs(param_dict));
    return Neuro_Success;
}

neuroError_t ConvBnElu2::create_descs(cudnnHandle_t cudnn_handle, const Tensor& intensor, Tensor& outtensor,
                                       bool infer_shape, size_t& max_layer_size, size_t& workspace_size)
{
    m_cudnn_handle = cudnn_handle;
    checkNeuro(m_conv.create_descs(cudnn_handle, intensor, outtensor, infer_shape, max_layer_size, workspace_size));
    checkNeuro(m_bn.create_descs(cudnn_handle, outtensor, outtensor, false, max_layer_size, workspace_size));
    if(m_do_act)
        checkNeuro(m_act.create_descs(cudnn_handle, outtensor, outtensor, false, max_layer_size, workspace_size));
    return Neuro_Success;
}

neuroError_t ConvBnElu2::forward(Tensor& intensor, Tensor& outtensor, void* workspace)
{
    checkNeuro(m_conv.forward(intensor, outtensor, workspace));
    checkNeuro(m_bn.forward(outtensor, outtensor, workspace));
    if(m_do_act)
        checkNeuro(m_act.forward(outtensor, outtensor, workspace));
    return Neuro_Success;
}


}

#include "neuro/csrc/layers/convtranspose3.h"
#include "neuro/csrc/layers/tensor_ops.h"

namespace medvision {

// transposed convolution
ConvTranspose3::ConvTranspose3()
{
    initialize("", 0, 0, vec3d<int>(1, 1, 1), vec3d<int>(1, 1, 1), vec3d<int>(0, 0, 0));
}

ConvTranspose3::ConvTranspose3(const std::string& name,
                               int in_channels,
                               int out_channels,
                               const vec3d<int>& ksize3,
                               const vec3d<int>& stride3,
                               const vec3d<int>& pad3,
                               const vec3d<int>& dilate3,
                               int num_groups,
                               bool enable_bias,
                               float alpha,
                               float beta)
{
    initialize(name, in_channels, out_channels, ksize3, stride3, pad3, dilate3, num_groups, enable_bias, alpha, beta);
}


ConvTranspose3::~ConvTranspose3()
{
    if(m_convdesc != nullptr) {
        cudnnThrowError(cudnnDestroyConvolutionDescriptor(m_convdesc));
        m_convdesc = nullptr;
    }
}

void ConvTranspose3::initialize(const std::string& name,
                                int in_channels,
                                int out_channels,
                                const vec3d<int>& ksize3,
                                const vec3d<int>& stride3,
                                const vec3d<int>& pad3,
                                const vec3d<int>& dilate3,
                                int num_groups,
                                bool enable_bias,
                                float alpha,
                                float beta)
{
    m_name = name;
    m_inchannels = in_channels;
    m_outchannels = out_channels;
    m_ksize3 = ksize3;
    m_stride3 = stride3;
    m_pad3 = pad3;
    m_dilate3 = dilate3;
    m_num_groups = num_groups;
    m_enable_bias = enable_bias;
    m_convdesc = nullptr;
    m_alpha = alpha;
    m_beta = beta;

    // switch output and input channels
    int filter_size[] = {in_channels, out_channels, ksize3[0], ksize3[1], ksize3[2]};
    m_filter.set_size(filter_size);

    if(m_enable_bias) {
        int bias_size[] = {1, out_channels, 1, 1, 1};
        m_bias.set_size(bias_size);
    }

    m_bwdalg = CUDNN_CONVOLUTION_BWD_DATA_ALGO_0;
    m_cudnn_handle = nullptr;
    m_workspace_size = 0;
}

neuroError_t ConvTranspose3::set_param_ptrs(const ParamDictType& param_dict)
{
    std::string weight_name = m_name + std::string(".weight");
    std::string bias_name = m_name + std::string(".bias");

    auto it = param_dict.find(weight_name);
    if(it == param_dict.end()) {
        std::cerr << "ConvTranpose3: " << weight_name << " not found!" << std::endl;
        return Neuro_ParamNotFound;
    } else {
        m_filter.set_ptr(it->second);
    }

    it = param_dict.find(bias_name);
    if(it == param_dict.end()) {
        std::cerr << "ConvTranpose3: " << bias_name << " not found!" << std::endl;
        return Neuro_ParamNotFound;
    } else {
        m_bias.set_ptr(it->second);
    }
    return Neuro_Success;
}

neuroError_t ConvTranspose3::create_descs(cudnnHandle_t handle, const Tensor& intensor, Tensor& outtensor,
                                   bool infer_shape, size_t& max_layer_size, size_t& workspace_size)
{
    if(intensor.desc() == nullptr)
        return Neuro_EmptyDesc;

    m_cudnn_handle = handle;

    if(m_convdesc != nullptr) {
        cudnnThrowError(cudnnDestroyConvolutionDescriptor(m_convdesc));
        m_convdesc = nullptr;
    }

    // cuda init for filter and bias
    m_filter.create_desc();
    if(m_enable_bias)
        m_bias.create_desc();

    // setup convolution descriptor
    cudnnThrowError(cudnnCreateConvolutionDescriptor(&m_convdesc));
    cudnnThrowError(cudnnSetConvolutionNdDescriptor(m_convdesc, 3, m_pad3.data(), m_stride3.data(), m_dilate3.data(),
                                                    CUDNN_CROSS_CORRELATION, CUDNN_DATA_FLOAT));

#if CUDNN_MAJOR == 7
    if(m_num_groups != 1)
        cudnnThrowError(cudnnSetConvolutionGroupCount(m_convdesc, m_num_groups));
    cudnnThrowError(cudnnSetConvolutionMathType(m_convdesc, CUDNN_TENSOR_OP_MATH));
#endif

    // setup output tensor descriptor
    if(infer_shape) {
        const int* insize_ptr = intensor.size();

        int out_dims[5];
        out_dims[0] = insize_ptr[0];
        out_dims[1] = m_filter.size()[1];
        for(int i = 2; i < 5; ++i) {
            int s = m_stride3[i - 2], p = m_pad3[i - 2], d = m_dilate3[i - 2], f = m_filter.size()[i];
            out_dims[i] = (insize_ptr[i] - 1) * s - 2 * p + d * (f - 1) + 1;
        }

        outtensor.set_size(out_dims);
        outtensor.create_desc();
    }

    if(outtensor.desc() == nullptr)
        return Neuro_EmptyDesc;

    // choose best forward algorithm
#if CUDNN_MAJOR == 7

    int num_alg = 0;
    cudnnConvolutionBwdDataAlgoPerf_t alg_perf;
    cudnnThrowError(cudnnGetConvolutionBackwardDataAlgorithm_v7(handle, m_filter.desc(), intensor.desc(),
                                                                m_convdesc, outtensor.desc(), 1, &num_alg, &alg_perf));

    if(num_alg != 1)
        return Neuro_NoBwdAlg;

    m_bwdalg = alg_perf.algo;

#else

    cudnnThrowError(cudnnGetConvolutionBackwardDataAlgorithm(handle, m_filter.desc(), intensor.desc(), m_convdesc,
                                                             outtensor.desc(), CUDNN_CONVOLUTION_BWD_DATA_PREFER_FASTEST,
                                                             0, &m_bwdalg));

#endif

    // compute workspace size and update if necessary
    cudnnThrowError(cudnnGetConvolutionBackwardDataWorkspaceSize(handle, m_filter.desc(), intensor.desc(),
                                                                 m_convdesc, outtensor.desc(), m_bwdalg, &m_workspace_size));
    workspace_size = std::max<size_t>(workspace_size, m_workspace_size);

    // compute max layer size and update if necessary
    size_t local_max_layer_size = std::max<size_t>(intensor.bytes(), outtensor.bytes());
    max_layer_size = std::max<size_t>(max_layer_size, local_max_layer_size);

    return Neuro_Success;
}

neuroError_t ConvTranspose3::forward(Tensor& intensor, Tensor& outtensor, void* workspace)
{
    if(m_cudnn_handle == nullptr) {
        std::cerr << "ConvTranspose3: m_cudnn_handle == nullptr" << std::endl;
        return Neuro_InvalidContext;
    }

    if(intensor.desc() == nullptr || outtensor.desc() == nullptr)
        return Neuro_EmptyDesc;

    cudnnThrowError(cudnnConvolutionBackwardData(m_cudnn_handle, &m_alpha,
                                                 m_filter.desc(), m_filter.ptr(),
                                                 intensor.desc(), intensor.ptr(),
                                                 m_convdesc, m_bwdalg, workspace, m_workspace_size,
                                                 &m_beta, outtensor.desc(), outtensor.ptr()));

    if(m_enable_bias)
        checkNeuro(TensorOps::add(m_cudnn_handle, 1.0f, m_bias, 1.0f, outtensor));

    return Neuro_Success;
}


}

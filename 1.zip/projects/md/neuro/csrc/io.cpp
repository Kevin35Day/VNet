#include <neuro/csrc/io.h>
#include <cstdio>
#include <cstring>
#include <iostream>

namespace medvision {


NeuroFile::NeuroFile(const char* version_num): m_fp(nullptr)
{
    m_version_text = std::string("neuro_v") + std::string(version_num);
}

NeuroFile::~NeuroFile()
{
    close();
}

neuroError_t NeuroFile::open(const char* path)
{
    if(m_fp != nullptr)
        close();

    m_fp = fopen(path, "rb");
    if(m_fp == NULL) {
        m_fp = nullptr;
        return Neuro_FileNotFound;
    }

    char buffer[128];
    memset(buffer, 0, sizeof(char) * 128);

    size_t bytes_read = fread(buffer, 1, m_version_text.size(), m_fp);
    if(bytes_read != m_version_text.size()) {
        close(); return Neuro_ReadIncomplete;
    }

    if(std::string(buffer) != m_version_text) {
        close(); return Neuro_WrongVersion;
    }

    int num_keys = 0;
    if(fread(&num_keys, sizeof(int), 1, m_fp) != 1) {
        close(); return Neuro_ReadIncomplete;
    }

    for(int i = 0; i < num_keys; ++i) {
        if(fread(buffer, sizeof(char), 128, m_fp) != 128) {
            close(); return Neuro_ReadIncomplete;
        }

        std::string name = std::string(buffer);

        int value = 0;
        if(fread(&value, sizeof(int), 1, m_fp) != 1) {
            close(); return Neuro_ReadIncomplete;
        }
        m_starts[name] = value;

        if(fread(&value, sizeof(int), 1, m_fp) != 1) {
            close(); return Neuro_ReadIncomplete;
        }
        m_sizes[name] = value;
    }

    return Neuro_Success;
}


void NeuroFile::close()
{
    if(m_fp != nullptr) {
        fclose(m_fp);
        m_fp = nullptr;
    }

    m_starts.clear();
    m_sizes.clear();
}


neuroError_t NeuroFile::read(const char* name, void* buffer)
{
    if(m_fp == nullptr) {
        return Neuro_InvalidObject;
    }

    auto iter = m_starts.find(std::string(name));
    if(iter == m_starts.end()) {
        return Neuro_InvalidObject;
    }
    size_t start = iter->second;

    iter = m_sizes.find(std::string(name));
    if(iter == m_sizes.end()) {
        return Neuro_InvalidObject;
    }
    size_t size = iter->second;

    if(fseek(m_fp, static_cast<long>(start), SEEK_SET) != 0) {
        return Neuro_SeekFailure;
    }

    if(fread(buffer, sizeof(char), size, m_fp) != size) {
        return Neuro_ReadIncomplete;
    }

    return Neuro_Success;
}


neuroError_t NeuroFile::read(void* buffer)
{
    if(m_fp == nullptr) {
        return Neuro_InvalidObject;
    }

    size_t data_offset = get_data_offset();
    size_t data_bytes = get_data_bytes();

    if(fseek(m_fp, static_cast<long>(data_offset), SEEK_SET) != 0) {
        return Neuro_SeekFailure;
    }

    if(fread(buffer, sizeof(char), data_bytes, m_fp) != data_bytes) {
        return Neuro_ReadIncomplete;
    }

    return Neuro_Success;
}


size_t NeuroFile::pos_in_datablock(const std::string& name) const
{
    size_t data_start = get_data_offset();
    auto it = m_starts.find(name);
    if(it == m_starts.end()) {
        std::cerr << "[Error] Unknown parameter name" << std::endl;
        return 0;
    }

    size_t data_pos = it->second;
    size_t pos = data_pos - data_start;
    return pos;
}


std::vector<std::string> NeuroFile::list_names() const
{
    std::vector<std::string> names;
	for(auto v = m_starts.begin(); v != m_starts.end(); ++v) {
        names.push_back(v->first);
    }
    return names;
}


size_t NeuroFile::get_byte_size(const char* name) const
{
    auto iter = m_sizes.find(std::string(name));
    if(iter == m_sizes.end())
        return 0;
    else
        return iter->second;
}


size_t NeuroFile::get_data_offset() const
{
    int key_buffersize = 128;
    size_t data_offset = m_version_text.size() + 4 + m_starts.size() * (key_buffersize + 8);
    return data_offset;
}


size_t NeuroFile::get_data_bytes() const
{
    size_t size = 0;
	for(auto v = m_sizes.begin(); v != m_sizes.end(); ++v) {
        size += v->second;
    }
    return size;
}


}

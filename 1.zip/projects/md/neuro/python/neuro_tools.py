import numpy as np
import torch
import struct

class NeuroFile(object):
    """
    Neuro file format:

    'neuro_v2.0.0' + number of keys
    key1_name + key1_datastart + key1_datalength + ... keyn_name + keyn_datastart + keynlength
    key1_data + key2_data + key3_data + ...
    """

    def __init__(self, version_num):

        assert isinstance(version_num, str)
        self.version_num = version_num
        self.key_value_dict = {}


    def put_key(self, key, value):

        assert isinstance(key, str)
        if isinstance(value, np.ndarray):
            self.key_value_dict[key] = value.tobytes('C')
        elif isinstance(value, torch.FloatTensor) or isinstance(value, torch.cuda.FloatTensor):
            self.key_value_dict[key] = value.cpu().numpy().tobytes('C')
        elif isinstance(value, int):
            self.key_value_dict[key] = struct.pack('i', value)
        elif isinstance(value, float):
            self.key_value_dict[key] = struct.pack('f', value)
        elif isinstance(value, str):
            assert len(value) % 4 == 0, 'length of string must be 32-bit aligned'
            self.key_value_dict[key] = value
        elif isinstance(value, bytearray):
            assert len(value) % 4 == 0, 'length of bytearray must be 32-bit aligned'
            self.key_value_dict[key] = value
        else:
            raise ValueError('Unsupported value type!')


    def write(self, filename):

        version_txt = 'neuro_v{}'.format(self.version_num)
        assert len(version_txt) % 4 == 0, 'version txt must be multiple of 32 bits'

        key_buffersize = 128
        data_start = len(version_txt) + 4 + len(self.key_value_dict) * (key_buffersize + 8)

        with open(filename, 'wb') as f:

            f.write(version_txt)
            start = data_start

            # write out number of keys
            f.write(struct.pack('i', len(self.key_value_dict)))

            # write header
            for key, value in self.key_value_dict.iteritems():
                # write out key
                buffer = bytearray(key_buffersize)
                buffer[:len(key)] = key
                f.write(buffer)

                # write out start position
                buffer = struct.pack('i', start)
                f.write(buffer)

                # write out buffer size
                buffer = struct.pack('i', len(value))
                f.write(buffer)

                # move start memory pointer
                start += len(value)

            # write parameters
            for _, value in self.key_value_dict.iteritems():
                f.write(value)




"""
functions to manipulate image3d class

this file includes

lib:        a library object that contains library handle
fun_dict:   a dictionary contains function pointers
load:       load existing dynamic library
unload:     release loaded dynamic library

"""

import ctypes
import _ctypes
import platform
import os
import numpy as np
from md.image3d.python.image3d import Image3d
from medtypes import type_to_ctypes
from md.image3d.python.frame3d import Frame3d
from md.utils.python.find_dll import find_dll
from md.image3d.python.image3d_io import read_image


# dynamic library
lib = None

# function pointer dictionary
fun_dict = {}


def __get_library_path():

    dll_file = find_dll('pyimage3d_tools')
    if dll_file is None:
        raise OSError('dll not found')
    return dll_file


def __load_c_functions():

    global lib, fun_dict

    lib = ctypes.cdll.LoadLibrary(__get_library_path())

    lib.image3d_slice_nn.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p,
                                    ctypes.c_double, ctypes.c_double, ctypes.c_int32, ctypes.c_int32, ctypes.c_void_p, ctypes.c_double]
    lib.image3d_slice_nn.restype = ctypes.c_bool
    fun_dict['image3d_slice_nn'] = lib.image3d_slice_nn

    lib.image3d_create_like.argtypes = [ctypes.c_void_p]
    lib.image3d_create_like.restype = ctypes.c_void_p
    fun_dict['image3d_create_like'] = lib.image3d_create_like

    lib.image3d_estimate_intensity_window.argtypes = [ctypes.c_void_p, ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p]
    lib.image3d_estimate_intensity_window.restype = None
    fun_dict['image3d_estimate_intensity_window'] = lib.image3d_estimate_intensity_window

    lib.image3d_random_voxels.argtypes = [ctypes.c_void_p, ctypes.c_int32, ctypes.c_double, ctypes.c_double, ctypes.c_void_p]
    lib.image3d_random_voxels.restype = ctypes.c_int32
    fun_dict['image3d_random_voxels'] = lib.image3d_random_voxels

    lib.image3d_resample_nn.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int32, ctypes.c_void_p]
    lib.image3d_resample_nn.restype = None
    fun_dict['image3d_resample_nn'] = lib.image3d_resample_nn

    lib.image3d_resample_nn_bb.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int32,
                                        ctypes.c_void_p]
    lib.image3d_resample_nn_bb.restype = None
    fun_dict['image3d_resample_nn_bb'] = lib.image3d_resample_nn_bb

    lib.image3d_crop.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p]
    lib.image3d_crop.restype = None
    fun_dict['image3d_crop'] = lib.image3d_crop

    lib.image3d_convert_multi_label_to_binary.argtypes = [ctypes.c_void_p, ctypes.c_int32]
    lib.image3d_convert_multi_label_to_binary.restype = None
    fun_dict['image3d_convert_multi_label_to_binary'] = lib.image3d_convert_multi_label_to_binary

    lib.image3d_intensity_normalize.argtypes = [ctypes.c_void_p, ctypes.c_double, ctypes.c_double, ctypes.c_bool]
    lib.image3d_intensity_normalize.restype = None
    fun_dict['image3d_intensity_normalize'] = lib.image3d_intensity_normalize

    lib.image3d_mass_voxel_center.argtypes = [ctypes.c_void_p, ctypes.c_double, ctypes.c_double, ctypes.c_void_p]
    lib.image3d_mass_voxel_center.restype = ctypes.c_bool
    fun_dict['image3d_mass_voxel_center'] = lib.image3d_mass_voxel_center

    lib.image3d_weighted_mass_voxel_center.argtypes = [ctypes.c_void_p, ctypes.c_double, ctypes.c_double, ctypes.c_void_p]
    lib.image3d_weighted_mass_voxel_center.restype = ctypes.c_bool
    fun_dict['image3d_weighted_mass_voxel_center'] = lib.image3d_weighted_mass_voxel_center

    lib.image3d_boundingbox_voxel.argtypes = [ctypes.c_void_p, ctypes.c_double, ctypes.c_double, ctypes.c_void_p, ctypes.c_void_p]
    lib.image3d_boundingbox_voxel.restype = ctypes.c_bool
    fun_dict['image3d_boundingbox_voxel'] = lib.image3d_boundingbox_voxel

    lib.image3d_pick_largest_component.argtypes = [ctypes.c_void_p]
    lib.image3d_pick_largest_component.restype = ctypes.c_size_t
    fun_dict['image3d_pick_largest_component'] = lib.image3d_pick_largest_component

    lib.image3d_replace_pixel.argtypes = [ctypes.c_void_p, ctypes.c_double, ctypes.c_double]
    lib.image3d_replace_pixel.restype = None
    fun_dict['image3d_replace_pixel'] = lib.image3d_replace_pixel

    lib.image3d_hist_match.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    lib.image3d_hist_match.restype = None
    fun_dict['image3d_hist_match'] = lib.image3d_hist_match

    lib.image3d_max_min_avg.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p]
    lib.image3d_max_min_avg.restype = None
    fun_dict['image3d_max_min_avg'] = lib.image3d_max_min_avg

    lib.image3d_percentiles.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int32, ctypes.c_void_p]
    lib.image3d_percentiles.restype = None
    fun_dict['image3d_percentiles'] = lib.image3d_percentiles

    lib.image3d_get_pixel_value.argtypes = [ctypes.c_void_p, ctypes.c_int32, ctypes.c_int32, ctypes.c_int32]
    lib.image3d_get_pixel_value.restype = ctypes.c_double
    fun_dict['image3d_get_pixel_value'] = lib.image3d_get_pixel_value

    lib.image3d_set_pixel_value.argtypes = [ctypes.c_void_p, ctypes.c_int32, ctypes.c_int32, ctypes.c_int32, ctypes.c_double]
    lib.image3d_set_pixel_value.restype = None
    fun_dict['image3d_set_pixel_value'] = lib.image3d_set_pixel_value

    lib.image3d_count_labels.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    lib.image3d_count_labels.restype = ctypes.c_int32
    fun_dict['image3d_count_labels'] = lib.image3d_count_labels

    lib.image3d_boundingbox_voxel_multi.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int32, ctypes.c_void_p]
    lib.image3d_boundingbox_voxel_multi.restype = None
    fun_dict['image3d_boundingbox_voxel_multi'] = lib.image3d_boundingbox_voxel_multi

    lib.image3d_imflip.argtypes = [ctypes.c_void_p, ctypes.c_int32]
    lib.image3d_imflip.restype = None
    fun_dict['image3d_imflip'] = lib.image3d_imflip

    lib.image3d_impad.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    lib.image3d_impad.restype = None
    fun_dict['image3d_impad'] = lib.image3d_impad


def unload():

    global lib, fun_dict

    try:
        while lib is not None:
            if platform.system() == 'Windows':
                _ctypes.FreeLibrary(lib._handle)
            else:
                _ctypes.dlclose(lib._handle)
    except:
        lib = None
        fun_dict = {}


def load():

    unload()
    __load_c_functions()


# load dynamic library
load()


def load_c_functions_if_necesary():

    if len(fun_dict) == 0:
        print '[info] pyimage3d_tools dll reloaded'
        __load_c_functions()


def call_func(func_name, *args):

    load_c_functions_if_necesary()

    if len(args) == 0:
        return fun_dict[func_name]()
    else:
        return fun_dict[func_name](*args)


def slice_nn(image, cursor, axis_x, axis_y, center, spacing, plane_size, default_value):
    """
    get an arbitrary 2D slice from 3D volume
    :param image: image3d object
    :param cursor: the 3d world coordinate of a cursor
    :param axis_x: the x axis of 2D plane
    :param axis_y: the y axis of 2D plane
    :param center: the 3D center location (focus)
    :param spacing: the 2D spacing of 2D plane
    :param plane_size: the size of 2D plane
    :param default_value: the value for exterpolation
    :return: a 2D nd array corresponding to the slice
    """
    assert isinstance(image, Image3d), 'image must be an image3d object'

    cursor = np.ascontiguousarray(cursor, dtype=np.double)
    cursor_ptr = cursor.ctypes.data_as(ctypes.POINTER(ctypes.c_double))

    axis_x = np.ascontiguousarray(axis_x, dtype=np.double)
    axis_x_ptr = axis_x.ctypes.data_as(ctypes.POINTER(ctypes.c_double))

    axis_y = np.ascontiguousarray(axis_y, dtype=np.double)
    axis_y_ptr = axis_y.ctypes.data_as(ctypes.POINTER(ctypes.c_double))

    dot_prod = np.sum(axis_x * axis_y)
    if abs(dot_prod) > 1e-4:
        print('[warning] two axes are not strictly orthogonal (dot_prod: {:.4f})'.format(dot_prod))

    center = np.ascontiguousarray(center, dtype=np.double)
    center_ptr = center.ctypes.data_as(ctypes.POINTER(ctypes.c_double))

    width, height = ctypes.c_int32(plane_size[0]), ctypes.c_int32(plane_size[1])
    x_spacing, y_spacing = ctypes.c_double(spacing[0]), ctypes.c_double(spacing[1])
    default_value = ctypes.c_double(default_value)

    dtype = image.pixel_type()
    out_slice = np.empty((height.value, width.value), dtype=dtype)
    out_slice_ptr = out_slice.ctypes.data_as(ctypes.POINTER(type_to_ctypes[dtype]))

    call_func('image3d_slice_nn', image.ptr, cursor_ptr, axis_x_ptr, axis_y_ptr, center_ptr, x_spacing, y_spacing,
                                 width, height, out_slice_ptr, default_value)

    return out_slice


def create_image3d_like(image, fill_value=None):
    """
    create an image3d object with same size and frame as the input image
    :param image: a reference image
    :param fill_value: None if not fill, otherwise fill with constant
    :return: a new image3d object
    """
    ptr = call_func('image3d_create_like', image.ptr)
    obj = Image3d(ptr)

    if fill_value is not None:
        obj.fill(fill_value)

    return obj


def estimate_intensity_window(image, slice_only):
    """
    estimate intensity window from image
    :param image: image3d object
    :param slice_only: true using only the middle slice, false using the entire volume
    :return: intensity_center, intensity_width
    """
    assert isinstance(image, Image3d), 'image must be an image3d object'
    assert image.ptr is not None, 'invalid image object'
    intensity_center, intensity_width = ctypes.c_double(), ctypes.c_double()
    call_func('image3d_estimate_intensity_window', image.ptr, slice_only, ctypes.byref(intensity_center), ctypes.byref(intensity_width))
    return intensity_center.value, intensity_width.value


def random_voxels(image, num, min_val, max_val):
    """
    random sample voxels from intensity image
    :param image: the image
    :param num: the number of random voxels
    :param min_val: the minimum value (inclusive)
    :param max_val: the maximum value (inclusive)
    :return: object voxels
    """
    assert isinstance(image, Image3d), 'mask must be an image3d object'
    assert image.ptr is not None, 'invalid image object'

    voxels = np.empty((num, 3), dtype=np.int32)
    voxels_ptr = voxels.ctypes.data_as(ctypes.POINTER(ctypes.c_int32))

    num = ctypes.c_int32(num)
    min_val = ctypes.c_double(min_val)
    max_val = ctypes.c_double(max_val)

    ret = call_func('image3d_random_voxels', image.ptr, num, min_val, max_val, voxels_ptr)

    return voxels[:ret, :]


def resample_nn(image, frame, size, padtype=0):
    """
    resample a sub-volume from volume using nearest neighbor
    :param image:   an image3d object
    :param frame:   an frame3d object
    :param size:    the three dimension
    :param padtype: padding type, 0 for zero-padding, 1 for edge padding
    :return: a sub-volume image3d object
    """
    assert isinstance(image, Image3d), 'image must be an image3d object'
    assert isinstance(frame, Frame3d), 'frame must be a frame3d object'

    size = np.array(size, dtype=np.int32)
    size = np.ascontiguousarray(size, dtype=np.int32)
    size_ptr = size.ctypes.data_as(ctypes.POINTER(ctypes.c_int32))

    padtype = ctypes.c_int32(padtype)

    ret = Image3d()
    call_func('image3d_resample_nn', image.ptr, frame.ptr, size_ptr, padtype, ret.ptr)

    return ret


def resample_nn_bb(image, frame, size, mincorner, maxcorner, padtype=0):
    """
    resample a sub-volume from volume using nearest neighbor, voxels out of bounding box [mincorner, maxconer] are ignored
    :param image:   an image3d object
    :param frame:   an frame3d object
    :param size:    the three dimension
    :param mincorner:    mincorner in voxel coordinate of input image space
    :param maxcorner:    maxcorner in voxel coordinate of input image space
    :param padtype: padding type, 0 for zero-padding, 1 for edge padding
    :return: a sub-volume image3d object
    """
    assert isinstance(image, Image3d), 'image must be an image3d object'
    assert isinstance(frame, Frame3d), 'frame must be a frame3d object'

    size = np.array(size, dtype=np.int32)
    size = np.ascontiguousarray(size, dtype=np.int32)
    size_ptr = size.ctypes.data_as(ctypes.POINTER(ctypes.c_int32))

    mincorner = np.array(mincorner, dtype=np.int32)
    mincorner = np.ascontiguousarray(mincorner, dtype=np.int32)
    mincorner_ptr = mincorner.ctypes.data_as(ctypes.POINTER(ctypes.c_int32))

    maxcorner = np.array(maxcorner, dtype=np.int32)
    maxcorner = np.ascontiguousarray(maxcorner, dtype=np.int32)
    maxcorner_ptr = maxcorner.ctypes.data_as(ctypes.POINTER(ctypes.c_int32))

    padtype = ctypes.c_int32(padtype)

    ret = Image3d()
    call_func('image3d_resample_nn_bb', image.ptr, frame.ptr, size_ptr, mincorner_ptr, maxcorner_ptr, padtype, ret.ptr)

    return ret


def crop(image, sp, ep):
    """
    crop a sub-volume from the entire volume
    :param image: an image3d object
    :param sp: start coordinate (inclusive)
    :param ep: end coordinate (exclusive)
    :return: a cropped image3d object
    """
    assert isinstance(image, Image3d), 'image must be an image3d object'

    sp = np.array(sp, dtype=np.int32)
    sp = np.ascontiguousarray(sp, dtype=np.int32)
    sp_ptr = sp.ctypes.data_as(ctypes.POINTER(ctypes.c_int32))

    ep = np.array(ep, dtype=np.int32)
    ep = np.ascontiguousarray(ep, dtype=np.int32)
    ep_ptr = ep.ctypes.data_as(ctypes.POINTER(ctypes.c_int32))

    out = Image3d()
    call_func('image3d_crop', image.ptr, sp_ptr, ep_ptr, out.ptr)

    return out


def convert_multi_label_to_binary(image, label):
    """
    inplace convert multi-class label map to binary label map
    :param image: an image3d object
    :param label: the target label
    :return: None
    """
    assert isinstance(image, Image3d), 'image must be an image3d object'

    label = ctypes.c_int32(label)
    call_func('image3d_convert_multi_label_to_binary', image.ptr, label)


def intensity_normalize(image, mean, stddev, clip):
    """
    inplace normalize the intensity within image using mean and standard deviation
    :param image: the image3d object
    :param mean: the mean intensity
    :param stddev: the standard deviation
    :param clip: whether to clip value between -1 and 1
    :return: None
    """
    assert isinstance(image, Image3d), 'image must be an image3d object'

    mean, stddev = ctypes.c_double(mean), ctypes.c_double(stddev)
    clip = ctypes.c_bool(clip)

    call_func('image3d_intensity_normalize', image.ptr, mean, stddev, clip)


def mass_voxel_center(image, min_val, max_val):
    """
    calculate the mass center of voxels within intensity range
    :param image: the image3d object
    :param min_val: min of intensity range (inclusive)
    :param max_val: max of intensity range (inclusive)
    :return: voxel coordinate of mass center
    """
    assert isinstance(image, Image3d), 'image must be an image3d object'

    voxel = np.empty(3, dtype=np.double)
    voxel_ptr = voxel.ctypes.data_as(ctypes.POINTER(ctypes.c_double))

    min_val = ctypes.c_double(min_val)
    max_val = ctypes.c_double(max_val)
    ret=call_func('image3d_mass_voxel_center', image.ptr, min_val, max_val, voxel_ptr)

    if ret:
        return voxel
    else:
        return None


def weighted_mass_voxel_center(image, min_val, max_val):
    """
    calculate the mass center of voxels within intensity range weighted by the voxel intensity.
    :param image: the image3d object
    :param min_val: min of intensity range (inclusive)
    :param max_val: max of intensity range (inclusive)
    :return: voxel coordinate of mass center
    """
    assert isinstance(image, Image3d), 'image must be an image3d object'

    voxel = np.empty(3, dtype=np.double)
    voxel_ptr = voxel.ctypes.data_as(ctypes.POINTER(ctypes.c_double))

    min_val = ctypes.c_double(min_val)
    max_val = ctypes.c_double(max_val)
    ret = call_func('image3d_weighted_mass_voxel_center', image.ptr, min_val, max_val, voxel_ptr)

    if ret:
        return voxel
    else:
        return None


def bounding_box_voxel(image, min_val, max_val):
    """
    calculate the bounding box of voxels within intensity range
    :param image: the image3d object
    :param min_val: min of intensity range (inclusive)
    :param max_val: max of intensity range (inclusive)
    :return: voxel coordinate of bounding box (inclusive)
    """
    assert isinstance(image, Image3d), 'image must be an image3d object'

    minbox = np.empty(3, dtype=np.int32)
    minbox_ptr = minbox.ctypes.data_as(ctypes.POINTER(ctypes.c_int32))

    maxbox = np.empty(3, dtype=np.int32)
    maxbox_ptr = maxbox.ctypes.data_as(ctypes.POINTER(ctypes.c_int32))

    min_val = ctypes.c_double(min_val)
    max_val = ctypes.c_double(max_val)

    ret=call_func('image3d_boundingbox_voxel', image.ptr, min_val, max_val, minbox_ptr, maxbox_ptr)

    if ret:
        return minbox, maxbox
    else:
        return None, None


def pick_largest_component(image):
    """
    this is an inplace-version of connected component analysis.
    It works only if:
    1. the input image is binary. Each pixel has value 0 or 1.
    2. the pixel type of image should be large enough to hold component index.
       Usually short should be enough.
    :param image: the binary input image
    :return: the size of largest connected component
    """
    assert isinstance(image, Image3d), 'image must be an image3d object'
    ret = call_func('image3d_pick_largest_component', image.ptr)
    return ret


def replace_pixel(image, target, replace):
    """
    this function replaces pixel value target with pixel value replace in-place
    :param image: an image3d object
    :param target: the target pixel value to replace
    :param replace: the replaced value
    :return: None
    """
    assert isinstance(image, Image3d), 'image must be an image3d object'
    target = ctypes.c_double(target)
    replace = ctypes.c_double(replace)
    call_func('image3d_replace_pixel', image.ptr,  target, replace)


def hist_match(src_image, ref_image):
    """
    this function maps the histogram of src_image to ref_image.
    The modification is done inplace.
    :param src_image: the source image3d object
    :param ref_image: the reference image3d object
    :return: None
    """
    assert isinstance(src_image, Image3d), 'src_image must be an image3d object'
    assert isinstance(ref_image, Image3d), 'ref_image must be an image3d object'
    call_func('image3d_hist_match', src_image.ptr, ref_image.ptr)


def max_min_avg(image):
    """
    this function computes the maximum, minimum and average intensity of an image
    :param image:  the source image3d object
    :return: max, min, avg intensity
    """
    assert isinstance(image, Image3d), 'image must be an image3d object'
    max_v = ctypes.c_double()
    min_v = ctypes.c_double()
    avg_v = ctypes.c_double()

    call_func('image3d_max_min_avg', image.ptr, ctypes.byref(max_v), ctypes.byref(min_v), ctypes.byref(avg_v))
    return max_v.value, min_v.value, avg_v.value


def percentiles(image, percents):
    """
    this function computes the intensities at input percentiles
    :param image: an image3d object
    :param percents: the percentiles
    :return: intensities at the input percentiles
    """
    assert isinstance(image, Image3d), 'image must be an image3d object'

    percents = np.array(percents, dtype=np.double)
    assert percents.ndim == 1, 'input percentiles must be 1d vector'

    percents = np.ascontiguousarray(percents,dtype=np.double)
    percents_ptr = percents.ctypes.data_as(ctypes.POINTER(ctypes.c_double))

    num = ctypes.c_int32(len(percents))

    out = np.empty(len(percents), dtype=np.double)
    out_ptr = out.ctypes.data_as(ctypes.POINTER(ctypes.c_double))

    call_func('image3d_percentiles', image.ptr, percents_ptr, num, out_ptr)
    return out


def get_pixel_value(image, coord):
    """
    get the pixel value from image3d object using voxel coordinate
    :param image: an image3d object
    :param coord: the 3d coordinate
    :return: pixel value
    """
    assert isinstance(image, Image3d), 'image must be an image3d object'
    x, y, z = int(coord[0]), int(coord[1]), int(coord[2])
    x, y, z = ctypes.c_int32(x), ctypes.c_int32(y), ctypes.c_int32(z)

    ret = call_func('image3d_get_pixel_value', image.ptr, x, y, z)
    return ret


def set_pixel_value(image, coord, val):
    """
    set the pixel value of image3d object using voxel coordinate
    :param image: an image3d object
    :param coord: the 3d coordinate
    :param val: pixel value
    """

    assert isinstance(image, Image3d), 'image must be an image3d object'
    x, y, z = int(coord[0]), int(coord[1]), int(coord[2])
    x, y, z = ctypes.c_int32(x), ctypes.c_int32(y), ctypes.c_int32(z)

    pixel_value = float(val)
    pixel_value = ctypes.c_double(pixel_value)
    call_func('image3d_set_pixel_value', image.ptr, x, y, z, pixel_value)


def count_labels(image):
    """
    count labels in image (label range 0-255)
    :param image: an image3d object
    :return: the existing labels
    """
    assert isinstance(image, Image3d), 'image must be an image3d object'
    out = np.zeros((256,), dtype=np.int32)
    out_ptr = out.ctypes.data_as(ctypes.POINTER(ctypes.c_int32))
    call_func('image3d_count_labels', image.ptr, out_ptr)
    labels = np.flatnonzero(out)
    return labels


def bounding_box_voxel_multi(image, labels):
    """
    compute bounding box for each input label
    :param image: an image3d object
    :param labels: labels of interest
    :return: the output bounding box
    """
    assert isinstance(image, Image3d), 'image must be an image3d object'
    if len(labels) == 0:
        return []

    labels = np.ascontiguousarray(labels, dtype=np.int32)
    labels_ptr = labels.ctypes.data_as(ctypes.POINTER(ctypes.c_int32))
    num_labels = ctypes.c_int32(len(labels))

    boxes = np.empty((len(labels), 6), dtype=np.int32)
    boxes_ptr = boxes.ctypes.data_as(ctypes.POINTER(ctypes.c_int32))

    call_func('image3d_boundingbox_voxel_multi', image.ptr, labels_ptr, num_labels, boxes_ptr)

    min_coords, max_coords = {}, {}
    for i, label in enumerate(labels):
        min_coords[label] = boxes[i, :3]
        max_coords[label] = boxes[i, 3:]

    return min_coords, max_coords


def imflip(image, axis):
    """
    flip an image
    :param image: an image3d object
    :param axis: the axis index
    :return: None
    """
    assert isinstance(image, Image3d)
    assert axis >= 0 and axis <= 2
    axis = ctypes.c_int32(axis)
    call_func('image3d_imflip', image.ptr, axis)


def impad(image, pad):
    """
    image filtering
    :param image: an image3d object
    :param pad: 3d padding
    :return: None
    """
    assert isinstance(image, Image3d)
    # assert len(fsize) == 3

    pad = np.array(pad, dtype=np.int32)
    pad = np.ascontiguousarray(pad, dtype=np.int32)
    pad_ptr = pad.ctypes.data_as(ctypes.POINTER(ctypes.c_int32))

    call_func('image3d_impad', image.ptr, pad_ptr)


def resample_nn_with_padding(image, frame, size, multiple, padtype=0):
    """
    resample a volume with a frame and size, pad dimensions to multiples of a scalar
    :param image: an image3d object
    :param frame: the new frame
    :param size: the output volume size
    :param multiple: base multiple
    :param padtype: padding type, 0 for zero-padding, 1 for edge padding
    :return: a resampled and padded image3d object
    """
    assert isinstance(image, Image3d), 'image must be an image3d object'
    assert isinstance(frame, Frame3d), 'frame must be an frame3d object'

    for i in range(3):
        size[i] = int(np.ceil(size[i] * 1.0 / multiple) * multiple)

    return resample_nn(image, frame, size, padtype)


def resample_volume_nn(image, spacing, padtype=0):
    """
    resample a volume with new spacing using nearest neighbor
    :param image:   an image3d object
    :param spacing: a 3d spacing
    :param padtype: padding type, 0 for zero-padding, 1 for edge padding
    :return: a resampled image3d object
    """
    assert isinstance(image, Image3d), 'image must be an image3d object'

    in_size = np.array(image.size(), dtype=np.double)
    in_spacing = np.array(image.spacing(), dtype=np.double)
    out_spacing = np.array(spacing, dtype=np.double)
    out_size = np.round(in_size * in_spacing / out_spacing).astype(np.int32)

    frame = image.frame().deep_copy()
    frame.set_spacing(out_spacing)

    return resample_nn(image, frame, out_size, padtype)


def resample_volume_nn_with_padding(image, spacing, multiple, padtype=0):
    """
    resample a volume with new spacing and pad dimensions to multiples of a scalar
    :param image: an image3d object
    :param spacing: the new 3d spacing
    :param multiple: base multiple
    :param padtype: padding type, 0 for zero-padding, 1 for edge padding
    :return: a resampled and padded image3d object
    """
    assert isinstance(image, Image3d), 'image must be an image3d object'

    in_size = np.array(image.size(), dtype=np.double)
    in_spacing = np.array(image.spacing(), dtype=np.double)
    out_spacing = np.array(spacing, dtype=np.double)
    out_size = np.round(in_size * in_spacing / out_spacing).astype(np.int32)

    for i in range(3):
        out_size[i] = int(np.ceil(out_size[i] * 1.0 / multiple) * multiple)

    frame = image.frame().deep_copy()
    frame.set_spacing(out_spacing)

    return resample_nn(image, frame, out_size, padtype)


def center_crop(image, coord, spacing, size, padtype=0, is_world=False):
    """
    crop a sub-volume centered at voxel.
    :param image:       an image3d object
    :param coord:       the coordinate of center voxel
    :param spacing:     spacing of output volume
    :param size:        size of output volume
    :param padtype:     padding type, 0 for zero-padding and 1 for edge padding
    :param is_world:    whether the coord is world coordinate
    :return: a sub-volume image3d object
    """
    assert isinstance(image, Image3d), 'image must be an image3d object'

    if size[0] <= 0 or size[1] <= 0 or size[2] <= 0:
        raise ValueError('[error] negative image size')

    coord = np.array(coord, dtype=np.double)
    spacing = np.array(spacing, dtype=np.double)

    if not is_world:
        origin = image.voxel_to_world(coord)
    else:
        origin = coord

    if not is_world:
        for i in range(3):
            origin -= image.axis(i) * spacing[i] * size[i] / 2.0
    else:
        for i in range(3):
            origin -= image.axis(i) * size[i] / 2.0

        for i in range(3):
            size[i]=int(size[i]/spacing[i])

    frame = image.frame().deep_copy()
    assert isinstance(frame, Frame3d)
    frame.set_origin(origin)
    frame.set_spacing(spacing)

    return resample_nn(image, frame, size, padtype)


def resample_volume_as_ref(image, refimg, padtype=0):
    """
    resample a volume as a reference volume.
    :param image:       an image3d object
    :param refimg:      a reference image
    :param padtype:     padding type, 0 for zero-padding and 1 for edge padding
    :return: a sub-volume image3d object
    """
    assert isinstance(image, Image3d), 'image must be an image3d object'
    assert isinstance(refimg, Image3d), 'refimg must be an image3d object'

    frame = refimg.frame().deep_copy()
    assert isinstance(frame, Frame3d)
    size = refimg.size()

    return resample_nn(image, frame, size, padtype)


def resample_mask_as_ref(mask, minlabel, maxlabel, refimg, padtype=0):
    """
    resample a mask volume as a reference volume
    :param mask:       an multi-class mask image
    :param minlabel:   the minimum label to consider (inclusive)
    :param maxlabel:   the maximum label to consider (inclusive)
    :param refimg:     a reference image
    :param padtype:    padding type, 0 for zero-padding and 1 for edge padding
    :return: a sub-volume image3d object
    """
    assert isinstance(mask, Image3d), 'mask must be an image3d object'
    assert isinstance(refimg, Image3d), 'refimg must be an image3d object'

    minbox, maxbox = bounding_box_voxel(mask, minlabel, maxlabel)
    frame = refimg.frame().deep_copy()
    assert isinstance(frame, Frame3d)
    size = refimg.size()

    if minbox is None or maxbox is None:
        ret = Image3d(width=size[0], height=size[1], depth=size[2], dtype=mask.pixel_type())
        ret.set_zeros()
        return ret
    else:
        return resample_nn_bb(mask, frame, size, minbox, maxbox, padtype)


def resample_volume_nn_rai(image, spacing, padtype=0):
    """
    resample a volume with new spacing using nearest neighbor using RAI coordinate
    :param image:   an image3d object
    :param spacing: a 3d spacing
    :param padtype: padding type, 0 for zero-padding, 1 for edge padding
    :return: a resampled image3d object
    """
    assert isinstance(image, Image3d), 'image must be an image3d object'

    out_spacing = np.array(spacing, dtype=np.double)

    min_coord, max_coord = image.world_box()
    frame = Frame3d()
    frame.set_origin(min_coord)
    frame.set_spacing(out_spacing)

    out_size = np.round((max_coord - min_coord) / out_spacing)
    out_size = out_size.astype(np.int32)

    return resample_nn(image, frame, out_size, padtype)


def resample_volume_nn_with_extra_padding_rai(image, spacing, padding_size, multiple, padtype=0):
    """
    resample a volume with new spacing and padding dimensions along both directions of each dimesion
    with specified padding size and to multiples of a scalar using RAI coordinate.
    :param image:         an image3d object
    :param spacing:       the new 3d spacing
    :param padding_size:  the 3d padding size
    :param multiple:      the scalar of base multiple
    :param padtype:       padding type, 0 for zero-padding, 1 for edge padding
    :return:              a resampled and padded image3d object
    """
    assert isinstance(image, Image3d), 'image must be an image3d object'

    min_coord, max_coord = image.world_box()

    out_spacing = np.array(spacing, dtype=np.double)

    padding_size = np.array(padding_size, dtype=np.double)

    min_coord, max_coord = image.world_box()
    min_coord -= padding_size * out_spacing
    max_coord += padding_size * out_spacing

    frame = Frame3d()
    frame.set_origin(min_coord)
    frame.set_spacing(out_spacing)

    out_size = np.round((max_coord - min_coord) / out_spacing)
    out_size = out_size.astype(np.int32)

    for i in range(3):
        out_size[i] = int(np.ceil(out_size[i] * 1.0 / multiple) * multiple)

    return resample_nn(image, frame, out_size, padtype)


def resample_volume_nn_with_padding_rai(image, spacing, multiple, padtype=0):
    """
    resample a volume with new spacing and pad dimensions to multiples of a scalar using RAI coordinate
    :param image: an image3d object
    :param spacing: the new 3d spacing
    :param multiple: base multiple
    :param padtype: padding type, 0 for zero-padding, 1 for edge padding
    :return: a resampled and padded image3d object
    """
    assert isinstance(image, Image3d), 'image must be an image3d object'

    out_spacing = np.array(spacing, dtype=np.double)

    min_coord, max_coord = image.world_box()
    frame = Frame3d()
    frame.set_origin(min_coord)
    frame.set_spacing(out_spacing)

    out_size = np.round((max_coord - min_coord) / out_spacing)
    out_size = out_size.astype(np.int32)

    for i in range(3):
        out_size[i] = int(np.ceil(out_size[i] * 1.0 / multiple) * multiple)

    return resample_nn(image, frame, out_size, padtype)


def swap_label(image, label1, label2, tmp_label = 999):
    """
    swap two labels in the image
    :param image: an image3d object
    :param label1: label a
    :param label2: label b
    :param tmp_label: the intermediate label
    :return: None
    """
    replace_pixel(image, label1, tmp_label)
    replace_pixel(image, label2, label1)
    replace_pixel(image, tmp_label, label2)


def volsize_stat_dir(folder, img_exts, spacing):
    """
    print out statistics of volume size of all images under the folder
    :param folder: the top-level folder
    :param img_exts: the image file extensions
    :param spacing: the 3d spacing
    :return: None
    """
    if isinstance(spacing, int) or isinstance(spacing, float):
        spacing = [spacing, spacing, spacing]
    assert len(spacing) == 3

    dim_x = []
    dim_y = []
    dim_z = []

    for root, dirs, files in os.walk(folder):
        for filepath in files:
            _, ext = os.path.splitext(filepath)
            if ext[1:] in img_exts:
                print os.path.join(root, filepath)
                im = read_image(os.path.join(root, filepath))
                minbox, maxbox = im.world_box()
                dim_x.append(maxbox[0] - minbox[0])
                dim_y.append(maxbox[1] - minbox[1])
                dim_z.append(maxbox[2] - minbox[2])

    assert len(dim_x) > 0, 'no images found under the folder'

    dim_x = np.floor(np.array(dim_x, dtype=np.float) / spacing[0]) + 1
    dim_y = np.floor(np.array(dim_y, dtype=np.float) / spacing[1]) + 1
    dim_z = np.floor(np.array(dim_z, dtype=np.float) / spacing[2]) + 1

    print 'x dim: {} min, {} 25%, {} 50%, {} 75%, {} max'.format(
        np.percentile(dim_x, 0),
        np.percentile(dim_x, 25),
        np.percentile(dim_x, 50),
        np.percentile(dim_x, 75),
        np.percentile(dim_x, 100)
    )

    print 'y dim: {} min, {} 25%, {} 50%, {} 75%, {} max'.format(
        np.percentile(dim_y, 0),
        np.percentile(dim_y, 25),
        np.percentile(dim_y, 50),
        np.percentile(dim_y, 75),
        np.percentile(dim_y, 100)
    )

    print 'z dim: {} min, {} 25%, {} 50%, {} 75%, {} max'.format(
        np.percentile(dim_z, 0),
        np.percentile(dim_z, 25),
        np.percentile(dim_z, 50),
        np.percentile(dim_z, 75),
        np.percentile(dim_z, 100)
    )


def get_pixel_general(image, coord, is_world=False):
    """
    get the pixel value from image3d object using voxel coordiante
    :param image: an image3d object
    :param coord: voxel or world coordinate
    :param is_world: whether coord is a world coordinate
    :return: pixel value
    """
    assert isinstance(image, Image3d)
    if not is_world:
        coord = np.array(coord, dtype=np.int32)
    else:
        coord = image.world_to_voxel(coord)
        coord = coord.astype(dtype=np.int32)

    return get_pixel_value(image, coord)

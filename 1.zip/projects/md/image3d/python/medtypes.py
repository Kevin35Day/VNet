import numpy as np
import ctypes

# numpy type to integer value of pixel type
type_to_value = {
    np.uint8:             ctypes.c_int32(1),
    np.dtype('uint8'):    ctypes.c_int32(1),
    np.char:              ctypes.c_int32(2),
    np.int8:              ctypes.c_int32(2),
    np.dtype('int8'):     ctypes.c_int32(2),
    np.ushort:            ctypes.c_int32(3),
    np.uint16:            ctypes.c_int32(3),
    np.dtype('uint16'):   ctypes.c_int32(3),
    np.short:             ctypes.c_int32(4),
    np.int16:             ctypes.c_int32(4),
    np.dtype('int16'):    ctypes.c_int32(4),
    np.uint32:            ctypes.c_int32(5),
    np.dtype('uint32'):   ctypes.c_int32(5),
    np.int32:             ctypes.c_int32(6),
    np.dtype('int32'):    ctypes.c_int32(6),
    np.uint64:            ctypes.c_int32(7),
    np.dtype('uint64'):   ctypes.c_int32(7),
    np.int64:             ctypes.c_int32(8),
    np.dtype('int64'):    ctypes.c_int32(8),
    np.float32:           ctypes.c_int32(9),
    np.dtype('float32'):  ctypes.c_int32(9),
    np.double:            ctypes.c_int32(10),
    np.dtype('float64'):  ctypes.c_int32(10)
}

# integer value of pixel type to numpy type
value_to_type = [
    None,
    np.uint8,
    np.int8,
    np.ushort,
    np.short,
    np.uint32,
    np.int32,
    np.uint64,
    np.int64,
    np.float32,
    np.double
]

# numpy type to ctypes
type_to_ctypes = {
    np.uint8:               ctypes.c_uint8,
    np.dtype('uint8'):      ctypes.c_uint8,
    np.int8:                ctypes.c_int8,
    np.dtype('int8'):       ctypes.c_int8,
    np.ushort:              ctypes.c_uint16,
    np.dtype('uint16'):     ctypes.c_uint16,
    np.short:               ctypes.c_int16,
    np.dtype('int16'):      ctypes.c_int16,
    np.uint32:              ctypes.c_uint32,
    np.dtype('uint32'):     ctypes.c_uint32,
    np.int32:               ctypes.c_int32,
    np.dtype('int32'):      ctypes.c_int32,
    np.uint64:              ctypes.c_uint64,
    np.dtype('uint64'):     ctypes.c_uint64,
    np.int64:               ctypes.c_int64,
    np.dtype('int64'):      ctypes.c_int64,
    np.float32:             ctypes.c_float,
    np.dtype('float32'):    ctypes.c_float,
    np.double:              ctypes.c_double,
    np.dtype('float64'):    ctypes.c_double
}

# type to byte size
type_to_bytes = {
    np.uint8:       1L,
    np.char:        1L,
    np.int8:        1L,
    np.ushort:      2L,
    np.uint16:      2L,
    np.short:       2L,
    np.int16:       2L,
    np.uint32:      4L,
    np.int32:       4L,
    np.uint64:      8L,
    np.int64:       8L,
    np.float32:     4L,
    np.double:      8L
}

# type to string
type_to_string = {
    np.uint8:       'UCHAR',
    np.char:        'CHAR',
    np.int8:        'CHAR',
    np.ushort:      'USHORT',
    np.uint16:      'USHORT',
    np.short:       'SHORT',
    np.int16:       'SHORT',
    np.uint32:      'UINT32',
    np.int32:       'INT32',
    np.uint64:      'UINT64',
    np.int64:       'INT64',
    np.float32:     'FLOAT32',
    np.double:      'DOUBLE'
}

"""
python wrapper for image3d_vis library

this file includes:

dump_slice
dump_labeled_slice

"""

import ctypes
import _ctypes
from md.utils.python.find_dll import find_dll
import platform
import os
import numpy as np

# dynamic library
lib = None

# function pointer dictionary
fun_dict = {}


def __get_library_path():

    dll_file = find_dll('pyimage3d_vis')
    if dll_file is None:
        raise OSError('dll not found')
    return dll_file


def __load_c_functions():

    global lib, fun_dict

    lib = ctypes.cdll.LoadLibrary(__get_library_path())

    lib.image3d_dump_slice.argtypes = [ctypes.c_void_p, ctypes.c_int32, ctypes.c_int32, ctypes.c_char_p]
    lib.image3d_dump_slice.restype = ctypes.c_bool
    fun_dict['image3d_dump_slice'] = lib.image3d_dump_slice

    lib.image3d_dump_labeled_slice.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int32, ctypes.c_int32, ctypes.c_double, ctypes.c_char_p, ctypes.c_int32, ctypes.c_int32, ctypes.c_char_p]
    lib.image3d_dump_labeled_slice.restype = ctypes.c_bool
    fun_dict['image3d_dump_labeled_slice'] = lib.image3d_dump_labeled_slice

    lib.image3d_slice_to_bytes.argtypes = [ctypes.c_void_p, ctypes.c_int32, ctypes.c_int32, ctypes.c_int32, ctypes.c_int32, ctypes.c_void_p]
    lib.image3d_slice_to_bytes.restype = None
    fun_dict['image3d_slice_to_bytes'] = lib.image3d_slice_to_bytes

    lib.image3d_bytes_to_colors.argtypes = [ctypes.c_void_p, ctypes.c_int32, ctypes.c_int32, ctypes.c_int32,
                                           ctypes.c_void_p, ctypes.c_void_p]
    lib.image3d_bytes_to_colors.restype = ctypes.c_bool
    fun_dict['image3d_bytes_to_colors'] = lib.image3d_bytes_to_colors

    lib.image3d_multi_image_alpha_blend.argtypes = [ctypes.c_void_p, ctypes.c_int32, ctypes.c_int32, ctypes.c_int32,
                                           ctypes.c_void_p, ctypes.c_void_p]
    lib.image3d_multi_image_alpha_blend.restype = None
    fun_dict['image3d_multi_image_alpha_blend'] = lib.image3d_multi_image_alpha_blend


def unload():

    global lib, fun_dict

    try:
        while lib is not None:
            if platform.system() == 'Windows':
                _ctypes.FreeLibrary(lib._handle)
            else:
                _ctypes.dlclose(lib._handle)
    except:
        lib = None
        fun_dict = {}


def load():

    unload()
    __load_c_functions()


# load dynamic library and function pointers
load()


def load_c_functions_if_necesary():

    if len(fun_dict) == 0:
        print '[info] pyimage3d_vis dll reloaded'
        __load_c_functions()


def call_func(func_name, *args):

    load_c_functions_if_necesary()

    if len(args) == 0:
        return fun_dict[func_name]()
    else:
        return fun_dict[func_name](*args)


def dump_slice(image, slice_index, slice_option, filename):
    """
    dump a slice to disk
    :param image: an image3d object
    :param slice_index: slice index
    :param slice_option: slice direction, 0 for axial, 1 for coronal, 2 for sagittal
    :param filename: disk file path
    :return: None
    """
    if slice_option not in [0, 1, 2]:
        raise ValueError('slice option must be 0, 1 or 2')

    slice_index = ctypes.c_int32(slice_index)
    slice_option = ctypes.c_int32(slice_option)

    return call_func('image3d_dump_slice', image.ptr, slice_index, slice_option, filename)


def dump_labeled_slice(orgimage, labeledimage, slice_index, slice_option, alpha, color_config_file, win_min, win_max, output_file):
    """
    dump a slice to disk
    :param orgimage: an image3d object, intensity image
    :param labeledimage: an image3d object, labeled image
    :param slice_index: slice index
    :param slice_option: slice direction, 0 for axial, 1 for coronal, 2 for sagittal
    :param alpha: alpha blending parameter [0,1]
    :param color_config_file: color_config_file
    :param win_min: minimum window level
    :param win_max: maximum window level
    :param output_file: disk file path
    :return: None
    """
    if slice_option not in [0, 1, 2]:
        raise ValueError('slice option must be 0, 1 or 2')

    if alpha < 0 or alpha > 1:
        raise ValueError('alpha value must be between 0 and 1')

    slice_index = ctypes.c_int32(slice_index)
    slice_option = ctypes.c_int32(slice_option)
    alpha = ctypes.c_double(alpha)

    return call_func('image3d_dump_labeled_slice', orgimage.ptr, labeledimage.ptr, slice_index, slice_option, alpha, color_config_file, win_min, win_max, output_file)


def slice_to_bytes(orgslice,win_min,win_max):
    """
    convert a slice to byte slice
    :param orgslice: a 2D slice
    :param win_min: window minimum intensity
    :param win_max: window maximum intensity
    :return: a byte slice
    """
    orgslice = np.ascontiguousarray(orgslice, dtype=np.float32)
    orgslice_ptr = orgslice.ctypes.data_as(ctypes.POINTER(ctypes.c_float))

    height, width = orgslice.shape[0], orgslice.shape[1]
    height = ctypes.c_int32(height)
    width = ctypes.c_int32(width)

    win_min = int(win_min)
    win_max = int(win_max)
    win_min = ctypes.c_int32(win_min)
    win_max = ctypes.c_int32(win_max)

    byteslice = np.empty((height.value, width.value), dtype=np.uint8)
    byteslice_ptr = byteslice.ctypes.data_as(ctypes.POINTER(ctypes.c_uint8))

    call_func('image3d_slice_to_bytes', orgslice_ptr, width, height, win_min, win_max, byteslice_ptr)
    return byteslice


def bytes_to_colors(byteslice, option, extra=None):
    """
    convert a byte slice to RGB colors
    :param byteslice: a 2D byte slice
    :param option: 0 for grayscale, 1 for red, 2 for green, 3 for blue, 4 for jet color, 5 for color config
    :param extra: if option = 5, extra is a list of 4-tuple integers, each tuple (label, R, G, B)
    :return: color slice
    """
    assert isinstance(option, int) and option <= 5 and option >= 0

    byteslice = np.ascontiguousarray(byteslice, dtype=np.uint8)
    byteslice_ptr = byteslice.ctypes.data_as(ctypes.POINTER(ctypes.c_uint8))

    height, width = byteslice.shape[0], byteslice.shape[1]
    height = ctypes.c_int32(height)
    width = ctypes.c_int32(width)

    colorslice = np.empty((height.value, width.value, 3), dtype=np.uint8)
    colorslice_ptr = colorslice.ctypes.data_as(ctypes.POINTER(ctypes.c_uint8))

    if option == 5 and extra is not None:
        extra = np.ascontiguousarray(extra, dtype=np.int32)
        extra_ptr = extra.ctypes.data_as(ctypes.POINTER(ctypes.c_int32))
    else:
        extra_ptr = ctypes.c_void_p(0)

    call_func('image3d_bytes_to_colors', byteslice_ptr, width, height, option, extra_ptr, colorslice_ptr)
    return colorslice


def multi_image_alpha_blend(slices, alphalist):
    """
    alpha blending multiple 2D slices
    :param slices: a 3D ndarray, slice_num x height x width x 3
    :param alphalist: alpha list
    :return: a blended RGB slice
    """
    assert len(slices) == len(alphalist)

    image_num = ctypes.c_int32(slices.shape[0])

    slices = np.ascontiguousarray(slices, dtype=np.uint8)
    slices_ptr = slices.ctypes.data_as(ctypes.POINTER(ctypes.c_uint8))

    height, width = slices.shape[1], slices.shape[2]
    height = ctypes.c_int32(height)
    width = ctypes.c_int32(width)

    alphalist= np.ascontiguousarray(alphalist, dtype=np.double)
    alphalist_ptr = alphalist.ctypes.data_as(ctypes.POINTER(ctypes.c_double))

    blendedslice = np.empty((height.value, width.value, 3), dtype=np.uint8)
    blendedslice_ptr = blendedslice.ctypes.data_as(ctypes.POINTER(ctypes.c_uint8))

    call_func('image3d_multi_image_alpha_blend', slices_ptr, image_num, width, height, alphalist_ptr, blendedslice_ptr)
    return blendedslice



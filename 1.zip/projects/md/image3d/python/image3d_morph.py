"""
functions for image3d morphological operations

this file includes

lib:        a library object that contains library handle
fun_dict:   a dictionary contains function pointers
load:       load existing dynamic library
unload:     release loaded dynamic library

"""

import ctypes
import _ctypes
import platform
from md.image3d.python.image3d import Image3d
from md.utils.python.find_dll import find_dll


# dynamic library
lib = None

# function pointer dictionary
fun_dict = {}


def __get_library_path():

    dll_file = find_dll('pyimage3d_morph')
    if dll_file is None:
        raise OSError('dll not found')
    return dll_file


def __load_c_functions():

    global lib, fun_dict

    lib = ctypes.cdll.LoadLibrary(__get_library_path())

    lib.image3d_imerode.argtypes = [ctypes.c_void_p, ctypes.c_int32, ctypes.c_int32]
    lib.image3d_imerode.restype = None
    fun_dict['image3d_imerode'] = lib.image3d_imerode

    lib.image3d_imdilate.argtypes = [ctypes.c_void_p, ctypes.c_int32, ctypes.c_int32]
    lib.image3d_imdilate.restype = None
    fun_dict['image3d_imdilate'] = lib.image3d_imdilate


def unload():

    global lib, fun_dict

    try:
        while lib is not None:
            if platform.system() == 'Windows':
                _ctypes.FreeLibrary(lib._handle)
            else:
                _ctypes.dlclose(lib._handle)
    except:
        lib = None
        fun_dict = {}


def load():

    unload()
    __load_c_functions()


# load dynamic library
load()


def load_c_functions_if_necesary():

    if len(fun_dict) == 0:
        print '[info] pyimage3d_morph dll reloaded'
        __load_c_functions()


def call_func(func_name, *args):

    load_c_functions_if_necesary()

    if len(args) == 0:
        return fun_dict[func_name]()
    else:
        return fun_dict[func_name](*args)


def imerode(image, iteration, label):
    """
    erode image
    :param image: an image3d object
    :param iteration: erode times
    :param label: target label
    :return: None
    """
    assert isinstance(image, Image3d)
    label = ctypes.c_int32(label)
    iteration = ctypes.c_int32(iteration)
    call_func('image3d_imerode', image.ptr, iteration, label)


def imdilate(image, iteration, label):
    """
    dilate image
    :param image: an image3d object
    :param iteration: dilate times
    :param label: target label
    :return: None
    """
    assert isinstance(image, Image3d)
    label = ctypes.c_int32(label)
    iteration = ctypes.c_int32(iteration)
    call_func('image3d_imdilate', image.ptr, iteration, label)

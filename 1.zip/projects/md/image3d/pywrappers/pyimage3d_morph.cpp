#include "image3d/pywrappers/pyimage3d_morph.h"
#include "image3d/csrc/image3d.h"
#include "image3d/csrc/image3d_morph.h"
#include "utils/csrc/template_macros.h"
#include <iostream>

using namespace medvision;

void image3d_imerode(void* image, int iteration, int label)
{
    Image3d* image_w = static_cast<Image3d*>(image);
    PixelType ptype = image_w->pixel_type();

    ptypecall_1(imerode, ptype, *image_w, iteration, label);
}


void image3d_imdilate(void* image, int iteration, int label)
{
    Image3d* image_w = static_cast<Image3d*>(image);
    PixelType ptype = image_w->pixel_type();

    ptypecall_1(imdilate, ptype, *image_w, iteration, label);
}


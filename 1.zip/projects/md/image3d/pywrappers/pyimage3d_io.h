#ifndef PYIMAGE3D_IO_H
#define PYIMAGE3D_IO_H

#include <cstddef>

#ifdef __cplusplus
extern "C" {
#endif

/*! \brief read a 3d volume from disk */
void* image3d_read(const char* filename, int out_ptype);

/*! \brief read image frame and size from disk */
void* image3d_read_frame_and_size(const char* filename, int* size);

/*! \brief write a 3d volume to disk */
bool image3d_write(void* image, const char* filename, int out_ptype, bool compression);

/*! \brief get dicom series names */
const char* image3d_get_dicom_series(const char* directory, const char* restrictions);

/*! \brief read dicom series */
void* image3d_read_dicom_series(const char* directory, int out_ptype, const char* series_name, const char* restrictions, char** tag_strs);

/*! \brief write dicom series */
bool image3d_write_dicom_series(void* image, const char* directory, int out_ptype, const char* tags);

#ifdef __cplusplus
}
#endif

#endif // PYIMAGE3D_IO_H

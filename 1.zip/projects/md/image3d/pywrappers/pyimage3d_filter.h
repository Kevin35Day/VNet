#ifndef PYIMAGE3D_FILTER_H
#define PYIMAGE3D_FILTER_H

#include <cstddef>

#ifdef __cplusplus
extern "C" {
#endif

/*! \brief image filtering */
void image3d_imfilt(void* image, const double* filter, const int* fsize);

#ifdef __cplusplus
}
#endif

#endif // PYIMAGE3D_FILTER_H

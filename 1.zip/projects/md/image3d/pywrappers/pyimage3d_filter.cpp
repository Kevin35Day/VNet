#include "image3d/pywrappers/pyimage3d_filter.h"
#include "image3d/csrc/image3d.h"
#include "image3d/csrc/image3d_filter.h"
#include "utils/csrc/template_macros.h"
#include <iostream>

using namespace medvision;

void image3d_imfilt(void* image, const double* filter, const int* fsize)
{
    Image3d* image_w = static_cast<Image3d*>(image);
    PixelType ptype = image_w->pixel_type();
    vec3d<int> fsize_w(fsize[0], fsize[1], fsize[2]);

    ptypecall_1(imfilt, ptype, *image_w, filter, fsize_w);
}

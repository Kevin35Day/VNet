#include "image3d/csrc/itk/image3d_io.h"
#include "image3d/pywrappers/pyimage3d_io.h"
#include "image3d/csrc/image3d.h"

using namespace medvision;

void* image3d_read(const char* filename, int out_ptype)
{
    if(out_ptype < 0 || out_ptype > PT_DOUBLE) {
        std::cerr << "invalid output pixel type" << std::endl;
        return nullptr;
    }

    Image3d* image = new Image3d();
    if(!read_image(filename, *image, static_cast<PixelType>(out_ptype))) {
        delete image;
        return nullptr;
    }
    else
        return image;
}


void* image3d_read_frame_and_size(const char* filename, int* size)
{
    Frame3d* frame = new Frame3d();

    vec3d<int> size_vec;
    bool success = read_frame_and_size(filename, *frame, size_vec);
    if(!success) {
        delete frame;
        return nullptr;
    } else {
        size[0] = size_vec[0];
        size[1] = size_vec[1];
        size[2] = size_vec[2];
        return frame;
    }
}


bool image3d_write(void* image, const char* filename, int out_ptype, bool compression)
{
    if(out_ptype < 0 || out_ptype > PT_DOUBLE) {
        std::cerr << "invalid output pixel type" << std::endl;
        return false;
    }

    Image3d* obj = static_cast<Image3d*>(image);
    if(!write_image(*obj, filename, static_cast<PixelType>(out_ptype), compression))
        return false;
    else
        return true;
}


const char* image3d_get_dicom_series(const char* directory, const char* restrictions)
{
    std::vector<std::string> series_names;
    get_dicom_series(directory, restrictions, series_names);
    std::stringstream out;
    for(size_t i = 0; i < series_names.size(); ++i) {
        if(i == 0)
            out << series_names[i];
        else
            out << ";" << series_names[i];
    }

    std::string out_str = out.str();

    char* ret = static_cast<char*>(malloc(sizeof(char) * (1 + out_str.size())));
    memcpy(ret, out_str.c_str(), out_str.size());
    ret[out_str.size()] = 0;

    return ret;
}


void* image3d_read_dicom_series(const char* directory, int out_ptype, const char* series_name, const char* restrictions, char** tags_str)
{
    std::map<std::string, std::string> tags;
    Image3d* image = new Image3d();
    bool ret = read_dicom_series(directory, *image, tags, static_cast<PixelType>(out_ptype), series_name, restrictions);
    if(!ret) {
        delete image;
        return nullptr;
    }

    std::stringstream ss;
    auto it = tags.begin();
    while(it != tags.end()) {
        ss << it->first << "#" << it->second << ";";
        ++ it;
    }

    std::string tmp = ss.str();
    *tags_str = (char*)( malloc(sizeof(char) * (tmp.size() + 1)) );
    memcpy(*tags_str, tmp.c_str(), sizeof(char) * tmp.size());
    (*tags_str)[tmp.size()] = 0;

    return image;
}


bool image3d_write_dicom_series(void* image, const char* directory, int out_ptype, const char* tags_str)
{
    if(out_ptype < 0 || out_ptype > PT_DOUBLE) {
        std::cerr << "invalid output pixel type" << std::endl;
        return false;
    }

    Image3d* obj = static_cast<Image3d*>(image);
    std::map<std::string, std::string> tags;

    if(tags_str != nullptr) {
        int first_idx = 0, idx = 0;
        std::string tag, value;
        while(tags_str[idx] != 0) {
            char c = tags_str[idx];
            if(c == '#') {
                tag = std::string(tags_str + first_idx, idx - first_idx);
                first_idx = idx + 1;
            }
            else if(c == ';') {
                value = std::string(tags_str + first_idx, idx - first_idx);
                tags[tag] = value;
                first_idx = idx + 1;
            }
            ++ idx;
        }
        if(first_idx < idx) {
            value = std::string(tags_str + first_idx, idx - first_idx);
            tags[tag] = value;
            first_idx = idx + 1;
        }
    }

//    auto it = tags.begin();
//    while(it != tags.end()) {
//        std::cout << it->first << " : " << it->second << std::endl;
//        ++ it;
//    }

    if(!write_dicom_series(*obj, directory, static_cast<PixelType>(out_ptype), tags))
        return false;
    else
        return true;

}


#include "image3d/csrc/itk/image3d_vis.h"
#include "image3d/pywrappers/pyimage3d_vis.h"
#include "image3d/csrc/image3d.h"
#include "utils/csrc/template_macros.h"

using namespace medvision;

bool image3d_dump_slice(void* image, int slice_index, int slice_option, const char* filename)
{
    Image3d* image_w = static_cast<Image3d*>(image);
    PixelType ptype = image_w->pixel_type();
    bool ret = false;
    ptypeassign_1(dump_slice, ptype, ret, *image_w, slice_index, slice_option, filename);
    return ret;
}

bool image3d_dump_labeled_slice(void* orgimage, void* labelimage, int slice_index, int slice_option, double alpha, const char* color_config_file, int win_min, int win_max, const char* output_file)
{
	Image3d* image_w1 = static_cast<Image3d*>(orgimage);
	PixelType ptype1 = image_w1->pixel_type();

	Image3d* image_w2 = static_cast<Image3d*>(labelimage);
	PixelType ptype2 = image_w2->pixel_type();

	bool ret = false;
	ptypeassign_2(dump_labeled_slice, ptype1, ptype2, ret, *image_w1, *image_w2, slice_index, slice_option, alpha, color_config_file, win_min, win_max, output_file);
	return ret;
}

void image3d_slice_to_bytes(const float* slice, int width, int height, int win_min, int win_max, unsigned char* valbuffer)
{
    size_t image_size = static_cast<size_t>(width) * static_cast<size_t>(height);
    image_to_bytes_window_level<float>(slice, image_size, win_min, win_max, valbuffer);
}

bool image3d_bytes_to_colors(const unsigned char* valbuffer, int width, int height, int option, void* extra, unsigned char* rgbbuffer)
{
	bool ret=bytes_to_colors(valbuffer, width, height, option, extra, rgbbuffer);
	return ret;
}

void image3d_multi_image_alpha_blend(const unsigned char* im_rgbbuffers, int image_num, int width, int height, double* alpha, unsigned char* blended_rgbbuffer)
{
    size_t image_size = static_cast<size_t>(width) * static_cast<size_t>(height);
    multi_image_alpha_blend(im_rgbbuffers, size_t(image_num), image_size, alpha, blended_rgbbuffer);
}


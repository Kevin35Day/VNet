#ifndef PYFRAME3D_H
#define PYFRAME3D_H

#include <cstddef>

#ifdef __cplusplus
extern "C" {
#endif

/*! \brief create frame3d object */
void* frame3d_create();

/*! \brief delete frame3d object */
void frame3d_delete(void* obj);

/*! \brief deep copy frame3d object */
void* frame3d_deepcopy(void* obj);

/*! \brief restore default */
void frame3d_restore_default(void* obj);

/*! \brief get origin */
void frame3d_origin(void* obj, double* out);

/*! \brief get spacing */
void frame3d_spacing(void* obj, double* out);

/*! \brief get axis */
void frame3d_axis(void* obj, size_t idx, double* out);

/*! \brief get axes */
void frame3d_axes(void* obj, double* out);

/*! \brief set origin */
void frame3d_set_origin(void* obj, double x, double y, double z);

/*! \brief set spacing */
void frame3d_set_spacing(void* obj, double x, double y, double z);

/*! \brief set axis */
void frame3d_set_axis(void* obj, size_t idx, double x, double y, double z);

/*! \brief set axes */
void frame3d_set_axes(void* obj, const double* axes);

/*! \brief world to voxel coordinates conversion */
void frame3d_world_to_voxel(void* obj, const double* world, int num, double* voxel);

/*! \brief voxel to world coordinate conversion */
void frame3d_voxel_to_world(void* obj, const double* voxel, int num, double* world);

/*! \brief get number of bytes of an object */
size_t frame3d_bytes(void* obj);

/*! \brief write object to buffer */
bool frame3d_write_to_buffer(void* obj, void* data);

/*! \brief read an object from buffer */
bool frame3d_read_from_buffer(void* obj, void* data);


#ifdef __cplusplus
}
#endif

#endif

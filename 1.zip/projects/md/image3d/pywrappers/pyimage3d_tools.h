#ifndef PYIMAGE3D_TOOLS_H
#define PYIMAGE3D_TOOLS_H

#include <cstddef>

#ifdef __cplusplus
extern "C" {
#endif

/*! \brief get an abitary slice from a 3d image volume */
bool image3d_slice_nn(void* image, const double* cursor, const double* axis1, const double* axis2, const double* center, double x_spacing, double y_spacing, int width, int height, void* out, double default_value);

/*! \brief create an image same with a given image except the content */
void* image3d_create_like(void* image);

/*! \brief estimate intensity window center and width */
void image3d_estimate_intensity_window(void* image, bool slice_only, double* center, double* width);

/*! \brief random pick random voxels from image */
int image3d_random_voxels(void* mask, int num, double min_val, double max_val, int* voxels);

/*! \brief resample a subvolume from volume using nearest neighbor and edge padding */
void image3d_resample_nn(void* image, void* frame, const int* size, int pad_t, void* out);

/*! \brief resample a subvolume from volume using nearest neighbor and edge padding */
void image3d_resample_nn_bb(void* image, void* frame, const int* size, const int* mincorner, const int* maxcorner, int pad_t, void* out);

/*! \brief crop a subvolume from volume */
void image3d_crop(void* image, const int* sp, const int* ep, void* out);

/*! \brief convert multi-class label map to binary label map */
void image3d_convert_multi_label_to_binary(void* image, int label);

/*! \brief normalize the intensity */
void image3d_intensity_normalize(void* image, double mean, double stddev, bool clip);

/*! \brief calculate mass voxel center */
int image3d_mass_voxel_center(void* image, double minVal, double maxVal, double* voxelcenter);

/*! \brief calculate weighted mass voxel center */
int image3d_weighted_mass_voxel_center(void*image, double minVal, double maxVale, double* voxelcenter);

/*! \brief calculate bounding box in voxel cooridnate*/
int image3d_boundingbox_voxel(void* image, double minVal, double maxVal, int* mincorner, int* maxcorner);

/*! \brief pick the largest connected component */
size_t image3d_pick_largest_component(void* image);

/*! \brief image3d replace value */
void image3d_replace_pixel(void* image, double target, double replace);

/*! \brief image3d pixel type */
void image3d_hist_match(void* src_image, void* ref_image);

/*! \brief image3d minimum maximum average */
void image3d_max_min_avg(void* image, double* max_value, double* min_value, double* avg_value);

/*! \brief image3d compute intensity percentile */
void image3d_percentiles(void* image, const double* percents, int num, double* out);

/*! \brief image3d get pixel value */
double image3d_get_pixel_value(void* image, int x, int y, int z);

/*! \brief set a pixel value */
void image3d_set_pixel_value(void* image, int x, int y, int z, double v);

/*! \brief count labels in image */
int image3d_count_labels(void* image, int* has_label);

/*! \brief compute multiple bounding boxes, one for each label */
void image3d_boundingbox_voxel_multi(void* image, const int* labels, int num_labels, int* boxes);

/*! \brief flip image */
void image3d_imflip(void* image, int axis);

/*! \brief image padding */
void image3d_impad(void* image, const int* pad);


#ifdef __cplusplus
}
#endif

#endif // PYIMAGE3D_TOOLS_H

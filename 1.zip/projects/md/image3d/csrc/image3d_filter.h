/* image3d_filter.h
 *
 * template tools for image filtering operations
 */

#ifndef IMAGE_FILTER_H
#define IMAGE_FILTER_H

#include "image3d/csrc/image3d.h"
#include "image3d/csrc/image3d_tools.h"
#include "image3d/csrc/pixel_type_traits.h"
#include "math/plane3d.h"
#include "utils/csrc/template_macros.h"

#include <limits>
#include <algorithm>
#include <queue>
#include <time.h>
#include <map>
#include <unordered_map>

namespace medvision {

    /*! \brief Image filtering
     *
     *  \param image       an image object
     *  \param filter      3D filter pointer
     *  \param fsize       size of filter, vec3d object
     */
    template <typename T>
    void imfilt(Image3d &image, const double* filter, const vec3d<int> &fsize)
    {
        if (image.pixel_type() != PT_DOUBLE && image.pixel_type() != PT_FLOAT)
            std::cerr << "[Warning] Double or float image pixel type expected ! " << std::endl;

        vec3d<int> hfsize = fsize/2;
        T* data = static_cast<T* >(image.data());
        Image3d image_tmp(image);

        vec3d<int> pad(hfsize[0], hfsize[1], hfsize[2]);       
        impad<T >(image_tmp, pad);
        T* data_tmp = static_cast<T* >(image_tmp.data());
        vec3d<int> size = image_tmp.size();
        vec3d<size_t> stridet = image_tmp.strides();
        vec3d<size_t> strides = image.strides();

        #pragma omp parallel for
        for (int z = 0+hfsize[2] ; z < size[2]-hfsize[2] ; z++){
            for (int y = 0+hfsize[1] ; y < size[1]-hfsize[1] ; y++){
                for (int x = 0+hfsize[0] ; x < size[0]-hfsize[0] ; x++){
                    double value = 0;

                    for (int k = 0; k < fsize[2]; k++){
                        for (int j = 0; j < fsize[1]; j++){
                            for (int i = 0; i < fsize[0]; i++){
                                int filter_index= i + j*fsize[0] + k*fsize[0]*fsize[1];
                                size_t data_index = x+i-hfsize[0] + (y+j-hfsize[1])*stridet[1] + (z+k-hfsize[2])*stridet[2];
                                value += filter[filter_index] * data_tmp[data_index];
                            }
                        }
                    }//end of filtering
                    data[(x-pad[0]) + (y-pad[1])*strides[1] + (z-pad[2])*strides[2]] = static_cast<T> (value);
                }
            }
        }//end of for loop
    }//end of function

}

#endif // IMAGE_FILTER_H 

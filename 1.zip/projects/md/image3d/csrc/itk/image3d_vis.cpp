#include "image3d/csrc/itk/image3d_vis.h"
#include "utils/csrc/template_macros.h"

namespace medvision {

bool write_rgb_buffer(unsigned char* rgb_buffer, int width, int height, const char* filename)
{
    typedef itk::Image<itk::RGBPixel<unsigned char>, 2> itkImageType;

    itkImageType::Pointer itk_image = itkImageType::New();
    itk_image->Initialize();
    itk::ImageRegion<2> region;
    {
        itk::Index<2> idx;
        idx[0] = idx[1] = 0;

        itk::Size<2> size;
        size[0] = width;
        size[1] = height;

        region.SetIndex(idx);
        region.SetSize(size);
    }

    itk_image->SetRegions(region);
    itk_image->Allocate();

    typedef itk::ImageRegionIterator<itkImageType> IteratorType;
    IteratorType it(itk_image, itk_image->GetLargestPossibleRegion());
    it.GoToBegin();

    size_t idx = 0;
    while (!it.IsAtEnd()) {

        itk::RGBPixel<unsigned char> pixel_value;
        pixel_value[0] = rgb_buffer[idx * 3];
        pixel_value[1] = rgb_buffer[idx * 3+1];
        pixel_value[2] = rgb_buffer[idx * 3+2];

        it.Set(pixel_value);
        ++it; ++idx;
    }

    typedef itk::ImageFileWriter< itkImageType > WriterType;
    WriterType::Pointer writer = WriterType::New();

    writer->SetInput(itk_image);
    writer->SetFileName(filename);

    try {
        writer->Update();
    }
    catch (const itk::ExceptionObject& exp) {
        std::cerr << exp.GetDescription() << std::endl;
        return false;
    }

    return true;
}

void label_max_blend(const unsigned char* im_rgbbuffer, const unsigned char* label_rgbbuffer, size_t length, double alpha, unsigned char* rgbbuffer3)
{
    for (size_t i = 0; i < length; i++)
    {
		rgbbuffer3[i] = im_rgbbuffer[i] > label_rgbbuffer[i] ? im_rgbbuffer[i] : label_rgbbuffer[i];
    }
}

void mapJet(double v, double vmin, double vmax, unsigned char& r, unsigned char& g, unsigned char& b)
{
	r = 0;
	g = 0;
	b = 0;

	if (v < vmin) {
		v = vmin;
	}

	if (v > vmax) {
		v = vmax;
	}

	double dr, dg, db;

	if (v < 0.1242) {
		db = 0.504 + ((1. - 0.504) / 0.1242)*v;
		dg = dr = 0.;
	}
	else if (v < 0.3747) {
		db = 1.;
		dr = 0.;
		dg = (v - 0.1242) * (1. / (0.3747 - 0.1242));
	}
	else if (v < 0.6253) {
		db = (0.6253 - v) * (1. / (0.6253 - 0.3747));
		dg = 1.;
		dr = (v - 0.3747) * (1. / (0.6253 - 0.3747));
	}
	else if (v < 0.8758) {
		db = 0.;
		dr = 1.;
		dg = (0.8758 - v) * (1. / (0.8758 - 0.6253));
	}
	else {
		db = 0.;
		dg = 0.;
		dr = 1. - (v - 0.8758) * ((1. - 0.504) / (1. - 0.8758));
	}

	r = (unsigned char)(255 * dr);
	g = (unsigned char)(255 * dg);
	b = (unsigned char)(255 * db);

	return;
}

void bytes_to_jet_color(const unsigned char* valbuffer, size_t length, unsigned char* rgbbuffer)
{
	for (size_t i = 0; i < length; i++)
	{
		mapJet(double(valbuffer[i])/255., 0., 1., rgbbuffer[3*i], rgbbuffer[3*i+1], rgbbuffer[3 * i + 2]);
	}
	return;
}

void bytes_to_single_color(const unsigned char* valbuffer, size_t buffer_size, int channel_option, unsigned char* rgbbuffer)
{
    memset(rgbbuffer, 0, buffer_size * 3);

	for (size_t i = 0; i < buffer_size; ++i)
	{
		switch (channel_option)
		{
		case 0:
			rgbbuffer[i * 3] = valbuffer[i];
			break;
		case 1:
			rgbbuffer[i * 3 + 1] = valbuffer[i];
			break;
		case 2:
			rgbbuffer[i * 3 + 2] = valbuffer[i];
			break;
		default:
			continue;
		}
	}

	return;
}

void bytes_to_color_config(const unsigned char* valbuffer, size_t buffer_size, const std::map<int, vec3d<unsigned char>>& colormap, unsigned char* rgbbuffer)
{
	for (size_t i = 0; i < buffer_size; ++i) 
	{
		int pixelval = int(valbuffer[i]);
		auto iter = colormap.find(pixelval);
		if (iter != colormap.end())
		{
			rgbbuffer[i * 3] = iter->second[0];
			rgbbuffer[i * 3 + 1] = iter->second[1];
			rgbbuffer[i * 3 + 2] = iter->second[2];
		}
		else
		{
			rgbbuffer[i * 3] = 0;
			rgbbuffer[i * 3 + 1] = 0;
			rgbbuffer[i * 3 + 2] = 0;
		}
	}
	return;
}

void bytes_to_grayscale(const unsigned char* valbuffer, size_t buffer_size, unsigned char* rgbbuffer)
{
	for (size_t i = 0; i < buffer_size; ++i) 
	{
			rgbbuffer[i * 3] = valbuffer[i];
			rgbbuffer[i * 3 + 1] = valbuffer[i];
			rgbbuffer[i * 3 + 2] = valbuffer[i];
	}
	return;
}

//The length of colormap_array must be 256*3
void deserialize_colormap(int* colormap_array, std::map<int, vec3d<unsigned char>>& colormap)
{
	for (int i = 0; i < 256; i++)
	{
		if (colormap_array[i * 3] == 0 && colormap_array[i * 3 + 1] == 0 && colormap_array[i * 3 + 2] == 0)
			continue;

		colormap[i] = vec3d<unsigned char>(colormap_array[i * 3], colormap_array[i * 3 + 1], colormap_array[i * 3 + 2]);
	}
	return;
}

bool bytes_to_colors(const unsigned char* valbuffer, int width, int height, int option, void* extra, unsigned char* rgbbuffer)
{
	size_t buffer_size = size_t(width*height);
	std::map<int, vec3d<unsigned char>> colormap;

	switch (option)
	{
	case 0:
		bytes_to_grayscale(valbuffer, buffer_size, rgbbuffer);
		return true;

	case 1:
		bytes_to_single_color(valbuffer, buffer_size, 0, rgbbuffer);
		return true;

	case 2:
		bytes_to_single_color(valbuffer, buffer_size, 1, rgbbuffer);
		return true;

	case 3:
		bytes_to_single_color(valbuffer, buffer_size, 2, rgbbuffer);
		return true;

	case 4:
		bytes_to_jet_color(valbuffer, buffer_size, rgbbuffer);
		return true;

	case 5:
		deserialize_colormap(static_cast<int*>(extra), colormap);
		bytes_to_color_config(valbuffer, buffer_size, colormap, rgbbuffer);
		return true;

	default:
		std::cerr << "[Error] Invalid option: " << option << std::endl;
		return false;
	}
}

void multi_image_alpha_blend(const unsigned char* im_rgbbuffers, size_t image_num, size_t image_size, double* alpha, unsigned char* blended_rgbbuffer)
{
	int color_buffer_size = image_size * 3;

	//Normalize alpha
	double total_alpha(0);
	for (size_t index = 0; index < image_num; index++)
	{
		total_alpha += alpha[index];
	}
	for (size_t index = 0; index < image_num; index++)
	{
		alpha[index]/=total_alpha;
	}

	memset(blended_rgbbuffer, 0, color_buffer_size);
	for (size_t i = 0; i < image_size; i++)
	{
		double rgb[3];
		rgb[0] = 0; rgb[1] = 0; rgb[2] = 0;

		for (size_t index = 0; index < image_num; index++)
		{
			for (size_t color_index = 0; color_index < 3; ++color_index)
			{
				rgb[color_index] += alpha[index] * im_rgbbuffers[index*color_buffer_size + i * 3 + color_index];
			}
		}

		for (size_t color_index = 0; color_index < 3; ++color_index)
		{
			if (rgb[color_index]<0)
			{
				blended_rgbbuffer[i * 3 + color_index] = 0;
			}
			else if (rgb[color_index]>255)
			{
				blended_rgbbuffer[i * 3 + color_index] = 255;
			}
			else
			{
				blended_rgbbuffer[i * 3 + color_index] = static_cast<unsigned char>(rgb[color_index]);
			}
		}
	}
}

void label_alpha_blend(const unsigned char* im_rgbbuffer, const unsigned char* label_rgbbuffer, size_t length, double alpha, unsigned char* rgbbuffer3, bool ignorezero)
{
	length = length / 3;
	for (size_t i = 0; i < length; i++)
	{
		if (label_rgbbuffer[3 * i] == 0 && label_rgbbuffer[3 * i + 1] == 0 && label_rgbbuffer[3 * i + 2] == 0 && ignorezero)
		{
			for (int j = 0; j < 3; j++)
			{
				rgbbuffer3[3 * i + j] = im_rgbbuffer[3 * i + j];
			}
		}
		else
		{
			for (int j = 0; j < 3; j++)
			{
				double val = im_rgbbuffer[3 * i + j] * alpha + label_rgbbuffer[3 * i + j] * (1. - alpha);

				if (val < 0)
				{
					rgbbuffer3[3 * i + j] = 0;
				}
				else if (val > 255)
				{
					rgbbuffer3[3 * i + j] = 255;
				}
				else
				{
					rgbbuffer3[3 * i + j] = static_cast<unsigned char>(val);
				}
			}
		}
	}
}

bool read_color_map(const char* filename, std::map<int, vec3d<unsigned char>>& colormap)
{
    FILE* fp;
    fp = fopen(filename, "r");
    if (fp == NULL)
    {
        std::cerr << "[Error] cannot open color config file " << filename << std::endl;
        return false;
    }

    int color_num(0);
    int matched = fscanf(fp, "%d", &color_num);
    if(matched != 1)
        return false;

    colormap.clear();
    vec3d<unsigned char> RGB;
    int label(0);
    for (int i = 0; i < color_num; i++)
    {
        int matched = fscanf(fp, "%d %hhu %hhu %hhu", &label, &RGB[0], &RGB[1], &RGB[2]);
        if(matched != 4)
            return false;

        colormap[label] = RGB;
    }

    fclose(fp);
    return true;
}

}

/* image3d_vis.h
 *
 * visualization tools
 */

#ifndef IMAGE3D_VIS_H
#define IMAGE3D_VIS_H

#include <map>
#include "image3d/csrc/image3d.h"
#include "image3d/csrc/image3d_tools.h"

#include <itkImage.h>
#include <itkImageRegionIterator.h>
#include <itkImageFileReader.h>
#include <itkImageFileWriter.h>

namespace medvision {

/*! \brief write a rgb buffer to disk
*
*  \param rgb_buffer    a rgb buffer, each pixel has three values R, G, B
*  \param width         the image width
*  \param height        the image height
*  \param filename      the output file name
*  \return True if write successful, false otherwise
*/
bool write_rgb_buffer(unsigned char* rgb_buffer, int width, int height, const char* filename);


/*! \brief convert grayscale values to RGB buffer
 *
 *  \param valbuffer        the 2D grayscale buffer
 *  \param width            the image width
 *  \param height           the image height
 *  \param option           the grayscale to color option
 *  \param rgbbuffer        the output rgb buffer
 */
bool bytes_to_colors(const unsigned char* valbuffer, int width, int height, int option, void* extra, unsigned char* rgbbuffer);


/*! \brief read color map from a configuration file
*
*  \param filename     the configuration file path
*  \param colormap     the label to rgb color mapping
*  \return true if successful otherwise false
*/
bool read_color_map(const char* filename, std::map<int, vec3d<unsigned char>>& colormap);


/*! \brief convert a colormap array to map structure */
void deserialize_colormap(int* colormap_array, std::map<int, vec3d<unsigned char>>& colormap);


/*! \brief map a value to jet color
*
*  \param v     input value in [0,1]
*  \param vmin	mininum v
*  \param vmax	maximum v
*  \param r     red
*  \param g     green
*  \param b     blue
*/
void mapJet(double v, double vmin, double vmax, unsigned char& r, unsigned char& g, unsigned char& b);


/* start block
 * different gray-scale to RGB color mapping */

void bytes_to_jet_color(const unsigned char* valbuffer, size_t buffer_size, unsigned char* rgbbuffer);

void bytes_to_single_color(const unsigned char* valbuffer, size_t buffer_size, int channel_option, unsigned char* rgbbuffer);

void bytes_to_color_config(const unsigned char* valbuffer, size_t buffer_size, const std::map<int, vec3d<unsigned char>>& colormap, unsigned char* rgbbuffer);

void bytes_to_grayscale(const unsigned char* valbuffer, size_t buffer_size, unsigned char* rgbbuffer);

/* end block
 * different gray-scale to RGB color mapping */


/*! \brief blend multiple images using their alpha values
 *
 *  \param im_rgbbuffers       the image RGB buffer of multiple images, stored image by image
 *  \param image_num           the number of images
 *  \param image_size          the number of image pixels
 *  \param alpha               the list of alpha values, one for each image
 *  \param blended_rgbbuffer   the blended RGB buffer
 */
void multi_image_alpha_blend(const unsigned char* im_rgbbuffers, size_t image_num, size_t image_size, double* alpha, unsigned char* blended_rgbbuffer);


/*! \brief alpha blend of two rgb buffers of the same size
*
*
*  \param im_rgbbuffer      the rgb buffer from intensity image
*  \param label_rgbbuffer   the rgb buffer from label image
*  \param length            the buffer size
*  \param alpha             the alpha value
*  \param rgbbuffer3        the output rgb buffer
*  \param ignorezero        if this switch is true and the RGB in the label rgb buffer is zero, alpha blending is skipped at this location.
*/
void label_alpha_blend(const unsigned char* im_rgbbuffer, const unsigned char* label_rgbbuffer, size_t length, double alpha, unsigned char* rgbbuffer3, bool ignorezero = false);


/*! \brief maximum blend of two rgb buffers of the same size
*
*  \param im_rgbbuffer      the rgb buffer from intensity image
*  \param label_rgbbuffer   the rgb buffer from label image
*  \param length            the buffer size
*  \param rgbbuffer3        the output rgb buffer
*/
void label_max_blend(const unsigned char* im_rgbbuffer, const unsigned char* label_rgbbuffer, size_t length, double alpha, unsigned char* rgbbuffer3);


/*! \brief convert intensity image into grayscale image */
template<typename T>
void image_to_bytes_window_level(const T* image, size_t image_size, int win_min, int win_max, unsigned char* valbuffer)
{
    int win_width = win_max - win_min;
    for (int i=0; i<image_size;i++)
    {
            double value = image[i];
            if (value < static_cast<double>(win_min))
                valbuffer[i] = static_cast<unsigned char>(0);
            else if (value > static_cast<double>(win_max))
                valbuffer[i] = static_cast<unsigned char>(255);
            else
                valbuffer[i] = static_cast<unsigned char>((value - win_min) / win_width * 255);
    }
    return;
}


/*! \brief convert a 2D gray level image to a gray scale rgb buffer
*
*  \param image         the 2D image pointer
*  \param width         image width
*  \param height        image height
*  \param min_value     min intensity
*  \param max_value     max intensity
*  \param rgbbuffer     the output rgb buffer
*/
template <typename T>
void image_to_grayscale(const T* image, int width, int height, int min_value, int max_value, unsigned char* rgbbuffer)
{
	std::vector<unsigned char> valbuffer(width*height);
	unsigned char* data_ptr = valbuffer.data();
	image_to_bytes_window_level(image, size_t(width*height), min_value, max_value, data_ptr);

	bytes_to_grayscale(data_ptr, size_t(width*height), rgbbuffer);
}


/*! \brief convert a 2D gray level image to a color rgb buffer
*
*  \param image         the 2D image pointer
*  \param width         image width
*  \param height        image height
*  \param min_value     min intensity
*  \param max_value     max intensity
*  \param option	    color option
*  \param extra         the extra data for options
*  \param rgbbuffer     the output rgb buffer
*/
template <typename T>
void image_to_color_general(const T* image, int width, int height, int win_min, int win_max, int option, void * extra, unsigned char* rgbbuffer)
{
	std::vector<unsigned char> valbuffer(width*height);
	unsigned char* data_ptr = valbuffer.data();
	image_to_bytes_window_level(image, size_t(width*height), win_min, win_max, data_ptr);

	bytes_to_colors(data_ptr, width, height, option, extra, rgbbuffer);
	return;
}


/* start block
 * convert 2D image to RGB buffer using different color modes */

template <typename T>
void image_to_colorconfig(const T* image, int width, int height, int win_min, int win_max, const std::map<int, vec3d<unsigned char>>& colormap, unsigned char* rgbbuffer)
{
	std::vector<unsigned char> valbuffer(width*height);
	unsigned char* data_ptr = valbuffer.data();
	image_to_bytes_window_level(image, size_t(width*height), win_min, win_max, data_ptr);

	bytes_to_color_config(data_ptr, size_t(width*height), colormap, rgbbuffer);
}

template <typename T>
void image_to_singlecolor(const T* image, int width, int height, int min_value, int max_value, int channel_option, unsigned char* rgbbuffer)
{
	std::vector<unsigned char> valbuffer(width*height);
	unsigned char* data_ptr = valbuffer.data();
	image_to_bytes_window_level(image, size_t(width*height), min_value, max_value, data_ptr);

	bytes_to_single_color(data_ptr, size_t(width*height), channel_option, rgbbuffer);
}

template <typename T>
void image_to_jetcolor(const T* image, int width, int height, int min_value, int max_value, unsigned char* rgbbuffer)
{
	std::vector<unsigned char> valbuffer(width*height);
	unsigned char* data_ptr = valbuffer.data();
	image_to_bytes_window_level(image, size_t(width*height), min_value, max_value, data_ptr);

	bytes_to_jet_color(data_ptr, size_t(width*height), rgbbuffer);
	return;
}

/* end block
 * convert 2D image to RGB buffer using different color modes */


/*! \brief write a 2D gray-level image to disk
*
*   \param image          the 2D image pointer
*   \param width          the image width
*   \param height         the image height
*   \param min_value      the minimum intensity value
*   \param max_value      the maximum intensity value
*   \param filename       the output file path
*   \return True if write successful, false otherwise
*/
template <typename T>
bool write_slice(const T* image, int width, int height, int min_value, int max_value, const char* filename)
{
    std::vector<unsigned char>rgbbuffer(width*height * 3);
    image_to_grayscale(image, width, height, min_value, max_value, rgbbuffer.data());
    return write_rgb_buffer(rgbbuffer.data(), width, height, filename);
}


/*! \brief get an image slice (axial, coronal or sagittal)
 *
 *  \param image        the image3d object
 *  \param slice_index  the slice index
 *  \param slice_option 0 for axial, 1 for coronal, 2 for sagittal
 *  \param slice        the output buffer (allocated within function)
 *  \param width        the output slice width
 *  \param height       the output slice height
 *  \return true if successful, false otherwise
 */
template <typename T>
bool get_image_slice(const Image3d& image, int slice_index, int slice_option, std::vector<T>& slice, int& width, int& height)
{
    vec3d<int> size = image.size();

    if (slice_option < 0 || slice_option > 2) {
        std::cerr << "[error] invalid slice option" << slice_option << std::endl;
        return false;
    }

    if (slice_index<0 || slice_index >= size[2-slice_option]) {
        std::cerr << "[error] invalid slice index " << slice_index << std::endl;
        return false;
    }

    switch (slice_option)
    {
    case 0:
        width = size[0];
        height = size[1];
        break;
    case 1:
        width = size[0];
        height = size[2];
        break;
    case 2:
        width = size[1];
        height = size[2];
        break;
    default:
        break;
    }

    slice.resize(height * width);
    for (int row = 0; row<height; row++)
    {
        for (int col = 0; col < width; col++)
        {
            switch (slice_option)
            {
            case 0:
                slice[row*width + col] = get_pixel<T>(image, col, row, slice_index);
                break;

            case 1:
                slice[row*width + col] = get_pixel<T>(image, col, slice_index, size[2] - 1 - row);
                break;

            case 2:
                slice[row*width + col] = get_pixel<T>(image, slice_index, col, size[2] - 1 - row);
                break;

            default:
                break;
            }
        }
    }
    return true;
}


/*! \brief dump a slice of a 3d image
*
*  \param image             an image3d object
*  \param slice_index       slice index
*  \param slice_option      0: axial 1: coronal 2: saggital
*  \param file_name         otuput file name
*  \param win_min           minimum intensity (auto-computed by default)
*  \param win_max           maximum intensity (auto-computed by default)
*  \return true if successful, false otherwise
*/
template <typename T>
bool dump_slice(const Image3d& image, int slice_index, int slice_option, const char* file_name, int win_min=0, int win_max=0)
{
    std::vector<T> slice;
    int width(0), height(0);
    if (!get_image_slice<T>(image, slice_index, slice_option, slice, width, height))
    {
        return false;
    }

    T max_value = T(), min_value = T();
    if (win_max-win_min<=0)
    {
        double avg_value = 0.0;
        max_min_avg(slice.data(), slice.size(), max_value, min_value, avg_value);
    }
    else
    {
        min_value = T(win_min);
        max_value = T(win_max);
    }

    if(!write_slice<T>(slice.data(), width, height, min_value, max_value, file_name)) {
        std::cerr << "fail to write slice to disk" << std::endl;
        return false;
    }

    return true;
}

/*! \brief dump the labeled slice
*
*  \param orgimage          intensity image
*  \param labelimage        label image
*  \param slice_index       slice index
*  \param slice_option      0: axial 1: coronal 2: saggital
*  \param alpha             alpha blending parameter
*  \param color_config_file	color config file
*  \param output_file       output file
*  \param win_min           minimum intensity
*  \param win_max           maximum intensity
*  \return true if successful, false otherwises
*/
template <typename T1, typename T2>
bool dump_labeled_slice(const Image3d& orgimage, const Image3d& labelimage, int slice_index, int slice_option, double alpha, const char* color_config_file, int win_min, int win_max, const char* output_file)
{
    if (orgimage.size() != labelimage.size())
    {
        std::cerr << "[Error] original image and label image need to have the same size!" << std::endl;
        return false;
    }

    std::vector<T1> slice1;
    int width(0), height(0);
    if (!get_image_slice<T1>(orgimage, slice_index, slice_option, slice1, width, height))
    {
        std::cerr << "[Error] fail to get intensity image slice" << std::endl;
        return false;
    }

	T1 max_value = T1(), min_value = T1();
    if (win_max - win_min <= 0)
    {
        double avg_value = 0.0;
        max_min_avg(slice1.data(), slice1.size(), max_value, min_value, avg_value);
    }
    else
    {
        min_value = T1(win_min);
        max_value = T1(win_max);
    }

    std::vector<unsigned char> rgbbuffer1(width * height * 3);
    image_to_grayscale(slice1.data(), width, height, min_value, max_value, rgbbuffer1.data());
	
    std::vector<T2> slice2;
    if (!get_image_slice<T2>(labelimage, slice_index, slice_option, slice2, width, height))
    {
        std::cerr << "[Error] fail to get label image slice" << std::endl;
        return false;
    }

    std::map<int, vec3d<unsigned char>> colormap;
    if (!read_color_map(color_config_file, colormap))
    {
        std::cerr << "[Error] fail to read config file" << std::endl;
        return false;
    }

    std::vector<unsigned char> rgbbuffer2(width * height * 3);
	int win_min2(0), win_max2(255);
    image_to_colorconfig(slice2.data(), width, height, win_min2, win_max2,colormap, rgbbuffer2.data());
	//int color_option = 1;
	//image_to_singlecolor(slice2.data(), width, height, min_value, max_value, color_option, rgbbuffer2.data());
	//image_to_jetcolor(slice2.data(), width, height, min_value, max_value, rgbbuffer2.data());

    std::vector<unsigned char> rgbbuffer3(width * height * 3);
    label_alpha_blend(rgbbuffer1.data(), rgbbuffer2.data(), width * height * 3, alpha, rgbbuffer3.data(),true);

    if (!write_rgb_buffer(rgbbuffer3.data(), width, height, output_file))
    {
        std::cerr << "fail to write rgb buffer to disk" << std::endl;
        return false;
    }

    return true;
}

}

#endif // IMAGE3D_VIS_H

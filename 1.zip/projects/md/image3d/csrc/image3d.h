#ifndef IMAGE3D_H
#define IMAGE3D_H

#include "math/vec3d.h"
#include "image3d/csrc/frame3d.h"
#include <vector>

namespace medvision {

/*! \brief pixel type */
enum PixelType { PT_UNKNOWN = 0, PT_UCHAR, PT_CHAR, PT_USHORT, PT_SHORT, PT_UINT, PT_INT, PT_ULONG, PT_LONG, PT_FLOAT, PT_DOUBLE };

/*! \brief pixel type to string */
const char* ptype_to_str(PixelType ptype);

/*! \brief 3d image volume class */
class Image3d
{
public:
    /*! \brief default constructor */
    Image3d();
    /*! \brief construct a zero volume with specified size and pixel type */
    Image3d(int width, int height, int depth, PixelType pixel_type);
    /*! \brief copy constructor */
    Image3d(const Image3d& arg);
    /*! \brief deconstructor */
    ~Image3d();

    /*! \brief get image size */
    inline vec3d<int> size() const { return m_size; }
    /*! \brief get image width */
    inline int width() const { return m_size[0]; }
    /*! \brief get image height */
    inline int height() const { return m_size[1]; }
    /*! \brief get image depth */
    inline int depth() const { return m_size[2]; }
    /*! \brief get image strides */
    inline vec3d<size_t> strides() const {
        vec3d<size_t> ret;
        ret[2] = static_cast<size_t>(m_size[0] * m_size[1]);
        ret[1] = static_cast<size_t>(m_size[0]);
        ret[0] = static_cast<size_t>(1);
        return ret;
    }
    /*! \brief get pixel type */
    inline PixelType pixel_type() const { return m_pixel_type; }
    /*! \brief get world coordinate of origin */
    inline vec3d<double> origin() const { return m_frame.get_origin(); }
    /*! \brief get spacing */
    inline vec3d<double> spacing() const { return m_frame.get_spacing(); }
    /*! \brief get one axis */
    inline vec3d<double> axis(int idx) const { return m_frame.get_axis(idx); }
    /*! \brief get the frame of this image */
    inline Frame3d frame() const { return m_frame; }
    /*! \brief get raw image data */
    inline void* data() { return m_data; }
    /*! \brief const version of get raw image data */
    inline const void* data() const { return m_data; }
    /*! \brief compute world coordinate center of image */
    inline vec3d<double> center() const {
        vec3d<double> voxel_center(m_size[0]/2.0, m_size[1]/2.0, m_size[2]/2.0);
        return m_frame.voxel_to_world(voxel_center);
    }
    /*! \brief compute world box */
    void world_box(vec3d<double>& min_coord, vec3d<double>& max_coord) const;

    /*! \brief set all zeros to pixels */
    void set_zeros();

    // resize and cast will invalidate the old buffer if managed
    /*! \brief resize the image
     *
     *  If buffer is managed, existing buffer will be freed before resize.
     */
    void resize(int width, int height, int depth);

    /*! \brief resize the image
     *
     *  If buffer is managed, existing buffer will be freed before resize.
     */
    void resize(const vec3d<int>& size);

    /*! \brief allocate image with specified size and pixel type
     *
     *  If existing buffer is managed, it will be freed
     */
    void allocate(int width, int height, int depth, PixelType pixel_type);

    /*! \brief allocate image with specified size and pixel type
     *
     *  If existing buffer is managed, it will be freed
     */
    void allocate(const vec3d<int>& size, PixelType pixel_type);

    /*! \brief cast pixel type of image
     *
     *  If buffer is managed, existing buffer will be freed before cast.
     *  The content of existing buffer will be casted to the new buffer.
     */
    bool cast(PixelType pixel_type);

    /*! \brief cast pixel type of image to another image */
    void cast_to(PixelType pixel_type, Image3d& out) const;

    /*! \brief set image buffer from raw pointer
     *
     *  \param managed true if the object is responsible for releasing the buffer.
     *                 false if the object should not release the buffer.
     */
    void set_data(void* data, int width, int height, int depth, PixelType pixel_type, bool managed = false);

    /*! \brief set image buffer from raw pointer
     *
     *  \param managed true if the object is responsible for releasing the buffer.
     *                 false if the object should not release the buffer.
     */
    void set_data(void* data, const vec3d<int>& size, PixelType pixel_type, bool managed = false);

    /*! \brief copy data from raw pointer */
    void copy_data(void* data, int width, int height, int depth, PixelType pixel_type);

    /*! \brief copy image content to a buffer pointed by a raw pointer */
    void copy_data_to(void* data) const;

    /*! \brief set world coordinate of origin */
    void set_origin(double x, double y, double z);

    /*! \brief set world coordinate of origin */
    void set_origin(const vec3d<double>& origin);

    /*! \brief set spacing */
    void set_spacing(double x, double y, double z);

    /*! \brief set spacing */
    void set_spacing(const vec3d<double>& spacing);

    /*! \brief set all three axes */
    void set_axes(const double* axes);

    /*! \brief set all three axes */
    void set_axes(const vec3d<double>& x1, const vec3d<double>& x2, const vec3d<double>& x3);

    /*! \brief set frame of image */
    void set_frame(const Frame3d& frame);

    /*! \brief clear memory if managed and reset frame */
    void clear_state();

    /*! \brief release old buffer if managed and create new buffer according to header */
    void update_buffer();

    /*! \brief convert world coordinate to voxel coordinate */
    vec3d<double> world_to_voxel(const vec3d<double>& coord) const;

    /*! \brief convert voxel coordinate to world coordinate */
    vec3d<double> voxel_to_world(const vec3d<double>& coord) const;

    /*! \brief serialize object to stream */
    void serialize(std::ostream& out) const;

    /*! \brief deserialize object from stream */
    void deserialize(std::istream& in);

    /*! \brief the number of bytes of object */
    size_t bytes() const;

    /*! \brief the number of bytes of data */
    size_t data_bytes() const;

    /*! \brief write object to a buffer */
    bool write_to_buffer(void* out_buffer) const;

    /*! \brief read object from a buffer */
    bool read_from_buffer(void* in_buffer);

private:
    /*! \brief bytes of a pixel */
    inline size_t pixel_size() const;

    /*! \brief disallow assignment operator */
    Image3d& operator =(const Image3d& im);

private:
    /*! \brief raw image bytes */
    void* m_data;

    /*! \brief image size */
    vec3d<int> m_size;

    /*! \brief pixel type */
    PixelType m_pixel_type;

    /*! \brief whether to release memory after deconstruction */
    bool m_managed;

    /*! \brief 3d frame of image */
    Frame3d m_frame;
};


} // end namespace medvision

#endif // IMAGE3D_H

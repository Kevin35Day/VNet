/* image_tools.h
 *
 * template tools to manipulate images
 */

#ifndef IMAGE_TOOLS_H
#define IMAGE_TOOLS_H

#include "image3d/csrc/image3d.h"
#include "image3d/csrc/pixel_type_traits.h"
#include "math/plane3d.h"
#include "utils/csrc/template_macros.h"

#include <limits>
#include <algorithm>
#include <queue>
#include <time.h>
#include <map>
#include <unordered_map>

namespace medvision {

	/*! \brief cast and copy a T1-type buffer to T2-type buffer
	 *
	 *  \param src          the pointer of source buffer (T1 type)
	 *  \param num_elems    the number of elements in source buffer
	 *  \param dst          the pointer of destination buffer (T2 type)
	 */
	template <typename T1, typename T2>
	void cast_copy(void* src, size_t num_elems, void* dst)
	{
		const T1* src_ptr = static_cast<T1*>(src);
		T2* dst_ptr = static_cast<T2*>(dst);
		for (size_t i = 0; i < num_elems; ++i)
			dst_ptr[i] = static_cast<T2>(src_ptr[i]);
	}


	/*! \brief fill in an image with a constant pixel value
	 *
	 *  \param image        an image3d object
	 *  \param v            the constant value
	 */
	template <typename T>
	void image_fill(Image3d& image, double v)
	{
		T* data_ptr = static_cast<T*>(image.data());

		vec3d<int> size = image.size();
		size_t num_elems = static_cast<size_t>(size[0]) * static_cast<size_t>(size[1]) * static_cast<size_t>(size[2]);

		for (size_t i = 0; i < num_elems; ++i)
			data_ptr[i] = static_cast<T>(v);
	}


	/*! \brief get a pixel value
	 *
	 *  \param image        an image3d object
	 *  \param x            x coordinate
	 *  \param y            y coordinate
	 *  \param z            z coordinate
	 *  \return             the pixel value
	 */
	template <typename T>
	double get_pixel_value(const Image3d& image, int x, int y, int z)
	{
		vec3d<int> size = image.size();
		const T* data_ptr = static_cast<const T*>(image.data());

		size_t width = static_cast<size_t>(size[0]);
		size_t height = static_cast<size_t>(size[1]);
		size_t depth = static_cast<size_t>(size[2]);

		if (x < 0 || y < 0 || z < 0 || x >= size[0] || y >= size[1] || z >= size[2])
			return 0.0;
		else
			return static_cast<double>(data_ptr[z * width * height + y * width + x]);
	}


	/*! \brief get a pixel value
	 *
	 * \param image         an image3d object
	 * \param x             x coordinate
	 * \param y             y coordinate
	 * \param z             z coordinate
	 * \return              the pixel value
	 */
	template <typename T>
	T get_pixel(const Image3d& image, int x, int y, int z)
	{
		vec3d<int> size = image.size();
		const T* data_ptr = static_cast<const T*>(image.data());

		size_t width = static_cast<size_t>(size[0]);
		size_t height = static_cast<size_t>(size[1]);
		size_t depth = static_cast<size_t>(size[2]);

		if (x < 0 || y < 0 || z < 0 || x >= size[0] || y >= size[1] || z >= size[2])
			return static_cast<T>(0);
		else
			return data_ptr[z * width * height + y * width + x];
	}

    /*! \brief get a pixel value
     *
     * \param image         an image3d object
     * \param index         index = x + y*stride[1] + z*stride[2]
     * \return              the pixel value in double type
     */
    template <typename T>
    double get_pixel_by_index(const Image3d& image, size_t index)
    {
        const T* data = static_cast<const T* >(image.data());
        return static_cast<double>(data[index]);
    }


	/*! \brief set a pixel value
	 *
	 *  \param image        an image3d object
	 *  \param x            x coordinate
	 *  \param y            y coordinate
	 *  \param z            z coordinate
	 *  \param value        the value to set
	 */
	template <typename T>
	void set_pixel(Image3d& image, int x, int y, int z, T value)
	{
		vec3d<int> size = image.size();
		T* data_ptr = static_cast<T*>(image.data());

		size_t width = static_cast<size_t>(size[0]);
		size_t height = static_cast<size_t>(size[1]);
		size_t depth = static_cast<size_t>(size[2]);

		if (x < 0 || y < 0 || z < 0 || x >= size[0] || y >= size[1] || z >= size[2])
			return;
		else
			data_ptr[z * width * height + y * width + x] = value;
	}

    template <typename T>
    void set_pixel_value(Image3d& image, int x, int y, int z, double value)
    {
        vec3d<int> size = image.size();
        T* data_ptr = static_cast<T*>(image.data());

        size_t width = static_cast<size_t>(size[0]);
        size_t height = static_cast<size_t>(size[1]);
        size_t depth = static_cast<size_t>(size[2]);

        if (x < 0 || y < 0 || z < 0 || x >= size[0] || y >= size[1] || z >= size[2])
            return;
        else
            data_ptr[z * width * height + y * width + x] = static_cast<T>(value);
    }


	/*! \brief estimate intensity window center and window width
	 *
	 *  \param image        an image3d object
	 *  \param sliceOnly    use only middle slice or entire volume
	 *  \return (intensity_center, intensity_width)
	 */
	template <typename T>
	std::pair<double, double> estimate_intensity_window(const Image3d& image, bool slice_only)
	{
		vec3d<int> size = image.size();
		const T* data_ptr = static_cast<const T*>(image.data());

		size_t width = static_cast<size_t>(size[0]);
		size_t height = static_cast<size_t>(size[1]);
		size_t depth = static_cast<size_t>(size[2]);
		size_t stride = width * height;

		T min_value = (std::numeric_limits<T>::max)();
		T max_value = (std::numeric_limits<T>::min)();

		if (slice_only) {
			const T* slice_ptr = data_ptr + depth / 2 * stride;
			for (size_t i = 0; i < stride; ++i) {
				if (min_value > slice_ptr[i])
					min_value = slice_ptr[i];
				if (max_value < slice_ptr[i])
					max_value = slice_ptr[i];
			}
		}
		else {
			size_t num_elems = width * height * depth;
			for (size_t i = 0; i < num_elems; ++i) {
				if (min_value > data_ptr[i])
					min_value = data_ptr[i];
				if (max_value < data_ptr[i])
					max_value = data_ptr[i];
			}
		}

		double intensity_center = (static_cast<double>(min_value) + static_cast<double>(max_value)) / 2.0;
		double intensity_width = static_cast<double>(max_value) - static_cast<double>(min_value);
		return std::make_pair(intensity_center, intensity_width);
	}


	/*! \brief get a slice of a 3d image using nearest neighbor interpolation
	 *
	 *  \param image            a 3d image (type T1)
	 *  \param plane            the slice plane
	 *  \param center           the 3d center, which is the current focus
	 *  \param x_spacing        the spacing of x axis in 2d plane
	 *  \param y_spacing        the spacing of y axis in 2d plane
	 *  \param width            the width of 2d plane
	 *  \param height           the height of 2d plane
	 *  \param out              the output buffer (type T2)
	 *  \param default_value    the default value if a voxel is outside the volume
	 */
	template <typename T1, typename T2>
	void slice_nn(const Image3d& image, const Plane3d<double>& plane, const vec3d<double>& center, double x_spacing, double y_spacing,
		size_t width, size_t height, void* out, double default_value = 0)
	{
		vec3d<double> projected_center = plane.map_onto_plane(center);

		double world_width = static_cast<double>(width) * x_spacing;
		double world_height = static_cast<double>(height) * y_spacing;

		vec3d<double> left_top = projected_center - plane.m_axis1 * (world_width / 2.0) - plane.m_axis2 * (world_height / 2.0);

		int vol_width = image.width();
		int vol_height = image.height();
		int vol_depth = image.depth();

		const T1* image_data = static_cast<const T1*>(image.data());
		T2* out_ptr = static_cast<T2*>(out);

		// combine pixel_to_world and world_to_voxel into a single transform
		// precompute several parameters
		vec3d<double> shifted_left_top = left_top - image.origin();
		vec3d<double> vol_spacing = image.spacing();
		vec3d<double> vol_axes[3];
		for (int i = 0; i < 3; ++i)
			vol_axes[i] = image.axis(i) / vol_spacing[i];

		vec3d<double> x_axis = plane.m_axis1 * x_spacing;
		vec3d<double> y_axis = plane.m_axis2 * y_spacing;

		// compute start voxel, row voxel offset and column voxel offset
		vec3d<double> start;
		for (int i = 0; i < 3; ++i)
			start[i] = vec3d<double>::dot_prod(shifted_left_top, vol_axes[i]);

		vec3d<double> row_offset, col_offset;
		for (int i = 0; i < 3; ++i) {
			row_offset[i] = vec3d<double>::dot_prod(y_axis, vol_axes[i]);
			col_offset[i] = vec3d<double>::dot_prod(x_axis, vol_axes[i]);
		}

		// pixel value outside the image domain
		T2 default_v = static_cast<T2>(default_value);

		for (size_t row = 0; row < height; ++row) {

			vec3d<double> voxel = start;

			for (size_t col = 0; col < width; ++col) {

				vec3d<int> nn_voxel;
				nn_voxel[0] = static_cast<int>(voxel[0] + 0.5);
				nn_voxel[1] = static_cast<int>(voxel[1] + 0.5);
				nn_voxel[2] = static_cast<int>(voxel[2] + 0.5);

				if (nn_voxel[0] < 0 || nn_voxel[1] < 0 || nn_voxel[2] < 0) {
					out_ptr[row * width + col] = default_v;
				}
				else if (nn_voxel[0] >= vol_width || nn_voxel[1] >= vol_height || nn_voxel[2] >= vol_depth) {
					out_ptr[row * width + col] = default_v;
				}
				else {
					size_t index = static_cast<size_t>(nn_voxel[2]) * static_cast<size_t>(vol_width * vol_height);
					index += static_cast<size_t>(nn_voxel[1]) * static_cast<size_t>(vol_width);
					index += static_cast<size_t>(nn_voxel[0]);

					out_ptr[row * width + col] = static_cast<T2>(image_data[index]);
				}

				// increment voxel location to next column
				voxel += col_offset;
			}

			// increment voxel location to next row
			start += row_offset;
		}
	}


   /*! \brief resample an image volume using nearest neighbor
	*
	*  \param in_image an input image volume
	*  \param frame    the resample frame
	*  \param size     the crop size
    *  \param min_corner minimum corner of the bounding box, defined in in_image voxel space
    *  \param max_corner maximum corner of the bounding box, defined in in_image voxel space
	*  \param pad_t    padding type (0 for zero-padding, 1 for edge-padding)
	*  \param out      the output crop volume
	*/
    template <typename T1, typename T2>
    void resample_nn_bb(const Image3d& in_image, const Frame3d& frame, const vec3d<int>& size, const vec3d<int>& mincorner, const vec3d<int>& maxcorner, int pad_t, Image3d& out, bool out_alloc=true)
	{
		//clock_t init, final;
		//init = clock();
		
		if (pad_t < 0 || pad_t > 1) {
			std::cerr << "[error] invalid padding type" << std::endl;
			return;
		}

        if(out_alloc) {
            out.clear_state();
            out.set_frame(frame);
            out.allocate(size, pixel_type_traits<T2>::value());
        }

        // set all pixels to zero
        out.set_zeros();

        if(in_image.pixel_type() != out.pixel_type()) {
            std::cerr << "[error] input and output pixel type mismatch" << std::endl;
            return;
        }
        if(out.size() != size) {
            std::cerr << "[error] output size does not match reference" << std::endl;
            return;
        }


        const T1* in_ptr = static_cast<const T1*>(in_image.data());
		vec3d<double> in_spacing = in_image.spacing();
		vec3d<int> in_size = in_image.size();
		vec3d<size_t> in_strides = in_image.strides();

        T2* out_ptr = static_cast<T2*>(out.data());
		vec3d<double> out_origin = frame.get_origin();
		vec3d<double> out_origin_voxel = in_image.world_to_voxel(out_origin);
		vec3d<double> out_spacing = frame.get_spacing();
		vec3d<size_t> out_strides = out.strides();

		vec3d<double> voxel_offset[3];
		for (int i = 0; i < 3; ++i) {
			vec3d<double> tmp1 = frame.get_axis(i) * out_spacing[i];
			for (int j = 0; j < 3; ++j) {
				vec3d<double> tmp2 = in_image.axis(j) / in_spacing[j];
				voxel_offset[i][j] = vec3d<double>::dot_prod(tmp1, tmp2);
			}
		}

		//Convert bounding box (voxel cooridnates) in input image to voxel cooridnates in output image
		vec3d<double> out_min_corner, out_max_corner;
		for (int i = 0; i < 3; i++)
		{
            out_min_corner[i] = (std::numeric_limits<double>::max)();
            out_max_corner[i] = (std::numeric_limits<double>::lowest)();
		}

		std::vector< vec3d<double> > cornerlist;
		cornerlist.resize(8);
		cornerlist[0] = vec3d<double>(mincorner[0], mincorner[1], mincorner[2]);
		cornerlist[1] = vec3d<double>(mincorner[0], maxcorner[1], mincorner[2]);
		cornerlist[2] = vec3d<double>(mincorner[0], mincorner[1], maxcorner[2]);
		cornerlist[3] = vec3d<double>(mincorner[0], maxcorner[1], maxcorner[2]);
		cornerlist[4] = vec3d<double>(maxcorner[0], mincorner[1], mincorner[2]);
		cornerlist[5] = vec3d<double>(maxcorner[0], maxcorner[1], mincorner[2]);
		cornerlist[6] = vec3d<double>(maxcorner[0], mincorner[1], maxcorner[2]);
		cornerlist[7] = vec3d<double>(maxcorner[0], maxcorner[1], maxcorner[2]);
		for (int i = 0; i < 8; i++)
		{
			vec3d<double> out_corner = out.world_to_voxel(in_image.voxel_to_world(cornerlist[i]));
			for (int j = 0; j < 3; j++)
			{
				if (out_corner[j] < out_min_corner[j]) out_min_corner[j] = out_corner[j];
				if (out_corner[j] > out_max_corner[j]) out_max_corner[j] = out_corner[j];
			}
		}
		vec3d<int> startvoxel, endvoxel;
		for (int i = 0; i < 3; i++)
		{
			startvoxel[i] = std::max(0, int(out_min_corner[i]));
			endvoxel[i] = std::min(size[i], int(out_max_corner[i])+1);
		}

		vec3d<double> slice_start_voxel = in_image.world_to_voxel(out.voxel_to_world(startvoxel.astype<double>()));
		for (int z = startvoxel[2]; z < endvoxel[2]; ++z)
		{
			vec3d<double> line_start_voxel = slice_start_voxel;
			for (int y = startvoxel[1]; y < endvoxel[1]; ++y)
			{
				vec3d<double> current_voxel = line_start_voxel;
				for (int x = startvoxel[0]; x < endvoxel[0]; ++x)
				{
					vec3d<int> nn_voxel;
					nn_voxel[0] = static_cast<int>(current_voxel[0] + 0.5);
					nn_voxel[1] = static_cast<int>(current_voxel[1] + 0.5);
					nn_voxel[2] = static_cast<int>(current_voxel[2] + 0.5);

					if (pad_t == 0) {
						// zero padding
						size_t out_index = z * out_strides[2] + y * out_strides[1] + x;
						if (nn_voxel[0] < 0 || nn_voxel[1] < 0 || nn_voxel[2] < 0)
							out_ptr[out_index] = 0;
						else if (nn_voxel[0] >= in_size[0] || nn_voxel[1] >= in_size[1] || nn_voxel[2] >= in_size[2])
							out_ptr[out_index] = 0;
						else {
							size_t in_index = 0;
							for (int i = 0; i < 3; ++i)
								in_index += nn_voxel[i] * in_strides[i];
                            out_ptr[out_index] = static_cast<T2>(in_ptr[in_index]);
						}
					}
					else if (pad_t == 1) {
						// edge padding
						for (int i = 0; i < 3; ++i)
							nn_voxel[i] = nn_voxel[i] < 0 ? 0 : (nn_voxel[i] >= in_size[i] ? in_size[i] - 1 : nn_voxel[i]);

						size_t in_index = 0;
						for (int i = 0; i < 3; ++i)
							in_index += nn_voxel[i] * in_strides[i];

                        out_ptr[z * out_strides[2] + y * out_strides[1] + x] = static_cast<T2>(in_ptr[in_index]);
					}
					else {
						std::cerr << "[error] invalid padding type" << std::endl;
						return;
					}

					current_voxel += voxel_offset[0];
				}
				line_start_voxel += voxel_offset[1];
			}
			slice_start_voxel += voxel_offset[2];
		}

		//final = clock() - init;
		//std::cout << "\nresample_nn_bb takes "<<(double)final / ((double)CLOCKS_PER_SEC)<<std::endl;
		return;
	}

    /*! \brief resample an image volume using nearest neighbor
	 *
	 *  \param in_image an input image volume
	 *  \param frame    the resample frame
	 *  \param size     the crop size
	 *  \param pad_t    padding type (0 for zero-padding, 1 for edge-padding)
	 *  \param out      the output crop volume
	 */
    template <typename T1, typename T2>
	void resample_nn(const Image3d& in_image, const Frame3d& frame, const vec3d<int>& size, int pad_t, Image3d& out)
	{
		//clock_t init, final;
		//init = clock();

		if (pad_t < 0 || pad_t > 1) {
			std::cerr << "[error] invalid padding type" << std::endl;
			return;
		}

		out.clear_state();
		out.set_frame(frame);
        out.allocate(size, pixel_type_traits<T2>::value());

        const T1* in_ptr = static_cast<const T1*>(in_image.data());
		vec3d<double> in_spacing = in_image.spacing();
		vec3d<int> in_size = in_image.size();
		vec3d<size_t> in_strides = in_image.strides();

        T2* out_ptr = static_cast<T2*>(out.data());
		vec3d<double> out_origin = frame.get_origin();
		vec3d<double> out_origin_voxel = in_image.world_to_voxel(out_origin);
		vec3d<double> out_spacing = frame.get_spacing();
		vec3d<size_t> out_strides = out.strides();

		vec3d<double> voxel_offset[3];
		for (int i = 0; i < 3; ++i) {
			vec3d<double> tmp1 = frame.get_axis(i) * out_spacing[i];
			for (int j = 0; j < 3; ++j) {
				vec3d<double> tmp2 = in_image.axis(j) / in_spacing[j];
				voxel_offset[i][j] = vec3d<double>::dot_prod(tmp1, tmp2);
			}
		}

		vec3d<double> slice_start_voxel = out_origin_voxel;
		for (int z = 0; z < size[2]; ++z)
		{
			vec3d<double> line_start_voxel = slice_start_voxel;
			for (int y = 0; y < size[1]; ++y)
			{
				vec3d<double> current_voxel = line_start_voxel;
				for (int x = 0; x < size[0]; ++x)
				{
					vec3d<int> nn_voxel;
					nn_voxel[0] = static_cast<int>(current_voxel[0] + 0.5);
					nn_voxel[1] = static_cast<int>(current_voxel[1] + 0.5);
					nn_voxel[2] = static_cast<int>(current_voxel[2] + 0.5);

					if (pad_t == 0) {
						// zero padding
						size_t out_index = z * out_strides[2] + y * out_strides[1] + x;
						if (nn_voxel[0] < 0 || nn_voxel[1] < 0 || nn_voxel[2] < 0)
							out_ptr[out_index] = 0;
						else if (nn_voxel[0] >= in_size[0] || nn_voxel[1] >= in_size[1] || nn_voxel[2] >= in_size[2])
							out_ptr[out_index] = 0;
						else {
							size_t in_index = 0;
							for (int i = 0; i < 3; ++i)
								in_index += nn_voxel[i] * in_strides[i];
                            out_ptr[out_index] = static_cast<T2>(in_ptr[in_index]);
						}
					}
					else if (pad_t == 1) {
						// edge padding
						for (int i = 0; i < 3; ++i)
							nn_voxel[i] = nn_voxel[i] < 0 ? 0 : (nn_voxel[i] >= in_size[i] ? in_size[i] - 1 : nn_voxel[i]);

						size_t in_index = 0;
						for (int i = 0; i < 3; ++i)
							in_index += nn_voxel[i] * in_strides[i];

                        out_ptr[z * out_strides[2] + y * out_strides[1] + x] = static_cast<T2>(in_ptr[in_index]);
					}
					else {
						std::cerr << "[error] invalid padding type" << std::endl;
						return;
					}

					current_voxel += voxel_offset[0];
				}
				line_start_voxel += voxel_offset[1];
			}
			slice_start_voxel += voxel_offset[2];
		}

		//final = clock() - init;
		//std::cout << "\nresample_nn takes " << (double)final / ((double)CLOCKS_PER_SEC) << std::endl;
	}


    /*! \brief resample a volume with new spacing and pad dimensions to multiples of a scalar using RAI coordinates
     *
     *  \param image         an image3d object
     *  \param spacing       the new 3d spacing
     *  \param multiple      base multiple
     *  \param padtype       padding type, 0 for zero padding, 1 for edge padding
     *  \param out           a resampled and padded image3d object
     */
    template <typename T1, typename T2>
    void resample_volume_nn_with_padding_rai(const Image3d& image, const vec3d<double>& spacing, int multiple,
                                             int padtype, Image3d& out)
    {
        vec3d<double> min_coord, max_coord;
        image.world_box(min_coord, max_coord);

        Frame3d frame3;
        frame3.set_origin(min_coord);
        frame3.set_spacing(spacing);

        vec3d<int> out_size;
        for(int i = 0; i < 3; ++i) {
            int s = static_cast<int>((max_coord[i] - min_coord[i]) / spacing[i] + 0.5);
            out_size[i] = static_cast<int>(std::ceil(s * 1.0 / multiple) * multiple);
        }

        resample_nn<T1,T2>(image, frame3, out_size, padtype, out);
    }


    /*! \brief resample a volume with a frame and size, pad dimensions to multiples of a scalar
     *
     *  \param image            an image3d object
     *  \param frame            the new frame
     *  \param size             the output volume size
     *  \param multiple         base multiple
     *  \param padtype          padding type, 0 for zero-padding, 1 for edge padding
     *  \return a resampled and padded image3d object
     */
    template <typename T1, typename T2>
    void resample_volumn_nn_with_padding(const Image3d& image, const Frame3d& frame, const vec3d<int>& size, int multiple,
                                         int padtype, Image3d& out)
    {
        vec3d<int> pad_size;
        for(int i = 0; i < 3; ++i)
            pad_size[i] = static_cast<int>(std::ceil(size[i] * 1.0 / multiple) * multiple);

        resample_nn<T1,T2>(image, frame, pad_size, padtype, out);
    }


	/*! \brief crop a sub-volume from a volume
	 *
	 *  If the crop exceeds the volume, use zero padding
	 *
	 *  \param image    an image3d object
	 *  \param sp       start voxel (inclusive)
	 *  \param ep       end voxel (exclusive)
	 *  \param out      output image3d object
	 */
	template <typename T>
	void crop(const Image3d& image, const vec3d<int>& sp, const vec3d<int>& ep, Image3d& out)
	{
		vec3d<int> out_size = ep - sp;
		vec3d<double> origin = image.voxel_to_world(sp.astype<double>());

		out.clear_state();
		out.set_frame(image.frame());
		out.set_origin(origin);
		out.allocate(out_size, image.pixel_type());

		for (int z = 0; z < out_size[2]; ++z) {
			for (int y = 0; y < out_size[1]; ++y) {
				for (int x = 0; x < out_size[0]; ++x) {
					T value = get_pixel<T>(image, x + sp[0], y + sp[1], z + sp[2]);
					set_pixel<T>(out, x, y, z, value);
				}
			}
		}
	}


    /*! \brief select random voxels from image
	 *
     *  \param image    an image3d object
	 *  \param num      the number of random voxels
     *  \param min_val  the minimum value
     *  \param max_val  the maximum value
	 *  \param voxels   the output buffer
	 *  \return the number of voxels selected (might be less than num)
	 */
	template <typename T>
    int random_voxels(const Image3d& image, int num, double min_val, double max_val, int* voxels)
	{
		std::vector<size_t> object_voxels;

        const T* in_ptr = static_cast<const T*>(image.data());
        vec3d<int> size = image.size();
		size_t num_voxels = size.self_prod<size_t>();

		for (size_t i = 0; i < num_voxels; ++i) {
            double val = static_cast<double>(in_ptr[i]);
            if (val >= min_val && val <= max_val)
				object_voxels.push_back(i);
		}

		std::random_shuffle(object_voxels.begin(), object_voxels.end());

		int select_num = std::min(num, static_cast<int>(object_voxels.size()));
		size_t plane_num = static_cast<size_t>(size[0]) * static_cast<size_t>(size[1]);

		for (int i = 0; i < select_num; ++i) {
			voxels[i * 3] = static_cast<int>(object_voxels[i] % plane_num % static_cast<size_t>(size[0]));
            voxels[i * 3 + 1] = static_cast<int>(object_voxels[i] % plane_num / static_cast<size_t>(size[0]));
			voxels[i * 3 + 2] = static_cast<int>(object_voxels[i] / plane_num);
		}

		return select_num;
    }


	/*! \brief convert multi-class label to binary label
	 *
	 *  \param mask a multi-class label map
	 *  \param label the target label
	 */
	template <typename T>
	void convert_multi_label_to_binary(Image3d& mask, int label)
	{
		T* in_ptr = static_cast<T*>(mask.data());
		vec3d<int> size = mask.size();
		size_t num_voxels = size.self_prod<size_t>();

		for (size_t i = 0; i < num_voxels; ++i) {
			int value = static_cast<int>(in_ptr[i]);
			if (value == label)
				in_ptr[i] = static_cast<T>(1);
			else
				in_ptr[i] = static_cast<T>(0);
		}
	}


	/*! \brief normalize the image with mean and standard deviation
	 *
	 *  \param image        the image3d object
	 *  \param mean         the mean intensity
	 *  \param stddev       the standard deviation
     *  \param clip         whether to clip value between -1 and 1
	 */
	template <typename T>
    void intensity_normalize(Image3d& image, double mean, double stddev, bool clip)
	{
		T* in_ptr = static_cast<T*>(image.data());
		vec3d<int> size = image.size();
		size_t num_voxels = size.self_prod<size_t>();

		for (size_t i = 0; i < num_voxels; ++i) {
			double v = (static_cast<double>(in_ptr[i]) - mean) / stddev;
            if(clip) {
                if(v < -1) v = -1;
                if(v > 1) v = 1;
            }
			in_ptr[i] = static_cast<T>(v);
		}
	}


    /*! \brief get max,min and average of a data buffer
	*
    *  \param data_ptr      the data buffer pointer
    *  \param num_voxels    the size of the buffer
	*  \param max_value     the max intensity
	*  \param min_value     the min intensity
	*  \param avg_value     the average intensity
	*/
	template <typename T>
    void max_min_avg(const T* data_ptr, size_t num_voxels, T& max_value, T& min_value, double& avg_value)
	{
		min_value = (std::numeric_limits<T>::max)();
		max_value = (std::numeric_limits<T>::min)();

		double sum(0);
		for (size_t i = 0; i < num_voxels; ++i) {
			sum += (double)data_ptr[i];
			if (min_value > data_ptr[i])
				min_value = data_ptr[i];
			if (max_value < data_ptr[i])
				max_value = data_ptr[i];
		}
		avg_value = sum / (double)num_voxels;
	}


    /*! \brief get max, min and average of an image
     *
     *  \param image        the image3d object
     *  \param max_value    the max intensity
     *  \param min_value    the min intensity
     *  \param avg_value    the average intensity
     */
    template <typename T>
    void max_min_avg(const Image3d& image, double& max_value, double& min_value, double& avg_value)
    {
        T max_v = T(), min_v = T();
        const T* data_ptr = static_cast<const T*>(image.data());

        max_min_avg<T>(data_ptr, image.size().self_prod<size_t>(), max_v, min_v, avg_value);
        max_value = static_cast<double>(max_v);
        min_value = static_cast<double>(min_v);
    }

    /*! \brief get mass center of an image, weighted by the voxel value.
    *
    *  \param image        an image3d object
    *  \param minVal       minimum value of intensity range (inclusive)
    *  \param maxVal       maximum value of intensity range (inclusive)
    *  \param masscenter   weighted mass center in voxel coordinates
    *  \return             true for success and false for failure
    */
    template <typename T>
    bool weighted_mass_voxel_center(const Image3d& image, double minVal, double maxVal, vec3d<double>& masscenter)
    {
        vec3d<int> size = image.size();
        const T* data_ptr = static_cast<const T*>(image.data());

        size_t width = static_cast<size_t>(size[0]);
        size_t height = static_cast<size_t>(size[1]);
        size_t depth = static_cast<size_t>(size[2]);

        double validvoxelsum(0);
        masscenter = vec3d<double>(0, 0, 0);

        for (size_t z = 0; z < depth; z++)
            for (size_t y = 0; y < height; y++)
                for (size_t x = 0; x < width; x++)
                {
                    double value = static_cast<double>(data_ptr[z * width * height + y * width + x]);
                    if (value >= minVal && value <= maxVal)
                    {
                        masscenter[0] += x * value;
                        masscenter[1] += y * value;
                        masscenter[2] += z * value;
                        validvoxelsum += value;
                    }
                }

        if (validvoxelsum == 0)
        {
            std::cerr << "[error] no voxel within intensity range" << std::endl;
            return false;
        }

        for (int i = 0; i < 3; i++)
        {
            masscenter[i] /= validvoxelsum;
        }
        return true;
    }


	/*! \brief get mass center of an image
	*
	*  \param image        an image3d object
    *  \param minVal       minimum value of intensity range (inclusive)
    *  \param maxVal       maximum value of intensity range (inclusive)
	*  \param masscenter   mass center in voxel coordinates
    *  \return             true for success and false for failure
	*/
	template <typename T>
	bool mass_voxel_center(const Image3d& image, double minVal, double maxVal, vec3d<double>& masscenter)
	{
		vec3d<int> size = image.size();
		const T* data_ptr = static_cast<const T*>(image.data());

		size_t width = static_cast<size_t>(size[0]);
		size_t height = static_cast<size_t>(size[1]);
		size_t depth = static_cast<size_t>(size[2]);

        size_t validvoxelnum(0);
		masscenter = vec3d<double>(0, 0, 0);

        for (size_t z = 0; z < depth; z++)
            for (size_t y = 0; y < height; y++)
                for (size_t x = 0; x < width; x++)
				{
                    double value = static_cast<double>(data_ptr[z * width * height + y * width + x]);
                    if (value >= minVal && value <= maxVal)
					{
						masscenter[0] += x;
						masscenter[1] += y;
						masscenter[2] += z;
						validvoxelnum++;
					}
				}

		if (validvoxelnum == 0)
		{
			std::cerr << "[error] no voxel within intensity range" << std::endl;
			return false;
		}

		for (int i = 0; i < 3; i++)
		{
			masscenter[i] /= (double)validvoxelnum;
		}
		return true;
	}


	/*! \brief get bounding box of voxels within certain intensity range
	*
	*  \param image        an image3d object
	*  \param minVal       minimum value of intensity range (close range)
	*  \param maxVal       maximum value of intensity range (close range)
	*  \param mincorner    min corner
	*  \param maxcorner    max corner
    *  \return             true for success and false for failure
	*/
	template <typename T>
	bool boundingbox_voxel(const Image3d& image, double minVal, double maxVal, vec3d<int>& mincorner, vec3d<int>& maxcorner)
	{
		vec3d<int> size = image.size();
		const T* data_ptr = static_cast<const T*>(image.data());

		size_t width = static_cast<size_t>(size[0]);
		size_t height = static_cast<size_t>(size[1]);
		size_t depth = static_cast<size_t>(size[2]);

        size_t validvoxelnum(0);
		for (int i = 0; i < 3; i++)
		{
			mincorner[i] = (std::numeric_limits<int>::max)();
			maxcorner[i] = (std::numeric_limits<int>::min)();
		}

		for (int z = 0; z < depth; z++)
			for (int y = 0; y < height; y++)
				for (int x = 0; x < width; x++)
				{
                    size_t idx = z * width * height + y * width + x;
                    double value = static_cast<double>(data_ptr[idx]);
                    if (value >= minVal && value <= maxVal)
                    {
						if (x < mincorner[0]) mincorner[0] = x;
						if (y < mincorner[1]) mincorner[1] = y;
						if (z < mincorner[2]) mincorner[2] = z;

						if (x > maxcorner[0]) maxcorner[0] = x;
						if (y > maxcorner[1]) maxcorner[1] = y;
						if (z > maxcorner[2]) maxcorner[2] = z;

						validvoxelnum++;
					}
				}

		if (validvoxelnum == 0)
		{
            // std::cerr << "[error] no voxel within intensity range" << std::endl;
			return false;
		}

		return true;
	}


    template <typename T1, typename T2>
    size_t _mark_component(Image3d& image, int x, int y, int z, int component_idx, Image3d& label_image)
    {
        vec3d<int> imsize = image.size();
        vec3d<size_t> stride = image.strides();
        T1* image_data_ptr = static_cast<T1*>(image.data());
        T2* label_data_ptr = static_cast<T2*>(label_image.data());

        //mark input point
        std::queue<vec3d<int>> q;
        q.push(vec3d<int>(x, y, z));
        set_pixel(label_image, x, y, z, static_cast<T2>(component_idx));

        size_t comp_size = 0;
        while(!q.empty())
        {
            vec3d<int> v = q.front();
            q.pop();
            ++ comp_size;

            for(int dz = -1; dz <= 1; ++dz) {
                for(int dy = -1; dy <= 1; ++dy) {
                    for(int dx = -1; dx <= 1; ++dx) {
                        // 6-neighborhood
                        if(std::abs(dx) + std::abs(dy) + std::abs(dz) != 1)
                            continue;
                        vec3d<int> nb(dx+v[0],dy+v[1],dz+v[2]);
                        // out of image boundary
                        if(nb[0] < 0 || nb[1] < 0 || nb[2] < 0)
                            continue;
                        if(nb[0] >= imsize[0] || nb[1] >= imsize[1] || nb[2] >= imsize[2])
                            continue;
                        size_t data_index = nb[0] + nb[1] * stride[1] + nb[2] * stride[2];
                        int value = static_cast<int>(image_data_ptr[data_index]);
                        int value_label = static_cast<int>(label_data_ptr[data_index]);
                        // except background and already labeled
                        if(value == 1 && value_label != component_idx){
                            label_data_ptr[data_index] = static_cast<T2>(component_idx);
                            q.push(nb);
                        }
                    }
                }
            }
        }//end of while

        return comp_size;
    }

    /*! \brief pick the largest connected component from binary image (inplace)
     *
     *  Note for inplace = true:
     *  In order for this function to work correctly, each pixel has value 0 or 1.
     *  The pixel type must be large enough to hold component index, e.g., short
     *
     *  \param image        an image3d object (treated as binary image)
     *  \param inplace      create a new int image to mark the components when inplace is false,
     *                      or it will mark components in input char image(only support 127 conponents).
     *
     *  \return the size of largest connected component
     */
    template <typename T>
    size_t pick_largest_component(Image3d& image, bool inplace=false)
    {
        vec3d<int> imsize = image.size();
        vec3d<size_t> stride = image.strides();

        // (component index, component size)
        std::vector<std::pair<int, size_t>> components;
        int start_label = 2, component_idx = start_label;

        // label_image is input image if inplace is true
        // otherwise create a label image of the same size as input image
        Image3d label_image, *label_imptr = nullptr;

        if (inplace) {
            label_imptr = &image;
        }
        else{
            // Creating an image in int type to mark components, for the reason that char input can only mark 127 components.
            label_image.allocate(imsize[0], imsize[1], imsize[2], PT_INT);
            label_image.set_zeros();
            label_imptr = &label_image;
        }

        PixelType ptype_im = image.pixel_type();
        PixelType ptype_la = label_image.pixel_type();

        for(int z = 0; z < imsize[2]; ++z) {
            for(int y = 0; y < imsize[1]; ++y) {
                for(int x = 0; x < imsize[0]; ++x) {

                    size_t data_index = x + y * stride[1] + z * stride[2];

                    double value = 0.0, label_value = 0.0;
                    ptypeassign_1(get_pixel_by_index, ptype_im, value, image, data_index);
                    ptypeassign_1(get_pixel_by_index, ptype_la, label_value, *label_imptr, data_index);

                    if(int(value) == 1 && int(label_value) < start_label) {
                        size_t comp_size = 0;
                        ptypeassign_2(_mark_component, ptype_im, ptype_la, comp_size, image, x, y, z, component_idx, *label_imptr);
                        components.push_back(std::make_pair(component_idx, comp_size));
                        ++component_idx;
                    }
                }
            }
        } //end of 3-loop for

        // empty image
        if(components.size() == 0)
            return 0;

        // from largest to smallest
        typedef std::pair<int, size_t> PairType;
        std::sort(components.begin(), components.end(), [](PairType& left, PairType& right){
            return left.second > right.second;
        });

        // pick out the largest component
        int target_label = components[0].first;
        size_t num_voxel = imsize.self_prod<size_t>();

        T* image_data_ptr = static_cast<T*>(image.data());
        for(size_t i = 0; i < num_voxel; ++i) {
           double label_value;
           ptypeassign_1(get_pixel_by_index, ptype_la, label_value, *label_imptr, i);
           if(static_cast<int>(label_value) == target_label)
               image_data_ptr[i] = static_cast<T>(1);
            else
               image_data_ptr[i] = static_cast<T>(0);
        }

        return components[0].second;
    }


    /*! \brief replace one pixel value in image with a specified value
     *
     *  this function does replacement in place.
     *
     *  \param target_value the target value to replace
     *  \param replace_value the replaced value
     */
    template <typename T>
    void replace_pixel(Image3d& image, double target_value, double replace_value)
    {
        T target = static_cast<T>(target_value);
        T replace = static_cast<T>(replace_value);

        size_t num_voxels = image.size().self_prod<size_t>();
        T* ptr = static_cast<T*>(image.data());
        for(size_t i = 0; i < num_voxels; ++i) {
            if(ptr[i] == target)
                ptr[i] = replace;
        }
    }


    /*! \brief compute image quantile
     *
     *  \param image the 3d image volume
     *  \param quantiles the image quantile (increasing and last value = 1)
     *  \param xvalues the x-axis values that correspond to each quantile
     *  \param value2idx the intensity value to quantile index
     */
    template <typename T>
    void _image_quantile(const Image3d& image, std::vector<double>& quantiles, std::vector<double>& xvalues, std::map<T,size_t>& value2idx)
    {
        std::map<T, size_t> im_hist;

        const T* im_data = static_cast<const T*>(image.data());
        size_t im_voxels = image.size().self_prod<size_t>();
        for(size_t i = 0; i < im_voxels; ++i)
            ++ im_hist[im_data[i]];

        quantiles.resize(im_hist.size());
        xvalues.resize(im_hist.size());

        size_t i = 0;
		for(auto p = im_hist.begin(); p != im_hist.end(); ++p) {
            xvalues[i] = static_cast<double>(p->first);
            if(i == 0)
                quantiles[i] = static_cast<double>(p->second);
            else
                quantiles[i] = quantiles[i - 1] + static_cast<double>(p->second);
            value2idx[p->first] = i;
            ++ i;
        }

        // normalize to 1
        double sum = quantiles[quantiles.size()-1];
        for(size_t i = 0; i < quantiles.size(); ++i) {
            quantiles[i] /= sum;
        }
    }


    /*! \brief linear interpolate points on curve
     *
     *  It is better to use float or double as T
     *
     *  \param interp_x the interpolated x values
     *  \param curve_x the x values on the curve (sorted, increasing)
     *  \param curve_y the y values on the curve
     *  \param len the number of points on the curve
     *  \param interp_y the interpolated y values (output)
     */
    template <typename T>
    void curve_linear_interp(const T* interp_x, size_t interp_len, const T* curve_x,
                             const T* curve_y, size_t curve_len, T* interp_y)
    {
        for(size_t i = 0; i < interp_len; ++i) {
            auto iter = std::lower_bound(curve_x, curve_x + curve_len, interp_x[i]);
            size_t interp_idx = static_cast<size_t>(iter - curve_x);
            if(interp_idx == curve_len)
                interp_y[i] = curve_y[curve_len-1];
            else if(interp_idx == 0)
                interp_y[i] = curve_y[0];
            else {
                double left_x = static_cast<double>(curve_x[interp_idx-1]);
                double left_y = static_cast<double>(curve_y[interp_idx-1]);

                double right_x = static_cast<double>(curve_x[interp_idx]);
                double right_y = static_cast<double>(curve_y[interp_idx]);

                double x = interp_x[i];
                double y = (x - left_x) / (right_x - left_x) * (right_y - left_y) + left_y;
                interp_y[i] = static_cast<T>(y);
            }
        }
    }


    /*! \brief histogram matching
     *
     *  this function maps the histogram of one image to that of a reference image
     *
     *  \param image the target image to be transformed
     *  \param refimage the reference image
     */
    template <typename T1, typename T2>
    void hist_match(Image3d& image, const Image3d& refimage)
    {
        std::vector<double> im_quantiles, im_xvalues;
        std::map<T1, size_t> im_v2i;
        _image_quantile(image, im_quantiles, im_xvalues, im_v2i);

        std::vector<double> ref_quantiles, ref_xvalues;
        std::map<T2, size_t> ref_v2i;
        _image_quantile(refimage, ref_quantiles, ref_xvalues, ref_v2i);

        // interpolate to get the x values of im_quantiles in reference quantile curve
        std::vector<double> interp_xvalues(im_quantiles.size());
        curve_linear_interp<double>(im_quantiles.data(), im_quantiles.size(),
                                    ref_quantiles.data(), ref_xvalues.data(),
                                    ref_xvalues.size(), interp_xvalues.data());

        // intensity mapping
        T1* ptr = static_cast<T1*>(image.data());
        size_t num_voxels = image.size().self_prod<size_t>();
        for(size_t i = 0; i < num_voxels; ++i) {
            T1 v = ptr[i];
            size_t idx = im_v2i[v];
            ptr[i] = static_cast<T1>(interp_xvalues[idx]);
        }
    }


    /*! \brief compute percentile of intensities in image
     *
     *  \param image an image3d object
     *  \param percents multiple percentiles
     *  \param num the number of percentiles
     *  \param out the output intensities at input percentiles
     */
    template <typename T>
    void percentiles(const Image3d& image, const double* percents, size_t num, double* out)
    {
        size_t num_voxels = image.size().self_prod<size_t>();
        std::vector<T> buffer(num_voxels);

        const T* data = static_cast<const T*>(image.data());
        for(size_t i = 0; i < num_voxels; ++i)
            buffer[i] = data[i];

        std::sort(buffer.begin(), buffer.end());

        for(size_t i = 0; i < num; ++i) {
            double idx = static_cast<double>(num_voxels-1) * percents[i];
            idx = static_cast<double>(static_cast<int>(idx + 0.5));
            if(idx < 0)
                idx = 0;
            if(idx > static_cast<double>(num_voxels-1))
                idx = static_cast<double>(num_voxels-1);
            size_t iidx = static_cast<size_t>(idx);
            out[i] = static_cast<double>(buffer[iidx]);
        }
    }


    /*! \brief count the labels in image
     *
     *  \param image        an image3d object
     *  \param has_label    a 256-size array with value indicating this label exists
     *  \return the number of labels in the image
     */
    template <typename T>
    int count_labels(const Image3d& image, int* has_label)
    {
        const size_t max_labels = 256;
        memset(has_label, 0, sizeof(int) * max_labels);

        const T* data = static_cast<const T*>(image.data());
        size_t num_voxels = image.size().self_prod<size_t>();

        int count = 0;
        for(size_t i = 0; i < num_voxels; ++i)
        {
            int value = static_cast<int>(data[i]);
            if(value > 0 && value < max_labels) {
                if(!has_label[value])
                    ++count;
                has_label[value] = true;
            }
        }

        return count;
    }


    /*! \brief compute multiple bounding boxes for given labels in one pass
     *
     *  \param image        an image3d object
     *  \param labels       the label array
     *  \param num_labels   the number of labels of interest
     *  \param boxes        the 6x output array, each consists of 3-size min_coord and 3-size max_coord
     */
    template <typename T>
    void boundingbox_voxel_multi(const Image3d& image, const int* labels, int num_labels, int* boxes)
    {
        std::unordered_map<int, int> value_to_idx;

        for(int i = 0; i < num_labels; ++i) {
            boxes[i * 6] = (std::numeric_limits<int>::max)();
            boxes[i * 6 + 1] = (std::numeric_limits<int>::max)();
            boxes[i * 6 + 2] = (std::numeric_limits<int>::max)();
            boxes[i * 6 + 3] = (std::numeric_limits<int>::min)();
            boxes[i * 6 + 4] = (std::numeric_limits<int>::min)();
            boxes[i * 6 + 5] = (std::numeric_limits<int>::min)();
            value_to_idx[labels[i]] = i;
        }

        vec3d<int> size = image.size();
        const T* data = static_cast<const T*>(image.data());

        for(int z = 0; z < size[2]; ++z) {
            for(int y = 0; y < size[1]; ++y) {
                for(int x = 0; x < size[0]; ++x) {
                    vec3d<int> coord3(x, y, z);
                    int value = static_cast<int>(get_pixel<T>(image, x, y, z));
                    auto iter = value_to_idx.find(value);
                    if(iter != value_to_idx.end()) {
                        int label_idx = iter->second;
                        for(int i = 0; i < 3; ++i) {
                            if(boxes[label_idx * 6 + i] > coord3[i])
                                boxes[label_idx * 6 + i] = coord3[i];
                            if(boxes[label_idx * 6 + 3 + i] < coord3[i])
                                boxes[label_idx * 6 + 3 + i] = coord3[i];
                        }
                    }
                }
            }
        }

        // if label not detected, reset the box to all zeros
        for(int i = 0; i < num_labels; ++i)
        {
            bool flag = false;
            for(int j = 0; j < 3; ++j) {
                if(boxes[i * 6 + j] >= boxes[i * 6 + 3 + j]) {
                    flag = true; break;
                }
            }
            if(flag) {
                for(int j = 0; j < 6; ++j)
                    boxes[i * 6 + j] = 0;
            }
        }
    }

    /*! \brief flip the image along one axis
     *
     *  \param image        an image3d object
     *  \param axis         the axis index [0-2]
     */
    template <typename T>
    void imflip(Image3d& image, int axis)
    {
        if(axis < 0 || axis > 2) {
            std::cerr << "[Warning] Axis index out of range, ignored" << std::endl;
            return;
        }

        T* data = static_cast<T*>(image.data());
        vec3d<int> size = image.size();
        vec3d<size_t> strides = image.strides();

        if(axis == 0) {
            for(int z = 0; z < size[2]; ++z) {
                for(int y = 0; y < size[1]; ++y) {
                    int start = 0, end = size[0] - 1;
                    while(start < end) {
                        size_t start_i = z * strides[2] + y * strides[1] + start;
                        size_t end_i = z * strides[2] + y * strides[1] + end;
                        std::swap(data[start_i], data[end_i]);
                        ++ start; -- end;
                    }
                }
            }
        }
        else if(axis == 1) {
            for(int z = 0; z < size[2]; ++z) {
                for(int x = 0; x < size[0]; ++x) {
                    int start = 0, end = size[1] - 1;
                    while(start < end) {
                        size_t start_i = z * strides[2] + start * strides[1] + x;
                        size_t end_i = z * strides[2] + end * strides[1] + x;
                        std::swap(data[start_i], data[end_i]);
                        ++ start; -- end;
                    }
                }
            }
        }
        else if(axis == 2) {
            for(int y = 0; y < size[1]; ++y) {
                for(int x = 0; x < size[0]; ++x) {
                    int start = 0, end = size[2] - 1;
                    while(start < end) {
                        size_t start_i = start * strides[2] + y * strides[1] + x;
                        size_t end_i = end * strides[2] + y * strides[1] + x;
                        std::swap(data[start_i], data[end_i]);
                        ++ start; -- end;
                    }
                }
            }
        }
        else {
            std::cerr << "[Error] Axis index out of range, unexpected" << std::endl;
            return;
        }
    }


    /*! \brief Image padding
     *
     *  \param image       an image object
     *  \param pad         an vec3d object
     */
    template <typename T>
    void impad(Image3d &image, const vec3d<int> &pad){
        T* data = static_cast<T* >(image.data());
        vec3d<int> size = image.size();
        vec3d<size_t> stride = image.strides();

        Image3d image_tmp(image.width()+pad[0]*2, image.height()+pad[1]*2, image.depth()+pad[2]*2, image.pixel_type());
        T* data_tmp = static_cast<T* >(image_tmp.data());
        vec3d<int> sizet = image_tmp.size();
        vec3d<size_t> stridet = image_tmp.strides();

        int minx = pad[0]; int maxx = sizet[0] - pad[0];
        int miny = pad[1]; int maxy = sizet[1] - pad[1];
        int minz = pad[2]; int maxz = sizet[2] - pad[2];
        T default_value = 0;
        #pragma omp parallel for
        for (int z = 0; z < sizet[2]; z++){
            for (int y = 0; y < sizet[1]; y++){
                for (int x = 0; x < sizet[0]; x++){
                    if (x<minx || x>=maxx || y<miny || y>=maxy || z<minz || z>=maxz)
                        data_tmp[x + y*stridet[1] + z*stridet[2]] = default_value;
                    else
                        data_tmp[x + y*stridet[1] + z*stridet[2]] = data[x-pad[0] + (y-pad[1])*stride[1] + (z-pad[2])*stride[2]];
                }
            }
        }//end of for
        image.copy_data(data_tmp, image_tmp.width(), image_tmp.height(), image_tmp.depth(), image.pixel_type());
        vec3d<double> origin(image.origin());
        vec3d<double> spacing(image.spacing());
        for (int i = 0; i < 3; i++){
            origin[i] = origin[i] - (pad[i]*spacing[i]);
        }
        image.set_origin(origin);
    }

}

#endif // IMAGE_TOOLS_H

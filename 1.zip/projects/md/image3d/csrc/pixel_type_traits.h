#ifndef PIXEL_TYPE_TRAITS_H
#define PIXEL_TYPE_TRAITS_H

#include "image3d/csrc/image3d.h"

namespace medvision {

/*! \brief template class to convert type to PixelType */
template <typename T>
struct pixel_type_traits {
    static PixelType value();
};

template <>
struct pixel_type_traits<unsigned char> {
    static PixelType value() {
        return PT_UCHAR;
    }
};

template <>
struct pixel_type_traits<char> {
    static PixelType value() {
        return PT_CHAR;
    }
};

template <>
struct pixel_type_traits<unsigned short> {
    static PixelType value() {
        return PT_USHORT;
    }
};

template <>
struct pixel_type_traits<short> {
    static PixelType value() {
        return PT_SHORT;
    }
};

template <>
struct pixel_type_traits<unsigned int> {
    static PixelType value() {
        return PT_UINT;
    }
};

template <>
struct pixel_type_traits<int> {
    static PixelType value() {
        return PT_INT;
    }
};

template <>
struct pixel_type_traits<unsigned long> {
    static PixelType value() {
        return PT_ULONG;
    }
};

template <>
struct pixel_type_traits<long> {
    static PixelType value() {
        return PT_LONG;
    }
};

template <>
struct pixel_type_traits<float> {
    static PixelType value() {
        return PT_FLOAT;
    }
};

template <>
struct pixel_type_traits<double> {
    static PixelType value() {
        return PT_DOUBLE;
    }
};

} // end namespace medvision

#endif // PIXEL_TYPE_TRAITS_H

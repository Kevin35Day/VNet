#ifndef FRAME3D_H
#define FRAME3D_H

#include "math/vec3d.h"
#include <iostream>

namespace medvision {

class Frame3d
{
public:
    Frame3d();
    Frame3d(const Frame3d& arg);

    /*! \brief restore the default frame */
    void restore_default();

    /*! \brief get world coordinate of origin */
    vec3d<double> get_origin() const;

    /*! \brief get spacing */
    vec3d<double> get_spacing() const;

    /*! \brief get one axis indexed from 0-2 */
    vec3d<double> get_axis(size_t i) const;

    /*! \brief set world coordinate of origin */
    void set_origin(const vec3d<double>& origin);

    /*! \brief set spacing */
    void set_spacing(const vec3d<double>& spacing);

    /*! \brief set one axis indexed from 0-2 */
    void set_axis(const vec3d<double>& axis, size_t idx);

    /*! \brief convert world coordinate to voxel coordinate */
    vec3d<double> world_to_voxel(const vec3d<double>& world) const;

    /*! \brief convert voxel coordinate to world coordinate */
    vec3d<double> voxel_to_world(const vec3d<double>& voxel) const;

    /*! \brief serialize object to stream */
    void serialize(std::ostream& out) const;

    /*! \brief deserialize object from strea */
    void deserialize(std::istream& in);

    /*! \brief number of bytes of object */
    size_t bytes() const;

    /*! \brief write object to a buffer */
    bool write_to_buffer(void* data) const;

    /*! \brief read object from a buffer */
    bool read_from_buffer(void* data);

    /*! \brief override = operator */
    Frame3d& operator=(const Frame3d& rhs);

private:
    /*! \brief world coordinate of origin */
    vec3d<double> m_origin;
    /*! \brief spacing */
    vec3d<double> m_spacing;
    /*! \brief three axes */
    vec3d<double> m_axes[3];
};

} // end namespace

#endif // FRAME3D_H

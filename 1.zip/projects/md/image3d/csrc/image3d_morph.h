/* image3d_morph.h
 *
 * template tools for morphological operations
 */

#ifndef IMAGE_MORPH_H
#define IMAGE_MORPH_H

#include "image3d/csrc/image3d.h"
#include "image3d/csrc/image3d_tools.h"
#include "image3d/csrc/pixel_type_traits.h"
#include "math/plane3d.h"
#include "utils/csrc/template_macros.h"

#include <limits>
#include <algorithm>
#include <queue>
#include <time.h>
#include <map>
#include <unordered_map>

namespace medvision {

    /*! \brief erode imput image
     *
     *  \param image        an image3d object
     *  \param iteration    erode times
     *  \param label        target label
     */
    template <typename T>
    void imerode(Image3d& image, int iteration, int label)
    {
        if (iteration < 1){
            return;
        }

        const int nebor[6][3] = {
            {1,0,0}, {0,1,0}, {0,0,1}, {-1,0,0}, {0,-1,0}, {0,0,-1}
        };

        T* data = static_cast<T* > (image.data());
        vec3d<int> im_size = image.size();
        const vec3d<size_t> strides = image.strides();
        PixelType ptype = image.pixel_type();

        Image3d image_tmp(image);
        T* data_tmp = static_cast<T*>(image_tmp.data());

        // set edge to 0
        T val = 0;
        for (int y = 0; y < im_size[1]; y++){
            for (int x = 0; x < im_size[0]; x++){
                int z = 0;
                data_tmp[z * strides[2] + y * strides[1] + x] = val;
                z = im_size[2] - 1;
                data_tmp[z * strides[2] + y * strides[1] + x] = val;
            }
        }
        for (int z = 0; z < im_size[2]; z++){
            for (int x = 0; x < im_size[0]; x++){
                int y = 0;
                data_tmp[z * strides[2] + y * strides[1] + x] = val;
                y = im_size[1] - 1;
                data_tmp[z * strides[2] + y * strides[1] + x] = val;
            }
        }
        for (int z = 0; z < im_size[2]; z++){
            for (int y = 0; y < im_size[0]; y++){
                int x = 0;
                data_tmp[z * strides[2] + y * strides[1] + x] = val;
                x = im_size[0] - 1;
                data_tmp[z * strides[2] + y * strides[1] + x] = val;
            }
        }

        //process erode iteration       
        int x_n, y_n, z_n;
        for (int i = 0; i < iteration; i++){
            for (int z = 1; z < im_size[2]-1; z++){
                for (int y = 1; y < im_size[1]-1; y++){
                    for (int x = 1; x < im_size[0]-1; x++){
                        size_t data_index = z * strides[2] + y * strides[1] + x;
                        int value = static_cast<int>( data[data_index]);
                        if (value == label){
                            for (int j =0; j < 6; j++){
                                x_n = x + nebor[j][0];
                                y_n = y + nebor[j][1];
                                z_n = z + nebor[j][2];
                                int nebor_value = static_cast<int>(data[z_n * strides[2] + y_n * strides[1] + x_n]);
                                if (nebor_value != label){
                                    data_tmp[data_index] = val;
                                    break;
                                }
                            }
                        }
                    } // end x
                } // end y
            } // end z
            image_tmp.copy_data_to(data);
        } // end iteration
    }

    /*! \brief sub fuction of imdilate
     *
     *  \param image        an image3d object
     *  \param image_tmp    an image3d object
     *  \param min_e        min coordinates of mask
     *  \param max_e        max coordinates of mask
     *  \param label        target label
     *  \param check_edge   determine if check out edge
     */
    template <typename T>
    void _sub_dilate_fun(const Image3d &image, Image3d &image_tmp, const vec3d<int> &min_e, const vec3d<int> &max_e, int label, bool check_edge =false)
    {
        const int nebor[6][3] = {
            {-1,0,0}, {1,0,0}, {0,-1,0}, {0,1,0}, {0,0,-1}, {0,0,1}
        };

        const T val = static_cast<const T>(label);
        const int width = static_cast<const int >(image.width());
        const int height = static_cast<const int>(image.height());
        const int depth = static_cast<const int>(image.depth());
        vec3d<size_t> strides = image.strides();

        const T* data = static_cast<const T*> (image.data());
        T* data_tmp = static_cast<T* >(image_tmp.data());

        if (check_edge){
            for (int z = min_e[2]; z <= max_e[2]; z++){
                for (int y = min_e[1]; y <= max_e[1]; y++){
                    for (int x = min_e[0]; x <= max_e[0]; x++){
                        if (static_cast<int>(data[z * strides[2] + y * strides[1] + x])==label)
                            continue;
                        for (int j =0; j < 6; j++){
                            int x_n = x + nebor[j][0];
                            int y_n = y + nebor[j][1];
                            int z_n = z + nebor[j][2];
                            // check if out edge
                            if (x_n<0||x_n>=width||y_n<0||y_n>=height||z_n<0||z_n>=depth)
                                continue;
                            int nebor_value = static_cast<int>(data[z_n * strides[2] + y_n * strides[1] + x_n]);
                            if (nebor_value == label){
                                data_tmp[z * strides[2] + y * strides[1] + x] = val;
                                break;
                            }
                        }
                    }
                }
            }//end of data for loop
        }
        else{
//            #pragma omp parallel for
            for (int z = min_e[2]; z <= max_e[2]; z++){
                for (int y = min_e[1]; y <= max_e[1]; y++){
                    for (int x = min_e[0]; x <= max_e[0]; x++){
                        if (static_cast<int>(data[z * strides[2] + y * strides[1] + x])==label)
                            continue;
                        for (int j =0; j < 6; j++){
                            int x_n = x + nebor[j][0];
                            int y_n = y + nebor[j][1];
                            int z_n = z + nebor[j][2];
                            int nebor_value = static_cast<int>(data[z_n * strides[2] + y_n * strides[1] + x_n]);
                            if (nebor_value == label){
                                data_tmp[z * strides[2] + y * strides[1] + x] = val;
                                break;
                            }
                        }
                    }
                }
            }//end of data for loop
        }//end of if
    }//end of function


    /*! \brief dilate imput image
     *
     *  \param image        an image3d object
     *  \param iteration    dilate times
     *  \param label        target label
     */
    template <typename T>
    void imdilate(Image3d& image, int iteration, int label)
    {
        if (iteration < 1){
            return;
        }

        vec3d<int> min_b,max_b;
        if (!boundingbox_voxel<T>(image, label, label, min_b, max_b )){
            return;
        }

        Image3d image_tmp(image);
        vec3d<int> im_size = image.size();

        //process dilate image iteration
        for (int iter = 0; iter < iteration; iter++){
            //bounding box expand 1 pixel
            for (int bi = 0; bi < 3; bi++){
                min_b[bi] = (min_b[bi]-1 > 0)? min_b[bi]-1:0;
                max_b[bi] = (max_b[bi]+1 < im_size[bi])? max_b[bi]+1:im_size[bi]-1;
            }
            // edge slice process, max 6 slices
            vec3d<int> min_org(min_b), max_org(max_b);
            for (int i = 0; i < 3; i++){
                // min edge process
                if (min_b[i] == 0){
                    vec3d<int> max_e(max_org), min_e(min_org);
                    max_e[i] = 0;
                    _sub_dilate_fun<T>(image, image_tmp, min_e, max_e, label, true);
                    min_b[i] = 1;
                }
                // max edge slice process
                if (max_b[i] == im_size[i]-1){
                    vec3d<int> max_e(max_org), min_e(min_org);
                    min_e[i] = im_size[i]-1;
                    _sub_dilate_fun<T>(image, image_tmp, min_e, max_e, label, true);
                    max_b[i] = im_size[i]-2;
                }
            }

            // dilate in bounding box, except edge voxel
             _sub_dilate_fun<T > (image, image_tmp, min_b, max_b, label, false);
            //copy data for next iteration
             image_tmp.copy_data_to(image.data());
        }//end of iter
    }//end of function

}

#endif // IMAGE_MORPH_H
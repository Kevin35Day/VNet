from PyQt5.Qt import *
from PyQt5.QtCore import Qt
import sys


class DynamicButtonPanel(QWidget):
    """ dynamically display variable number of buttons """

    # when the input text is in wrong format
    text_parse_error = pyqtSignal()

    # when a button is clicked
    button_clicked = pyqtSignal(str)

    def __init__(self, num_buttons_per_row = 4, max_allowed_buttons = 50, font_size = 16):

        super(DynamicButtonPanel, self).__init__()

        # save parameter
        self.num_buttons_per_row = num_buttons_per_row
        self.max_allowed_buttons = max_allowed_buttons
        self.font_size = font_size

        # setup layout
        main_layout = QVBoxLayout()

        # top input line edit
        input_layout = QHBoxLayout()
        text_widget = QLabel('BIDs: ')
        self.__set_font_size(text_widget)
        text_widget.setSizePolicy(QSizePolicy.Maximum, QSizePolicy.Maximum)
        input_layout.addWidget(text_widget)

        self.input_widget = QLineEdit()
        self.__set_font_size(self.input_widget)
        self.input_widget.returnPressed.connect(self.returnPressed)
        input_layout.addWidget(self.input_widget)

        main_layout.addLayout(input_layout)

        # bottom button grid
        self.button_layout = QGridLayout()
        main_layout.addLayout(self.button_layout)

        main_layout.setAlignment(Qt.AlignTop)
        self.setLayout(main_layout)

    def __parse_token(self, token):
        """ parse each token in the input text that is separated by ; """
        assert isinstance(token, str)
        if '-' not in token:
            if not token.isdigit():
                return []
            else:
                return [int(token)]
        else:
            parts = token.split('-')
            if len(parts) != 2:
                return []
            if not parts[0].isdigit() or not parts[1].isdigit():
                return []
            left = int(parts[0])
            right = int(parts[1])
            if left > right:
                return []

            return range(left, right+1)

    def __parse_ids(self):
        """ parse ids from the text input """
        text = self.input_widget.displayText()
        text = str(text)
        text = text.replace(' ', '')

        if len(text) == 0:
            self.text_parse_error.emit()
            return None

        if text[-1] == ';':
            text = text[:-1]

        ids = []

        tokens = text.split(';')
        for token in tokens:
            local_ids = self.__parse_token(token)
            if len(local_ids) == 0:
                self.text_parse_error.emit()
                return None
            ids.extend(local_ids)

        if len(ids) > self.max_allowed_buttons:
            self.text_parse_error.emit()
            return None

        ids = sorted(ids)
        return ids

    def __clear_buttons(self):
        """ clear all buttons in the grid view """
        for i in reversed(range(self.button_layout.count())):
            widget_to_remove = self.button_layout.itemAt(i).widget()
            self.button_layout.removeWidget(widget_to_remove)
            widget_to_remove.setParent(None)

    def __set_font_size(self, widget):
        """ set font size of a widget """
        font = widget.font()
        font.setPointSize(self.font_size)
        widget.setFont(font)

    def returnPressed(self):
        """ when an enter was pressed on input edit """
        ids = self.__parse_ids()
        if ids is None:
            return

        self.__clear_buttons()

        for i in range(len(ids)):
            row, col = i // self.num_buttons_per_row, i % self.num_buttons_per_row
            button = QPushButton('{}'.format(ids[i]))
            self.__set_font_size(button)
            button.clicked.connect(self.buttonClicked)
            self.button_layout.addWidget(button, row, col)

    def buttonClicked(self):
        """ when a button was clicked """
        self.button_clicked.emit(self.sender().text())


if __name__ == '__main__':

    app = QApplication(sys.argv)
    view = DynamicButtonPanel()
    view.resize(512, 512)
    view.show()
    sys.exit(app.exec_())
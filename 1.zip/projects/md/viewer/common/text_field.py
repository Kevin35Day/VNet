# -*- coding: utf-8 -*-

from PyQt5.Qt import *
from PyQt5.QtCore import Qt


class TextField(QLabel):
    
    def __init__(self, parent, group, fontsize=20, indent=20, textcolor='red'):
        
        super(TextField, self).__init__(parent=parent)

        self.group = group

        font = self.font()
        font.setPointSize(fontsize)
        self.setFont(font)
        self.setStyleSheet('QLabel { color: ' + textcolor + '; }')

        self.setIndent(indent)
        self.setAlignment(Qt.AlignCenter)

    def add_line(self, message):

        text = self.text()
        text += message + '\n'
        self.setText(text)

    def clear_text(self):

        self.setText('')


if __name__ == '__main__':

    import sys

    app = QApplication(sys.argv)
    view = TextField(None, 0, 32)
    view.resize(1024, 1024)

    text = u'医学影像大小： 512×512×100'
    view.add_line(text)

    text = u'全自动器官分割耗时： {} 秒'.format(0.5)
    view.add_line(text)

    view.show()
    sys.exit(app.exec_())



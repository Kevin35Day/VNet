import numpy as np
from PyQt5 import QtGui
from PyQt5.Qt import *
from PyQt5.QtCore import Qt
from md.image3d.python.image3d import Image3d
from md.image3d.python.image3d_tools import estimate_intensity_window, slice_nn
from md.image3d.python.image3d_vis import slice_to_bytes, bytes_to_colors, multi_image_alpha_blend
from md.viewer.common.selector import Selector
from md.viewer.common.text_field import TextField
import md.viewer.common.view3_cfg as view3_cfg
from md.viewer.common.view2 import View2


class View3(QWidget):
    """ a Qt Widget that contains multiple 2d views and selectors """

    help_str = 's:  switch focus image within group\n' \
               'h:  show/hide overlay (text + cursor)\n' \
               'w:  switch to WW/WC mode\n' \
               'a:  switch to alpha mode\n' \
               'c:  switch to color mode\n' \
               'F1: center image at cursor\n' \
               'F2: reset world coordinate system\n' \
               'F3: adjust WW/WC under current contrast\n' \
               'F5: jump across landmarks\n'

    def __init__(self, cfg, parent=None):

        super(View3, self).__init__(parent=parent)
        assert isinstance(cfg, view3_cfg.View3Config)

        self.cursor3 = np.array([0, 0, 0], dtype=np.double)
        self.center3 = np.array([0, 0, 0], dtype=np.double)
        self.spacing = 1                                    # initial spacing
        self.init_zoom_factor = 1                           # zoom factor for reseting
        self.zoom_factor = self.init_zoom_factor            # zoom factor
        self.default_v = -1024                              # default value

        # convert colormap to list of 4-tuples
        self.colormap = np.zeros((256 * 3,), dtype=np.int32)
        for i, item in enumerate(cfg.colormap.items()):
            idx = int(item[0])
            assert idx < 256 and idx >= 0
            self.colormap[idx * 3] = item[1][0]
            self.colormap[idx * 3 + 1] = item[1][1]
            self.colormap[idx * 3 + 2] = item[1][2]

        self.cfg = cfg
        self.children = []              # children widgets
        self.selectors = []             # child selectors
        self.view2_group = {}           # group_id : view2 list
        self.sel_group = {}             # group_id : selected image names
        self.textfield_group = {}       # group_id : text field

        # focus control
        self.focus_group = 0            # active group_id
        self.focus_im = {}              # group_id : focus imname

        # images
        self.images = {}                # image_name : image3d
        self.im_params = {}             # image_name : image_parameters
                                        # params: win_center, win_width, alpha, colormode

        # interactive mode
        self.mode = 0                   # 0 for regular mode
                                        # 1 for WC/WW mode
                                        # 2 for alpha mode
                                        # 3 for color mode

        # landmarks
        self.lms = {}                   # name : np.ndarray(3)
        self.lm_params = {}             # name : {'zoom_factor', 'tag_visible'}
        self.sel_lm = None              # current lm name

        # additional text shown on the right-down corner
        self.rd_text = ''
        self.rd_textcolor = QColor(255, 255, 0)
        self.rd_fontsize = 16

        # colormode str
        self.colormode_str = ['Grayscale', 'Red', 'Green', 'Blue', 'Jet', 'LabelConfig']

        # init image caches
        view_num = len(self.cfg.views)
        self.init_images(view_num)

        self.setup_ui()

    def reset_data(self):

        self.cursor3 = np.array([0, 0, 0], dtype=np.double)
        self.center3 = np.array([0, 0, 0], dtype=np.double)
        self.spacing = 1
        self.zoom_factor = 1
        self.default_v = -1024

        for group in self.sel_group.keys():
            self.sel_group[group] = set()
            self.focus_im[group] = None
        self.focus_group = self.sel_group.keys()[0]

        self.focus_im = {}
        self.images = {}
        self.im_params = {}
        self.mode = 0
        self.lms = {}
        self.sel_lm = None
        self.rd_text = ''
        self.init_images(len(self.children))

    def get_widget(self, vidx, cfg):

        if cfg['type'] == 'sel':
            widget = Selector(cfg['group'], cfg['fontsize'], parent=self)
            widget.selectionModel().selectionChanged.connect(self.selectionChanged)
            widget.key_pressed.connect(self.keyPressEvent)
        elif cfg['type'] == 'view2':
            widget = View2(cfg['x_axis'], cfg['y_axis'], cfg['o_axis'], cfg['group'], vidx,
                           cfg['enable_text'], parent=self)
            widget.rbutton_shifted.connect(self.rbuttonShifted)
            widget.wheel_scrolled.connect(self.wheelScrolled)
            widget.cursor_changed.connect(self.cursorChanged)
        elif cfg['type'] == 'text':
            widget = TextField(self, cfg['group'], cfg['fontsize'], cfg['indent'], cfg['textcolor'])
        else:
            raise ValueError('unknown widget type')

        return widget

    def init_images(self, view_num):

        self.raw_imlist = []
        self.byte_imlist = []
        self.color_imlist = []
        self.mix_im = []

        for i in range(view_num):
            self.raw_imlist.append({})
            self.byte_imlist.append({})
            self.color_imlist.append({})
            self.mix_im.append(None)

    def setup_ui(self):

        grid = QGridLayout()
        groups = set()

        for view_idx, view_cfg in enumerate(self.cfg.views):

            if view_cfg is None:
                continue

            widget = self.get_widget(view_idx, view_cfg)
            widget.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Ignored)

            self.children.append(widget)

            row = view_idx // self.cfg.cols
            col = view_idx % self.cfg.cols
            grid.addWidget(widget, row, col)

            if isinstance(widget, Selector):
                self.selectors.append(widget)
            elif isinstance(widget, TextField):
                self.textfield_group[widget.group] = widget
            elif isinstance(widget, View2):
                if widget.group in self.view2_group:
                    self.view2_group[widget.group].append(widget)
                else:
                    self.view2_group[widget.group] = [widget]

            groups.add(widget.group)

        for group in groups:
            self.sel_group[group] = set()
            self.focus_im[group] = None

        self.focus_group = list(groups)[0]
        self.setLayout(grid)

    def add_image(self, image, name, win_center=None, win_width=None, colormode=0, alpha=1):

        self.images[name] = image
        for selector in self.selectors:
            selector.add_image(name, image.size())

        if win_center is None or win_width is None:
            win_center, win_width = estimate_intensity_window(image, slice_only=False)

        self.im_params[name] = {}
        self.im_params[name]['win_center'] = win_center
        self.im_params[name]['win_width'] = win_width
        self.im_params[name]['colormode'] = colormode
        self.im_params[name]['alpha'] = alpha

    def update_raw_imlist(self, vidx, imname_list=None):

        view2 = self.children[vidx]
        if not isinstance(view2, View2):
            return

        ims = self.raw_imlist[vidx]
        if imname_list is None:
            imname_list = ims.keys()

        for imname in imname_list:
            im3 = self.images[imname]
            x_axis, y_axis = view2.x_axis, view2.y_axis
            spacing = self.spacing * self.zoom_factor
            spacing = [spacing, spacing]
            size = [view2.width(), view2.height()]
            raw_data = slice_nn(im3, self.cursor3, x_axis, y_axis, self.center3, spacing, size, self.default_v)
            raw_data = raw_data.astype(np.float32)
            self.raw_imlist[vidx][imname] = raw_data

        # raw data change triggers grayscale/byte image update
        if len(imname_list) > 0:
            self.update_byte_imlist(vidx, imname_list)

    def update_byte_imlist(self, vidx, imname_list=None):

        view2 = self.children[vidx]
        if not isinstance(view2, View2):
            return

        ims = self.byte_imlist[vidx]
        if imname_list is None:
            imname_list = ims.keys()

        for imname in imname_list:
            slice = self.raw_imlist[vidx][imname]
            colormode = self.im_params[imname]['colormode']
            if colormode == 5:
                self.byte_imlist[vidx][imname] = np.array(slice, dtype=np.uint8)
            else:
                win_center, win_width = self.im_params[imname]['win_center'], self.im_params[imname]['win_width']
                win_min, win_max = win_center - win_width / 2.0, win_center + win_width / 2.0
                self.byte_imlist[vidx][imname] = slice_to_bytes(slice, win_min, win_max)

        # byte data change triggers color image update
        if len(imname_list) > 0:
            self.update_color_imlist(vidx, imname_list)

    def update_color_imlist(self, vidx, imname_list=None):

        view2 = self.children[vidx]
        if not isinstance(view2, View2):
            return

        ims = self.color_imlist[vidx]
        if imname_list is None:
            imname_list = ims.keys()

        for imname in imname_list:
            byte_slice = self.byte_imlist[vidx][imname]
            colormode = self.im_params[imname]['colormode']
            self.color_imlist[vidx][imname] = bytes_to_colors(byte_slice, colormode, self.colormap)

        # color data change triggers blended image update
        if len(imname_list) > 0:
            self.update_mix_image(vidx)

    def update_mix_image(self, vidx):

        view2 = self.children[vidx]
        if not isinstance(view2, View2):
            return

        num_slices = len(self.color_imlist[vidx])
        if num_slices == 0:
            self.mix_im[vidx] = None
            return

        first_im = self.color_imlist[vidx].items()[0][1]
        assert isinstance(first_im, np.ndarray)
        height, width, channels = first_im.shape[0], first_im.shape[1], first_im.shape[2]

        slices = np.zeros((num_slices, height, width, channels), dtype=np.uint8)
        alphas = np.zeros((num_slices,), dtype=np.double)
        for i, item in enumerate(self.color_imlist[vidx].items()):
            slices[i] = item[1]
            imname = item[0]
            alphas[i] = self.im_params[imname]['alpha']

        mix_im = multi_image_alpha_blend(slices, alphas)
        row_bytes = mix_im.strides[0]

        self.mix_im[vidx] = QImage(mix_im.data, width, height, row_bytes, QImage.Format_RGB888)

    def request_mix_image(self, vidx, width, height):

        im = self.mix_im[vidx]
        if im is None or im.width() != width or im.height() != height:
            self.update_raw_imlist(vidx)

        return self.mix_im[vidx]

    def select_images(self, group, imnames):

        if len(imnames) == 0:
            return

        # if no focus, set focus image
        if len(self.sel_group[group]) == 0:
            self.focus_im[group] = imnames[0]

        self.sel_group[group].update(imnames)

        for view2 in self.view2_group[group]:
            vidx = view2.vidx
            for imname in imnames:
                self.raw_imlist[vidx][imname] = None
                self.byte_imlist[vidx][imname] = None
                self.color_imlist[vidx][imname] = None

    def deselect_images(self, group, imnames):

        if len(imnames) == 0:
            return

        for imname in imnames:
            self.sel_group[group].remove(imname)

        # if lose focus, reset focus image
        if self.focus_im[group] in imnames:
            if(len(self.sel_group[group]) == 0):
                self.focus_im[group] = None
            else:
                self.focus_im[group] = list(self.sel_group[group])[0]

        for view2 in self.view2_group[group]:
            vidx = view2.vidx
            for imname in imnames:
                del self.raw_imlist[vidx][imname]
                del self.byte_imlist[vidx][imname]
                del self.color_imlist[vidx][imname]

    def deselect_all_images(self, group):

        del_list = list(self.sel_group[group])
        self.deselect_images(group, del_list)

    def update_view(self, group):
        for view2 in self.view2_group[group]:
            view2.update_view()

    def update_all(self, imname_list=None):
        for view2 in self.children:
            if not isinstance(view2, View2):
                continue
            self.update_raw_imlist(view2.vidx, imname_list)
            view2.image = self.mix_im[view2.vidx]
            view2.update_view()

    def zoom(self, pixel_shift):
        # use y-shift to zoom
        pixel_shift = -pixel_shift[1]

        if pixel_shift >= 0:
            zoom_factor = 1.0 + pixel_shift * 1.0 / self.cfg.px_per_zoom
        else:
            zoom_factor = 1.0 / (1.0 - pixel_shift * 1.0 / self.cfg.px_per_zoom)

        zoom_factor *= self.zoom_factor
        zoom_factor = min(zoom_factor, self.cfg.max_zoom_factor)
        zoom_factor = max(zoom_factor, self.cfg.min_zoom_factor)

        self.zoom_factor = zoom_factor
        self.update_all()

    def adjust_wcww(self, shift):

        x, y = -shift[0], shift[1]

        # adjust window width by percents
        if y >= 0:
            ww_factor = 1.0 + y * 1.0 / self.cfg.px_per_percent
        else:
            ww_factor = 1.0 / (1.0 - y * 1.0 / self.cfg.px_per_percent)

        imname = self.focus_im[self.focus_group]
        ww = self.im_params[imname]['win_width'] * ww_factor
        if ww < 1:
            ww = 1

        # adjust window center using window width
        percent = x * 1.0 / self.cfg.px_per_percent
        wc = self.im_params[imname]['win_center'] + self.im_params[imname]['win_width'] * percent

        self.im_params[imname]['win_width'] = ww
        self.im_params[imname]['win_center'] = wc

        for view2 in self.children:
            if not isinstance(view2, View2):
                continue
            if imname in self.byte_imlist[view2.vidx]:
                self.update_byte_imlist(view2.vidx, [imname])
                view2.image = self.mix_im[view2.vidx]
            view2.update_view()

    def cursor_scroll(self, o_axis, delta):
        shift = self.spacing * delta
        self.cursor3 = self.cursor3 + o_axis * shift
        self.update_all()

    def adjust_alpha(self, delta):

        imname = self.focus_im[self.focus_group]
        alpha = self.im_params[imname]['alpha']
        alpha += delta * self.cfg.alpha_per_delta
        alpha = np.clip(alpha, self.cfg.min_alpha, self.cfg.max_alpha)
        self.im_params[imname]['alpha'] = alpha
        for view2 in self.children:
            if not isinstance(view2, View2):
                continue
            self.update_mix_image(view2.vidx)
            view2.image = self.mix_im[view2.vidx]
            view2.update_view()

    def switch_colormode(self, delta):

        imname = self.focus_im[self.focus_group]
        colormode = self.im_params[imname]['colormode']
        colormode = (colormode + delta) % len(self.colormode_str)
        self.im_params[imname]['colormode'] = colormode
        for view2 in self.children:
            if not isinstance(view2, View2):
                continue
            if imname in self.color_imlist[view2.vidx]:
                self.update_color_imlist(view2.vidx, [imname])
                view2.image = self.mix_im[view2.vidx]
                view2.update_view()

    def auto_adjust_wcww(self):

        imname = self.focus_im[self.focus_group]
        if imname is not None:
            min_v, max_v = None, None
            for view2 in self.view2_group[self.focus_group]:
                im = self.raw_imlist[view2.vidx][imname]
                tmp_min = np.min(im)
                tmp_max = np.max(im)
                if min_v is None or tmp_min < min_v:
                    min_v = tmp_min
                if max_v is None or tmp_max > max_v:
                    max_v = tmp_max
            self.im_params[imname]['win_center'] = (min_v + max_v) / 2.0
            self.im_params[imname]['win_width'] = max_v - min_v
            for view2 in self.children:
                if not isinstance(view2, View2):
                    continue
                if imname in self.byte_imlist[view2.vidx]:
                    self.update_byte_imlist(view2.vidx, [imname])
                    view2.image = self.mix_im[view2.vidx]
                    view2.update_view()

    def set_cursor3(self, cursor3):
        assert len(cursor3) == 3
        self.cursor3 = cursor3

    def set_center3(self, center3):
        assert len(center3) == 3
        self.center3 = center3

    def set_base_spacing(self, spacing):
        self.spacing = spacing

    # Instructions

    def add_lm(self, lmname, lm, lmdesc='', zoom_factor=None, tag_visible=True, text_visible=True, radius=0):

        self.lms[lmname] = np.array(lm, np.double)

        self.lm_params[lmname] = {}
        if zoom_factor is not None:
            self.lm_params[lmname]['zoom_factor'] = zoom_factor
        else:
            self.lm_params[lmname]['zoom_factor'] = self.zoom_factor

        self.lm_params[lmname]['description'] = lmdesc
        self.lm_params[lmname]['tag_visible'] = tag_visible
        self.lm_params[lmname]['text_visible'] = text_visible
        self.lm_params[lmname]['circle_radius'] = radius

        for view2 in self.children:
            if not isinstance(view2, View2):
                continue
            view2.update_view()

    def remove_lm(self, lmname):
        del self.lms[lmname]
        if self.sel_lm == lmname:
            self.sel_lm = None
        for view2 in self.children:
            if not isinstance(view2, View2):
                continue
            view2.update_view()

    def goto_lm(self, lmname):
        if lmname not in self.lm_params:
            print 'landmark {} not found'.format(lmname)
            return

        if lmname in self.lms:
          self.goto(self.lms[lmname], self.lm_params[lmname]['zoom_factor'])

    def goto(self, world, zoom_factor=None):
        self.cursor3 = world
        self.center3 = world
        if zoom_factor is not None:
            self.zoom_factor = zoom_factor
        self.update_all()

    def goto_voxel(self, imid, voxel, zoom_factor=None):
        if imid not in self.images:
            print '{} not found in image list'.format(imid)
            return
        image = self.images[imid]
        assert isinstance(image, Image3d)
        world = image.voxel_to_world(voxel)
        self.goto(world, zoom_factor)

    def get_voxel(self, imid):
        world = self.cursor3
        if imid not in self.images:
            print '{} not found in image list'.format(imid)
            return
        image = self.images[imid]
        assert isinstance(image, Image3d)
        voxel = image.world_to_voxel(world)
        return voxel

    def add_text_line(self, group, text):

        textfield = self.textfield_group[group]
        assert isinstance(textfield, TextField)
        textfield.add_line(text)

    def clear_lines(self, group):

        textfield = self.textfield_group[group]
        assert isinstance(textfield, TextField)
        textfield.clear_text()

    def active_image(self, imid):

        if imid not in self.images:
            QMessageBox.warning(self, 'No such Image', '{} not found in the image list'.format(imid))
            return

        im = self.images[imid]
        self.cursor3 = im.center()
        self.center3 = self.cursor3

        for selector in self.selectors:
            selector.clear_and_select(imid)

    def set_wcww(self, imid, wc, ww):

        if imid not in self.im_params:
            return

        self.im_params[imid]['win_center'] = wc
        self.im_params[imid]['win_width'] = ww
        self.update_all([imid])

    def adjust_opacity(self, imid, alpha):

        if imid not in self.im_params:
            return

        self.im_params[imid]['alpha'] = alpha
        self.update_all([imid])

    def adjust_colormode(self, imid, colormode):

        if imid not in self.im_params:
            return

        self.im_params[imid]['colormode'] = colormode
        self.update_all([imid])

    def select(self, imids):

        for selector in self.selectors:
            selector.select_images(imids)

    def deselect(self, imids):

        for selector in self.selectors:
            selector.deselect_images(imids)

    def clear_selections(self):

        for selector in self.selectors:
            selector.clear_selections()

    # Event handlers

    def selectionChanged(self, selected, deselected):

        assert isinstance(selected, QItemSelection)
        assert isinstance(deselected, QItemSelection)

        sender = self.sender()
        group = sender.parent().group

        new_sel = set()
        for idx in selected.indexes():
            name = sender.parent().model().item(idx.row(), 0).text()
            new_sel.add(name)
        self.select_images(group, list(new_sel))

        new_desel = set()
        for idx in deselected.indexes():
            name = sender.parent().model().item(idx.row(), 0).text()
            new_desel.add(name)
        self.deselect_images(group, list(new_desel))

        # update cached images
        for view2 in self.view2_group[group]:
            if len(new_sel) == 0:
                self.update_mix_image(view2.vidx)
            else:
                self.update_raw_imlist(view2.vidx, new_sel)
            view2.image = self.mix_im[view2.vidx]

        self.update_view(group)

        # call parent's event handler to handle selection by row
        sender.parent().selectionChanged(selected, deselected)

    def keyPressEvent(self, event):
        """ called when a key is pressed """
        assert isinstance(event, QKeyEvent)

        if self.sender() is None:
            super(View3, self).keyPressEvent(event)

        if event.key() == Qt.Key_S:
            # switch focus image
            sel = list(self.sel_group[self.focus_group])
            if len(sel) <= 1:
                return

            current = self.focus_im[self.focus_group]
            if current is None:
                self.focus_im[self.focus_group] = sel[0]
            else:
                idx = sel.index(current)
                idx = (idx + 1) % len(sel)
                self.focus_im[self.focus_group] = sel[idx]

            self.update_view(self.focus_group)
            event.accept()

        elif event.key() == Qt.Key_H:

            modifiers = QtGui.QGuiApplication.keyboardModifiers()
            if modifiers == Qt.ControlModifier:
                QMessageBox.about(self, 'Shortcut Keys', self.help_str)
            else:
                # hide overlay (cursor + text)
                group = self.focus_group
                for view2 in self.view2_group[group]:
                    flag = not view2.show_overlay_flag
                    view2.show_overlay(flag)
                    view2.update_view()
            event.accept()

        elif event.key() == Qt.Key_W:

            self.mode= 0 if self.mode == 1 else 1
            self.update_view(self.focus_group)
            event.accept()

        elif event.key() == Qt.Key_A:

            self.mode = 0 if self.mode == 2 else 2
            self.update_view(self.focus_group)
            event.accept()

        elif event.key() == Qt.Key_C:

            self.mode = 0 if self.mode == 3 else 3
            self.update_view(self.focus_group)
            event.accept()

        elif event.key() == Qt.Key_F1:

            self.center3 = self.cursor3
            self.update_all()
            event.accept()

        elif event.key() == Qt.Key_F2:

            imname = self.focus_im[self.focus_group]
            if imname is not None:
                im = self.images[imname]
                assert isinstance(im, Image3d)
                self.cursor3 = im.center()
                self.center3 = self.cursor3
                self.zoom_factor = self.init_zoom_factor
                self.update_all()
            event.accept()

        elif event.key() == Qt.Key_F3:

            self.auto_adjust_wcww()
            event.accept()

        elif event.key() == Qt.Key_F5:

            keys = self.lms.keys()
            if len(keys) != 0:
                if self.sel_lm is None:
                    self.sel_lm = keys[0]
                    lm = self.lms[self.sel_lm]
                else:
                    idx = keys.index(self.sel_lm)
                    idx = (idx + 1) % len(keys)
                    self.sel_lm = keys[idx]
                    lm = self.lms[self.sel_lm]

                zoom_factor = self.lm_params[self.sel_lm]['zoom_factor']
                self.goto(lm, zoom_factor)

            event.accept()

    def rbuttonShifted(self, shift):

        if self.mode == 0:
            self.zoom(shift)
        elif self.mode == 1:    # WW/WC mode
            self.adjust_wcww(shift)

    def wheelScrolled(self, delta):

        if self.mode == 0:
            o_axis = self.sender().o_axis
            self.cursor_scroll(o_axis, delta)

        elif self.mode == 2:    # alpha mode
            self.adjust_alpha(delta)

        elif self.mode == 3:    # color mode
            self.switch_colormode(delta)

    def cursorChanged(self, pos):

        self.cursor3 = pos
        self.update_all()


if __name__ == '__main__':

    import md._c._cimage3d_io as cio
    import sys

    image1 = cio.read_image('/home/ubuntu2/data/LUNA16/subset0/1.3.6.1.4.1.14519.5.2.1.6279.6001.105756658031515062000744821260.mhd')
    image2 = cio.read_image('/home/ubuntu2/data/LUNA16/subset0/1.3.6.1.4.1.14519.5.2.1.6279.6001.108197895896446896160048741492.mhd')

    cfg = view3_cfg.View3ConfigFactory().cfg_2x2('viewer')

    app = QApplication(sys.argv)
    view = View3(cfg)
    view.resize(1024, 1024)
    view.show()

    center = image1.center()
    view.set_center3(center)
    view.set_cursor3(center)
    view.set_base_spacing(1)

    print image1.center(), image2.center()

    view.add_image(image1, 'im1', win_center=0, win_width=2000)
    view.add_image(image2, 'im2', win_center=0, win_width=2000)
    view.add_lm('key_lms', [-11.20, 18.90, -143.84])
    view.add_lm('501', [-30.95, 16.34, -153.14])

    sys.exit(app.exec_())


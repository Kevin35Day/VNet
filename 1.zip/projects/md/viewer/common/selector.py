from PyQt5.Qt import *
from PyQt5 import QtGui


class Selector(QTreeView):

    # emitted when user press a key
    # input: QKeyEvent
    key_pressed = pyqtSignal(QKeyEvent)

    def __init__(self, group, fontsize, parent=None):
        
        super(Selector, self).__init__(parent=parent)

        self.group = group

        # remove indentation in tree view
        self.setRootIsDecorated(False)

        # select entire row
        self.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.setSelectionBehavior(QAbstractItemView.SelectRows)

        # data in tree view
        model = QStandardItemModel()
        model.setHorizontalHeaderItem(0, QStandardItem('Name'))
        model.setHorizontalHeaderItem(1, QStandardItem('Size'))
        self.setModel(model)

        # fixed width for each column
        self.setColumnWidth(0, 200)     # name
        self.setColumnWidth(1, 200)     # image size

        # set font size
        font = self.font()
        font.setPointSize(fontsize)
        self.setFont(font)

    def create_row_items(self, name, size):

        size_str = '{} x {} x {}'.format(size[0], size[1], size[2])

        items = []
        items.append(QStandardItem(name))
        items.append(QStandardItem(size_str))

        for item in items:
            item.setEditable(False)

        return items

    def add_image(self, name, size):

        items = self.create_row_items(name, size)

        model = self.model()
        assert isinstance(model, QStandardItemModel)
        rows = model.rowCount()

        is_duplicate = False
        for row_idx in range(rows):
            item = model.item(row_idx, 0)
            if item.text() == name:
                for i in range(1, len(items)):
                    model.setItem(row_idx, i, items[i])
                is_duplicate = True
                break

        if not is_duplicate:
            model.appendRow(items)

    def find_row_modelidx(self, name):

        model = self.model()
        assert isinstance(model, QStandardItemModel)
        rows = model.rowCount()

        for row in range(rows):
            item = model.item(row, 0)
            if item.text() == name:
                return item.index()

        return None

    def select_images(self, names):

        sel_flags = QItemSelectionModel.SelectionFlags(QItemSelectionModel.Select | QItemSelectionModel.Rows)
        for name in names:
            row_model_idx = self.find_row_modelidx(name)
            if row_model_idx is not None:
                self.selectionModel().select(row_model_idx, sel_flags)

    def deselect_images(self, names):

        sel_flags = QItemSelectionModel.SelectionFlags(QItemSelectionModel.Deselect | QItemSelectionModel.Rows)
        for name in names:
            row_model_idx = self.find_row_modelidx(name)
            if row_model_idx is not None:
                self.selectionModel().select(row_model_idx, sel_flags)

    def clear_and_select(self, name):

        sel_flags = QItemSelectionModel.ClearAndSelect | QItemSelectionModel.Rows
        row_model_idx = self.find_row_modelidx(name)
        if row_model_idx is not None:
            self.selectionModel().select(row_model_idx, sel_flags)

    def clear_selections(self):

        self.selectionModel().clearSelection()

    # event handlers

    def keyPressEvent(self, event):
        """ called when a key is pressed """
        super(Selector, self).keyPressEvent(event)

        modifiers = QtGui.QGuiApplication.keyboardModifiers()
        if modifiers == Qt.ControlModifier:
            # if ctrl is pressed, parent can receive keypressed event (?)
            # to remove duplicate, do not pass message up
            return
        elif event.key() >= Qt.Key_F1 and event.key() <= Qt.Key_F9:
            return
        else:
            self.key_pressed.emit(event)


if __name__ == '__main__':

    import sys
    app = QApplication(sys.argv)
    view = Selector(0, 16)
    view.resize(1024, 512)
    view.show()

    view.add_image('im1', [512, 512, 200])
    view.add_image('label1', [512, 512, 60])

    sys.exit(app.exec_())

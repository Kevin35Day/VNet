import os
import subprocess
import tempfile
import time

from PyQt5.Qt import *
from md.image3d.python.image3d import Image3d
import md.viewer.common.view3_cfg as view3_cfg
from PyQt5.QtNetwork import QLocalSocket


class ViewClient(object):
    """ viewer client """

    def __init__(self, name, config=None):
        """ initializer """
        assert config is None or isinstance(config, view3_cfg.View3Config)
        assert isinstance(name, str)

        if config is None:
            factory = view3_cfg.View3ConfigFactory()
            config = factory.cfg_2x2(name)

        self.config = config

        # record the return code of last function call
        self.last_ret = None

        # milliseconds to time out
        self.time_out = 5000

    def open(self, width=-1, height=-1, position=0):
        """ open viewer process """
        if self.exists():
            reply, error = self.__send_command('CMD;CLOSE')
            if reply is None or reply != 'REPLY;DONE':
                raise OSError('Fail to close existing server socket!')

        # write out temporary json file
        fp = tempfile.NamedTemporaryFile(delete=False)
        json_file = fp.name
        self.config.save_to_json(json_file)

        # create viewer server
        server_file = os.path.join(os.path.dirname(__file__), 'view_server.py')
        subprocess.Popen(['python', server_file, '-i', json_file,
                          '--width', '{}'.format(width),
                          '--height', '{}'.format(height),
                          '--position', '{}'.format(position)])

    def exists(self):

        socket = QLocalSocket()
        socket.error.connect(self.connectionError)
        socket.connected.connect(self.connectionSuccess)
        socket.connectToServer(self.config.name)

        if not self.last_ret:
            socket.disconnectFromServer()
            return False

        socket.writeData('CMD;ECHO')
        if not socket.waitForBytesWritten(self.time_out):
            return False

        if socket.waitForReadyRead(self.time_out):
            reply = socket.readAll().data()
            if reply != 'REPLY;ECHO':
                return False
        else:
            return False

        socket.disconnectFromServer()
        return True

    def wait_server_setup(self):

        try_time = 0

        while try_time < self.time_out:
            reply, error_msg = self.__send_command('CMD;ECHO')
            if reply is None or reply != 'REPLY;ECHO':
                time.sleep(0.5)
                try_time += 500
            else:
                break

        if try_time >= self.time_out:
            raise OSError('[Error] fail to setup server socket')

    def close(self):
        """  close viewer process """
        self.__send_command('CMD;CLOSE')

    def add_image(self, image, image_id, wc, ww, color, alpha, active):
        """ add/override image in viewer """
        assert isinstance(image, Image3d)

        num_bytes = image.bytes()

        # write image to shared memory
        mem = QSharedMemory(self.config.name)
        if not mem.create(num_bytes):
            mem.attach()
            if mem.size() < num_bytes:
                mem.detach()
                if not mem.create(num_bytes):
                    print '[Error] fail to create shared memory: ', mem.errorString()
                    return

        mem.lock()
        data_ptr = mem.data()
        image.write_to_buffer(int(data_ptr))
        mem.unlock()

        cmd = 'CMD;SET_IMAGE;{};{};{};{};{};{}'.format(image_id, wc, ww, color, alpha, active)
        reply, error_msg = self.__send_command(cmd)
        if reply is None or reply != 'REPLY;DONE':
            print error_msg

    def select_images(self, imids, reset=False):

        cmd = 'CMD;SELECT_IMAGE;{};{}'.format(':'.join(imids), reset)
        reply, error_msg = self.__send_command(cmd)
        if reply is None or reply != 'REPLY;DONE':
            print error_msg

    def deselect_images(self, imids):

        cmd = 'CMD;DESELECT_IMAGE;{}'.format(':'.join(imids))
        reply, error_msg = self.__send_command(cmd)
        if reply is None or reply != 'REPLY;DONE':
            print error_msg

    def adjust_wcww(self, name, wc, ww):

        cmd = 'CMD;ADJUST_WCWW;{};{};{}'.format(name, wc, ww)
        reply, error_msg = self.__send_command(cmd)
        if reply is None or reply != 'REPLY;DONE':
            print error_msg

    def adjust_opacity(self, name, alpha):

        cmd = 'CMD;ADJUST_OPACITY;{};{}'.format(name, alpha)
        reply, error_msg = self.__send_command(cmd)
        if reply is None or reply != 'REPLY;DONE':
            print error_msg

    def adjust_colormode(self, name, colormode):

        if colormode < 0 or colormode > 5:
            raise ValueError('colormode must be in [0,5]')

        cmd = 'CMD;ADJUST_COLORMODE;{};{}'.format(name, colormode)
        reply, error_msg = self.__send_command(cmd)
        if reply is None or reply != 'REPLY;DONE':
            print error_msg

    def goto(self, world, zoom_factor=None):

        cmd = 'CMD;GOTO;{};{};{};{}'.format(world[0], world[1], world[2], zoom_factor)
        reply, error_msg = self.__send_command(cmd)
        if reply is None or reply != 'REPLY;DONE':
            print error_msg

    def goto_voxel(self, name, voxel, zoom_factor=None):

        cmd = 'CMD;GOTO_VOXEL;{};{};{};{};{}'.format(name, voxel[0], voxel[1], voxel[2], zoom_factor)
        reply, error_msg = self.__send_command(cmd)
        if reply is None or reply != 'REPLY;DONE':
            print error_msg

    def get_cursor(self):

        cmd = 'CMD;GET_CURSOR'
        reply, error_msg = self.__send_command(cmd)
        if reply is None or not reply.startswith('REPLY;'):
            print error_msg
            return None
        else:
            tokens = reply.split(';')
            cursor = [float(tokens[1]), float(tokens[2]), float(tokens[3])]
            return cursor

    def get_voxel(self, imid):

        cmd = 'CMD;GET_VOXEL;{}'.format(imid)
        reply, error_msg = self.__send_command(cmd)
        if reply is None or not reply.startswith('REPLY;'):
            print error_msg
            return None
        else:
            tokens = reply.split(';')
            voxel = [float(tokens[1]), float(tokens[2]), float(tokens[3])]
            return voxel

    def zoom(self, zoom_factor=1.0):

        cmd = 'CMD;ZOOM;{}'.format(zoom_factor)
        reply, error_msg = self.__send_command(cmd)
        if reply is None or reply != 'REPLY;DONE':
            print error_msg

    def marklm(self, name, desc, tag_visible=True, text_visible=True, radius=0):

        cmd = 'CMD;MARKLM;{};{};{};{};{}'.format(name, desc, tag_visible, text_visible, radius)
        reply, error_msg = self.__send_command(cmd)
        if reply is None or reply != 'REPLY;DONE':
            print error_msg

    def marklm_cursor(self, cursor_x, cursor_y, cursor_z, name, desc, tag_visible=True, text_visible=True, radius=0):

        cmd = 'CMD;MARKLM_CURSOR;{};{};{};{};{};{};{};{}'.format(cursor_x, cursor_y, cursor_z, name, desc, tag_visible, text_visible, radius)
        reply, error_msg = self.__send_command(cmd)
        if reply is None or reply != 'REPLY;DONE':
            print error_msg

    def goto_lm(self, name):

        cmd = 'CMD;GOTOLM;{}'.format(name)
        reply, error_msg = self.__send_command(cmd)
        if reply is None or reply != 'REPLY;DONE':
            print error_msg

    def removelm(self, name):

        cmd = 'CMD;REMOVELM;{}'.format(name)
        reply, error_msg = self.__send_command(cmd)
        if reply is None or reply != 'REPLY;DONE':
            print error_msg

    def lms(self):

        cmd = 'CMD;LMS'
        reply, error_msg = self.__send_command(cmd)
        if reply is None or not reply.startswith('REPLY'):
            print error_msg
            return None

        tokens = reply.split(';')
        ret_lms = {}
        for token in tokens[1:]:
            lmname, desc, x, y, z = token.split(':')
            ret_lms[lmname] = {}
            ret_lms[lmname]['description'] = desc
            ret_lms[lmname]['coord'] = [x, y, z]

        return ret_lms

    #######################################################################
    # Private member functions
    #######################################################################

    def __send_command(self, command):
        """ send command and receive feedback """

        socket = QLocalSocket()
        socket.error.connect(self.connectionError)
        socket.connected.connect(self.connectionSuccess)
        socket.connectToServer(self.config.name)

        reply = None
        error_msg = None

        if not self.last_ret:
            error_msg = '[Error] cannot connect to the viewer process'
        else:
            socket.writeData(command)
            if not socket.waitForBytesWritten(self.time_out):
                error_msg = '[Error] fail to send command {}'.format(command)
            else:
                if not socket.waitForReadyRead(self.time_out):
                    error_msg = '[Error] not receive feedback from viewer'
                else:
                    reply = socket.readAll().data()

        socket.disconnectFromServer()
        return reply, error_msg

    #######################################################################
    # Event handlers
    #######################################################################

    def connectionError(self):
        self.last_ret = False

    def connectionSuccess(self):
        self.last_ret = True

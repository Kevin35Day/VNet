#ifndef VEC3D_H
#define VEC3D_H

#include <cmath>
#include <string>
#include <stdexcept>
#include <cstring>
#include <iostream>
#include <sstream>

namespace medvision {

template <typename T>
class vec3d
{
public:
    /*! \brief default constructor */
    vec3d();
    /*! \brief contruct by three values */
    vec3d(T arg1, T arg2, T arg3);
    /*! \brief copy construct */
    vec3d(const vec3d<T>& arg);

    /*! \brief get value by [] operator */
    inline T& operator[] (size_t i);
    /*! \brief get const value by [] operator */
    inline const T& operator[] (size_t i) const;

    /*! \brief assign operator */
    inline vec3d<T>& operator= (const vec3d<T>& arg);
    /*! \brief += operator */
    inline vec3d<T>& operator+= (const vec3d<T>& arg);
    /*! \brief + operator */
    inline vec3d<T> operator+ (const vec3d<T>& arg) const;
    /*! \brief -= operator */
    inline vec3d<T>& operator-= (const vec3d<T>& arg);
    /*! \brief - operator */
    inline vec3d<T> operator- (const vec3d<T>& arg) const;
    /*! \brief *= operator */
    inline vec3d<T>& operator*= (const vec3d<T>& arg);
    /*! \brief * operator */
    inline vec3d<T> operator* (const vec3d<T>& arg) const;
    /*! \brief /= operator */
    inline vec3d<T>& operator/= (const vec3d<T>& arg);
    /*! \brief / operator */
    inline vec3d<T> operator/ (const vec3d<T>& arg) const;

    /*! \brief const multiply scale operator */
    template <typename T2>
    inline vec3d<T>& operator*= (T2 arg);

    /*! \brief const multiply scale operator */
    template <typename T2>
    inline vec3d<T> operator* (T2 arg) const;

    /*! \brief const divide scale operator */
    template <typename T2>
    inline vec3d<T>& operator/= (T2 arg);

    /*! \brief const divide scale operator */
    template <typename T2>
    inline vec3d<T> operator/ (T2 arg) const;

    /*! \brief less operator (sorted by the order of z, y, x) */
    inline bool operator< (const vec3d<T>& rhs) const;
    /*! \brief less equal operator (sorted by the order of z, y, x) */
    inline bool operator<= (const vec3d<T>& rhs) const;
    /*! \brief greater operator (sorted by the order of z, y, x) */
    inline bool operator> (const vec3d<T>& rhs) const;
    /*! \brief greater equal operator (sorted by the order of z, y, x) */
    inline bool operator>= (const vec3d<T>& rhs) const;
    /*! \brief equal operator */
    inline bool operator== (const vec3d<T>& rhs) const;
    /*! \brief unequal operator */
    inline bool operator!= (const vec3d<T>& rhs) const;

    /*! \brief self product */
    template <typename T2>
    inline T2 self_prod() const;

    /*! \brief compute dot product of two vec3d */
    static T dot_prod(const vec3d<T>& v1, const vec3d<T>& v2);
    /*! \brief compute cross product of two vec3d */
    static vec3d<T> cross_prod(const vec3d<T>& v1, const vec3d<T>& v2);
    /*! \brief compute square L2 norm */
    inline double square_norm() const;
    /*! \brief compute L2 norm */
    inline double norm() const;
    /*! \brief compute L2 norm */
    inline double l2_norm() const;
    /*! \brief normalize to unit L2 norm */
    inline vec3d<T> normalize() const;
    /*! \brief normalized to unit L2 norm */
    inline void normalize_();
    /*! \brief comptue the sum */
    inline T sum();

    /*! \brief convert type of vec3d */
    template <typename T2>
    inline vec3d<T2> astype() const;

    /*! \brief convert object to string for display */
    inline std::string to_string() const;

    /*! \brief serialize object to stream */
    inline void serialize(std::ostream& o) const;

    /*! \brief deserialize object from stream */
    inline void deserialize(std::istream& in);

    /*! \brief return c-style buffer */
    T* data();
    /*! \brief return const c-style buffer */
    const T* data() const;

public:
    /*! \brief data buffer */
    T m_data[3];
};


// implementation

template <typename T>
vec3d<T>::vec3d() {
    memset(m_data, 0, sizeof(T) * 3);
}

template <typename T>
vec3d<T>::vec3d(T arg1, T arg2, T arg3) {
    m_data[0] = arg1;
    m_data[1] = arg2;
    m_data[2] = arg3;
}

template <typename T>
vec3d<T>::vec3d(const vec3d<T>& arg) {
    memcpy(m_data, arg.m_data, sizeof(T) * 3);
}

template <typename T>
inline T& vec3d<T>::operator[] (size_t i) {
    if(i > 2)
        throw std::out_of_range("index out of bound");
    return m_data[i];
}

template <typename T>
const T& vec3d<T>::operator[] (size_t i) const {
    if(i > 2)
        throw std::out_of_range("index out of bound");
    return m_data[i];
}

template <typename T>
vec3d<T>& vec3d<T>::operator= (const vec3d<T>& arg) {
    if(this == &arg)
        return *this;
    memcpy(m_data, arg.m_data, sizeof(T) * 3);
    return *this;
}

template <typename T>
vec3d<T>& vec3d<T>::operator+= (const vec3d<T>& arg) {
    m_data[0] += arg.m_data[0];
    m_data[1] += arg.m_data[1];
    m_data[2] += arg.m_data[2];
    return *this;
}

template <typename T>
vec3d<T> vec3d<T>::operator+ (const vec3d<T>& arg) const {
    vec3d<T> ret(*this);
    ret += arg;
    return ret;
}

template <typename T>
vec3d<T>& vec3d<T>::operator-= (const vec3d<T>& arg) {
    m_data[0] -= arg.m_data[0];
    m_data[1] -= arg.m_data[1];
    m_data[2] -= arg.m_data[2];
    return *this;
}

template <typename T>
vec3d<T> vec3d<T>::operator- (const vec3d<T>& arg) const {
    vec3d<T> ret(*this);
    ret -= arg;
    return ret;
}

template <typename T>
vec3d<T>& vec3d<T>::operator*= (const vec3d<T>& arg) {
    m_data[0] *= arg.m_data[0];
    m_data[1] *= arg.m_data[1];
    m_data[2] *= arg.m_data[2];
    return *this;
}

template <typename T>
vec3d<T> vec3d<T>::operator* (const vec3d<T>& arg) const {
    vec3d<T> ret(*this);
    ret *= arg;
    return ret;
}

template <typename T>
vec3d<T>& vec3d<T>::operator/= (const vec3d<T>& arg) {
    m_data[0] /= arg.m_data[0];
    m_data[1] /= arg.m_data[1];
    m_data[2] /= arg.m_data[2];
    return *this;
}

template <typename T>
vec3d<T> vec3d<T>::operator/ (const vec3d<T>& arg) const {
    vec3d<T> ret(*this);
    ret /= arg;
    return ret;
}

template <typename T> template <typename T2>
vec3d<T>& vec3d<T>::operator*= (T2 arg) {
    m_data[0] = static_cast<T>(static_cast<double>(m_data[0]) * arg);
    m_data[1] = static_cast<T>(static_cast<double>(m_data[1]) * arg);
    m_data[2] = static_cast<T>(static_cast<double>(m_data[2]) * arg);
    return *this;
}

template <typename T> template <typename T2>
vec3d<T> vec3d<T>::operator* (T2 arg) const {
    vec3d<T> ret(*this);
    ret *= arg;
    return ret;
}

template <typename T> template <typename T2>
vec3d<T>& vec3d<T>::operator/= (T2 arg) {
    m_data[0] = static_cast<T>(static_cast<double>(m_data[0]) / arg);
    m_data[1] = static_cast<T>(static_cast<double>(m_data[1]) / arg);
    m_data[2] = static_cast<T>(static_cast<double>(m_data[2]) / arg);
    return *this;
}

template <typename T> template <typename T2>
vec3d<T> vec3d<T>::operator/ (T2 arg) const {
    vec3d<T> ret(*this);
    ret /= arg;
    return ret;
}

template <typename T> template <typename T2>
T2 vec3d<T>::self_prod() const {
    T2 res = static_cast<T2>(m_data[0]) * static_cast<T2>(m_data[1]) * static_cast<T2>(m_data[2]);
    return res;
}

template <typename T>
T vec3d<T>::dot_prod(const vec3d<T>& v1, const vec3d<T>& v2)
{
    return v1.m_data[0] * v2.m_data[0] + v1.m_data[1] * v2.m_data[1] + v1.m_data[2] * v2.m_data[2];
}

template <typename T>
vec3d<T> vec3d<T>::cross_prod(const vec3d<T>& v1, const vec3d<T>& v2)
{
    vec3d<T> ret;
    ret.m_data[0] = v1.m_data[1] * v2.m_data[2] - v1.m_data[2] * v2.m_data[1];
    ret.m_data[1] = v1.m_data[2] * v2.m_data[0] - v1.m_data[0] * v2.m_data[2];
    ret.m_data[2] = v1.m_data[0] * v2.m_data[1] - v1.m_data[1] * v2.m_data[0];
    return ret;
}

template <typename T>
double vec3d<T>::square_norm() const
{
    return static_cast<double>(m_data[0] * m_data[0] + m_data[1] * m_data[1] + m_data[2] * m_data[2]);
}

template <typename T>
double vec3d<T>::norm() const
{
    return sqrt(square_norm());
}

template <typename T>
double vec3d<T>::l2_norm() const
{
    return norm();
}

template <typename T>
vec3d<T> vec3d<T>::normalize() const
{
    double norm = l2_norm();
    vec3d<T> ret;
    ret.m_data[0] = static_cast<T>(m_data[0] / norm);
    ret.m_data[1] = static_cast<T>(m_data[1] / norm);
    ret.m_data[2] = static_cast<T>(m_data[2] / norm);
    return ret;
}

template <typename T>
void vec3d<T>::normalize_()
{
    double norm = l2_norm();
    m_data[0] = static_cast<T>(m_data[0] / norm);
    m_data[1] = static_cast<T>(m_data[1] / norm);
    m_data[2] = static_cast<T>(m_data[2] / norm);
}

template <typename T>
T vec3d<T>::sum()
{
    return m_data[0] + m_data[1] + m_data[2];
}

template <typename T>
bool vec3d<T>::operator< (const vec3d<T>& rhs) const
{
    if (m_data[2] < rhs.m_data[2])
        return true;
    else if (m_data[2] > rhs.m_data[2])
        return false;
    else {
        if (m_data[1] < rhs.m_data[1])
            return true;
        else if (m_data[1] > rhs.m_data[1])
            return false;
        else {
            if (m_data[0] < rhs.m_data[0])
                return true;
            else if (m_data[0] > rhs.m_data[0])
                return false;
            else
                return false;
        }
    }
}

template <typename T>
bool vec3d<T>::operator<= (const vec3d<T>& rhs) const
{
    return this->operator<(rhs) || this->operator==(rhs);
}

template <typename T>
bool vec3d<T>::operator> (const vec3d<T>& rhs) const
{
    return !this->operator<=(rhs);
}

template <typename T>
bool vec3d<T>::operator>= (const vec3d<T>& rhs) const
{
    return !this->operator<(rhs);
}

template <typename T>
bool vec3d<T>::operator== (const vec3d<T>& rhs) const
{
    if (m_data[0] == rhs.m_data[0] && m_data[1] == rhs.m_data[1] && m_data[2]== rhs.m_data[2])
        return true;
    else
        return false;
}

template <typename T>
bool vec3d<T>::operator!= (const vec3d<T>& rhs) const
{
    return !this->operator==(rhs);
}

template <typename T> template <typename T2>
vec3d<T2> vec3d<T>::astype() const
{
    vec3d<T2> ret;
    ret.m_data[0] = static_cast<T2>(m_data[0]);
    ret.m_data[1] = static_cast<T2>(m_data[1]);
    ret.m_data[2] = static_cast<T2>(m_data[2]);
    return ret;
}

template <typename T>
std::string vec3d<T>::to_string() const
{
    std::ostringstream convert;
    convert << "[" << m_data[0] << ", " << m_data[1] << ", " << m_data[2] << "]";
    return convert.str();
}

template <typename T>
std::ostream& operator<<(std::ostream& os, const vec3d<T>& vec)
{
    os << "[" << vec.m_data[0] << ", " << vec.m_data[1] << ", " << vec.m_data[2] << "]";
    return os;
}

template <typename T>
void vec3d<T>::serialize(std::ostream& o) const {
    o.write((const char*)(m_data), sizeof(T) * 3);
}

template <typename T>
void vec3d<T>::deserialize(std::istream& in) {
    in.read((char*)(m_data), sizeof(T) * 3);
}

template <typename T>
T* vec3d<T>::data()
{
    return m_data;
}

template <typename T>
const T* vec3d<T>::data() const
{
    return m_data;
}

} // end namespace medvision

#endif // VEC3D_H

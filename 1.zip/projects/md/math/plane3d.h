#ifndef PLANE3D_H
#define PLANE3D_H

#include "math/vec3d.h"

namespace medvision {

template <typename T>
class Plane3d
{
public:
    /*! \brief default constructor */
    Plane3d();

    /*! \brief construct by a point and two axes */
    Plane3d(const vec3d<T>& pt, const vec3d<T>& x1, const vec3d<T>& x2);

    /*! \brief  map a 3d point to the plane */
    vec3d<T> map_onto_plane(const vec3d<T>& p) const;

public:
    /*! \brief a point on the 3d plane */
    vec3d<T> m_pt;

    /*! \brief x axis of the 3d plane */
    vec3d<T> m_axis1;

    /*! \brief y axis of the 3d plane */
    vec3d<T> m_axis2;
};


template <typename T>
Plane3d<T>::Plane3d() {
    m_axis1[0] = static_cast<T>(1.0); m_axis1[1] = static_cast<T>(0.0); m_axis1[2] = static_cast<T>(0.0);
    m_axis2[0] = static_cast<T>(0.0); m_axis2[1] = static_cast<T>(1.0); m_axis2[2] = static_cast<T>(0.0);
}

template <typename T>
Plane3d<T>::Plane3d(const vec3d<T>& pt, const vec3d<T>& x1, const vec3d<T>& x2)
{
    m_pt = pt;
    m_axis1 = x1;
    m_axis2 = x2;
}

template <typename T>
vec3d<T> Plane3d<T>::map_onto_plane(const vec3d<T>& pt) const
{
    vec3d<T> normal = vec3d<T>::cross_prod(m_axis1, m_axis2);
    vec3d<T> offset = pt - m_pt;
    double v = vec3d<T>::dot_prod(normal, offset);
    offset = offset - normal * v;
    return m_pt + offset;
}

} // end namespace medvision

#endif // PLANE3D_H

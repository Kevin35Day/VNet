import json


def view2_cfg(x_axis, y_axis, o_axis, group, enable_text):
    return {'type': 'view2', 'x_axis': x_axis, 'y_axis': y_axis, 'o_axis': o_axis, 'group': group,
            'enable_text': enable_text}


def selector_cfg(fontsize, group):
    return {'type': 'sel', 'fontsize': fontsize, 'group': group}


def text_cfg(fontsize, indent, textcolor, group):
    return {'type': 'text', 'fontsize': fontsize, 'indent': indent,
            'textcolor': textcolor, 'group': group}


class View3Config(object):

    def __init__(self, **kwargs):

        self.name = self.get_value(kwargs, 'name', 'viewer')
        self.rows = self.get_value(kwargs, 'rows', 1)
        self.cols = self.get_value(kwargs, 'cols', 1)
        self.px_per_zoom = self.get_value(kwargs, 'px_per_zoom', 120)
        self.px_per_percent = self.get_value(kwargs, 'px_per_percent', 240)
        self.min_zoom_factor = self.get_value(kwargs, 'min_zoom_factor', 0.01)
        self.max_zoom_factor = self.get_value(kwargs, 'max_zoom_factor', 25)
        self.alpha_per_delta = self.get_value(kwargs, 'alpha_per_delta', 0.1)
        self.max_alpha = self.get_value(kwargs, 'max_alpha', 10)
        self.min_alpha = self.get_value(kwargs, 'min_alpha', 0)
        self.cross_radius = self.get_value(kwargs, 'cross_radius', 0)
        self.lm_vis_dist = self.get_value(kwargs, 'lm_vis_dist', 0.5)
        self.lm_radius = self.get_value(kwargs, 'lm_radius', 2)
        self.lm_zoom_factor = self.get_value(kwargs, 'lm_zoom_factor', 0.2)
        self.image_alpha = self.get_value(kwargs, 'image_alpha', 0.75)

        colormap = {1: [255, 0,   0], 2: [0,   255,   0], 3: [  0,  0,  255],
                    4: [  255,   255, 0], 5: [  0, 255, 255], 6: [255,   0, 255]}
        self.colormap = self.get_value(kwargs, 'colormap', colormap)

        self.views = self.get_value(kwargs, 'views', [None] * (self.rows * self.cols))

    def get_value(self, dict, key, default):
        return dict[key] if key in dict else default

    def set_subcfg(self, row, col, cfg):
        assert row >= 0 and row < self.rows
        assert col >= 0 and col < self.cols
        self.views[row * self.cols + col] = cfg

    def save_to_json(self, outfile):
        with open(outfile, 'w') as f:
            json.dump(self.__dict__, f, separators=(',', ':'), sort_keys=True, indent=4)


def load_view3_cfg(infile):
    with open(infile, 'r') as f:
        json_data = json.load(f)
    return View3Config(**json_data)


class View3ConfigFactory(object):

    def cfg_2x2(self, name):

        opt = {'name': name, 'rows': 2, 'cols': 2}
        config = View3Config(**opt)

        # transverse view
        v00 = view2_cfg(x_axis=(1, 0, 0), y_axis=(0, 1, 0), o_axis=(0, 0, 1), group=0, enable_text=True)
        config.set_subcfg(0, 0, v00)

        # saggital view
        v01 = view2_cfg(x_axis=(0, 1, 0), y_axis=(0, 0, -1), o_axis=(1, 0, 0), group=0, enable_text=False)
        config.set_subcfg(0, 1, v01)

        # coronal view
        v10 = view2_cfg(x_axis=(1, 0, 0), y_axis=(0, 0, -1), o_axis=(0, 1, 0), group=0, enable_text=False)
        config.set_subcfg(1, 0, v10)

        # selector view
        v11 = selector_cfg(fontsize=16, group=0)
        config.set_subcfg(1, 1, v11)

        return config

    def cfg_2x2_nosel(self, name):

        opt = {'name': name, 'rows': 2, 'cols': 2}
        config = View3Config(**opt)

        # transverse view
        v00 = view2_cfg(x_axis=(1, 0, 0), y_axis=(0, 1, 0), o_axis=(0, 0, 1), group=0, enable_text=True)
        config.set_subcfg(0, 0, v00)

        # saggital view
        v01 = view2_cfg(x_axis=(0, 1, 0), y_axis=(0, 0, -1), o_axis=(1, 0, 0), group=0, enable_text=False)
        config.set_subcfg(0, 1, v01)

        # coronal view
        v10 = view2_cfg(x_axis=(1, 0, 0), y_axis=(0, 0, -1), o_axis=(0, 1, 0), group=0, enable_text=False)
        config.set_subcfg(1, 0, v10)

        # text output
        v11 = text_cfg(fontsize=20, indent=20, textcolor='red', group=0)
        config.set_subcfg(1, 1, v11)

        return config

from PyQt5.Qt import *
from PyQt5.QtCore import Qt
import numpy as np
from md.image3d.python.image3d_tools import get_pixel_general


class View2(QLabel):
    """ a 2D slice view widget """

    # emitted when user presses left-button
    # input: new cursor 3d world coordinate
    cursor_changed = pyqtSignal(np.ndarray)

    # emitted when user shifts mouse while pressing right mouse button
    # input: mouse-move pixels
    rbutton_shifted = pyqtSignal(tuple)

    # emitted when user scrolls wheel
    # input: scroll units
    wheel_scrolled = pyqtSignal(int)

    def __init__(self, x_axis, y_axis, o_axis, group, vidx,
                 enable_text, parent=None):
        """
        constructor of SliceView widget
        :param x_axis: the 3d axis along x direction (column-by-column)
        :param y_axis: the 3d axis along y direction (row-by-row)
        :param o_axis: the 3d axis along orthogonal direction to x-y plane
        :param group: the group number
        :param vidx: view2 index
        :param enable_text: whether to visualize text
        :param parent: parent widget
        """
        super(View2, self).__init__(parent=parent)

        self.group = group
        self.vidx = vidx
        self.enable_text = enable_text
        self.show_overlay_flag = True

        self.setFocusPolicy(Qt.StrongFocus)

        self.x_axis = np.array(x_axis, dtype=np.double)
        self.y_axis = np.array(y_axis, dtype=np.double)
        self.o_axis = np.array(o_axis, dtype=np.double)
        self.normal = np.cross(self.x_axis, self.y_axis)
        self.axes = np.array((x_axis, y_axis))

        # GUI related
        self.cursor_radius = 30
        self.cursor_color = Qt.green
        self.frame_thickness = 4
        self.frame_color = QColor(212, 166, 144)
        self.text_top_margin = 8
        self.text_bot_margin = 8
        self.text_left_margin = 10
        self.text_right_margin = 10
        self.lm_text_margin = 5
        self.text_color = QColor(0, 255, 0)
        self.adjust_color = QColor(0, 255, 255)
        self.lm_color = QColor(255, 119, 0)
        self.text_width = 300
        self.text_height = 150

        self.bold_font = QFont(self.font())
        self.bold_font.setBold(True)

        # private data
        self.rclicked_pos = None
        self.image = None

        # set background color
        self.setAutoFillBackground(True)
        p = self.palette()
        p.setColor(self.backgroundRole(), Qt.black)
        self.setPalette(p)

    def get_pt_dist(self, pt3):
        offset = np.array(pt3) - np.array(self.parent().cursor3)
        dist = np.abs(np.sum(offset * self.normal))
        return dist

    def get_view_pt3(self, pt3):
        offset = np.array(pt3) - np.array(self.parent().cursor3)
        offset -= self.normal * np.sum(offset * self.normal)
        return offset + self.parent().cursor3

    def get_view_coord2(self, pt3):
        pt3 = self.get_view_pt3(pt3)
        origin3 = self.get_view_origin3()
        view_spacing = self.parent().spacing * self.parent().zoom_factor
        pos2 = np.matmul(self.axes, pt3 - origin3) / view_spacing
        return pos2

    def get_pixels_from_mm(self, len_in_mm):
        view_spacing = self.parent().spacing * self.parent().zoom_factor
        len_in_pixels = len_in_mm / view_spacing
        return len_in_pixels

    def get_view_origin3(self):
        view_spacing = self.parent().spacing * self.parent().zoom_factor
        offset2 = np.array([self.width(), self.height()], dtype=np.double)
        offset2 = offset2 / 2.0 * view_spacing
        view_center3 = self.get_view_pt3(self.parent().center3)
        return view_center3 - np.matmul(offset2, self.axes)

    def get_coord3(self, x, y):
        origin3 = self.get_view_origin3()
        view_spacing = self.parent().spacing * self.parent().zoom_factor
        px = np.array([x, y], dtype=np.double)
        return origin3 + np.matmul(px * view_spacing, self.axes)

    def get_rd_text(self):
        return self.parent().rd_text

    def get_rd_fontsize(self):
        return self.parent().rd_fontsize

    def get_rd_textcolor(self):
        return self.parent().rd_textcolor

    def show_overlay(self, show=True):
        self.show_overlay_flag = show

    def update_view(self):
        if self.image is not None:
            pxmap = QPixmap.fromImage(self.image)
            if self.parent().focus_group == self.group:
                self.draw_focus_frame(pxmap)
            if self.show_overlay_flag:
                self.draw_text(pxmap)
                self.draw_lm(pxmap)
                self.draw_cursor(pxmap)
        else:
            pxmap = QPixmap(self.width(), self.height())
            pxmap.fill(QColor(0, 0, 0))
        self.setPixmap(pxmap)

    def draw_cursor(self, image):
        assert isinstance(image, QPixmap)
        x, y = self.get_view_coord2(self.parent().cursor3)
        painter = QPainter(image)
        painter.setPen(self.cursor_color)

        # draw cross
        cross_radius = self.parent().cfg.cross_radius
        painter.drawLine(x - cross_radius, y, x + cross_radius, y)
        painter.drawLine(x, y - cross_radius, x, y + cross_radius)

        r = self.cursor_radius
        # horizontal line
        painter.drawLine(0, y, x - r, y)
        painter.drawLine(x + r, y, self.width(), y)
        # vertical line
        painter.drawLine(x, 0, x, y - r)
        painter.drawLine(x, y + r, x , self.height())

    def draw_focus_frame(self, image):

        assert isinstance(image, QPixmap)
        painter = QPainter(image)
        painter.fillRect(0, 0, image.width(), self.frame_thickness, self.frame_color)
        painter.fillRect(0, 0, self.frame_thickness, image.height(), self.frame_color)
        painter.fillRect(image.width() - self.frame_thickness, 0, self.frame_thickness, image.height(), self.frame_color)
        painter.fillRect(0, image.height() - self.frame_thickness, self.width(), self.frame_thickness, self.frame_color)

    def draw_focus_text(self, image):

        assert isinstance(image, QPixmap)
        painter = QPainter(image)
        painter.setPen(self.text_color)
        width, height = self.width(), self.height()

        # group and focus information
        focus_imname = self.parent().focus_im[self.group]
        if focus_imname is None:
            focus_imname = ''
            win_center, win_width = 0, 0
            alpha, colormode_str = 0, 'Unknown'
        else:
            win_center = self.parent().im_params[focus_imname]['win_center']
            win_width = self.parent().im_params[focus_imname]['win_width']
            alpha = self.parent().im_params[focus_imname]['alpha']
            colormode = self.parent().im_params[focus_imname]['colormode']
            colormode_str = self.parent().colormode_str[colormode]

        text = 'Group: {}\nFocus: {}\n'.format(self.group, focus_imname)
        left = width - self.text_right_margin - self.text_width
        top = self.text_top_margin
        rect = QRectF(left, top, self.text_width, self.text_height)
        painter.drawText(rect, Qt.AlignRight, text)

        text = 'WC: {:.2f}\nWW: {:.2f}\n'.format(win_center, win_width)
        top += painter.fontMetrics().height() * 2
        rect = QRectF(left, top, self.text_width, self.text_height)

        if self.parent().mode == 1:
            font = self.font()
            painter.setPen(self.adjust_color)
            painter.setFont(self.bold_font)
            painter.drawText(rect, Qt.AlignRight, text)
            painter.setFont(font)
            painter.setPen(self.text_color)
        else:
            painter.drawText(rect, Qt.AlignRight, text)

        text = 'Alpha: {:.2f}\n'.format(alpha)
        top += painter.fontMetrics().height() * 2
        rect = QRectF(left, top, self.text_width, self.text_height)

        if self.parent().mode == 2:
            font = self.font()
            painter.setPen(self.adjust_color)
            painter.setFont(self.bold_font)
            painter.drawText(rect, Qt.AlignRight, text)
            painter.setFont(font)
            painter.setPen(self.text_color)
        else:
            painter.drawText(rect, Qt.AlignRight, text)

        text = 'Color: {}'.format(colormode_str)
        top += painter.fontMetrics().height()
        rect = QRectF(left, top, self.text_width, self.text_height)

        if self.parent().mode == 3:
            font = self.font()
            painter.setPen(self.adjust_color)
            painter.setFont(self.bold_font)
            painter.drawText(rect, Qt.AlignRight, text)
            painter.setFont(font)
            painter.setPen(self.text_color)
        else:
            painter.drawText(rect, Qt.AlignRight, text)

    def draw_image_text(self, image):

        assert isinstance(image, QPixmap)
        painter = QPainter(image)
        painter.setPen(self.text_color)

        focus_imname = self.parent().focus_im[self.group]
        if focus_imname is None:
            focus_imname = ''

        # focused image information
        if focus_imname in self.parent().images:
            im3 = self.parent().images[focus_imname]

            size = im3.size()
            size_str = '{}, {}, {}'.format(size[0], size[1], size[2])
            spacing = im3.spacing()
            spacing_str = '{:.2f}, {:.2f}, {:.2f}'.format(spacing[0], spacing[1], spacing[2])
            origin = im3.origin()
            origin_str = '{:.2f}, {:.2f}, {:.2f}'.format(origin[0], origin[1], origin[2])
            x_axis, y_axis, z_axis = im3.axis(0), im3.axis(1), im3.axis(2)
            xaxis_str = '{:.2f}, {:.2f}, {:.2f}'.format(x_axis[0], x_axis[1], x_axis[2])
            yaxis_str = '{:.2f}, {:.2f}, {:.2f}'.format(y_axis[0], y_axis[1], y_axis[2])
            zaxis_str = '{:.2f}, {:.2f}, {:.2f}'.format(z_axis[0], z_axis[1], z_axis[2])

            text = 'Size: {}\nSpacing: {}\nOrigin: {}\n'.format(size_str, spacing_str, origin_str)
            text += 'x: {}\ny: {}\nz: {}\n'.format(xaxis_str, yaxis_str, zaxis_str)

            left = self.text_left_margin
            top = self.text_top_margin
            rect = QRectF(left, top, self.text_width, self.text_height)
            painter.drawText(rect, Qt.AlignLeft, text)

    def draw_cursor_text(self, image):

        assert isinstance(image, QPixmap)
        painter = QPainter(image)
        painter.setPen(self.text_color)
        width, height = self.width(), self.height()

        focus_imname = self.parent().focus_im[self.group]
        if focus_imname is None:
            focus_imname = ''

        if focus_imname in self.parent().images:
            # cursor information
            cursor3 = self.parent().cursor3
            cursor3_str = '{:.2f}, {:.2f}, {:.2f}'.format(cursor3[0], cursor3[1], cursor3[2])

            im3 = self.parent().images[focus_imname]
            value = get_pixel_general(im3, cursor3, is_world=True)
            value_str = '{:.2f}'.format(value)

            text = 'Cursor: {}\nValue: {}'.format(cursor3_str, value_str)
            left = self.text_left_margin
            top = height - self.text_bot_margin - painter.fontMetrics().height() * 2
            rect = QRectF(left, top, self.text_width, painter.fontMetrics().height() * 2)
            painter.drawText(rect, Qt.AlignLeft, text)

    def draw_rd_text(self, image):

        rd_text = self.get_rd_text()
        rd_textcolor = self.get_rd_textcolor()
        rd_fontsize = self.get_rd_fontsize()
        width, height = self.width(), self.height()
        font = self.font()
        rd_font = QFont(self.font())
        rd_font.setPointSize(rd_fontsize)

        if rd_text == '':
            return

        assert isinstance(image, QPixmap)
        painter = QPainter(image)
        painter.setPen(rd_textcolor)
        painter.setFont(rd_font)

        right = width - self.text_right_margin
        fm = painter.fontMetrics()
        text_width = fm.width(rd_text)
        left = right - text_width

        bot = height - self.text_bot_margin
        top = bot - fm.height()

        rect = QRectF(left, top, self.text_width, fm.height())
        painter.drawText(rect, Qt.AlignLeft, rd_text)

        painter.setFont(font)
        painter.setPen(self.text_color)

    def draw_text(self, image):

        if self.enable_text:
            self.draw_image_text(image)
            self.draw_focus_text(image)
            self.draw_cursor_text(image)
            self.draw_rd_text(image)

    def draw_lm(self, image):

        lms = self.parent().lms
        painter = QPainter(image)
        painter.setPen(self.lm_color)
        painter.setBrush(self.lm_color)

        fm = self.fontMetrics()
        lm_radius = self.parent().cfg.lm_radius

        for lmname, lm in lms.iteritems():

            tag_visible = self.parent().lm_params[lmname]['tag_visible']
            if not tag_visible:
                continue

            lm_desc = self.parent().lm_params[lmname]['description']
            lm_text = lmname if lm_desc == '' else lmname + '(' + lm_desc + ')'

            dist = self.get_pt_dist(lm)
            if dist <= self.parent().cfg.lm_vis_dist:
                coord2 = self.get_view_coord2(lm)
                x, y = int(coord2[0] + 0.5), int(coord2[1] + 0.5)
                painter.drawEllipse(x - lm_radius, y - lm_radius, 2 * lm_radius + 1, 2 * lm_radius + 1)

                circle_radius = self.parent().lm_params[lmname]['circle_radius']
                if circle_radius > 0:
                    radius_in_pixels = self.get_pixels_from_mm(circle_radius)
                    painter.setBrush(Qt.NoBrush)
                    painter.drawEllipse(x - radius_in_pixels, y - radius_in_pixels, 2 * radius_in_pixels + 1, 2 * radius_in_pixels + 1)

                text_visible = self.parent().lm_params[lmname]['text_visible']
                if text_visible:
                    width = fm.width(lm_text)
                    height = fm.height()
                    top = y - self.lm_text_margin - height
                    left = x - width // 2
                    rect = QRectF(left, top, width, height)
                    painter.drawText(rect, Qt.AlignLeft, lm_text)

    # event handlers

    def mousePressEvent(self, event):
        assert isinstance(event, QMouseEvent)

        if self.image is None:
            return

        if event.button() == Qt.LeftButton:
            px_pos = event.pos()
            cursor3 = self.get_coord3(px_pos.x(), px_pos.y())
            self.cursor_changed.emit(cursor3)

        elif event.button() == Qt.RightButton:
            self.rclicked_pos = event.pos()

    def mouseReleaseEvent(self, event):
        assert isinstance(event, QMouseEvent)

        if self.image is None:
            return

        if event.button() == Qt.RightButton:
            self.rclicked_pos = None

    def mouseMoveEvent(self, event):
        assert isinstance(event, QMouseEvent)

        if self.image is None:
            return

        if event.buttons() == Qt.LeftButton:
            px_pos = event.pos()
            cursor3 = self.get_coord3(px_pos.x(), px_pos.y())
            self.cursor_changed.emit(cursor3)

        elif event.buttons() == Qt.RightButton and self.rclicked_pos is not None:
            x_shift = self.rclicked_pos.x() - event.pos().x()
            y_shift = self.rclicked_pos.y() - event.pos().y()
            self.rclicked_pos = event.pos()
            self.rbutton_shifted.emit((x_shift, y_shift))

    def wheelEvent(self, event):
        assert isinstance(event, QWheelEvent)

        if self.image is None:
            return

        delta = event.angleDelta().y() // 120
        self.wheel_scrolled.emit(delta)

    def resizeEvent(self, event):
        assert isinstance(event, QResizeEvent)
        self.image = self.parent().request_mix_image(self.vidx, self.width(), self.height())
        self.update_view()

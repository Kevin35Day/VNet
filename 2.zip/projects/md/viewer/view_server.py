import argparse
import os
import sys

from PyQt5.Qt import *
from md.image3d.python.image3d import Image3d
import md.viewer.common.view3_cfg as view3_cfg
import md.viewer.common.view3 as view3


class ViewServer(QMainWindow):
    """ standalone viewer process """

    # command name -> number of arguments
    commands = {'ECHO': 0,
                'SET_IMAGE': 6,
                'SELECT_IMAGE': 2,
                'DESELECT_IMAGE': 1,
                'ADJUST_WCWW': 3,
                'ADJUST_OPACITY': 2,
                'ADJUST_COLORMODE': 2,
                'GOTO': 4,
                'GOTO_VOXEL': 5,
                'GET_CURSOR': 0,
                'GET_VOXEL': 1,
                'ZOOM': 1,
                'MARKLM': 5,
                'MARKLM_CURSOR': 8,
                'GOTOLM': 1,
                'REMOVELM': 1,
                'LMS': 0,
                'CLOSE': 0}

    def __init__(self, config):

        assert isinstance(config, view3_cfg.View3Config)
        super(ViewServer, self).__init__()
        self.view3 = view3.View3(config, parent=self)
        self.setCentralWidget(self.view3)

        # server parameters
        self.timeout = 3000     # timeout milliseconds

        # set viewer name as window title
        self.setWindowTitle(config.name)

        # setup server
        self.setup_server()

    def setup_server(self):
        """ setup server and listen for commands """
        self.server = QLocalServer(self)
        success = self.server.listen(config.name)
        if not success:
            if self.server.serverError() == QAbstractSocket.AddressInUseError:
                # print '[Server-Warning] Server address in use. Remove old server and restart'
                QLocalServer.removeServer(config.name)
                success = self.server.listen(config.name)
                if not success:
                    print '[Server-Error] Unable to start the server'
                    self.close()
            else:
                QMessageBox.critical(self, 'Viewer', 'Unable to start the server')
                self.close()

        self.server.newConnection.connect(self.connectReceived)

    ####################################################################
    # Event handlers
    ####################################################################

    def closeEvent(self, event):
        """ event handler when a close event is requested """
        isinstance(event, QCloseEvent)
        if 'server' in self.__dict__:
            self.server.close()
        super(ViewServer, self).closeEvent(event)

    def connectReceived(self):

        client_connection = self.server.nextPendingConnection()
        assert isinstance(client_connection, QLocalSocket)
        client_connection.disconnected.connect(client_connection.deleteLater)

        if not client_connection.waitForConnected(self.timeout):
            print '[Server-Warning] client connection time out'
            return

        if not client_connection.waitForReadyRead(self.timeout):
            print '[Server-Warning] client read time out'
            return

        command = client_connection.readAll()
        assert isinstance(command, QByteArray)

        # command format: CMD;COMMAND_NAME;ARG1;ARG2...
        command = command.data()
        tokens = command.split(';')

        if not self.__message_filter(tokens):
            print '[Server-Warning] message is not in the correct format'
            return

        if tokens[1] == 'SET_IMAGE':
            self.__set_image(tokens[2:], client_connection)
        elif tokens[1] == 'SELECT_IMAGE':
            self.__select_image(tokens[2:], client_connection)
        elif tokens[1] == 'DESELECT_IMAGE':
            self.__deselect_image(tokens[2:], client_connection)
        elif tokens[1] == 'ADJUST_WCWW':
            self.__adjust_wcww(tokens[2:], client_connection)
        elif tokens[1] == 'ADJUST_OPACITY':
            self.__adjust_opacity(tokens[2:], client_connection)
        elif tokens[1] == 'ADJUST_COLORMODE':
            self.__adjust_colormode(tokens[2:], client_connection)
        elif tokens[1] == 'GOTO':
            self.__goto(tokens[2:], client_connection)
        elif tokens[1] == 'GOTO_VOXEL':
            self.__goto_voxel(tokens[2:], client_connection)
        elif tokens[1] == 'GET_CURSOR':
            self.__get_cursor(client_connection)
        elif tokens[1] == 'ZOOM':
            self.__zoom(tokens[2:], client_connection)
        elif tokens[1] == 'MARKLM':
            self.__marklm(tokens[2:], client_connection)
        elif tokens[1] == 'MARKLM_CURSOR':
            self.__marklm_cursor(tokens[2:], client_connection)
        elif tokens[1] == 'GOTOLM':
            self.__gotolm(tokens[2:], client_connection)
        elif tokens[1] == 'REMOVELM':
            self.__removelm(tokens[2:], client_connection)
        elif tokens[1] == 'LMS':
            self.__lms(client_connection)
        elif tokens[1] == 'ECHO':
            self.__echo(client_connection)
        elif tokens[1] == 'CLOSE':
            self.__close(client_connection)
        elif tokens[1] == 'GET_VOXEL':
            self.__get_voxel(tokens[2:],client_connection)

        client_connection.disconnectFromServer()

    ############################################################
    # private member functions
    ############################################################

    def __message_filter(self, tokens):
        """ return true if pass for parser, false if filtered"""

        if len(tokens) <= 1 or tokens[0] != 'CMD':
            # command header mismatch
            return False

        if tokens[1] not in self.commands:
            # no such commands
            return False

        if len(tokens)-2 != self.commands[tokens[1]]:
            # the number of arguments mismatch
            return False

        return True

    def __reply(self, client_connection, message):
        """ reply client with certain message """
        client_connection.write(message)
        client_connection.waitForBytesWritten()

    def __close(self, client_connection):
        """ called when viewer process receives close event """
        self.__reply(client_connection, 'REPLY;DONE')
        self.close()

    def __echo(self, client_connection):
        """ echo back to client """
        self.__reply(client_connection, 'REPLY;ECHO')
        client_connection.waitForBytesWritten()

    def __select_image(self, args, client_connection):
        """ select an image """
        imids = args[0].split(':')
        reset = True if args[1] == 'True' else False
        if reset:
            self.view3.clear_selections()
        self.view3.select(imids)
        self.__reply(client_connection, 'REPLY;DONE')

    def __deselect_image(self, args, client_connection):
        """ deselect an image """
        imids = args[0].split(':')
        self.view3.deselect(imids)
        self.__reply(client_connection, 'REPLY;DONE')

    def __adjust_wcww(self, args, client_connection):
        """ adjust window center and width """
        name = args[0]
        wc = float(args[1])
        ww = float(args[2])
        self.view3.set_wcww(name, wc, ww)
        self.__reply(client_connection, 'REPLY;DONE')

    def __adjust_opacity(self, args, client_connection):
        """ adjust opacity of image """
        name = args[0]
        alpha = float(args[1])
        self.view3.adjust_opacity(name, alpha)
        self.__reply(client_connection, 'REPLY;DONE')

    def __adjust_colormode(self, args, client_connection):
        """ adjust colormode of image """
        name = args[0]
        colormode = int(args[1])
        self.view3.adjust_colormode(name, colormode)
        self.__reply(client_connection, 'REPLY;DONE')

    def __goto(self, args, client_connection):
        """ goto the world coordinate """
        world_pos = [float(args[0]), float(args[1]), float(args[2])]
        zoom_factor = float(args[3]) if args[3] != 'None' else None
        self.view3.goto(world_pos, zoom_factor)
        self.__reply(client_connection, 'REPLY;DONE')

    def __goto_voxel(self, args, client_connection):
        """ goto the voxel coordinate """
        name = args[0]
        voxel_pos = [float(args[1]), float(args[2]), float(args[3])]
        zoom_factor = float(args[4]) if args[4] != 'None' else None
        self.view3.goto_voxel(name, voxel_pos, zoom_factor)
        self.__reply(client_connection, 'REPLY;DONE')

    def __get_voxel(self, args, client_connection):
        imid = args[0]
        voxel3 = self.view3.get_voxel(imid)
        reply = 'REPLY;{};{};{}'.format(voxel3[0], voxel3[1], voxel3[2])
        self.__reply(client_connection, reply)

    def __get_cursor(self, client_connection):
        """ get cursor """
        cursor3 = self.view3.cursor3
        reply = 'REPLY;{};{};{}'.format(cursor3[0], cursor3[1], cursor3[2])
        self.__reply(client_connection, reply)

    def __zoom(self, args, client_connection):
        """ zoom view """
        zoom_factor =float(args[0])
        self.view3.zoom_factor = zoom_factor
        self.view3.update_all()
        self.__reply(client_connection, 'REPLY;DONE')

    def __marklm(self, args, client_connection):
        """ mark a landmark """
        name = args[0]
        desc = args[1]
        tag_visible = True if args[2] == 'True' else False
        text_visible = True if args[3] == 'True' else False
        radius = int(args[4])

        self.view3.add_lm(name, self.view3.cursor3, desc, tag_visible=tag_visible, text_visible=text_visible, radius=radius)
        self.view3.update_view(0)
        self.__reply(client_connection, 'REPLY;DONE')

    def __marklm_cursor(self, args, client_connection):
        """ mark a landmark at any position """
        cursor_x = args[0]
        cursor_y = args[1]
        cursor_z = args[2]
        cursor = [cursor_x, cursor_y, cursor_z]

        name = args[3]
        desc = args[4]
        tag_visible = True if args[5] == 'True' else False
        text_visible = True if args[6] == 'True' else False
        radius = int(args[7])

        self.view3.add_lm(name, cursor, desc, tag_visible=tag_visible, text_visible=text_visible, radius=radius)
        self.__reply(client_connection, 'REPLY;DONE')

    def __removelm(self, args, client_connection):
        """ clear all landmark annotations """
        self.view3.remove_lm(args[0])
        self.__reply(client_connection, 'REPLY;DONE')

    def __gotolm(self, args, client_connection):
        """ goto a landmark """
        name = args[0]
        self.view3.goto_lm(name)
        self.__reply(client_connection, 'REPLY;DONE')

    def __lms(self, client_connection):
        """ get all landmark positions """
        reply = 'REPLY'
        for lmname in self.view3.lms:
            coord = self.view3.lms[lmname]
            desc = self.view3.lm_params[lmname]['description']
            lmstr = '{}:{}:{}:{}:{}'.format(lmname, desc, coord[0], coord[1], coord[2])
            reply += ';' + lmstr
        self.__reply(client_connection, reply)

    def __set_image(self, args, client_connection):
        """ set image to viewer """

        # load image3d from shared memory
        mem = QSharedMemory(config.name)
        if not mem.attach():
            print '[Server-Error] fail to attach to shared memory for reading image'
            self.__reply(client_connection, 'REPLY;FAIL')
            return

        # lock down shared memory
        mem.lock()

        data_ptr = mem.data()
        image = Image3d()
        success = image.read_from_buffer(int(data_ptr))

        # set image in viewer
        imid = args[0]
        wc = float(args[1]) if args[1] != 'None' else None
        ww = float(args[2]) if args[2] != 'None' else None
        colormode = int(args[3])
        alpha = float(args[4])
        active = True if args[5] == 'True' else False

        self.view3.add_image(image, imid, wc, ww, colormode, alpha)
        if active:
            self.view3.active_image(imid)

        # unlock shared memory
        mem.unlock()
        mem.detach()

        if not success:
            print '[Server-Error] fail to read image from shared memory'
            self.__reply(client_connection, 'REPLY;FAIL')
            return
        else:
            self.__reply(client_connection, 'REPLY;DONE')
            return


def screen_center(view):
    """ center viewer on screen """
    screen_geometry = QApplication.desktop().availableGeometry()
    x = (screen_geometry.width() - view.width()) / 2
    y = 0
    view.move(x, y)


def screen_left(view):
    """ align viewer on the left of screen """
    x = 0
    y = 0
    view.move(x, y)


def screen_right(view):
    """ align viewer on the right of screen """
    screen_geometry = QApplication.desktop().availableGeometry()
    x = screen_geometry.width() - view.width()
    y = 0
    view.move(x, y)


if __name__ == '__main__':

    parser = argparse.ArgumentParser('parse inputs for viewer server')
    parser.add_argument('-i', '--input', default=None, help='input configuration json file')
    parser.add_argument('--delete', type=bool, default=True, help='whether delete json file after loading')
    parser.add_argument('--position', type=int, default=1, help='0 for center position, 1 for left position, 2 for right position')
    parser.add_argument('--width', type=int, default=-1, help='-1 for automatic width')
    parser.add_argument('--height', type=int, default=-1, help='-1 for automatic height')
    args = parser.parse_args()

    if args.input is None:
        factory = view3_cfg.View3ConfigFactory()
        config = factory.cfg_2x2('viewer')
    else:
        if not os.path.isfile(args.input):
            raise ValueError('[Error] json file not found!')
        config = view3_cfg.load_view3_cfg(args.input)
        if args.delete:
            os.remove(args.input)

    app = QApplication(sys.argv)

    screen_size = QDesktopWidget().availableGeometry()
    width = screen_size.height() if args.width == -1 else args.width
    height = screen_size.height() if args.height == -1 else args.height

    view = ViewServer(config)
    view.resize(width, height)

    if args.position == 0:
        screen_center(view)
    elif args.position == 1:
        screen_left(view)
    elif args.position == 2:
        screen_right(view)
    else:
        raise ValueError('unknown position option, supported: 0 for center, 1 for left, 2 for right')

    view.show()

    sys.exit(app.exec_())

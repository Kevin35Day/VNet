from view_client import ViewClient
import inspect


def view(im, imid=None, wc=None, ww=None, color=0, alpha=1, viewer='viewer', active=True):
    """
    view an image3d object
    :param im:      image3d object
    :param imid:    image id
    :param wc:      window center
    :param ww:      window width
    :param color:   colormode, 0-5
    :param alpha:   transparency
    :param viewer:  viewer name
    :param active:  activate the image
    :return: a viewer controller
    """
    if imid is None:
        callers_local_vars = inspect.currentframe().f_back.f_locals.items()
        imids = [var_name for var_name, var_val in callers_local_vars if var_val is im]
        imid = imids[0]

    client = ViewClient(viewer, config=None)
    if not client.exists():
        client.open()
        client.wait_server_setup()

    client.add_image(im, imid, wc, ww, color, alpha, active)
    return client


def viewim(im, imid=None, wc=None, ww=None, alpha=1, viewer='viewer', active=True):
    """ view an intensity image """
    if imid is None:
        callers_local_vars = inspect.currentframe().f_back.f_locals.items()
        imids = [var_name for var_name, var_val in callers_local_vars if var_val is im]
        imid = imids[0]

    return view(im, imid, wc, ww, 0, alpha, viewer, active)


def viewseg(im, imid=None, alpha=1, viewer='viewer', active=False):
    """ view a mask image  """
    if imid is None:
        callers_local_vars = inspect.currentframe().f_back.f_locals.items()
        imids = [var_name for var_name, var_val in callers_local_vars if var_val is im]
        imid = imids[0]

    return view(im, imid, None, None, 5, alpha, viewer, active)


def close_viewer(viewer='viewer'):
    """ close a viewer by name """
    client = ViewClient(viewer, config=None)
    client.close()


def select(vars, reset=False, viewer='viewer'):
    """ select images """
    names = []
    if not isinstance(vars, (list, tuple)):
        vars = [vars]

    for var in vars:
        if isinstance(var, (str, unicode)):
            names.append(var)
        else:
            callers_local_vars = inspect.currentframe().f_back.f_locals.items()
            imids = [var_name for var_name, var_val in callers_local_vars if var_val is var]
            names.append(imids[0])

    client = ViewClient(viewer, config=None)
    client.select_images(names, reset)


def deselect(vars, viewer='viewer'):
    """ deselect images """
    names = []
    if not isinstance(vars, (list, tuple)):
        vars = [vars]

    for var in vars:
        if isinstance(var, (str, unicode)):
            names.append(var)
        else:
            callers_local_vars = inspect.currentframe().f_back.f_locals.items()
            imids = [var_name for var_name, var_val in callers_local_vars if var_val is var]
            names.append(imids[0])

    client = ViewClient(viewer, config=None)
    client.deselect_images(names)


def view_wcww(var, wc, ww, viewer='viewer'):
    """ set window center and width """
    if isinstance(var, (str, unicode)):
        name = var
    else:
        callers_local_vars = inspect.currentframe().f_back.f_locals.items()
        imids = [var_name for var_name, var_val in callers_local_vars if var_val is var]
        name = imids[0]

    client = ViewClient(viewer, config=None)
    client.adjust_wcww(name, wc, ww)


def view_opacity(var, alpha, viewer='viewer'):
    """ set opacity value """
    if isinstance(var, (str, unicode)):
        name = var
    else:
        callers_local_vars = inspect.currentframe().f_back.f_locals.items()
        imids = [var_name for var_name, var_val in callers_local_vars if var_val is var]
        name = imids[0]

    client = ViewClient(viewer, config=None)
    client.adjust_opacity(name, alpha)


def view_colormode(var, colormode, viewer='viewer'):
    """ set colormode of image """
    if isinstance(var, (str, unicode)):
        name = var
    else:
        callers_local_vars = inspect.currentframe().f_back.f_locals.items()
        imids = [var_name for var_name, var_val in callers_local_vars if var_val is var]
        name = imids[0]

    client = ViewClient(viewer, config=None)
    client.adjust_colormode(name, colormode)


def goto(x, y, z, zoom_factor=None, viewer='viewer'):
    """ goto a position pointed by the world coordinate """
    client = ViewClient(viewer, config=None)
    client.goto([x, y, z], zoom_factor)


def goto_voxel(var, x, y, z, zoom_factor=None, viewer='viewer'):
    """ goto a position pointed by the voxel coordinate of image """
    if isinstance(var, (str, unicode)):
        name = var
    else:
        callers_local_vars = inspect.currentframe().f_back.f_locals.items()
        imids = [var_name for var_name, var_val in callers_local_vars if var_val is var]
        name = imids[0]

    client = ViewClient(viewer, config=None)
    client.goto_voxel(name, [x, y, z], zoom_factor)


def zoom(zoom_factor=1.0, viewer='viewer'):
    """ zoom the view """
    client = ViewClient(viewer, config=None)
    client.zoom(zoom_factor)


def cursor(viewer='viewer'):
    """ get the world position of viewer """
    client = ViewClient(viewer, config=None)
    cursor = client.get_cursor()
    return cursor


def marklm(name, desc='', tag_visible=True, text_visible=True, radius=0, viewer='viewer'):
    """ mark a landmark on image """
    assert (';' not in name) and (';' not in desc)
    client = ViewClient(viewer, config=None)
    client.marklm(name, desc, tag_visible=tag_visible, text_visible=text_visible, radius=radius)


def goto_lm(name, viewer='viewer'):
    """ goto a landmark """
    client = ViewClient(viewer, config=None)
    client.goto_lm(name)


def removelm(name, viewer='viewer'):
    """ clear all landmarks in viewer """
    client = ViewClient(viewer, config=None)
    client.removelm(name)


def lms(viewer='viewer'):
    """ get all landmarks """
    client = ViewClient(viewer, config=None)
    return client.lms()


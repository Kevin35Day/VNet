"""
python wrapper for image3d library

this file includes

fun_dict:   a dictionary contains function pointers
Image3d:    an image3d class

"""

import platform
import os
import _ctypes
import md.image3d.python.frame3d as frame3d
from md.utils.python.find_dll import find_dll
import ctypes
import numpy as np
import medtypes


# dll library
lib = None

# function pointer dictionary
fun_dict = {}


def __get_library_path():

    dll_file = find_dll('pyimage3d')
    if dll_file is None:
        raise OSError('dll not found')
    return dll_file


def __load_c_functions():

    global lib, fun_dict

    lib = ctypes.cdll.LoadLibrary(__get_library_path())

    lib.image3d_create.argtypes = []
    lib.image3d_create.restype = ctypes.c_void_p
    fun_dict['image3d_create'] = lib.image3d_create

    lib.image3d_create_with_size.argtypes = [ctypes.c_int32, ctypes.c_int32, ctypes.c_int32, ctypes.c_int32]
    lib.image3d_create_with_size.restype = ctypes.c_void_p
    fun_dict['image3d_create_with_size'] = lib.image3d_create_with_size

    lib.image3d_delete.argtypes = [ctypes.c_void_p]
    lib.image3d_delete.restype = None
    fun_dict['image3d_delete'] = lib.image3d_delete

    lib.image3d_size.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    lib.image3d_size.restype = None
    fun_dict['image3d_size'] = lib.image3d_size

    lib.image3d_width.argtypes = [ctypes.c_void_p]
    lib.image3d_width.restype = ctypes.c_int32
    fun_dict['image3d_width'] = lib.image3d_width

    lib.image3d_height.argtypes = [ctypes.c_void_p]
    lib.image3d_height.restype = ctypes.c_int32
    fun_dict['image3d_height'] = lib.image3d_height

    lib.image3d_depth.argtypes = [ctypes.c_void_p]
    lib.image3d_depth.restype = ctypes.c_int32
    fun_dict['image3d_depth'] = lib.image3d_depth

    lib.image3d_pixel_type.argtypes = [ctypes.c_void_p]
    lib.image3d_pixel_type.restype = ctypes.c_int32
    fun_dict['image3d_pixel_type'] = lib.image3d_pixel_type

    lib.image3d_origin.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    lib.image3d_origin.restype = None
    fun_dict['image3d_origin'] = lib.image3d_origin

    lib.image3d_spacing.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    lib.image3d_spacing.restype = None
    fun_dict['image3d_spacing'] = lib.image3d_spacing

    lib.image3d_axis.argtypes = [ctypes.c_void_p, ctypes.c_int32, ctypes.c_void_p]
    lib.image3d_axis.restype = None
    fun_dict['image3d_axis'] = lib.image3d_axis

    lib.image3d_frame.argtypes = [ctypes.c_void_p]
    lib.image3d_frame.restype = ctypes.c_void_p
    fun_dict['image3d_frame'] = lib.image3d_frame

    lib.image3d_center.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    lib.image3d_center.restype = None
    fun_dict['image3d_center'] = lib.image3d_center

    lib.image3d_data.argtypes = [ctypes.c_void_p]
    lib.image3d_data.restype = ctypes.c_void_p
    fun_dict['image3d_data'] = lib.image3d_data

    lib.image3d_resize.argtypes = [ctypes.c_void_p, ctypes.c_int32, ctypes.c_int32, ctypes.c_int32]
    lib.image3d_resize.restype = ctypes.c_bool
    fun_dict['image3d_resize'] = lib.image3d_resize

    lib.image3d_allocate.argtypes = [ctypes.c_void_p, ctypes.c_int32, ctypes.c_int32, ctypes.c_int32, ctypes.c_int32]
    lib.image3d_allocate.restype = ctypes.c_bool
    fun_dict['image3d_allocate'] = lib.image3d_allocate

    lib.image3d_cast.argtypes = [ctypes.c_void_p, ctypes.c_int32]
    lib.image3d_cast.restype = ctypes.c_bool
    fun_dict['image3d_cast'] = lib.image3d_cast

    lib.image3d_copy_data.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int32, ctypes.c_int32, ctypes.c_int32, ctypes.c_int32]
    lib.image3d_copy_data.restype = ctypes.c_bool
    fun_dict['image3d_copy_data'] = lib.image3d_copy_data

    lib.image3d_copy_data_to.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    lib.image3d_copy_data_to.restype = None
    fun_dict['image3d_copy_data_to'] = lib.image3d_copy_data_to

    lib.image3d_set_origin.argtypes = [ctypes.c_void_p, ctypes.c_double, ctypes.c_double, ctypes.c_double]
    lib.image3d_set_origin.restype = None
    fun_dict['image3d_set_origin'] = lib.image3d_set_origin

    lib.image3d_set_spacing.argtypes = [ctypes.c_void_p, ctypes.c_double, ctypes.c_double, ctypes.c_double]
    lib.image3d_set_spacing.restype = None
    fun_dict['image3d_set_spacing'] = lib.image3d_set_spacing

    lib.image3d_set_axes.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    lib.image3d_set_axes.restype = None
    fun_dict['image3d_set_axes'] = lib.image3d_set_axes

    lib.image3d_set_frame.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    lib.image3d_set_frame.restype = None
    fun_dict['image3d_set_frame'] = lib.image3d_set_frame

    lib.image3d_clear_state.argtypes = [ctypes.c_void_p]
    lib.image3d_clear_state.restype = None
    fun_dict['image3d_clear_state'] = lib.image3d_clear_state

    lib.image3d_world_to_voxel.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int32, ctypes.c_void_p]
    lib.image3d_world_to_voxel.restype = None
    fun_dict['image3d_world_to_voxel'] = lib.image3d_world_to_voxel

    lib.image3d_voxel_to_world.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int32, ctypes.c_void_p]
    lib.image3d_voxel_to_world.restype = None
    fun_dict['image3d_voxel_to_world'] = lib.image3d_voxel_to_world

    lib.image3d_bytes.argtypes = [ctypes.c_void_p]
    lib.image3d_bytes.restype = ctypes.c_size_t
    fun_dict['image3d_bytes'] = lib.image3d_bytes

    lib.image3d_write_to_buffer.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    lib.image3d_write_to_buffer.restype = ctypes.c_bool
    fun_dict['image3d_write_to_buffer'] = lib.image3d_write_to_buffer

    lib.image3d_read_from_buffer.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    lib.image3d_read_from_buffer.restype = ctypes.c_bool
    fun_dict['image3d_read_from_buffer'] = lib.image3d_read_from_buffer

    lib.image3d_fill_pixel.argtypes = [ctypes.c_void_p, ctypes.c_double]
    lib.image3d_fill_pixel.restype = None
    fun_dict['image3d_fill_pixel'] = lib.image3d_fill_pixel

    lib.image3d_pixel_value.argtypes = [ctypes.c_void_p, ctypes.c_int32, ctypes.c_int32, ctypes.c_int32]
    lib.image3d_pixel_value.restype = ctypes.c_double
    fun_dict['image3d_pixel_value'] = lib.image3d_pixel_value

    lib.image3d_deep_copy.argtypes = [ctypes.c_void_p]
    lib.image3d_deep_copy.restype = ctypes.c_void_p
    fun_dict['image3d_deep_copy'] = lib.image3d_deep_copy

    lib.image3d_set_zeros.argtypes = [ctypes.c_void_p]
    lib.image3d_set_zeros.restype = None
    fun_dict['image3d_set_zeros'] = lib.image3d_set_zeros



def unload():

    global lib, fun_dict

    try:
        while lib is not None:
            if platform.system() == 'Windows':
                _ctypes.FreeLibrary(lib._handle)
            else:
                _ctypes.dlclose(lib._handle)
    except:
        lib = None
        fun_dict = {}


def load():

    unload()
    __load_c_functions()


# load dynamic library and function pointers
load()


def load_c_functions_if_necesary():

    if len(fun_dict) == 0:
        print '[info] pyimage3d dll reloaded'
        __load_c_functions()


def call_func(func_name, *args):

    load_c_functions_if_necesary()

    if len(args) == 0:
        return fun_dict[func_name]()
    else:
        return fun_dict[func_name](*args)


def _image_bytes(size, pixel_type):
    size = np.array(size, dtype=np.long)
    pixel_bytes = medtypes.type_to_bytes[pixel_type]
    bytes_total = pixel_bytes * np.prod(size)
    return bytes_total


class Image3d(object):
    """ image3d class python wrapper """

    def __init__(self, *args, **kwargs):
        
        super(Image3d, self).__init__()

        if len(args) == 0 and len(kwargs) == 0:

            self.ptr = call_func('image3d_create')

        elif len(args) > 0:

            assert len(args) == 1, 'positional argument must be only a raw ptr'
            self.ptr = args[0]

        else:
            if 'width' not in kwargs:
                raise ValueError('width argument missing')
            if 'height' not in kwargs:
                raise ValueError('height argument missing')
            if 'depth' not in kwargs:
                raise ValueError('depth argument missing')
            if 'dtype' not in kwargs:
                raise ValueError('dtype argument missing')

            if kwargs['dtype'] not in medtypes.type_to_value:
                raise ValueError('unknown dtype')

            width, height, depth = ctypes.c_int32(kwargs['width']), ctypes.c_int32(kwargs['height']), ctypes.c_int32(kwargs['depth'])
            assert width.value > 0 and height.value > 0 and depth.value > 0, 'negative dimensions'

            dtype = medtypes.type_to_value[kwargs['dtype']]
            self.ptr = call_func('image3d_create_with_size', width, height, depth, dtype)

            if self.ptr is None:
                bytes_total = _image_bytes([width.value, height.value, depth.value], kwargs['dtype'])
                del self.ptr
                raise MemoryError('fail to allocate image. {:.2f} Gb RAM needed'.format(bytes_total * 1.0 / 1024**3))

    def __del__(self):

        call_func('image3d_delete', self.ptr)
        self.ptr = None

    def __str__(self):

        size = self.size()
        ptype_str = medtypes.type_to_string[self.pixel_type()]
        bytes_total = _image_bytes([size[0], size[1], size[2]], self.pixel_type())

        frame = self.frame()

        out_str =  'size   : {}\n'.format(size)
        out_str += 'ptype  : {}\n'.format(ptype_str)
        out_str += 'storage: {} Mb\n'.format(bytes_total * 1.0 / 1024**2)
        out_str += str(frame)
        return out_str

    def deep_copy(self):

        ptr = call_func('image3d_deep_copy', self.ptr)

        if ptr is None:
            bytes_total = _image_bytes(self.size(), self.pixel_type())
            raise MemoryError('fail to copy image. {:.2f} Gb RAM needed'.format(bytes_total * 1.0 / 1024 ** 3))

        return Image3d(ptr)

    def size(self):

        size = np.empty((3,), dtype=np.int32)
        size_ptr = size.ctypes.data_as(ctypes.POINTER(ctypes.c_int32))
        call_func('image3d_size', self.ptr, size_ptr)
        return size

    def width(self):
        return call_func('image3d_width', self.ptr)


    def height(self):
        return call_func('image3d_height', self.ptr)

    def depth(self):
        return call_func('image3d_depth', self.ptr)

    def pixel_type(self):

        type_idx = call_func('image3d_pixel_type', self.ptr)
        return medtypes.value_to_type[type_idx]

    def data(self):

        return call_func('image3d_data', self.ptr)

    def origin(self):

        origin = np.empty((3,), dtype=np.double)
        origin_ptr = origin.ctypes.data_as(ctypes.POINTER(ctypes.c_double))
        call_func('image3d_origin', self.ptr, origin_ptr)
        return origin

    def spacing(self):

        spacing = np.empty((3,), dtype=np.double)
        spacing_ptr = spacing.ctypes.data_as(ctypes.POINTER(ctypes.c_double))
        call_func('image3d_spacing', self.ptr, spacing_ptr)
        return spacing

    def axis(self, idx):

        assert isinstance(idx, int) and idx >= 0 and idx <= 2

        idx = ctypes.c_int32(idx)
        axis = np.empty((3,), dtype=np.double)
        axis_ptr = axis.ctypes.data_as(ctypes.POINTER(ctypes.c_double))
        call_func('image3d_axis', self.ptr, idx, axis_ptr)
        return axis

    def center(self):

        center = np.empty((3,), dtype=np.double)
        center_ptr = center.ctypes.data_as(ctypes.POINTER(ctypes.c_double))
        call_func('image3d_center', self.ptr, center_ptr)
        return center

    def frame(self):

        ptr = call_func('image3d_frame', self.ptr)
        return frame3d.Frame3d(ptr)

    def get_pixel(self, idx):

        assert len(idx) == 3, 'index must be 3-dimensional'
        size = self.size()

        if idx[0] < 0 or idx[1] < 0 or idx[2] < 0:
            raise ValueError('index out of image domain')
        if idx[0] >= size[0] or idx[1] >= size[1] or idx[2] >= size[2]:
            raise ValueError('index out of image domain')

        x, y, z = ctypes.c_int32( int(idx[0]) ), ctypes.c_int32( int(idx[1]) ), ctypes.c_int32( int(idx[2]) )
        value = call_func('image3d_pixel_value', self.ptr, x, y, z)

        return value

    def fill(self, value):

        value = ctypes.c_double(value)
        call_func('image3d_fill_pixel', self.ptr, value)

    def resize(self, width, height, depth):

        assert width > 0 and height > 0 and depth > 0

        width, height, depth = ctypes.c_int32(width), ctypes.c_int32(height), ctypes.c_int32(depth)
        success = call_func('image3d_resize', self.ptr, width, height, depth)

        if not success:
            bytes_total = _image_bytes([width.value, height.value, depth.value], self.pixel_type())
            del self.ptr   # the object is corrupted, delete the ptr in case others call member functions
            raise MemoryError('fail to allocate image. {:.2f} Gb RAM needed. '
                              'Please delete the image3d var'.format(bytes_total * 1.0 / 1024 ** 3))

    def allocate(self, width, height, depth, type):

        assert width > 0 and height > 0 and depth > 0

        width, height, depth = ctypes.c_int32(width), ctypes.c_int32(height), ctypes.c_int32(depth)
        success = call_func('image3d_allocate', self.ptr, width, height, depth, medtypes.type_to_value[type])
        if not success:
            bytes_total = _image_bytes([width.value, height.value, depth.value], type)
            del self.ptr   # the object is corrupted, delete the ptr in case others call member functions
            raise MemoryError('fail to allocate image. {:.2f} Gb RAM needed. '
                              'Please delete the image3d var'.format(bytes_total * 1.0 / 1024 ** 3))

    def cast(self, type):

        success = call_func('image3d_cast', self.ptr, medtypes.type_to_value[type])
        if not success:
            bytes_total = _image_bytes(self.size(), type)
            raise MemoryError('fail to cast pixel type. {:.2f} Gb RAM needed.'.format(bytes_total * 1.0 / 1024 ** 3))

    def from_numpy(self, data, dtype=None):

        assert isinstance(data, np.ndarray) and data.ndim == 3
        if dtype is None:
            dtype = data.dtype.type

        data_buffer = np.ascontiguousarray(data, dtype=dtype)
        data_ptr = data_buffer.ctypes.data_as(ctypes.POINTER(medtypes.type_to_ctypes[dtype]))

        depth, height, width = ctypes.c_int32(data.shape[0]), ctypes.c_int32(data.shape[1]), ctypes.c_int32(data.shape[2])
        success = call_func('image3d_copy_data', self.ptr, data_ptr, width, height, depth, medtypes.type_to_value[dtype])
        if not success:
            bytes_total = _image_bytes([width.value, height.value, depth.value], dtype)
            del self.ptr   # the object is corrupted, delete the ptr in case others call member functions
            raise MemoryError('fail to allocate image. {:.2f} Gb RAM needed. '
                              'Please delete the image3d var'.format(bytes_total * 1.0 / 1024 ** 3))

    def to_numpy(self):

        dtype = self.pixel_type()
        width, height, depth = self.width(), self.height(), self.depth()
        data = np.empty((depth, height, width), dtype=dtype)
        data_ptr = data.ctypes.data_as(ctypes.POINTER(medtypes.type_to_ctypes[dtype]))
        call_func('image3d_copy_data_to', self.ptr, data_ptr)
        return data

    def set_origin(self, origin):

        origin_x = ctypes.c_double(origin[0])
        origin_y = ctypes.c_double(origin[1])
        origin_z = ctypes.c_double(origin[2])

        call_func('image3d_set_origin', self.ptr, origin_x, origin_y, origin_z)

    def set_spacing(self, spacing):

        spacing_x = ctypes.c_double(spacing[0])
        spacing_y = ctypes.c_double(spacing[1])
        spacing_z = ctypes.c_double(spacing[2])

        call_func('image3d_set_spacing', self.ptr, spacing_x, spacing_y, spacing_z)

    def set_axes(self, axes):

        assert isinstance(axes, np.ndarray) and axes.shape == (3, 3)
        axes_buffer = np.ascontiguousarray(axes, dtype=np.double)
        axes_ptr = axes_buffer.ctypes.data_as(ctypes.POINTER(ctypes.c_double))
        call_func('image3d_set_axes', self.ptr, axes_ptr)

    def set_frame(self, frame):

        assert isinstance(frame, frame3d.Frame3d)
        call_func('image3d_set_frame', self.ptr, frame.ptr)

    def reset(self):
        call_func('image3d_clear_state', self.ptr)

    def world_to_voxel(self, world):

        world = np.array(world)
        if world.ndim == 1:
            num = 1
        elif world.ndim == 2:
            num = len(world)
        else:
            raise ValueError('incorrect dimension of world')

        world_buffer = np.ascontiguousarray(world, dtype=np.double)
        world_ptr = world_buffer.ctypes.data_as(ctypes.POINTER(ctypes.c_double))

        voxel = np.empty((num, 3), dtype=np.double)
        voxel_ptr = voxel.ctypes.data_as(ctypes.POINTER(ctypes.c_double))

        num = ctypes.c_int32(num)
        call_func('image3d_world_to_voxel', self.ptr, world_ptr, num, voxel_ptr)

        if world.ndim == 1:
            return voxel[0]
        elif world.ndim == 2:
            return voxel
        else:
            raise ValueError('incorrect dimension of world')

    def voxel_to_world(self, voxel):

        voxel = np.array(voxel)
        if voxel.ndim == 1:
            num = 1
        elif voxel.ndim == 2:
            num = len(voxel)
        else:
            raise ValueError('incorrect dimension of voxel')

        voxel_buffer = np.ascontiguousarray(voxel, dtype=np.double)
        voxel_ptr = voxel_buffer.ctypes.data_as(ctypes.POINTER(ctypes.c_double))

        world = np.empty((num, 3), dtype=np.double)
        world_ptr = world.ctypes.data_as(ctypes.POINTER(ctypes.c_double))

        num = ctypes.c_int32(num)
        call_func('image3d_voxel_to_world', self.ptr, voxel_ptr, num, world_ptr)

        if voxel.ndim == 1:
            return world[0]
        elif voxel.ndim == 2:
            return world
        else:
            raise ValueError('incorrect dimension of voxel')

    def bytes(self):
        return call_func('image3d_bytes', self.ptr)

    def write_to_buffer(self, out_ptr):
        return call_func('image3d_write_to_buffer', self.ptr, out_ptr)

    def read_from_buffer(self, in_ptr):
        return call_func('image3d_read_from_buffer', self.ptr, in_ptr)

    def world_box(self):

        imsize = self.size()

        coords = []
        coords.append([0, 0, 0])
        coords.append([imsize[0]-1, 0, 0])
        coords.append([0, imsize[1]-1, 0])
        coords.append([0, 0, imsize[2]-1])
        coords.append([imsize[0]-1, imsize[1]-1, 0])
        coords.append([imsize[0]-1, 0, imsize[2]-1])
        coords.append([0, imsize[1]-1, imsize[2]-1])
        coords.append([imsize[0]-1, imsize[1]-1, imsize[2]-1])

        coords = np.array(coords, dtype=np.double)
        for i in range(len(coords)):
            coords[i] = self.voxel_to_world(coords[i])

        min_coord = np.min(coords, axis=0)
        max_coord = np.max(coords, axis=0)

        return min_coord, max_coord

    def set_zeros(self):
        call_func('image3d_set_zeros', self.ptr)


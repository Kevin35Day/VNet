"""
python wrapper for frame3d library

this file includes

fun_dict:   a dictionary contains function pointers
frame3d:    an frame3d class

"""

import ctypes
import _ctypes
import numpy as np
import platform
from md.utils.python.find_dll import find_dll

# dll library
lib = None

# function pointer dictionary
fun_dict = {}


def __get_library_path():

    dll_file = find_dll('pyframe3d')
    if dll_file is None:
        raise OSError('dll not found')
    return dll_file


def __load_c_functions():

    global lib, fun_dict

    lib = ctypes.cdll.LoadLibrary(__get_library_path())

    lib.frame3d_create.argtypes = []
    lib.frame3d_create.restype = ctypes.c_void_p
    fun_dict['frame3d_create'] = lib.frame3d_create

    lib.frame3d_delete.argtypes = [ctypes.c_void_p]
    lib.frame3d_delete.restype = None
    fun_dict['frame3d_delete'] = lib.frame3d_delete

    lib.frame3d_deepcopy.argtypes = [ctypes.c_void_p]
    lib.frame3d_deepcopy.restype = ctypes.c_void_p
    fun_dict['frame3d_deepcopy'] = lib.frame3d_deepcopy

    lib.frame3d_restore_default.argtypes = [ctypes.c_void_p]
    lib.frame3d_restore_default.restype = None
    fun_dict['frame3d_restore_default'] = lib.frame3d_restore_default

    lib.frame3d_origin.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    lib.frame3d_origin.restype = None
    fun_dict['frame3d_origin'] = lib.frame3d_origin

    lib.frame3d_spacing.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    lib.frame3d_spacing.restype = None
    fun_dict['frame3d_spacing'] = lib.frame3d_spacing

    lib.frame3d_axis.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_void_p]
    lib.frame3d_axis.restype = None
    fun_dict['frame3d_axis'] = lib.frame3d_axis

    lib.frame3d_axes.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    lib.frame3d_axes.restype = None
    fun_dict['frame3d_axes'] = lib.frame3d_axes

    lib.frame3d_set_origin.argtypes = [ctypes.c_void_p, ctypes.c_double, ctypes.c_double, ctypes.c_double]
    lib.frame3d_set_origin.restype = None
    fun_dict['frame3d_set_origin'] = lib.frame3d_set_origin

    lib.frame3d_set_spacing.argtypes = [ctypes.c_void_p, ctypes.c_double, ctypes.c_double, ctypes.c_double]
    lib.frame3d_set_spacing.restype = None
    fun_dict['frame3d_set_spacing'] = lib.frame3d_set_spacing

    lib.frame3d_set_axis.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_double, ctypes.c_double, ctypes.c_double]
    lib.frame3d_set_axis.restype = None
    fun_dict['frame3d_set_axis'] = lib.frame3d_set_axis

    lib.frame3d_set_axes.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    lib.frame3d_set_axes.restype = None
    fun_dict['frame3d_set_axes'] = lib.frame3d_set_axes

    lib.frame3d_world_to_voxel.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int32, ctypes.c_void_p]
    lib.frame3d_world_to_voxel.restype = None
    fun_dict['frame3d_world_to_voxel'] = lib.frame3d_world_to_voxel

    lib.frame3d_voxel_to_world.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int32, ctypes.c_void_p]
    lib.frame3d_voxel_to_world.restype = None
    fun_dict['frame3d_voxel_to_world'] = lib.frame3d_voxel_to_world

    lib.frame3d_bytes.argtypes = [ctypes.c_void_p]
    lib.frame3d_bytes.restype = ctypes.c_size_t
    fun_dict['frame3d_bytes'] = lib.frame3d_bytes

    lib.frame3d_write_to_buffer.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    lib.frame3d_write_to_buffer.restype = ctypes.c_bool
    fun_dict['frame3d_write_to_buffer'] = lib.frame3d_write_to_buffer

    lib.frame3d_read_from_buffer.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    lib.frame3d_read_from_buffer.restype = ctypes.c_bool
    fun_dict['frame3d_read_from_buffer'] = lib.frame3d_read_from_buffer


def unload():

    global lib, fun_dict

    try:
        while lib is not None:
            if platform.system() == 'Windows':
                _ctypes.FreeLibrary(lib._handle)
            else:
                _ctypes.dlclose(lib._handle)
    except:
        lib = None
        fun_dict = {}


def load():

    unload()
    __load_c_functions()


# load dynamic library and function pointers
load()


def load_c_functions_if_necesary():

    if len(fun_dict) == 0:
        print '[info] pyframe3d dll reloaded'
        __load_c_functions()


def call_func(func_name, *args):

    load_c_functions_if_necesary()

    if len(args) == 0:
        return fun_dict[func_name]()
    else:
        return fun_dict[func_name](*args)


class Frame3d(object):
    """ Frame3d class python wrapper """

    def __init__(self, *args, **kwargs):

        if len(args) == 0 and len(kwargs) == 0:
            self.ptr = call_func('frame3d_create')

        elif len(args) > 0:
            assert len(args) == 1, 'positional argument must be only a raw ptr'
            self.ptr = args[0]

        else:
            raise ValueError('Frame3d accepts at most 1 argument')

    def __del__(self):

        call_func('frame3d_delete', self.ptr)
        self.ptr = None

    def __str__(self):

        origin = self.origin()
        spacing = self.spacing()
        axes = self.axes()

        out_str = 'origin : {}\n'.format(origin)
        out_str += 'spacing: {}\n'.format(spacing)
        out_str += 'axis_x : {}\n'.format(axes[0])
        out_str += 'axis_y : {}\n'.format(axes[1])
        out_str += 'axis_z : {}\n'.format(axes[2])
        return out_str

    def deep_copy(self):

        ptr = call_func('frame3d_deepcopy', self.ptr)
        return Frame3d(ptr)

    def restore_default(self):
        call_func('frame3d_restore_default', self.ptr)

    def origin(self):
        origin = np.empty((3,), dtype=np.double)
        origin_ptr = origin.ctypes.data_as(ctypes.POINTER(ctypes.c_double))
        call_func('frame3d_origin', self.ptr, origin_ptr)
        return origin

    def spacing(self):
        spacing = np.empty((3,), dtype=np.double)
        spacing_ptr = spacing.ctypes.data_as(ctypes.POINTER(ctypes.c_double))
        call_func('frame3d_spacing', self.ptr, spacing_ptr)
        return spacing

    def axis(self, idx):
        axis = np.empty((3,), dtype=np.double)
        axis_ptr = axis.ctypes.data_as(ctypes.POINTER(ctypes.c_double))
        idx = ctypes.c_size_t(idx)
        call_func('frame3d_axis', self.ptr, idx, axis_ptr)
        return axis

    def axes(self):
        axes = np.empty((3, 3), dtype=np.double)
        axes_ptr = axes.ctypes.data_as(ctypes.POINTER(ctypes.c_double))
        call_func('frame3d_axes', self.ptr, axes_ptr)
        return axes

    def set_origin(self, origin):
        x = ctypes.c_double(origin[0])
        y = ctypes.c_double(origin[1])
        z = ctypes.c_double(origin[2])
        call_func('frame3d_set_origin', self.ptr, x, y, z)

    def set_spacing(self, spacing):
        x = ctypes.c_double(spacing[0])
        y = ctypes.c_double(spacing[1])
        z = ctypes.c_double(spacing[2])
        call_func('frame3d_set_spacing', self.ptr, x, y, z)

    def set_axis(self, axis, idx):
        idx = ctypes.c_size_t(idx)
        x = ctypes.c_double(axis[0])
        y = ctypes.c_double(axis[1])
        z = ctypes.c_double(axis[2])
        call_func('frame3d_set_axis', self.ptr, idx, x, y, z)

    def set_axes(self, axes):
        axes = np.ascontiguousarray(axes, dtype=np.double)
        axes_ptr = axes.ctypes.data_as(ctypes.POINTER(ctypes.c_double))
        call_func('frame3d_set_axes', self.ptr, axes_ptr)

    def world_to_voxel(self, world):

        world = np.array(world)
        if world.ndim == 1:
            num = 1
        elif world.ndim == 2:
            num = len(world)
        else:
            raise ValueError('incorrect dimension of world')

        world = np.ascontiguousarray(world, dtype=np.double)
        world_ptr = world.ctypes.data_as(ctypes.POINTER(ctypes.c_double))

        voxel = np.empty((num, 3), dtype=np.double)
        voxel_ptr = voxel.ctypes.data_as(ctypes.POINTER(ctypes.c_double))

        num = ctypes.c_int32(num)
        call_func('frame3d_world_to_voxel', self.ptr, world_ptr, num, voxel_ptr)

        if world.ndim == 1:
            return voxel[0]
        elif world.ndim == 2:
            return voxel
        else:
            raise ValueError('incorrect dimension of world')

    def voxel_to_world(self, voxel):

        voxel = np.array(voxel)
        if voxel.ndim == 1:
            num = 1
        elif voxel.ndim == 2:
            num = len(voxel)
        else:
            raise ValueError('incorrect dimension of voxel')

        voxel = np.ascontiguousarray(voxel, dtype=np.double)
        voxel_ptr = voxel.ctypes.data_as(ctypes.POINTER(ctypes.c_double))

        world = np.empty((num, 3), dtype=np.double)
        world_ptr = world.ctypes.data_as(ctypes.POINTER(ctypes.c_double))

        num = ctypes.c_int32(num)
        call_func('frame3d_voxel_to_world', self.ptr, voxel_ptr, num, world_ptr)

        if voxel.ndim == 1:
            return world[0]
        elif voxel.ndim == 2:
            return world
        else:
            raise ValueError('incorrect dimension of voxel')

    def to_numpy(self):

        origin = np.expand_dims(self.origin(), 0)
        spacing = np.expand_dims(self.spacing(), 0)
        axes = self.axes()
        out = np.concatenate((origin, spacing, axes), 0)
        return out

    def from_numpy(self, in_data):

        self.set_origin(in_data[0])
        self.set_spacing(in_data[1])
        self.set_axes(in_data[2:])

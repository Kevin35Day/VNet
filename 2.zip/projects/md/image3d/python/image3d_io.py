"""
python wrapper for image3d_io library

this file includes:

read_image
write_image

"""

import ctypes
import _ctypes
from md.utils.python.find_dll import find_dll
import platform
from md.image3d.python.image3d import Image3d
from md.image3d.python.frame3d import Frame3d
from medtypes import type_to_value
import numpy as np
import os
import dicom
from skimage.draw import line_aa
from scipy.ndimage.morphology import binary_fill_holes

# dynamic library
lib = None

# function pointer dictionary
fun_dict = {}


def __get_library_path():

    dll_file = find_dll('pyimage3d_io')
    if dll_file is None:
        raise OSError('dll not found')
    return dll_file


def __load_c_functions():

    global lib, fun_dict

    lib = ctypes.cdll.LoadLibrary(__get_library_path())

    lib.image3d_read.argtypes = [ctypes.c_char_p, ctypes.c_int32]
    lib.image3d_read.restype = ctypes.c_void_p
    fun_dict['image3d_read'] = lib.image3d_read

    lib.image3d_read_frame_and_size.argtypes = [ctypes.c_char_p, ctypes.c_void_p]
    lib.image3d_read_frame_and_size.restype = ctypes.c_void_p
    fun_dict['image3d_read_frame_and_size'] = lib.image3d_read_frame_and_size

    lib.image3d_write.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_int32, ctypes.c_bool]
    lib.image3d_write.restype = ctypes.c_bool
    fun_dict['image3d_write'] = lib.image3d_write

    lib.image3d_get_dicom_series.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
    lib.image3d_get_dicom_series.restype = ctypes.c_char_p
    fun_dict['image3d_get_dicom_series'] = lib.image3d_get_dicom_series

    lib.image3d_read_dicom_series.argtypes = [ctypes.c_char_p, ctypes.c_int32, ctypes.c_char_p,
                                              ctypes.c_char_p, ctypes.POINTER(ctypes.c_char_p)]
    lib.image3d_read_dicom_series.restype = ctypes.c_void_p
    fun_dict['image3d_read_dicom_series'] = lib.image3d_read_dicom_series

    lib.image3d_write_dicom_series.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_int32, ctypes.c_char_p]
    lib.image3d_write_dicom_series.restype = ctypes.c_bool
    fun_dict['image3d_write_dicom_series'] = lib.image3d_write_dicom_series


def unload():

    global lib, fun_dict

    try:
        while lib is not None:
            if platform.system() == 'Windows':
                _ctypes.FreeLibrary(lib._handle)
            else:
                _ctypes.dlclose(lib._handle)
    except:
        lib = None
        fun_dict = {}


def load():

    unload()
    __load_c_functions()


# load dynamic library and function pointers
load()


def load_c_functions_if_necesary():

    if len(fun_dict) == 0:
        print '[info] pyimage3d_io dll reloaded'
        __load_c_functions()


def call_func(func_name, *args):

    load_c_functions_if_necesary()

    if len(args) == 0:
        return fun_dict[func_name]()
    else:
        return fun_dict[func_name](*args)


def read_image(filename, dtype=None):
    """
    read a 3D volume from disk with the specified output type
    :param filename: image filename
    :param dtype: desired output pixel type
    :return: an image3d object
    """
    type_value = ctypes.c_int32(0) if dtype is None else type_to_value[dtype]

    ptr = call_func('image3d_read', filename, type_value)
    if ptr is None:
        raise IOError('fail to read image from disk')

    return Image3d(ptr)


def read_frame_and_size(filename):
    """
    read frame and size from image on disk
    :param filename: image filename
    :return: frame, size
    """
    size = np.empty((3,), dtype=np.int32)
    size_ptr = size.ctypes.data_as(ctypes.POINTER(ctypes.c_int32))

    ptr = call_func('image3d_read_frame_and_size', filename, size_ptr)
    return Frame3d(ptr), size


def write_image(image, filename, dtype=None, compression=False):
    """
    write a 3D volume to disk with the specified output type
    :param image: an image3d object
    :param filename: image filename
    :param dtype: desired output pixel type
    :param compression:
    :return: boolean true for success, false for failure
    """
    type_value = ctypes.c_int32(0) if dtype is None else type_to_value[dtype]

    success = call_func('image3d_write', image.ptr, filename, type_value, compression)
    return success


def get_dicom_series(directory, restrictions=None):
    """
    get dicom series names from directory
    :param directory        the dicom directory
    :param restrictions     the restrictions
    :return: a list of dicom series
    """
    if not os.path.isdir(directory):
        raise OSError('input dicom directory does not exist')

    if restrictions is None:
        restrictions = ctypes.c_char_p(0)

    out = call_func('image3d_get_dicom_series', directory, restrictions)
    if len(out) == 0:
        return []
    else:
        return out.split(';')


def read_dicom_series(directory, dtype=None, series_name=None, restrictions=None):
    """
    read dicom series from directory
    :param directory:       dicom directory
    :param dtype:           output pixel type. None if using pixel type in file
    :param series_name:     the name of dicom series to read
    :param restrictions:    the restriction string containing first the group then the element of DICOM tag, e.g., "0008|0021"
    :return: an image3d object, dicom tags
    """
    if not os.path.isdir(directory):
        raise OSError('input dicom directory does not exist')

    type_value = ctypes.c_int32(0) if dtype is None else type_to_value[dtype]

    if series_name is None:
        series_name = ctypes.c_char_p(0)

    if restrictions is None:
        restrictions = ctypes.c_char_p(0)

    tags_str = ctypes.c_char_p(0)
    ptr = call_func('image3d_read_dicom_series', directory, type_value, series_name, restrictions, ctypes.byref(tags_str))
    if ptr is None:
        raise IOError('fail to read image from disk')

    tags = {}
    for token in tags_str.value.split(';'):
        if len(token) == 0:
            continue
        tag, value = token.split('#')
        tags[tag] = value

    return Image3d(ptr), tags


def write_dicom_series(image, directory, dtype=None, tags=None):
    """
    write image3d to dicom series
    :param image:           image3d object
    :param directory:       dicom directory
    :param dtype:           output pixel type. None if using pixel type of input
    :param tags:            dictionary of dicom tags, meta information
    :return: True if write successful, False if write unsuccessful
    """
    assert isinstance(image, Image3d)

    if not os.path.isdir(directory):
        os.makedirs(directory)

    type_value = ctypes.c_int32(0) if dtype is None else type_to_value[dtype]

    if tags is None:
        tags_str = ctypes.c_char_p(0)
    else:
        assert isinstance(tags, dict)
        tags_str = ''
        for tag, value in tags.iteritems():
            tags_str += '{}#{};'.format(tag, value)

    success = call_func('image3d_write_dicom_series', image.ptr, directory, type_value, tags_str)
    return success


def read_dicom_rt_contours(directory, names=None):
    """
    read rt contours from directory
    :param directory: dicom directory
    :param names: the contour names. None if read all rt contours
    :return: a list of image3d binary masks
    """
    if not os.path.isdir(directory):
        raise OSError('No such directory!')

    # rt struct dcm file
    rtstruct_dcm = None

    # all series uids in directory
    series_uids = get_dicom_series(directory)

    # frame uid to series uid mapping
    frameuid_to_seriesuid = {}

    # Iterate all dcm files to
    # 1) find RTSTRUCT file
    # 2) find SeriesI
    for dcm_file in os.listdir(directory):
        dcm_path = os.path.join(directory, dcm_file)
        try:
            rt = dicom.read_file(dcm_path)
        except:
            continue

        if rt.Modality != 'RTSTRUCT':
            # if dcm is not RTSTRUCT, record 1) FrameOfReferenceUID and 2) SeriesInstanceUID
            if len(rt.FrameOfReferenceUID) != 0 and (rt.FrameOfReferenceUID not in frameuid_to_seriesuid):
                for series_uid in series_uids:
                   if series_uid.startswith(rt.SeriesInstanceUID):
                       frameuid_to_seriesuid[rt.FrameOfReferenceUID] = series_uid
                       break
                if rt.FrameOfReferenceUID not in frameuid_to_seriesuid:
                    raise ValueError('SeriesUID associated with FrameUID {} not found'.format(rt.FrameOfReferenceUID))
        else:
            # if there are multiple rtstruct in folder, return error
            if rtstruct_dcm is not None:
                raise ValueError('Multiple RTSTRUCT in folders?')

            rtstruct_dcm = dcm_path

    # if RTSTRUCT not found
    if rtstruct_dcm is None:
        raise OSError('No RTSTRUCT DCM found in the directory: {}'.format(directory))

    # read RTSTRUCT file
    rt = dicom.read_file(rtstruct_dcm)

    # indexed by ROINumber, contains ROIName and ROIRefFrameUID
    roi_info = {}

    # index by FrameUID, contains image3d
    ref_ims = {}

    for roi in rt.StructureSetROISequence:
        roi_number = roi.ROINumber
        if names is not None and roi.ROIName not in names:
            continue
        roi_info[roi_number] = {}
        roi_info[roi_number]['ROIName'] = roi.ROIName
        roi_info[roi_number]['ROIRefFrameUID'] = roi.ReferencedFrameOfReferenceUID
        ref_ims[roi.ReferencedFrameOfReferenceUID] = None

    # load referenced dicom series
    for frame_uid, _ in ref_ims.iteritems():
        if frame_uid not in frameuid_to_seriesuid:
            raise OSError('ReferencedFrameOfReferenceUID {} not found'.format(frame_uid))
        series_name = frameuid_to_seriesuid[frame_uid]
        ref_ims[frame_uid], _ = read_dicom_series(directory, series_name=series_name)

    # binary ROI segmentation masks, one for each ROI.
    roi_masks = {}
    for roi in rt.ROIContourSequence:
        roi_number = roi.ReferencedROINumber
        roi_name = roi_info[roi_number]['ROIName']

        print 'Processing ROI {}'.format(roi_name)

        # get reference image
        if not roi_number in roi_info:
            raise ValueError('ROI Number {} not found'.format(roi_number))

        ref_frame_uid = roi_info[roi_number]['ROIRefFrameUID']
        ref_im = ref_ims[ref_frame_uid]
        assert isinstance(ref_im, Image3d)

        imsize = ref_im.size()
        mask = np.zeros((imsize[2], imsize[1], imsize[0]), dtype=np.uint8)

        # for each slice contour
        for contour in roi.ContourSequence:

            if contour.ContourGeometricType != 'CLOSED_PLANAR':
                raise ValueError('Contour type not supported: {}'.format(contour.ContourGemetricType))

            num_pts = int(contour.NumberOfContourPoints)
            pts = contour.ContourData
            assert len(pts) == num_pts * 3, 'inconsistent number of contour points'
            if num_pts == 0:
                continue

            # get voxel coordinates of all points
            pts = np.reshape([float(v) for v in pts], (num_pts, 3))
            pts = ref_im.world_to_voxel(pts)
            pts = np.round(pts).astype(np.int)

            # check whether all points on the same slice
            slice_idx = pts[0, 2]
            if np.any(pts[:, 2] != slice_idx):
                raise ValueError('Not all points on the same slice (Contour {})'.format(contour.ContourNumber))

            # slice mask
            slice_mask = np.zeros((imsize[1], imsize[0]), dtype=np.uint8)

            # draw closed contour
            for i in range(num_pts):
                pt = pts[i, :2]
                prev = pts[num_pts-1, :2] if i == 0 else pts[i-1, :2]
                rr, cc, _ = line_aa(prev[1], prev[0], pt[1], pt[0])
                rr[rr>=imsize[1]] = imsize[1]-1
                cc[cc>=imsize[0]] = imsize[0]-1
                slice_mask[rr, cc] = 1

            # fill holes
            slice_mask = binary_fill_holes(slice_mask).astype(np.uint8)
            mask[slice_idx, slice_mask > 0] = np.logical_not(mask[slice_idx, slice_mask > 0]).astype(np.uint8)

        roi_mask = Image3d()
        roi_mask.from_numpy(mask, dtype=np.uint8)
        roi_mask.set_frame(ref_im.frame())
        roi_masks[roi_name] = roi_mask

    return roi_masks


def dicom_tags_dict(
        modality='CT',
        image_type=r'DERIVED\\SECONDARY',
        conversion_type='DV',
        patient_position='HFS',
        series_description='UIH-AI',
        study_description='RTSeg',
        patient_name='Anonymous',
        patient_id='20171230',
        patient_age='99',
        rescale_type='HU',
        rescale_slope='1',
        rescale_intercept='0'):

    tags = {}
    tags['0008|0060'] = modality
    tags['0008|0008'] = image_type
    tags['0008|0064'] = conversion_type
    tags['0008|103E'] = series_description
    tags['0008|1030'] = study_description
    tags['0018|5100'] = patient_position
    tags['0010|0010'] = patient_name
    tags['0010|0020'] = patient_id
    tags['0010|1010'] = patient_age
    tags['0028|1052'] = rescale_intercept
    tags['0028|1053'] = rescale_slope
    tags['0028|1054'] = rescale_type

    return tags


if __name__ == '__main__':

    import md
    masks = md.read_dicom_rt_contours('/home/ubuntu2/data/dcm-contour')

    out_dir = '/home/ubuntu2/Desktop'
    for name, mask in masks.iteritems():
        name = name.replace(' ', '_')
        out_path = os.path.join(out_dir, '{}.nii.gz'.format(name))
        md.write_image(mask, out_path)


"""
functions to image3d filtering

this file includes

lib:        a library object that contains library handle
fun_dict:   a dictionary contains function pointers
load:       load existing dynamic library
unload:     release loaded dynamic library

"""

import ctypes
import _ctypes
import platform
import numpy as np
from md.image3d.python.image3d import Image3d
from md.utils.python.find_dll import find_dll


# dynamic library
lib = None

# function pointer dictionary
fun_dict = {}


def __get_library_path():

    dll_file = find_dll('pyimage3d_filter')
    if dll_file is None:
        raise OSError('dll not found')
    return dll_file


def __load_c_functions():

    global lib, fun_dict

    lib = ctypes.cdll.LoadLibrary(__get_library_path())

    lib.image3d_imfilt.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p]
    lib.image3d_imfilt.restype = None
    fun_dict['image3d_imfilt'] = lib.image3d_imfilt


def unload():

    global lib, fun_dict

    try:
        while lib is not None:
            if platform.system() == 'Windows':
                _ctypes.FreeLibrary(lib._handle)
            else:
                _ctypes.dlclose(lib._handle)
    except:
        lib = None
        fun_dict = {}


def load():

    unload()
    __load_c_functions()


# load dynamic library
load()


def load_c_functions_if_necesary():

    if len(fun_dict) == 0:
        print '[info] pyimage3d_filter dll reloaded'
        __load_c_functions()


def call_func(func_name, *args):

    load_c_functions_if_necesary()

    if len(args) == 0:
        return fun_dict[func_name]()
    else:
        return fun_dict[func_name](*args)


def imfilt(image, filter):
    """
    image filtering
    :param image: an image3d object
    :param filter: 3d filter
    :return: None
    """
    assert isinstance(image, Image3d)
    # assert len(fsize) == 3

    filter = np.array(filter, dtype=np.double)
    filter = np.ascontiguousarray(filter, dtype=np.double)
    filter_ptr = filter.ctypes.data_as(ctypes.POINTER(ctypes.c_double))

    size = filter.shape
    size = np.ascontiguousarray(size, dtype=np.int32)
    size_ptr = size.ctypes.data_as(ctypes.POINTER(ctypes.c_int32))

    call_func('image3d_imfilt', image.ptr, filter_ptr, size_ptr)

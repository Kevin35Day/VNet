#include "image3d/csrc/frame3d.h"

namespace medvision {

Frame3d::Frame3d()
{
    restore_default();
}

Frame3d::Frame3d(const Frame3d& arg)
{
    m_origin = arg.get_origin();
    m_spacing = arg.get_spacing();
    m_axes[0] = arg.get_axis(0);
    m_axes[1] = arg.get_axis(1);
    m_axes[2] = arg.get_axis(2);
}

void Frame3d::restore_default()
{
    m_origin = vec3d<double>(0, 0, 0);
    m_spacing = vec3d<double>(1, 1, 1);
    m_axes[0] = vec3d<double>(1, 0, 0);
    m_axes[1] = vec3d<double>(0, 1, 0);
    m_axes[2] = vec3d<double>(0, 0, 1);
}

vec3d<double> Frame3d::get_origin() const
{
    return m_origin;
}

vec3d<double> Frame3d::get_spacing() const
{
    return m_spacing;
}

vec3d<double> Frame3d::get_axis(size_t i) const
{
    if(i > 2)
        throw std::out_of_range("index out of bound");
    return m_axes[i];
}

void Frame3d::set_origin(const vec3d<double>& origin)
{
    m_origin = origin;
}

void Frame3d::set_spacing(const vec3d<double>& spacing)
{
    m_spacing = spacing;
}

void Frame3d::set_axis(const vec3d<double>& axis, size_t idx)
{
    if(idx > 2)
        throw std::out_of_range("index out of bound");
    m_axes[idx] = axis;
}

vec3d<double> Frame3d::world_to_voxel(const vec3d<double>& world) const
{
    vec3d<double> ret;
    for(int i = 0; i < 3; ++i)
        ret[i] = vec3d<double>::dot_prod(world - m_origin, m_axes[i]) / m_spacing[i];
    return ret;
}

vec3d<double> Frame3d::voxel_to_world(const vec3d<double>& voxel) const
{
    vec3d<double> ret = m_origin;
    for(int i = 0; i < 3; ++i)
        ret += m_axes[i] * (voxel[i] * m_spacing[i]);
    return ret;
}

void Frame3d::serialize(std::ostream& out) const
{
    m_origin.serialize(out);
    m_spacing.serialize(out);
    for(int i = 0; i < 3; ++i)
        m_axes[i].serialize(out);
}

void Frame3d::deserialize(std::istream& in)
{
    m_origin.deserialize(in);
    m_spacing.deserialize(in);
    for(int i = 0; i < 3; ++i)
        m_axes[i].deserialize(in);
}

size_t Frame3d::bytes() const
{
    return sizeof(double) * 15;
}

bool Frame3d::write_to_buffer(void* data) const
{
    char* out_buffer = static_cast<char*>(data);

    size_t buffer_size = 0;
    memcpy(out_buffer + buffer_size, m_origin.m_data, sizeof(double) * 3);
    buffer_size += sizeof(double) * 3;

    memcpy(out_buffer + buffer_size, m_spacing.m_data, sizeof(double) * 3);
    buffer_size += sizeof(double) * 3;

    memcpy(out_buffer + buffer_size, m_axes[0].m_data, sizeof(double) * 3);
    buffer_size += sizeof(double) * 3;

    memcpy(out_buffer + buffer_size, m_axes[1].m_data, sizeof(double) * 3);
    buffer_size += sizeof(double) * 3;

    memcpy(out_buffer + buffer_size, m_axes[2].m_data, sizeof(double) * 3);
    buffer_size += sizeof(double) * 3;

    return true;
}

bool Frame3d::read_from_buffer(void* data)
{
    const char* in_buffer = static_cast<char*>(data);

    size_t buffer_size = 0;
    memcpy(m_origin.m_data, in_buffer + buffer_size, sizeof(double) * 3);
    buffer_size += sizeof(double) * 3;

    memcpy(m_spacing.m_data, in_buffer + buffer_size, sizeof(double) * 3);
    buffer_size += sizeof(double) * 3;

    memcpy(m_axes[0].m_data, in_buffer + buffer_size, sizeof(double) * 3);
    buffer_size += sizeof(double) * 3;

    memcpy(m_axes[1].m_data, in_buffer + buffer_size, sizeof(double) * 3);
    buffer_size += sizeof(double) * 3;

    memcpy(m_axes[2].m_data, in_buffer + buffer_size, sizeof(double) * 3);
    buffer_size += sizeof(double) * 3;

    return true;
}

Frame3d& Frame3d::operator=(const Frame3d& rhs)
{
    if(this == &rhs)
        return *this;

    m_origin = rhs.get_origin();
    m_spacing = rhs.get_spacing();
    m_axes[0] = rhs.get_axis(0);
    m_axes[1] = rhs.get_axis(1);
    m_axes[2] = rhs.get_axis(2);

    return *this;
}

} // end namespace medvision

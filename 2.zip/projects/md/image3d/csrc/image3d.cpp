#include "image3d/csrc/image3d.h"
#include "image3d/csrc/image3d_tools.h"
#include "utils/csrc/template_macros.h"
#include <stdexcept>
#include <cstring>

namespace medvision {

//PT_UNKNOWN = 0, PT_UCHAR, PT_CHAR, PT_USHORT, PT_SHORT, PT_UINT, PT_INT, PT_ULONG, PT_LONG, PT_FLOAT, PT_DOUBLE

const char* ptype_to_str(PixelType ptype)
{
    switch (ptype) {
    case PT_UNKNOWN: return "PT_UNKNOWN";
    case PT_UCHAR: return "PT_UCHAR";
    case PT_CHAR: return "PT_CHAR";
    case PT_USHORT: return "PT_USHORT";
    case PT_SHORT: return "PT_SHORT";
    case PT_UINT: return "PT_UINT";
    case PT_INT: return "PT_INT";
    case PT_ULONG: return "PT_ULONG";
    case PT_LONG: return "PT_LONG";
    case PT_FLOAT: return "PT_FLOAT";
    case PT_DOUBLE: return "PT_DOUBLE";
    default: return "PT_ERROR";
    }
}


size_t Image3d::pixel_size() const
{
    switch (m_pixel_type) {
    case PT_CHAR:   return sizeof(char);
    case PT_UCHAR:  return sizeof(unsigned char);
    case PT_SHORT:  return sizeof(short);
    case PT_USHORT: return sizeof(unsigned short);
    case PT_INT:    return sizeof(int);
    case PT_UINT:   return sizeof(unsigned int);
    case PT_LONG:   return sizeof(long);
    case PT_ULONG:  return sizeof(unsigned long);
    case PT_FLOAT:  return sizeof(float);
    case PT_DOUBLE: return sizeof(double);
    default: throw std::invalid_argument("invalid pixel type");
    }
}

void Image3d::update_buffer()
{
    if(m_size[0] < 0 || m_size[1] < 0 || m_size[2] < 0)
        throw std::runtime_error("allocate error: negative image size");

    if(m_data != nullptr && m_managed) {
        free(m_data);
        m_data = nullptr;
    }

    if(m_size[0] == 0 || m_size[1] == 0 || m_size[2] == 0)
        return;

    size_t width = static_cast<size_t>(m_size[0]);
    size_t height = static_cast<size_t>(m_size[1]);
    size_t depth = static_cast<size_t>(m_size[2]);

    size_t buffer_size = pixel_size() * width * height * depth;
    m_data = malloc(buffer_size);
    if(m_data == nullptr) {
        std::cerr << "[Error] memory allocation fails - try to allocate " <<
                     buffer_size / 1024.0 / 1024.0 << " Mbytes" << std::endl;
        throw std::bad_alloc();
    }

    m_managed = true;
}

void Image3d::clear_state()
{
    if(m_managed && m_data != nullptr) {
        free(m_data);
        m_data = nullptr;
    }

    m_managed = false;
    m_pixel_type = PT_SHORT;
    m_frame.restore_default();
    m_size = vec3d<int>(0, 0, 0);
    m_data = nullptr;
}

// constructors

Image3d::Image3d(): m_managed(false), m_data(nullptr), m_pixel_type(PT_SHORT), m_size(0, 0, 0)
{
    m_frame.restore_default();
}

Image3d::Image3d(int width, int height, int depth, PixelType pixel_type)
{
    m_size = vec3d<int>(width, height, depth);
    m_pixel_type = pixel_type;
    m_frame.restore_default();
    m_data = nullptr;
    m_managed = false;

    update_buffer();
}

Image3d::Image3d(const Image3d& arg)
{
    m_size = arg.m_size;
    m_pixel_type = arg.pixel_type();
    m_frame = arg.m_frame;
    m_data = nullptr;
    m_managed = false;

    update_buffer();

    size_t width = m_size[0];
    size_t height = m_size[1];
    size_t depth = m_size[2];

    memcpy(m_data, arg.m_data, pixel_size() * width * height * depth);
}

Image3d::~Image3d()
{
    clear_state();
}

// setters

void Image3d::resize(int width, int height, int depth)
{
    if(width == m_size[0] && height == m_size[1] && depth == m_size[2])
        return;

    m_size = vec3d<int>(width, height, depth);
    update_buffer();
}

void Image3d::resize(const vec3d<int>& size)
{
    if(size == m_size)
        return;

    m_size = size;
    update_buffer();
}

void Image3d::allocate(int width, int height, int depth, PixelType pixel_type)
{
    if(width == m_size[0] && height == m_size[1] && depth == m_size[2] && m_pixel_type == pixel_type)
        return;

    m_size = vec3d<int>(width, height, depth);
    m_pixel_type = pixel_type;
    update_buffer();
}

void Image3d::allocate(const vec3d<int>& size, PixelType pixel_type)
{
    if(size == m_size && m_pixel_type == pixel_type)
        return;

    m_size = size;
    m_pixel_type = pixel_type;
    update_buffer();
}

bool Image3d::cast(PixelType pixel_type)
{
    if(pixel_type == m_pixel_type)
        return true;

    void* old_data = m_data;
    PixelType old_pixel_type = m_pixel_type;
    bool old_managed = m_managed;

    bool need_copy = false;
    if(m_data != nullptr)
        need_copy = true;

    m_managed = false;
    m_pixel_type = pixel_type;

    try{
        update_buffer();
    } catch(std::bad_alloc&) {
        // recover status before cast
        m_managed = old_managed;
        m_pixel_type = old_pixel_type;
        m_data = old_data;
        return false;
    }

    if(need_copy) {
        // copy data from old buffer to new one
        size_t width = static_cast<size_t>(m_size[0]);
        size_t height = static_cast<size_t>(m_size[1]);
        size_t depth = static_cast<size_t>(m_size[2]);
        size_t num_elems = width * height * depth;

        ptypecall_2(cast_copy, old_pixel_type, pixel_type, old_data, num_elems, m_data);
    }

    if(old_managed)
        free(old_data);

    return true;
}

void Image3d::cast_to(PixelType pixel_type, Image3d& out) const
{
    out.clear_state();
    out.set_frame(m_frame);
    out.allocate(m_size, pixel_type);
    ptypecall_2(cast_copy, m_pixel_type, pixel_type, m_data, m_size.self_prod<size_t>(), out.m_data);
}

void Image3d::set_data(void* data, int width, int height, int depth, PixelType pixel_type, bool managed)
{
    if(m_managed && m_data != nullptr) {
        free(m_data);
        m_data = nullptr;
    }

    m_data = data;
    m_size = vec3d<int>(width, height, depth);
    m_pixel_type = pixel_type;
    m_managed = managed;
}

void Image3d::set_data(void* data, const vec3d<int>& size, PixelType pixel_type, bool managed)
{
    set_data(data, size[0], size[1], size[2], pixel_type, managed);
}

void Image3d::copy_data(void* data, int width, int height, int depth, PixelType pixel_type)
{
    if(width == m_size[0] && height == m_size[1] && depth == m_size[2] && pixel_type == m_pixel_type)
    {
        size_t bytes = pixel_size() * static_cast<size_t>(width) * static_cast<size_t>(height) * static_cast<size_t>(depth);
        memcpy(m_data, data, bytes);
    }
    else
    {
        m_size = vec3d<int>(width, height, depth);
        m_pixel_type = pixel_type;
        update_buffer();

        size_t bytes = pixel_size() * static_cast<size_t>(width) * static_cast<size_t>(height) * static_cast<size_t>(depth);
        memcpy(m_data, data, bytes);
    }
}

void Image3d::copy_data_to(void* data) const
{
    size_t bytes = pixel_size() * static_cast<size_t>(m_size[0]) * static_cast<size_t>(m_size[1]) * static_cast<size_t>(m_size[2]);
    memcpy(data, m_data, bytes);
}

void Image3d::set_origin(double x, double y, double z)
{
    m_frame.set_origin(vec3d<double>(x, y, z));
}

void Image3d::set_origin(const vec3d<double>& origin)
{
    m_frame.set_origin(origin);
}

void Image3d::set_spacing(double x, double y, double z)
{
    m_frame.set_spacing(vec3d<double>(x, y, z));
}

void Image3d::set_spacing(const vec3d<double>& spacing)
{
    m_frame.set_spacing(spacing);
}

void Image3d::set_axes(const double* axes)
{
    m_frame.set_axis(vec3d<double>(axes[0], axes[1], axes[2]), 0);
    m_frame.set_axis(vec3d<double>(axes[3], axes[4], axes[5]), 1);
    m_frame.set_axis(vec3d<double>(axes[6], axes[7], axes[8]), 2);
}

void Image3d::set_axes(const vec3d<double>& x1, const vec3d<double>& x2, const vec3d<double>& x3)
{
    m_frame.set_axis(x1, 0);
    m_frame.set_axis(x2, 1);
    m_frame.set_axis(x3, 2);
}

void Image3d::set_frame(const Frame3d& frame)
{
    m_frame = frame;
}

vec3d<double> Image3d::world_to_voxel(const vec3d<double>& coord) const
{
    return m_frame.world_to_voxel(coord);
}

vec3d<double> Image3d::voxel_to_world(const vec3d<double>& coord) const
{
    return m_frame.voxel_to_world(coord);
}

void Image3d::world_box(vec3d<double>& min_coord, vec3d<double>& max_coord) const
{
    vec3d<double> voxels[8];
    voxels[0] = voxel_to_world(vec3d<double>(0,             0,              0));
    voxels[1] = voxel_to_world(vec3d<double>(m_size[0]-1,   0,              0));
    voxels[2] = voxel_to_world(vec3d<double>(0,             m_size[1]-1,    0));
    voxels[3] = voxel_to_world(vec3d<double>(0,             0,              m_size[2]-1));
    voxels[4] = voxel_to_world(vec3d<double>(m_size[0]-1,   m_size[1]-1,    0));
    voxels[5] = voxel_to_world(vec3d<double>(m_size[0]-1,   0,              m_size[2]-1));
    voxels[6] = voxel_to_world(vec3d<double>(0,             m_size[1]-1,    m_size[2]-1));
    voxels[7] = voxel_to_world(vec3d<double>(m_size[0]-1,   m_size[1]-1,    m_size[2]-1));

    min_coord[0] = min_coord[1] = min_coord[2] = std::numeric_limits<double>::max();
    max_coord[0] = max_coord[1] = max_coord[2] = std::numeric_limits<double>::lowest();

    for(int i = 0; i < 8; ++i) {
        for(int j = 0; j < 3; ++j) {
            min_coord[j] = std::min(min_coord[j], voxels[i][j]);
            max_coord[j] = std::max(max_coord[j], voxels[i][j]);
        }
    }
}

void Image3d::serialize(std::ostream& out) const
{
    // header version
    static const int header_size = 36;
    char header[header_size];
    memset(header, 0, header_size);
    const char* version_str = "Image3d_v1.0.0";
    strncpy(header, version_str, strlen(version_str));

    out.write(header, header_size);

    // image size
    m_size.serialize(out);

    // pixel type
    int pixel_type_int = static_cast<int>(m_pixel_type);
    out.write((const char*)(&pixel_type_int), sizeof(int));

    // frame
    m_frame.serialize(out);

    // data buffer
    const char* buffer_ptr = static_cast<const char*>(m_data);

    size_t width = static_cast<size_t>(m_size[0]);
    size_t height = static_cast<size_t>(m_size[1]);
    size_t depth = static_cast<size_t>(m_size[2]);
    size_t bytes = pixel_size() * width * height * depth;

    out.write(buffer_ptr, bytes);
}

void Image3d::deserialize(std::istream& in)
{
    clear_state();

    // header version
    static const int header_size = 36;
    char header[header_size];
    in.read(header, header_size);

    char expected_header[header_size];
    memset(expected_header, 0, header_size);
    const char* version_str = "Image3d_v1.0.0";
    strncpy(expected_header, version_str, strlen(version_str));

    if(strncmp(header, expected_header, header_size) != 0)
        throw std::runtime_error("unexpected image3d header");

    // image size
    m_size.deserialize(in);

    // pixel type
    int pixel_value_int = 0;
    in.read((char*)(&pixel_value_int), sizeof(int));
    m_pixel_type = static_cast<PixelType>(pixel_value_int);

    // frame
    m_frame.deserialize(in);

    // data
    size_t width = static_cast<size_t>(m_size[0]);
    size_t height = static_cast<size_t>(m_size[1]);
    size_t depth = static_cast<size_t>(m_size[2]);
    size_t bytes = pixel_size() * width * height * depth;

    m_data = malloc(bytes);
    in.read(static_cast<char*>(m_data), bytes);

    // set managed to true
    m_managed = true;
}

size_t Image3d::bytes() const
{
    // header size
    size_t total = 36;

    // m_size
    total += sizeof(int) * 3;

    // pixel type
    total += sizeof(int);

    // frame3d
    total += m_frame.bytes();

    // data
    size_t width = static_cast<size_t>(m_size[0]);
    size_t height = static_cast<size_t>(m_size[1]);
    size_t depth = static_cast<size_t>(m_size[2]);
    size_t bytes = pixel_size() * width * height * depth;
    total += bytes;

    return total;
}

size_t Image3d::data_bytes() const
{
    size_t width = static_cast<size_t>(m_size[0]);
    size_t height = static_cast<size_t>(m_size[1]);
    size_t depth = static_cast<size_t>(m_size[2]);
    size_t bytes = pixel_size() * width * height * depth;
    return bytes;
}

bool Image3d::write_to_buffer(void* out_buffer) const
{
    char* out = static_cast<char*>(out_buffer);

    // header version
    static const int header_size = 36;
    char header[header_size];
    memset(header, 0, header_size);
    const char* version_str = "Image3d_v1.0.0";
    strncpy(header, version_str, strlen(version_str));

    size_t buffer_size = 0;
    memcpy(out + buffer_size, header, header_size);
    buffer_size += header_size;

    // m_size
    memcpy(out + buffer_size, m_size.m_data, sizeof(int) * 3);
    buffer_size += sizeof(int) * 3;

    // pixel type
    int pixel_type_int = static_cast<int>(m_pixel_type);
    memcpy(out + buffer_size, (const char*)(&pixel_type_int), sizeof(int));
    buffer_size += sizeof(int);

    // frame3d
    if(!m_frame.write_to_buffer(out + buffer_size))
        return false;
    buffer_size += m_frame.bytes();

    // data
    size_t width = static_cast<size_t>(m_size[0]);
    size_t height = static_cast<size_t>(m_size[1]);
    size_t depth = static_cast<size_t>(m_size[2]);
    size_t bytes = pixel_size() * width * height * depth;
    memcpy(out + buffer_size, m_data, bytes);

    return true;
}

bool Image3d::read_from_buffer(void* in_buffer)
{
    clear_state();

    const char* in = static_cast<const char*>(in_buffer);
    size_t buffer_size = 0;

    // header version
    static const int header_size = 36;
    char header[header_size];
    memcpy(header, in + buffer_size, header_size);
    buffer_size += header_size;

    char expected_header[header_size];
    memset(expected_header, 0, header_size);
    const char* version_str = "Image3d_v1.0.0";
    strncpy(expected_header, version_str, strlen(version_str));

    if(strncmp(header, expected_header, header_size) != 0)
        throw std::runtime_error("unexpected image3d header");

    // m_size
    memcpy(m_size.m_data, in + buffer_size, sizeof(int) * 3);
    buffer_size += sizeof(int) * 3;

    // pixel type
    int pixel_type_int = 0;
    memcpy((char*)(&pixel_type_int), in + buffer_size, sizeof(int));
    m_pixel_type = static_cast<PixelType>(pixel_type_int);
    buffer_size += sizeof(int);

    // frame3d
    if(!m_frame.read_from_buffer(const_cast<char*>(in + buffer_size)))
        return false;
    buffer_size += m_frame.bytes();

    // data
    size_t width = static_cast<size_t>(m_size[0]);
    size_t height = static_cast<size_t>(m_size[1]);
    size_t depth = static_cast<size_t>(m_size[2]);
    size_t bytes = pixel_size() * width * height * depth;
    m_data = malloc(bytes);
    memcpy(m_data, in + buffer_size, bytes);
    buffer_size += bytes;

    // managed to true
    m_managed = true;

    return true;
}


void Image3d::set_zeros()
{
    size_t num_voxels = m_size.self_prod<size_t>();
    size_t bytes = num_voxels * pixel_size();
    if(m_data != nullptr && bytes > 0) {
        memset(m_data, 0, bytes);
    }
}


} // end namespace medvision

#include "image3d/csrc/itk/image3d_io.h"
#include "utils/csrc/template_macros.h"
#include "itkGDCMImageIO.h"
#include "itkGDCMSeriesFileNames.h"

namespace medvision {

PixelType read_pixel_type(const char* filename) {

    typedef itk::ImageIOBase::IOComponentType ScalarPixelType;
    itk::ImageIOBase::Pointer imageIO = itk::ImageIOFactory::CreateImageIO(filename, itk::ImageIOFactory::ReadMode);
    if (imageIO.IsNull()) {
        std::cerr << "[Error] image file does not exist" << std::endl;
        return PT_UNKNOWN;
    }

    imageIO->SetFileName(filename);
    imageIO->ReadImageInformation();

    if (imageIO->GetPixelType() != itk::ImageIOBase::SCALAR) {
        std::cerr << "the pixel type is not a scalar" << std::endl;
        return PT_UNKNOWN;
    }

    const ScalarPixelType pixelType = imageIO->GetComponentType();
    switch (pixelType)
    {
    case itk::ImageIOBase::UCHAR:   return PT_UCHAR; break;
    case itk::ImageIOBase::CHAR:    return PT_CHAR; break;
    case itk::ImageIOBase::USHORT:  return PT_USHORT; break;
    case itk::ImageIOBase::SHORT:   return PT_SHORT; break;
    case itk::ImageIOBase::UINT:    return PT_UINT; break;
    case itk::ImageIOBase::INT:     return PT_INT; break;
    case itk::ImageIOBase::ULONG:   return PT_ULONG; break;
    case itk::ImageIOBase::LONG:    return PT_LONG; break;
    case itk::ImageIOBase::FLOAT:   return PT_FLOAT; break;
    case itk::ImageIOBase::DOUBLE:  return PT_DOUBLE; break;
    default:                        return PT_UNKNOWN; break;
    }
}


bool read_frame_and_size(const char* filename, Frame3d& frame, vec3d<int>& size)
{
    typedef itk::ImageIOBase::IOComponentType ScalarPixelType;
    itk::ImageIOBase::Pointer imageIO = itk::ImageIOFactory::CreateImageIO(filename, itk::ImageIOFactory::ReadMode);
    if (imageIO.IsNull()) {
        std::cerr << "[Error] image file does not exist" << std::endl;
        return false;
    }

    imageIO->SetFileName(filename);
    imageIO->ReadImageInformation();

    const size_t n_dims = imageIO->GetNumberOfDimensions();
    if(n_dims != 3) {
        std::cerr << "[Error] the image dimension is " << n_dims << std::endl;
        return false;
    }

    vec3d<double> spacing;
    for(unsigned int i = 0; i < 3; ++i) {
        spacing[i] = imageIO->GetSpacing(i);
    }
    frame.set_spacing(spacing);

    for(unsigned int i = 0; i < 3; ++i) {
        size[i] = static_cast<int>(imageIO->GetDimensions(i));
    }

    vec3d<double> origin;
    for(unsigned int i = 0; i < 3; ++i) {
        origin[i] = imageIO->GetOrigin(i);
    }
    frame.set_origin(origin);

    std::vector<double> x = imageIO->GetDirection(0);
    std::vector<double> y = imageIO->GetDirection(1);
    std::vector<double> z = imageIO->GetDirection(2);

    vec3d<double> x_axis(x[0], x[1], x[2]);
    vec3d<double> y_axis(y[0], y[1], y[2]);
    vec3d<double> z_axis(z[0], z[1], z[2]);
    frame.set_axis(x_axis, 0);
    frame.set_axis(y_axis, 1);
    frame.set_axis(z_axis, 2);

    return true;
}


bool read_image(const char *filename, Image3d &image, PixelType out_ptype)
{
    PixelType pixel_type = read_pixel_type(filename);
    if(pixel_type == PT_UNKNOWN)
        return false;

    if(out_ptype == PT_UNKNOWN)
        out_ptype = pixel_type;

    ptypecall_2(read_image_template, pixel_type, out_ptype, filename, image);
	return true;
}


int get_dicom_series(const char* directory, const char* restrictions, std::vector<std::string>& series_names)
{
    typedef itk::GDCMSeriesFileNames NamesGeneratorType;
    NamesGeneratorType::Pointer name_generator = NamesGeneratorType::New();
    name_generator->SetUseSeriesDetails(true);
    if(restrictions != nullptr)
        name_generator->AddSeriesRestriction(restrictions);
    name_generator->SetDirectory(directory);

    const std::vector<std::string>& series_uid = name_generator->GetSeriesUIDs();
    series_names.clear();

    for(size_t i = 0; i < series_uid.size(); ++i)
        series_names.push_back(series_uid[i]);

    return static_cast<int>(series_names.size());
}


bool read_dicom_series(const char* directory, Image3d& image, std::map<std::string, std::string>& tags,
                       PixelType out_ptype, const char* series_name, const char* restrictions)
{
    typedef itk::GDCMSeriesFileNames NamesGeneratorType;
    NamesGeneratorType::Pointer name_generator = NamesGeneratorType::New();
    name_generator->SetUseSeriesDetails(true);
    if(restrictions != nullptr)
        name_generator->AddSeriesRestriction(restrictions);
    name_generator->SetDirectory(directory);

    const std::vector<std::string>& series_uid = name_generator->GetSeriesUIDs();
    if(series_uid.size() == 0) {
        std::cerr << "[Error] No dicom series found!" << std::endl;
        return false;
    }

    std::string series_id;
    if(series_name != nullptr)
        series_id = series_name;
    else
        series_id = series_uid.begin()->c_str();

    std::vector<std::string> file_names = name_generator->GetFileNames(series_id);
    if(file_names.size() == 0) {
        std::cerr << "[Error] No files associated with dicom series: " << series_id << std::endl;
        return false;
    }

    std::cout << "Loading " << file_names.size() << " files of " << "dicom series " << series_id << std::endl;

    PixelType ptype = read_pixel_type(file_names[0].c_str());
    if(out_ptype == PT_UNKNOWN)
        out_ptype = ptype;

    std::cout << "Input Pixel Type: " << ptype_to_str(ptype) << ", ";
    std::cout << "Output Pixel Type: " <<  ptype_to_str(out_ptype) << std::endl;

    bool ret = true;
    ptypeassign_2(read_dicom_series_template, ptype, out_ptype, ret, file_names, image, tags);

    return ret;
}


bool write_dicom_series(const Image3d& image, const char* directory, PixelType out_ptype,
                        const std::map<std::string,std::string>& tags)
{
    PixelType pixel_type = image.pixel_type();
    if(pixel_type == PT_UNKNOWN)
        return false;

    if(out_ptype == PT_UNKNOWN)
        out_ptype = pixel_type;

    bool ret = true;
    ptypeassign_2(write_dicom_series_template, pixel_type, out_ptype, ret, image, directory, tags);

    return ret;
}


bool write_image(const Image3d& image, const char* filename, PixelType out_ptype, bool compression)
{
    PixelType pixel_type = image.pixel_type();
    if(pixel_type == PT_UNKNOWN)
        return false;

    if(out_ptype == PT_UNKNOWN)
        out_ptype = pixel_type;

    bool ret = true;
    ptypeassign_2(write_image_template, pixel_type, out_ptype, ret, image, filename, compression);

    return ret;
}

} // end namespace medvision

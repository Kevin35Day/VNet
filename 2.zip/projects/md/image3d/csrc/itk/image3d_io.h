/* image3d_io.h
 *
 * template tools to read/write images
 *
 * List of functions included:
 *
 * itk_to_image3d
 * image3d_to_itk
 * read_image_template
 * read_pixel_type
 * read_image
 * write_image_template
 * write_image
 */

#ifndef IMAGE3D_IO_H
#define IMAGE3D_IO_H

#include "image3d/csrc/image3d.h"
#include "image3d/csrc/pixel_type_traits.h"
#include "image3d/csrc/image3d_tools.h"
#include "utils/csrc/template_macros.h"

#include <itkImage.h>
#include <itkImageRegionIterator.h>
#include <itkImageFileReader.h>
#include <itkImageFileWriter.h>
#include <itkImageSeriesReader.h>
#include <itkImageSeriesWriter.h>
#include <itkGDCMImageIO.h>
#include <itkNumericSeriesFileNames.h>


namespace medvision {

/*! \brief convert a itk image to image3d object
 *
 *  \param itk_image a itk image object
 *  \param out_image the output image3d object
 *  \return true if conversion is successful, false otherwise
 */
template <typename T1, typename T2>
bool itk_to_image3d(const typename itk::Image<T1,3>::Pointer itk_image, Image3d& out_image)
{
    typedef typename itk::Image<T1,3> itkImageType;

    out_image.clear_state();

    itk::Size<3> size = itk_image->GetLargestPossibleRegion().GetSize();
    itk::Point<double,3> origin = itk_image->GetOrigin();
    itk::Vector<double,3> spacing = itk_image->GetSpacing();
    typename itkImageType::DirectionType direction = itk_image->GetDirection();

    vec3d<int> image_size;
    for(int i = 0; i < 3; ++i)
        image_size[i] = static_cast<int>(size[i]);
    out_image.set_origin(vec3d<double>(origin[0], origin[1], origin[2]));
    out_image.set_spacing(vec3d<double>(spacing[0], spacing[1], spacing[2]));

    vec3d<double> axis1(direction[0][0], direction[1][0], direction[2][0]);
    vec3d<double> axis2(direction[0][1], direction[1][1], direction[2][1]);
    vec3d<double> axis3(direction[0][2], direction[1][2], direction[2][2]);
    out_image.set_axes(axis1, axis2, axis3);

    size_t width = static_cast<size_t>(image_size[0]);
    size_t height = static_cast<size_t>(image_size[1]);
    size_t depth  = static_cast<size_t>(image_size[2]);
    void* raw_ptr = malloc(sizeof(T2) * width * height * depth);
    if(raw_ptr == nullptr)
        return false;

    T2* out_ptr = static_cast<T2*>(raw_ptr);

    typedef typename itk::ImageRegionIterator<itkImageType> IteratorType;
    IteratorType it(itk_image, itk_image->GetLargestPossibleRegion());

    size_t idx = 0;
    it.GoToBegin();
    while (! it.IsAtEnd() ) {
        out_ptr[idx] = static_cast<T2>(it.Get());
        ++ it; ++idx;
    }
    assert(idx == width * height * depth);

    out_image.set_data(raw_ptr, image_size, pixel_type_traits<T2>::value(), true);
    return true;
}


/*! \brief convert a image3d object to an itk image
 *
 *  \param image the image3d object
 *  \param itk_image the output itk image
 *  \return True if conversion is sucessful, false otherwise
 */
template <typename T1, typename T2>
bool image3d_to_itk(const Image3d& image, typename itk::Image<T2,3>::Pointer itk_image) {

    typedef typename itk::Image<T2,3> itkImageType;

    itk_image->Initialize();

    itk::ImageRegion<3> region;
    {
        itk::Index<3> idx;
        idx[0] = idx[1] = idx[2] = 0;
        itk::Size<3> size;

        vec3d<int> image_size = image.size();
        for (int i = 0; i < 3; ++i)
            size[i] = image_size[i];

        region.SetIndex(idx);
        region.SetSize(size);
    }

    itk_image->SetRegions(region);
    itk_image->Allocate();

    typedef typename itk::ImageRegionIterator<itkImageType> IteratorType;
    IteratorType it(itk_image, itk_image->GetLargestPossibleRegion());
    it.GoToBegin();

    unsigned int idx = 0;
    const T1* data = static_cast<const T1*>(image.data());

    while (! it.IsAtEnd() ) {
        it.Set(static_cast<T2>(data[idx]));
        ++ it; ++ idx;
    }

    // set origin
    itk::Point<double,3> origin;
    vec3d<double> image_origin = image.origin();
    for (int i = 0; i < 3; ++i)
        origin[i] = image_origin[i];
    itk_image->SetOrigin(origin);

    // set spacing
    itk::Vector<double,3> spacing;
    vec3d<double> image_spacing = image.spacing();
    for (int i = 0; i < 3; ++i)
        spacing[i] = image_spacing[i];
    itk_image->SetSpacing(spacing);

    // set direction
    vec3d<double> axis[3] = {image.axis(0), image.axis(1), image.axis(2)};

    typename itkImageType::DirectionType direction;
    for (int col = 0; col < 3; ++col) {
        for (int row = 0; row < 3; ++row) {
            direction[row][col] = axis[col][row];
        }
    }
    itk_image->SetDirection(direction);

    return true;
}


/*! \brief read an image from disk
 *
 *  \param filename the filename
 *  \param image the output 3d image
 *  \return True if read successful, false otherwise
 */
template <typename TIn, typename TOut>
bool read_image_template(const char* filename, Image3d& image)
{
    typedef itk::Image<TIn,3> ImageType;
    typedef itk::ImageFileReader< ImageType > ReaderType;

    typename ReaderType::Pointer reader = ReaderType::New();

    reader->SetFileName(filename);
    try {
        reader->Update();
    } catch ( const itk::ExceptionObject& exp ) {
        std::cerr << exp.GetDescription() << std::endl;
        return false;
    }

    bool ret = itk_to_image3d<TIn, TOut>(reader->GetOutput(), image);
    if(!ret) {
        std::cerr << "[Error] fail to convert itk image to image3d." << std::endl;
        return false;
    }

    return true;
}


/*! \brief read pixel type from disk
 *
 *  \param filename the image file path
 *  \return the pixel type
 */
PixelType read_pixel_type(const char* filename);


/*! \brief read image frame and size info
 *
 *  \param filename the image file path
 *  \param frame the output frame
 *  \param size the output size info
 *  \return success or failure
 */
bool read_frame_and_size(const char* filename, Frame3d& frame, vec3d<int>& size);


/*! \brief read an image3d object from disk
 *
 *  \param filename the filename
 *  \param image the output image3d object
 *  \param out_ptype the desired output pixel type
 *  \return True if read successful, false otherwise
 */
bool read_image(const char *filename, Image3d &image, PixelType out_ptype = PT_UNKNOWN);


/*! \brief read dicom series from disk
 *
 *  \param filenames    the filenames of dicom series
 *  \param image        the output image3d object
 *  \param tags         the output dicom tags
 */
template <typename TIn, typename TOut>
bool read_dicom_series_template(const std::vector<std::string>& filenames, Image3d& image,
                                std::map<std::string, std::string>& tags)
{
    typedef itk::Image<TIn,3> ImageType;
    typedef itk::ImageSeriesReader<ImageType> ReaderType;
    typename ReaderType::Pointer reader = ReaderType::New();
    itk::GDCMImageIO::Pointer dicom_io = itk::GDCMImageIO::New();
    reader->SetFileNames(filenames);
    reader->SetImageIO(dicom_io);
    try {
        reader->Update();
    } catch(itk::ExceptionObject& ex) {
        std::cerr << ex << std::endl;
        return false;
    }

    typedef itk::MetaDataDictionary DictionaryType;
    const DictionaryType& dictionary = dicom_io->GetMetaDataDictionary();
    typedef itk::MetaDataObject< std::string > MetaDataStringType;

    DictionaryType::ConstIterator it = dictionary.Begin();
    DictionaryType::ConstIterator end = dictionary.End();
    while(it != end) {
        itk::MetaDataObjectBase::Pointer entry = it->second;
        MetaDataStringType::Pointer entry_value = dynamic_cast<MetaDataStringType*>(entry.GetPointer());
        if(entry_value) {
            std::string tag_key = it->first;
            std::string label_id;
            bool found = itk::GDCMImageIO::GetLabelFromTag(tag_key, label_id);
            std::string tag_value = entry_value->GetMetaDataObjectValue();
            if(found)
                tags[tag_key] = tag_value;
        }
        ++ it;
    }

    bool ret = itk_to_image3d<TIn, TOut>(reader->GetOutput(), image);
    if(!ret) {
        std::cerr << "[Error] fail to convert itk image to image3d." << std::endl;
        return false;
    }

    return true;
}


/*! \brief get dicom series names
 *
 *  \param directory        the directory containing dicom series
 *  \param series_names     a vector of series names
 *  \return the number of series in the directory
 */
int get_dicom_series(const char* directory, const char* restrictions, std::vector<std::string>& series_names);


/*! \brief read dicom series from disk
 *
 *  \param directory        the directory containing dicom series
 *  \param out_image        the output image
 *  \param out_ptype        the desired output pixel type
 *  \param series_name      the series name if there are multiple
 *  \param restrictions     the restriction string containing first the group then the element of DICOM tag, e.g., "0008|0021"
 *  \return True if read successful, false otherwise
 */
bool read_dicom_series(const char* directory, Image3d& image, std::map<std::string, std::string>& tags,
                       PixelType out_ptype=PT_UNKNOWN, const char* series_name=nullptr, const char* restrictions=nullptr);


/*! \brief write dicom series to disk (no meta data)
 *
 *  \param image            the input image3d object
 *  \param directory        the output directory
 *  \param out_ptype        the output pixel type
 *  \return True if write successful, false otherwise
 */
template <typename TIn, typename TOut>
bool write_dicom_series_template(const Image3d& image, const char* directory,
                                 const std::map<std::string, std::string>& tags)
{
    itksys::SystemTools::MakeDirectory(directory);

    typedef itk::Image<TOut,3> ImageType;
    typedef itk::Image<TOut,2> Image2DType;
    typedef itk::ImageSeriesWriter<ImageType, Image2DType> SeriesWriterType;

    typename ImageType::Pointer itk_image = ImageType::New();
    if(!image3d_to_itk<TIn,TOut>(image, itk_image)) {
        std::cerr << "[Error] fail to convert image3d to itk image." << std::endl;
        return false;
    }

    typename SeriesWriterType::Pointer writer = SeriesWriterType::New();
    itk::GDCMImageIO::Pointer gdcm_io = itk::GDCMImageIO::New();

    // setup meta dictionary
    itk::MetaDataDictionary& dict = gdcm_io->GetMetaDataDictionary();

    auto it = tags.begin();
    while(it != tags.end()) {
        itk::EncapsulateMetaData<std::string>(dict, it->first, it->second);
        ++ it;
    }

    vec3d<int> imsize = image.size();
    itk::NumericSeriesFileNames::Pointer name_generator = itk::NumericSeriesFileNames::New();
    std::string format = directory;
    format += "/%03d.dcm";
    name_generator->SetSeriesFormat(format.c_str());
    name_generator->SetStartIndex(0);
    name_generator->SetEndIndex(imsize[2]-1);
    name_generator->SetIncrementIndex(1);

    writer->SetInput(itk_image);
    writer->SetImageIO(gdcm_io);
    writer->SetFileNames(name_generator->GetFileNames());

    try {
        writer->Update();
    } catch ( const itk::ExceptionObject& exp ) {
        std::cerr << exp.GetDescription() << std::endl;
        return false;
    }

    return true;
}


/*! \brief write dicom series to disk (no meta data)
 *
 *  \param image            the input image3d object
 *  \param directory        the output directory
 *  \param out_ptype        the output pixel type
 *  \return True if write successful, false otherwise
 */
bool write_dicom_series(const Image3d& image, const char* directory, PixelType out_ptype=PT_UNKNOWN,
                        const std::map<std::string,std::string>& tags=std::map<std::string, std::string>());


/*! \brief write an image to disk
 *
 *  \param image            the 3d image to write out
 *  \param filename         the output file path
 *  \param compression      whether to use compression or not
 *  \return True if write successful, false otherwise
 */
template <typename TIn, typename TOut>
bool write_image_template(const Image3d& image, const char* filename, bool compression = false)
{
    typedef itk::Image<TOut,3> ImageType;
    typedef itk::ImageFileWriter< ImageType > WriterType;

    typename ImageType::Pointer itk_image = ImageType::New();
    if(!image3d_to_itk<TIn,TOut>(image, itk_image)) {
        std::cerr << "[Error] fail to convert image3d to itk image." << std::endl;
        return false;
    }

    typename WriterType::Pointer writer = WriterType::New();

    writer->SetInput(itk_image);
    writer->SetFileName(filename);
    writer->SetUseCompression(compression);

    try {
        writer->Update();
    } catch ( const itk::ExceptionObject& exp ) {
        std::cerr << exp.GetDescription() << std::endl;
        return false;
    }

    return true;
}


/*! \brief write an image to disk
 *
 *  \param image        the 3d image to write out
 *  \param filename     the output file path
 *  \param out_ptype    the desired output pixel type
 *  \return True if write successful, false otherwise
 */
bool write_image(const Image3d& image, const char* filename, PixelType out_ptype = PT_UNKNOWN, bool compression = false);


} // end namespace medvision

#endif // IMAGE3D_IO_H

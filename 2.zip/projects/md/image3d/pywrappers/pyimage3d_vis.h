#ifndef PYIMAGE3D_VIS_H
#define PYIMAGE3D_VIS_H

#include <cstddef>

#ifdef __cplusplus
extern "C" {
#endif

/*! \brief save a slice of a 3D volume */
bool image3d_dump_slice(void* image, int slice_index, int slice_option, const char* filename);

/*! \brief save a slice of a overlaid 3D volume */
bool image3d_dump_labeled_slice(void* orgimage, void* labelimage, int slice_index, int slice_option, double alpha, const char* color_config_file, int win_min, int win_max, const char* output_file);

/*! \brief convert a slice to a byte slice using window level */
void image3d_slice_to_bytes(const float* slice, int width, int height, int win_min, int win_max, unsigned char* valbuffer);

/*! \brief convert a byte slice to color slice */
bool image3d_bytes_to_colors(const unsigned char* valbuffer, int width, int height, int option, void* extra, unsigned char* rgbbuffer);

/*! \brief convert a byte slice to color slice */
void image3d_multi_image_alpha_blend(const unsigned char* im_rgbbuffers, int image_num, int width, int height, double* alpha, unsigned char* blended_rgbbuffer);

#ifdef __cplusplus
}
#endif

#endif // PYIMAGE3D_VIS_H

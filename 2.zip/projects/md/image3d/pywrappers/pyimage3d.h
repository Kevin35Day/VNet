#ifndef PYIMAGE3D_H
#define PYIMAGE3D_H

#include <cstddef>

#ifdef __cplusplus
extern "C" {
#endif

/*! \breif create image3d object */
void* image3d_create();

/*! \brief create image3d object */
void* image3d_create_with_size(int width, int height, int depth, int pixel_type);

/*! \brief delete image3d object */
void image3d_delete(void* image);

/*! \brief get size */
void image3d_size(void* image, int* size);

/*! \brief get width */
int image3d_width(void* image);

/*! \brief get height */
int image3d_height(void* image);

/*! \brief get depth */
int image3d_depth(void* image);

/*! \brief get pixel type */
int image3d_pixel_type(void* image);

/*! \brief get origin */
void image3d_origin(void* image, double* origin);

/*! \brief get spacing */
void image3d_spacing(void* image, double* spacing);

/*! \brief get axis */
void image3d_axis(void* image, int idx, double* axis);

/*! \brief get world center */
void image3d_center(void* image, double* center);

/*! \brief get frame */
void* image3d_frame(void* image);

/*! \brief get raw data ptr */
void* image3d_data(void* image);

/*! \brief resize image */
bool image3d_resize(void* image, int width, int height, int depth);

/*! \brief allocate image buffer */
bool image3d_allocate(void* image, int width, int height, int depth, int pixel_type);

/*! \brief cast image pixel type */
void image3d_cast(void* image, int pixel_type);

/*! \brief set raw image data */
void image3d_set_data(void* image, void* data, int width, int height, int depth, int pixel_type, bool managed);

/*! \brief copy image data */
bool image3d_copy_data(void* image, void* data, int width, int height, int depth, int pixel_type);

/*! \brief copy image data to a buffer */
void image3d_copy_data_to(void* image, void* data);

/*! \brief set image origin */
void image3d_set_origin(void* image, double x, double y, double z);

/*! \brief set image spacing */
void image3d_set_spacing(void* image, double x, double y, double z);

/*! \brief set image axis */
void image3d_set_axes(void* image, const double* axis);

/*! \brief set frame */
void image3d_set_frame(void* image, void* frame);

/*! \brief clear state */
void image3d_clear_state(void* image);

/*! \brief multiple world to voxel conversion */
void image3d_world_to_voxel(void* image, const double* worlds, int num, double* voxels);

/*! \brief multiple voxel to world conversion */
void image3d_voxel_to_world(void* image, const double* voxels, int num, double* worlds);

/*! \brief number of bytes for an image object */
std::size_t image3d_bytes(void* image);

/*! \brief write image3d object to buffer */
bool image3d_write_to_buffer(void* image, void* buffer);

/*! \brief read image3d object from buffer */
bool image3d_read_from_buffer(void* image, void* buffer);

/*! \brief set all pixel values to constant */
void image3d_fill_pixel(void* image, double v);

/*! \brief get a pixel value */
double image3d_pixel_value(void* image, int x, int y, int z);

/*! \brief deep copy an image */
void* image3d_deep_copy(void* image);

/*! \brief set all pixel values to zero */
void image3d_set_zeros(void* image);


#ifdef __cplusplus
}
#endif

#endif // IMAGE3D_LIB_H

#include "image3d/pywrappers/pyimage3d_tools.h"
#include "image3d/csrc/image3d.h"
#include "image3d/csrc/image3d_tools.h"
#include "utils/csrc/template_macros.h"
#include <iostream>

using namespace medvision;

bool image3d_slice_nn(void* image, const double* cursor, const double* axis1, const double* axis2, const double* center,
              double x_spacing, double y_spacing, int width, int height, void* out, double default_value)
{
    Image3d* obj = static_cast<Image3d*>(image);
    Plane3d<double> plane;
    plane.m_pt = vec3d<double>(cursor[0], cursor[1], cursor[2]);
    plane.m_axis1 = vec3d<double>(axis1[0], axis1[1], axis1[2]);
    plane.m_axis2 = vec3d<double>(axis2[0], axis2[1], axis2[2]);

    vec3d<double> focus_center(center[0], center[1], center[2]);
    size_t input_width = static_cast<size_t>(width), input_height = static_cast<size_t>(height);

    PixelType ptype = obj->pixel_type();
    if(ptype == PT_UNKNOWN)
        return false;

    ptypecall_2(slice_nn, ptype, ptype, *obj, plane, focus_center, x_spacing, y_spacing, input_width, input_height, out, default_value);

    return true;
}


void* image3d_create_like(void* image)
{
    Image3d* obj = static_cast<Image3d*>(image);
    PixelType ptype = obj->pixel_type();
    vec3d<int> size = obj->size();

    Image3d* new_obj = new Image3d(size[0], size[1], size[2], ptype);
    new_obj->set_frame(obj->frame());

    return new_obj;
}


void image3d_estimate_intensity_window(void* image, bool slice_only, double* center, double* width)
{
    Image3d* obj = static_cast<Image3d*>(image);
    PixelType ptype = obj->pixel_type();
    std::pair<double, double> ret;
    ptypeassign_1(estimate_intensity_window, ptype, ret, *obj, slice_only);

    *center = ret.first;
    *width = ret.second;
}


int image3d_random_voxels(void* mask, int num, double min_val, double max_val, int* voxels)
{
    Image3d* obj = static_cast<Image3d*>(mask);
    PixelType ptype = obj->pixel_type();

    int ret = 0;
    ptypeassign_1(random_voxels, ptype, ret, *obj, num, min_val, max_val, voxels);

    return ret;
}

void image3d_resample_nn(void* image, void* frame, const int* size, int pad_t, void* out)
{
    Image3d* image_w = static_cast<Image3d*>(image);
    Frame3d* frame_w = static_cast<Frame3d*>(frame);
    vec3d<int> size_w(size[0], size[1], size[2]);
    Image3d* out_w = static_cast<Image3d*>(out);

    PixelType ptype = image_w->pixel_type();
    ptypecall_2(resample_nn, ptype, ptype, *image_w, *frame_w, size_w, pad_t, *out_w);
}

void image3d_resample_nn_bb(void* image, void* frame, const int* size, const int* mincorner, const int* maxcorner, int pad_t, void* out)
{
	Image3d* image_w = static_cast<Image3d*>(image);
	Frame3d* frame_w = static_cast<Frame3d*>(frame);
	vec3d<int> size_w(size[0], size[1], size[2]);
	Image3d* out_w = static_cast<Image3d*>(out);

	vec3d<int> mincorner_w(mincorner[0], mincorner[1], mincorner[2]);
	vec3d<int> maxcorner_w(maxcorner[0], maxcorner[1], maxcorner[2]);

	PixelType ptype = image_w->pixel_type();
    ptypecall_2(resample_nn_bb, ptype, ptype, *image_w, *frame_w, size_w, mincorner_w, maxcorner_w, pad_t, *out_w);

}

void image3d_crop(void* image, const int* sp, const int* ep, void* out)
{
    Image3d* image_w = static_cast<Image3d*>(image);
    Image3d* out_w = static_cast<Image3d*>(out);
    vec3d<int> sp_w(sp[0], sp[1], sp[2]), ep_w(ep[0], ep[1], ep[2]);

    PixelType ptype = image_w->pixel_type();
    ptypecall_1(crop, ptype, *image_w, sp_w, ep_w, *out_w);
}

void image3d_convert_multi_label_to_binary(void* image, int label)
{
    Image3d* image_w = static_cast<Image3d*>(image);
    PixelType ptype = image_w->pixel_type();
    ptypecall_1(convert_multi_label_to_binary, ptype, *image_w, label);
}

void image3d_intensity_normalize(void* image, double mean, double stddev, bool clip)
{
    Image3d* image_w = static_cast<Image3d*>(image);
    PixelType ptype = image_w->pixel_type();
    ptypecall_1(intensity_normalize, ptype, *image_w, mean, stddev, clip);
}

int image3d_mass_voxel_center(void* image, double minVal, double maxVal, double* masscenter)
{
	Image3d* image_w = static_cast<Image3d*>(image);
	PixelType ptype = image_w->pixel_type();
	vec3d<double> mc;
	bool ret(false);
	ptypeassign_1(mass_voxel_center, ptype, ret, *image_w, minVal, maxVal, mc);	
	if (ret)
	{
		for (int i = 0; i < 3; i++)
			masscenter[i] = mc[i];
	}
	return ret;
}

int image3d_weighted_mass_voxel_center(void* image, double minVal, double maxVal, double* masscenter)
{
    Image3d* image_w = static_cast<Image3d*>(image);
    PixelType ptype = image_w->pixel_type();
    vec3d<double> mc;
    bool ret(false);
    ptypeassign_1(weighted_mass_voxel_center, ptype, ret, *image_w, minVal, maxVal, mc);
    if (ret)
    {
        for (int i = 0; i < 3; i++)
            masscenter[i] = mc[i];
    }
    return ret;
}

int image3d_boundingbox_voxel(void* image, double minVal, double maxVal, int* mincorner,int* maxcorner)
{
	Image3d* image_w = static_cast<Image3d*>(image);
	PixelType ptype = image_w->pixel_type();
	vec3d<int> minc,maxc;
	bool ret(false);
	ptypeassign_1(boundingbox_voxel, ptype, ret, *image_w, minVal, maxVal, minc, maxc);
	if (ret)
	{
		for (int i = 0; i < 3; i++)
		{
			mincorner[i] = minc[i];
			maxcorner[i] = maxc[i];
		}
	}
	return ret;
}


size_t image3d_pick_largest_component(void* image)
{
    Image3d* image_w = static_cast<Image3d*>(image);
    PixelType ptype = image_w->pixel_type();
    size_t ret = 0;
    ptypeassign_1(pick_largest_component, ptype, ret, *image_w);
    return ret;
}


void image3d_replace_pixel(void* image, double target, double replace)
{
    Image3d* image_w = static_cast<Image3d*>(image);
    PixelType ptype = image_w->pixel_type();
    ptypecall_1(replace_pixel, ptype, *image_w, target, replace);
}


void image3d_hist_match(void* src_image, void* ref_image)
{
    Image3d* src_image_w = static_cast<Image3d*>(src_image);
    PixelType src_ptype = src_image_w->pixel_type();

    Image3d* ref_image_w = static_cast<Image3d*>(ref_image);
    PixelType ref_ptype = ref_image_w->pixel_type();

    ptypecall_2(hist_match, src_ptype, ref_ptype, *src_image_w, *ref_image_w);
}


void image3d_max_min_avg(void* image, double* max_value, double* min_value, double* avg_value)
{
    Image3d* image_w = static_cast<Image3d*>(image);
    PixelType ptype = image_w->pixel_type();

    ptypecall_1(max_min_avg, ptype, *image_w, *max_value, *min_value, *avg_value);
}


void image3d_percentiles(void* image, const double* percents, int num, double* out)
{
    Image3d* image_w = static_cast<Image3d*>(image);
    PixelType ptype = image_w->pixel_type();

    ptypecall_1(percentiles, ptype, *image_w, percents, static_cast<size_t>(num), out);
}


double image3d_get_pixel_value(void* image, int x, int y, int z)
{
    Image3d* image_w = static_cast<Image3d*>(image);
    PixelType ptype = image_w->pixel_type();

    double ret = 0;
    ptypeassign_1(get_pixel_value, ptype, ret, *image_w, x, y, z);
    return ret;
}

void image3d_set_pixel_value(void* image, int x, int y, int z, double v)
{
    Image3d* image_w = static_cast<Image3d*>(image);
    PixelType ptype = image_w->pixel_type();

    ptypecall_1(set_pixel_value, ptype, *image_w, x, y, z, v);
}

int image3d_count_labels(void* image, int* has_label)
{
    Image3d* image_w = static_cast<Image3d*>(image);
    PixelType ptype = image_w->pixel_type();

    int ret = 0;
    ptypeassign_1(count_labels, ptype, ret, *image_w, has_label);
    return ret;
}


void image3d_boundingbox_voxel_multi(void* image, const int* labels, int num_labels, int* boxes)
{
    Image3d* image_w = static_cast<Image3d*>(image);
    PixelType ptype = image_w->pixel_type();

    ptypecall_1(boundingbox_voxel_multi, ptype, *image_w, labels, num_labels, boxes);
}

void image3d_imflip(void* image, int axis)
{
    Image3d* image_w = static_cast<Image3d*>(image);
    PixelType ptype = image_w->pixel_type();

    ptypecall_1(imflip, ptype, *image_w, axis);
}

void image3d_impad(void* image, const int* pad)
{
    Image3d* image_w = static_cast<Image3d*>(image);
    PixelType ptype = image_w->pixel_type();
    vec3d<int> pad_w(pad[0], pad[1], pad[2]);

    ptypecall_1(impad, ptype, *image_w, pad_w);
}

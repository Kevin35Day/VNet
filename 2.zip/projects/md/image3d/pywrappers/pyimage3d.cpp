#include "image3d/pywrappers/pyimage3d.h"
#include "image3d/csrc/image3d.h"
#include "image3d/csrc/image3d_tools.h"
#include "utils/csrc/template_macros.h"

using namespace medvision;

void* image3d_create()
{
    return new Image3d();
}

void* image3d_create_with_size(int width, int height, int depth, int pixel_type)
{
    PixelType type = static_cast<PixelType>(pixel_type);
    Image3d* obj = nullptr;
    try {
        obj = new Image3d(width, height, depth, type);
    } catch(std::bad_alloc&) {
        if(obj != nullptr) {
            delete obj;
            obj = nullptr;
        }
    }
    return obj;
}

void image3d_delete(void* image)
{
    Image3d* obj = static_cast<Image3d*>(image);
    delete obj;
}

void image3d_size(void* image, int* size)
{
    Image3d* obj = static_cast<Image3d*>(image);
    vec3d<int> size3 = obj->size();
    memcpy(size, size3.m_data, sizeof(int) * 3);
}

int image3d_width(void* image)
{
    Image3d* obj = static_cast<Image3d*>(image);
    return obj->width();
}

int image3d_height(void* image)
{
    Image3d* obj = static_cast<Image3d*>(image);
    return obj->height();
}

int image3d_depth(void* image)
{
    Image3d* obj = static_cast<Image3d*>(image);
    return obj->depth();
}

int image3d_pixel_type(void* image)
{
    Image3d* obj = static_cast<Image3d*>(image);
    return static_cast<int>(obj->pixel_type());
}

void image3d_origin(void* image, double* origin)
{
    Image3d* obj = static_cast<Image3d*>(image);
    vec3d<double> origin3 = obj->origin();
    memcpy(origin, origin3.m_data, sizeof(double) * 3);
}

void image3d_spacing(void* image, double* spacing)
{
    Image3d* obj = static_cast<Image3d*>(image);
    vec3d<double> spacing3 = obj->spacing();
    memcpy(spacing, spacing3.m_data, sizeof(double) * 3);
}

void image3d_axis(void* image, int idx, double* axis)
{
    Image3d* obj = static_cast<Image3d*>(image);
    vec3d<double> axis3 = obj->axis(idx);
    memcpy(axis, axis3.m_data, sizeof(double) * 3);
}

void image3d_center(void* image, double* center)
{
    Image3d* obj = static_cast<Image3d*>(image);
    vec3d<double> out = obj->center();
    memcpy(center, out.m_data, sizeof(double) * 3);
}

void* image3d_frame(void* image)
{
    Image3d* obj = static_cast<Image3d*>(image);
    Frame3d* frame = new Frame3d(obj->frame());
    return frame;
}

void* image3d_data(void* image)
{
    Image3d* obj = static_cast<Image3d*>(image);
    return obj->data();
}

bool image3d_resize(void* image, int width, int height, int depth)
{
    Image3d* obj = static_cast<Image3d*>(image);
    try {
        obj->resize(width, height, depth);
    } catch(std::bad_alloc&) {
        return false;
    }
    return true;
}

bool image3d_allocate(void* image, int width, int height, int depth, int pixel_type)
{
    Image3d* obj = static_cast<Image3d*>(image);
    try {
        obj->allocate(width, height, depth, static_cast<PixelType>(pixel_type));
    } catch(std::bad_alloc&) {
        return false;
    }
    return true;
}

void image3d_cast(void* image, int pixel_type)
{
    Image3d* obj = static_cast<Image3d*>(image);
    PixelType type = static_cast<PixelType>(pixel_type);
    obj->cast(type);
}

void image3d_set_data(void* image, void* data, int width, int height, int depth, int pixel_type, bool managed)
{
    Image3d* obj = static_cast<Image3d*>(image);
    PixelType type = static_cast<PixelType>(pixel_type);
    obj->set_data(data, width, height, depth, type, managed);
}

bool image3d_copy_data(void* image, void* data, int width, int height, int depth, int pixel_type)
{
    Image3d* obj = static_cast<Image3d*>(image);
    PixelType type = static_cast<PixelType>(pixel_type);
    try {
        obj->copy_data(data, width, height, depth, type);
    } catch (std::bad_alloc&) {
        return false;
    }
    return true;
}

void image3d_copy_data_to(void* image, void* data)
{
    Image3d* obj = static_cast<Image3d*>(image);
    obj->copy_data_to(data);
}

void image3d_set_origin(void* image, double x, double y, double z)
{
    Image3d* obj = static_cast<Image3d*>(image);
    obj->set_origin(x, y, z);
}

void image3d_set_spacing(void* image, double x, double y, double z)
{
    Image3d* obj = static_cast<Image3d*>(image);
    obj->set_spacing(x, y, z);
}

void image3d_set_axes(void* image, const double* axis)
{
    Image3d* obj = static_cast<Image3d*>(image);
    obj->set_axes(axis);
}

void image3d_set_frame(void* image, void* frame)
{
    Image3d* image_w = static_cast<Image3d*>(image);
    Frame3d* frame_w = static_cast<Frame3d*>(frame);
    image_w->set_frame(*frame_w);
}

void image3d_clear_state(void* image)
{
    Image3d* obj = static_cast<Image3d*>(image);
    obj->clear_state();
}

void image3d_world_to_voxel(void *image, const double *worlds, int num, double *voxels)
{
    Image3d* obj = static_cast<Image3d*>(image);
    for(int i = 0; i < num; ++i) {
        vec3d<double> coord(worlds[i * 3], worlds[i * 3 + 1], worlds[i * 3 + 2]);
        coord = obj->world_to_voxel(coord);
        memcpy(voxels + i * 3, coord.data(), sizeof(double) * 3);
    }
}

void image3d_voxel_to_world(void* image, const double* voxels, int num, double* worlds)
{
    Image3d* obj = static_cast<Image3d*>(image);
    for(int i = 0; i < num; ++i) {
        vec3d<double> coord(voxels[i * 3], voxels[i * 3 + 1], voxels[i * 3 + 2]);
        coord = obj->voxel_to_world(coord);
        memcpy(worlds + i * 3, coord.data(), sizeof(double) * 3);
    }
}

size_t image3d_bytes(void* image)
{
    Image3d* obj = static_cast<Image3d*>(image);
    return obj->bytes();
}

bool image3d_write_to_buffer(void* image, void* buffer)
{
    Image3d* obj = static_cast<Image3d*>(image);
    return obj->write_to_buffer(buffer);
}

bool image3d_read_from_buffer(void* image, void* buffer)
{
    Image3d* obj = static_cast<Image3d*>(image);
    return obj->read_from_buffer(buffer);
}

void image3d_fill_pixel(void* image, double v)
{
    Image3d* obj = static_cast<Image3d*>(image);
    ptypecall_1(image_fill, obj->pixel_type(), *obj, v);
}

double image3d_pixel_value(void* image, int x, int y, int z)
{
    Image3d* obj = static_cast<Image3d*>(image);
    double ret = 0;
    ptypeassign_1(get_pixel_value, obj->pixel_type(), ret, *obj, x, y, z);
    return ret;
}

void* image3d_deep_copy(void* image)
{
    Image3d* obj = static_cast<Image3d*>(image);
    Image3d* copy = nullptr;
    try {
        copy = new Image3d(*obj);
    } catch (std::bad_alloc&) {
        if(copy != nullptr) {
            delete copy;
            copy = nullptr;
        }
    }
    return copy;
}

void image3d_set_zeros(void* image)
{
    Image3d* obj = static_cast<Image3d*>(image);
    obj->set_zeros();
}

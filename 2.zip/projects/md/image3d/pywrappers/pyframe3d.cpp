#include "image3d/pywrappers/pyframe3d.h"
#include "image3d/csrc/frame3d.h"

using namespace medvision;

void* frame3d_create()
{
    return new Frame3d;
}

void frame3d_delete(void* obj)
{
    Frame3d* frame = static_cast<Frame3d*>(obj);
    delete frame;
}

void* frame3d_deepcopy(void* obj)
{
    Frame3d* frame = static_cast<Frame3d*>(obj);
    Frame3d* out = new Frame3d();
    out->set_origin(frame->get_origin());
    out->set_spacing(frame->get_spacing());
    for(int i = 0; i < 3; ++i)
        out->set_axis(frame->get_axis(i), i);
    return out;
}

void frame3d_restore_default(void* obj)
{
    Frame3d* frame = static_cast<Frame3d*>(obj);
    frame->restore_default();
}

void frame3d_origin(void* obj, double* out)
{
    Frame3d* frame = static_cast<Frame3d*>(obj);
    vec3d<double> origin = frame->get_origin();
    memcpy(out, origin.data(), sizeof(double) * 3);
}

void frame3d_spacing(void* obj, double* out)
{
    Frame3d* frame = static_cast<Frame3d*>(obj);
    vec3d<double> spacing = frame->get_spacing();
    memcpy(out, spacing.data(), sizeof(double) * 3);
}

void frame3d_axis(void* obj, size_t idx, double* out)
{
    Frame3d* frame = static_cast<Frame3d*>(obj);
    vec3d<double> axis = frame->get_axis(idx);
    memcpy(out, axis.data(), sizeof(double) * 3);
}

void frame3d_axes(void* obj, double* out)
{
    Frame3d* frame = static_cast<Frame3d*>(obj);
    vec3d<double> axis1 = frame->get_axis(0);
    memcpy(out, axis1.data(), sizeof(double) * 3);

    vec3d<double> axis2 = frame->get_axis(1);
    memcpy(out + 3, axis2.data(), sizeof(double) * 3);

    vec3d<double> axis3 = frame->get_axis(2);
    memcpy(out + 6, axis3.data(), sizeof(double) * 3);
}

void frame3d_set_origin(void* obj, double x, double y, double z)
{
    Frame3d* frame = static_cast<Frame3d*>(obj);
    frame->set_origin(vec3d<double>(x, y, z));
}

void frame3d_set_spacing(void* obj, double x, double y, double z)
{
    Frame3d* frame = static_cast<Frame3d*>(obj);
    frame->set_spacing(vec3d<double>(x, y, z));
}

void frame3d_set_axis(void* obj, size_t idx, double x, double y, double z)
{
    Frame3d* frame = static_cast<Frame3d*>(obj);
    frame->set_axis(vec3d<double>(x, y, z), idx);
}

void frame3d_set_axes(void* obj, const double* axes)
{
    Frame3d* frame = static_cast<Frame3d*>(obj);
    frame->set_axis(vec3d<double>(axes[0], axes[1], axes[2]), 0);
    frame->set_axis(vec3d<double>(axes[3], axes[4], axes[5]), 1);
    frame->set_axis(vec3d<double>(axes[6], axes[7], axes[8]), 2);
}

void frame3d_world_to_voxel(void* obj, const double* world, int num, double* voxel)
{
    Frame3d* frame = static_cast<Frame3d*>(obj);
    for(int i = 0; i < num; ++i) {
        vec3d<double> coord(world[i * 3], world[i * 3 + 1], world[i * 3 + 2]);
        coord = frame->world_to_voxel(coord);
        memcpy(voxel + i * 3, coord.data(), sizeof(double) * 3);
    }
}

void frame3d_voxel_to_world(void* obj, const double* voxel, int num, double* out)
{
    Frame3d* frame = static_cast<Frame3d*>(obj);
    for(int i = 0; i < num; ++i) {
        vec3d<double> coord(voxel[i * 3], voxel[i * 3 + 1], voxel[i * 3 + 2]);
        coord = frame->voxel_to_world(coord);
        memcpy(out + i * 3, coord.data(), sizeof(double) * 3);
    }
}

size_t frame3d_bytes(void* obj)
{
    Frame3d* frame = static_cast<Frame3d*>(obj);
    return frame->bytes();
}

bool frame3d_write_to_buffer(void* obj, void* data)
{
    Frame3d* frame = static_cast<Frame3d*>(obj);
    return frame->write_to_buffer(data);
}

bool frame3d_read_from_buffer(void* obj, void* data)
{
    Frame3d* frame = static_cast<Frame3d*>(obj);
    return frame->read_from_buffer(data);
}

#ifndef PYIMAGE3D_MORPH_H
#define PYIMAGE3D_MORPH_H

#include <cstddef>

#ifdef __cplusplus
extern "C" {
#endif

/*! \brief erode image */
void image3d_imerode(void* image, int iteration, int label);

/*! \brief dilate image */
void image3d_imdilate(void* image, int iteration, int label);

#ifdef __cplusplus
}
#endif

#endif // PYIMAGE3D_MORPH_H

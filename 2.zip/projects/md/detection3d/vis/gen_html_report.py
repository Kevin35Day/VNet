# coding:utf-8
import numpy as np
import os
import webbrowser
from md.detection3d.vis.error_analysis import ErrorAnalysis

def AddDocumentText(original_text, new_text_to_add):
    return original_text + r'+"{0}"'.format(new_text_to_add)

"""
Generate landmark evaluation HTML report.
Input arguments:
  labelled_point_list: 2-D array of labelled points.
  detected_point_list: 2-D array of detected points.
  labelled_image_list: 2-D array of extracted 2D plane (axial, coronal, sagittal)
                       image names crossing labelled points.
  detected_image_list: 2-D array of extracted 2D plane (axial, coronal, sagittal)
                       image names crossing detected points.
  output_folder: The output folder containing the html report.
  image_folder: The image folder containing the captured 2D plane images.
                Must be a relative path to the output_folder.
  html_report_name: The HTML report file name.
"""
def GenHtmlReport(file_name_list, labelled_point_list, detected_point_list,
                  labelled_image_list, detected_image_list,
                  output_folder, image_folder = './images',
                  html_report_name = 'result_analysis.html',
                  for_label_checking = False):

  error_summary = ErrorAnalysis(labelled_point_list, detected_point_list)
  num_data = len(labelled_point_list)
  if num_data != len(labelled_image_list) or num_data != len(detected_image_list):
    raise AssertionError()

  image_link_template = r'<img border=0  src= {0}  hspace=1  width={1} >'
  error_info_template = r'<b>Labelled</b>: [{0:.2f}, {1:.2f}, {2:.2f}];  ' + \
                        r'<b>Detected</b>: [{3:.2f}, {4:.2f}, {5:.2f}];  ' + \
                        r'<b>Error</b>: x:{6}; y:{7}; z:{8}; L2:{9:.2f}'

  document_text = r'"<h1>check predicted coordinates:</h1>"'
  document_text += "\n"
  width = 295
  if for_label_checking:
      width *= 2

  for i in range(num_data):
    if for_label_checking:
      index = i
    else:
      index = error_summary.sorted_index_list[i]
    labelled_point = labelled_point_list[index]
    detected_point = detected_point_list[index]
    labelled_images = labelled_image_list[index]
    detected_images = detected_image_list[index]
    x_error = error_summary.point_distance_list[index][0]
    y_error = error_summary.point_distance_list[index][1]
    z_error = error_summary.point_distance_list[index][2]
    l2_error = error_summary.l2_norm_error_list[index]

    error_info = error_info_template.format(labelled_point[0],
                                            labelled_point[1],
                                            labelled_point[2],
                                            detected_point[0],
                                            detected_point[1],
                                            detected_point[2],
                                            x_error,
                                            y_error,
                                            z_error,
                                            l2_error)

    case_info = r'<b>Case nunmber</b>:{0} : {1} ,   '.format(index,file_name_list[index])
    document_text = AddDocumentText(document_text, case_info)
    document_text = AddDocumentText(document_text, error_info)
    document_text += "\n"
    document_text = AddDocumentText(document_text, "<table border=1><tr>")
    for j in range(3):
      document_text += "\n"
      image_info = r'<td>{0}</td>'.format(image_link_template.format(
            os.path.join(image_folder, labelled_images[j]),width))
      document_text = AddDocumentText(document_text, image_info)
    if not for_label_checking:
      for j in range(3):
        document_text += "\n"
        image_info = r'<td>{0}</td>'.format(image_link_template.format(
              os.path.join(image_folder, detected_images[j]), width))
        document_text = AddDocumentText(document_text, image_info)


    document_text += "\n"
    document_text = AddDocumentText(document_text, r'</tr></table>')

  analysis_text = "There are {0} cases in total.".format(num_data)
  analysis_text += "\n"
  analysis_text += r'<p>mean:</p>{0:.2f}'.format(error_summary.mean_error)
  analysis_text += "\n"
  analysis_text += r'<p>median:</p>{0:.2f}'.format(error_summary.median_error)
  analysis_text += "\n"
  analysis_text += r'<p>max:</p>{0:.2f}'.format(error_summary.max_error)
  analysis_text += "\n"
  analysis_text += r'<p>min:</p>{0:.2f}'.format(error_summary.min_error)

  html_report_path = os.path.join(output_folder, html_report_name)
  f = open(html_report_path, 'w')
  message = """
  <html>
  <head></head>
  <body>
    <script type="text/javascript">       
      document.write(%s)               
    </script>
    <h1> Summary:</h1>
    %s
  </body>
  </html>""" % (document_text, analysis_text)

  f.write(message)
  f.close()
# webbrowser.open(html_report_path, new = 1)
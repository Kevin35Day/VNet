# coding:utf-8
import math
import numpy as np
import pandas as pd
from collections import namedtuple

"""
The struct containing the error summary.
"""
ErrorSummary = namedtuple('ErrorSummary',
                          'mean_error median_error max_error min_error point_distance_list l2_norm_error_list sorted_index_list')

"""
Run error analysis and return the error statistics summary.
Input arguments:
  labelled_point_list: 2-D list of labelled points.
  detected_point_list: 2-D list of detected points.
  descending:          Flag indicating whether errors sorted in ascending or
                       descending order.
Return:
  error_summary:       Summary of error statistics.
"""
def ErrorAnalysis(labelled_point_list, detected_point_list, descending=True):
  num_points = len(labelled_point_list)
  if num_points != len(detected_point_list):
      raise ValueError("The labelled point list is of different size"
                       " from the detected point list.")
  labelled_point_list = np.array(labelled_point_list)
  detected_point_list = np.array(detected_point_list)

  point_distance_list = labelled_point_list - detected_point_list
  l2_norm_error_list = np.linalg.norm(point_distance_list, axis = 1)
  max_error = np.amax(l2_norm_error_list)
  min_error = np.amin(l2_norm_error_list)
  median_error = np.median(l2_norm_error_list)
  mean_error = np.mean(l2_norm_error_list)

  # By default, argsort() sorts an array in ascending order.
  sorted_index_list = np.argsort(l2_norm_error_list)
  if descending:
    sorted_index_list = sorted_index_list[::-1]

  error_summary = ErrorSummary(
    mean_error = mean_error,
    median_error = median_error,
    max_error = max_error,
    min_error = min_error,
    point_distance_list = point_distance_list,
    l2_norm_error_list = l2_norm_error_list,
    sorted_index_list = sorted_index_list)
  return error_summary
import argparse
import numpy as np
import md.image3d.python.image3d_io as cio
import md.detection3d.config.mi_aorta_detection_config as config
import os
import pandas as pd
import torch

from md.mdpytorch.utils.tensor_tools import ToImage
from md.image3d.python.frame3d import Frame3d
from md.image3d.python.image3d_io import write_image
from md.detection3d.dataset.multi_detection_dataset import MultipleDetectionDataset
from md.detection3d.dataset.multi_detection_dataset import read_image_list
from md.detection3d.dataset.multi_detection_dataset import read_label_list
from torch.utils.data import DataLoader

def ParseAndCheckArguments():
  parser = argparse.ArgumentParser()

  parser.add_argument('--save_cropped_images_and_masks',
                      type=bool, default = False,
                      help='Flag indicating whether to save cropped images and'
                           ' masks for visual debugging.')
  parser.add_argument('--output_folder', type=str, default="",
                      help='The folder to save cropped images and masks.')

  args = parser.parse_args()


  if args.save_cropped_images_and_masks:
    if not args.output_folder:
      raise ValueError("Specify the ouput folder to save the cropped images"
                       " and masks.")
    if not os.path.isdir(args.output_folder):
      os.makedirs(args.output_folder)

  return args

def TestMultiDetectionDataset(args, config):
  """
  Test MultiDetectionDataset.
  Input arguments:
    config:          Dataset configuration
  """
  data_dir = os.path.join(config.general.root_dir, config.general.image_dir)
  label_dir = os.path.join(config.general.root_dir, config.general.label_dir)

  label_list = read_label_list(label_dir, config.general.label_list_files)
  image_list = read_image_list(label_dir, config.general.image_list_file)

  run_regression = config.loss.regression.lamda > 0
  if run_regression:
    num_mask_channels = 4
  else:
    num_mask_channels = 1

  dataset = MultipleDetectionDataset(
    data_dir,
    image_list,
    label_list,
    config.dataset.voxel_spacing,
    config.dataset.cropping_size,
    config.dataset.sampling_size,
    config.dataset.positive_upper_bound,
    config.dataset.negative_lower_bound,
    config.dataset.num_pos_patches_per_image,
    config.dataset.neg_to_pos_patches_ratio,
    config.dataset.normalization.mean,
    config.dataset.normalization.stddev,
    config.dataset.normalization.clip,
    run_regression)

  assert dataset.__len__() == len(image_list)
  data, mask, labels, frames = dataset.__getitem__(0)

  if args.save_cropped_images_and_masks:
    num_images = data.size()[0]
    save_path = args.output_folder
    if not os.path.isdir(save_path):
      os.makedirs(save_path)
    for i in range(num_images):
      frame = Frame3d()
      frame.from_numpy(frames[i])

      image = ToImage()(data[i].squeeze())
      image.set_frame(frame)
      write_image(image, os.path.join(save_path, 'crop_{0:02d}.mhd'.format(i)))

      label = ToImage()(mask[i].squeeze())
      label.set_frame(frame)
      write_image(label, os.path.join(save_path, 'mask_{0:02d}.mhd'.format(i)))

  num_positive_patches = cfg.dataset.num_pos_patches_per_image
  num_negative_patches = num_positive_patches * cfg.dataset.neg_to_pos_patches_ratio
  num_patches = num_positive_patches + num_negative_patches

  dim_z = cfg.dataset.cropping_size[2]
  dim_y = cfg.dataset.cropping_size[1]
  dim_x = cfg.dataset.cropping_size[0]

  assert data.dim() == 5
  assert data.size()[0] == num_patches
  assert data.size()[1] == 1
  assert data.size()[2] == dim_z
  assert data.size()[3] == dim_y
  assert data.size()[4] == dim_x

  assert mask.dim() == 5
  assert mask.size()[0] == num_patches
  assert mask.size()[1] == num_mask_channels
  assert mask.size()[2] == dim_z
  assert mask.size()[3] == dim_y
  assert mask.size()[4] == dim_x

  assert len(labels) == num_patches
  for i in range(num_patches):
    if i < num_positive_patches:
      assert labels[i] >= 1
    else:
      assert labels[i] == 0

  data_loader = DataLoader(dataset,
                           batch_size=cfg.train.batch_size,
                           num_workers=cfg.train.num_threads,
                           shuffle=True,
                           pin_memory=True)

  data_iter = iter(data_loader)
  batch_index = 0
  num_data = len(dataset)

  for batch_idx in range(len(data_loader)):
    cropped_images, cropped_masks, labels, _ = data_iter.next()
    batch_size = min(cfg.train.batch_size, num_data - batch_index)

    assert cropped_images.dim() == 6
    assert batch_size == cropped_images.size()[0]
    assert num_patches == cropped_images.size()[1]
    assert 1 == cropped_images.size()[2]
    assert dim_z == cropped_images.size()[3]
    assert dim_y == cropped_images.size()[4]
    assert dim_x == cropped_images.size()[5]

    assert cropped_masks.dim() == 6
    assert batch_size == cropped_masks.size()[0]
    assert num_patches == cropped_masks.size()[1]
    assert num_mask_channels == cropped_masks.size()[2]
    assert dim_z == cropped_masks.size()[3]
    assert dim_y == cropped_masks.size()[4]
    assert dim_x == cropped_masks.size()[5]

    assert batch_size == labels.shape[0]
    assert num_patches == labels.shape[1]

    batch_index += batch_size

    # move the output channel to the last dimension
    cropped_masks = cropped_masks.permute(0, 1, 3, 4, 5, 2).contiguous()
    # merge the dim_x, dim_y, dim_z, patch_index, volume_index together.
    cropped_masks = cropped_masks.view(-1, num_mask_channels)
    # only a subset of samples will contribute to the loss function.
    selected_sample_indices = torch.nonzero(cropped_masks[:,0] != -1)
    # extract the target matrix, the first dimension is along the samples,
    # the second dimension is along the output channels.
    targets = torch.index_select(cropped_masks, 0, selected_sample_indices.squeeze())
    positive_samples = 0
    negative_samples = 0
    for i in range(targets.size()[0]):
      label = targets[i, 0]
      assert label != -1
      if label == 0:
        negative_samples += 1
      elif label > 0:
        positive_samples += 1
      else:
        raise ValueError("Unexpected class label!")
    print "Batch {0}: {1} positive samples, {2} negative samples".format(
      batch_idx, positive_samples, negative_samples)

if __name__ == '__main__':
  cfg = config.cfg
  args = ParseAndCheckArguments()
  TestMultiDetectionDataset(args, cfg)

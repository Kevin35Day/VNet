import md.image3d.python.image3d_io as cio
import md.image3d.python.image3d_tools as ctools
import md.image3d.python.image3d as cimages
import numpy as np
import os
import pandas as pd
import torch

from md.mdpytorch.utils.tensor_tools import ToTensor
from torch.utils.data import Dataset

def read_label_list(label_list_dir, label_list_files):
  """
  Read a list of labelled landmark csv files and return a list of labelled
  landmarks.

  Input arguments:
   label_list_dir:   Directory of containing those labelled landmark csv files.
   label_list_files: The list of labelled landmark file names. The length of
                     the list indicates the size of the landmarks to detect.
                     The csv file format is compliant with the pandas data frame
                     structure:
                     --------------------------------
                       ,    filename,   x,    y,   z
                      0, patient_1.mhd, 100, 100, 100
                     ---------------------------------
  Return:
    label_list:      A list of dictionaries indexed by the landmark_id - 1. For each
                     landmark, it corresponds to a dictionary where the key is the
                     file name, and the value is a list of 3-D world coordinates
                     of the landmark. The structure allows multiple instances of the
                     same landmark in one volume. In case of absence, the file name
                     is not added into the dictionary.
                     [landmark_1, landmark_2, landmark_3, ..., landmark_n]
                     For each landmark_i, the item corresponds to a dictionary
                     {file_name_1: [[instance_1], [instance_2], ..., [instance_t]],
                      file_name_2: [[instance_1], [instance_2], ..., [instance_t]],
                      ...
                      file_name_m: [[instance_1], [instance_2], ..., [instance_t]]}
  """
  num_labels = len(label_list_files)
  label_list = []
  for i in range(num_labels):
    labels = pd.read_csv(os.path.join(label_list_dir, label_list_files[i]))

    label_dictionary = dict()
    for _, row in labels.iterrows():
      filename = row['filename']
      x = row['x']
      y = row['y']
      z = row['z']
      if not filename in label_dictionary:
        label_dictionary[filename] = []
      label_dictionary[filename].append([x, y, z])

    label_list.append(label_dictionary)

  return label_list

def read_image_list(image_list_dir, image_list_file):
  """
  Reads the image list file and returns a list of image file names.
  Input arguments:
   image_list_dit:  The directory containing the image list file.
   image_list_file: The file name of the image list.
  Return:
   image_list:      The list of image file names.
  """
  images = pd.read_csv(os.path.join(image_list_dir, image_list_file))
  image_list = images['filename'].tolist()
  return image_list


class MultipleDetectionDataset(Dataset):
  """
  Training dataset for multi-landmark detection.
  """
  def __init__(self,
               image_folder,
               image_list,
               label_list,
               voxel_spacing,
               cropping_size,
               sampling_size,
               positive_upper_bound,
               negative_lower_bound,
               num_pos_patches_per_image,
               neg_to_pos_patches_ratio,
               normalization_mean,
               normalization_stddev,
               normalization_clip,
               run_regression):
    self.image_folder = image_folder
    self.image_list = image_list
    self.label_list = label_list
    self.voxel_spacing = voxel_spacing
    self.cropping_size = cropping_size
    self.sampling_size = sampling_size
    self.positive_upper_bound = positive_upper_bound
    self.negative_lower_bound = negative_lower_bound
    self.num_pos_patches_per_image = num_pos_patches_per_image
    self.num_neg_patches_per_image = num_pos_patches_per_image * neg_to_pos_patches_ratio
    # + 1 for background
    self.num_classes = len(label_list) + 1
    self.num_positive_labels = len(label_list)
    self.normalization_mean = normalization_mean
    self.normalization_stddev = normalization_stddev
    self.normalization_clip = normalization_clip
    self.run_regression = run_regression

    self.positive_perturbs = []
    for dz in range(-positive_upper_bound, positive_upper_bound):
      for dy in range(-positive_upper_bound, positive_upper_bound):
        for dx in range(-positive_upper_bound, positive_upper_bound):
          perturb = [dx, dy, dz]
          if np.linalg.norm(perturb) <= positive_upper_bound:
            self.positive_perturbs.append(perturb)

  def __len__(self):
    """ get the number of images in this dataset """
    return len(self.image_list)


  def get_label_and_offset(self, image_file, sampled_point_world):
    """
    Get the label and offset of the specified point in a given volume.
    Input arguments:
      image_file:         The file name of the image volume.
      sample_point_world: The sampling point in world coordinate.
    Return:
      label:            0 if negative, 1 to N if positive corresponding
                        to N different landmarks, -1 otherwise. A voxel
                        can be neither positive nor negative.
      min_offset_voxel: The 3-d offset vector in voxels to the nearest
                        landmark and only set if the point is positive.
    """

    # initialized as negative label
    label = 0
    min_distance = -1
    min_offset_voxel = np.zeros(3, dtype=np.float32)

    # go through all different landmarks
    for i in range(self.num_positive_labels):
      if image_file in self.label_list[i].keys():
        # go through all labelled points for the given landmark and image volume
        for labelled_point_world in self.label_list[i][image_file]:
          offset_voxel = np.zeros(3, dtype=np.float32)
          for d in range(3):
            offset_voxel[d]  = labelled_point_world[d] - sampled_point_world[d]
            offset_voxel[d] /= self.voxel_spacing[d]

          offset_distance = np.linalg.norm(offset_voxel)

          # if the sample point falls within the positive range of a landmark,
          # select the label of the annotated landmark closest to the sample point.
          if offset_distance <= self.positive_upper_bound:
            if min_distance < 0 or min_distance > offset_distance:
              label = i + 1
              min_distance = offset_distance
              min_offset_voxel = offset_voxel
          elif offset_distance <= self.negative_lower_bound:
            # if the sample point falls outside of the negative range of a
            # landmark, we only mark it as undefined when it's still labelled
            # as negative.
            if label == 0:
              label = -1

    # normalize the offset vector for the regression so that each component of the
    # shift vector falls within the range of [-1, 1].
    min_offset_voxel /= self.positive_upper_bound

    return label, min_offset_voxel

  def crop_mask(self, image_file, cropped_image, world_center, sampling_size):
    """
     Crop 1 or 4 rectangular masks depending on whether the regression is turned
     on or not. Each mask is of the same size, resolution and offset as the input
     cropped image, and only voxels within the range of sampling size from the
     world_center will be filled in masks. The first mask contains the labels for
     the sampled voxels, where 0 stands for negative, 1 to N stand for positive
     corresponding to N different landmarks respectively. The 2nd to the 4th masks
     represent the normalized offset vectors for regression function which are
     only generated if regression is turned on.

     Input arguments:
      image_file:    String of the volume name.
      cropped_image: The cropped image.
      world_center:  Cropping center in world coordinate.
      sampling_size: Sampling size around the world center in voxel coordinate.
     Return:
      cropped_masks: A list of 1 or 4 masks of the same size as cropped_image.
     """
    assert isinstance(cropped_image, cimages.Image3d)

    # cropped masks are of 4 channels, [label, dx, dy, dz].
    if self.run_regression:
      num_masks = 4
    else:
      num_masks = 1

    cropped_mask = []
    for i in range(num_masks):
      mask = ctools.create_image3d_like(cropped_image)
      mask.fill(-1)
      cropped_mask.append(mask)

    spacing = cropped_image.spacing()
    world_sp = world_center - spacing * sampling_size / 2.0
    voxel_sp = np.round(cropped_image.world_to_voxel(world_sp)).astype(np.int32)

    cropped_width = cropped_image.width()
    cropped_height = cropped_image.height()
    cropped_depth = cropped_image.depth()

    for z in range(voxel_sp[2], voxel_sp[2] + sampling_size[2]):
      for y in range(voxel_sp[1], voxel_sp[1] + sampling_size[1]):
        for x in range(voxel_sp[0], voxel_sp[0] + sampling_size[0]):
          # check if the sampling point lies within the cropped image.
          if x < 0 or x >= cropped_width \
                  or y < 0 or y >= cropped_height \
                  or z < 0 or z >= cropped_depth:
            continue
          sampling_point_world = cropped_image.voxel_to_world([x, y, z])

          label, offset = self.get_label_and_offset(
            image_file, sampling_point_world)

          coord = [x, y, z]
          ctools.set_pixel_value(cropped_mask[0], coord, label)
          if self.run_regression:
            ctools.set_pixel_value(cropped_mask[1], coord, offset[0])
            ctools.set_pixel_value(cropped_mask[2], coord, offset[1])
            ctools.set_pixel_value(cropped_mask[3], coord, offset[2])

    return cropped_mask

  def crop_center(self, image, world_center, cropping_size):
    """
    Crop a rectangular patch from image with specified center in world coordinate
    and cropping size in voxels. Automatically padded with zero if cropped outside
    of the original volume.

    Input arguments:
     image:        Image3d object
     world_center: Cropping center in world coordinate.
     crop_size:    Cropping size in voxel coordinate.
    Return:
     image_crop:   The cropped image with same resolution as the input image.
    """
    assert isinstance(image, cimages.Image3d)
    spacing = image.spacing()
    world_sp = world_center - spacing * cropping_size / 2.0
    voxel_sp = np.round(image.world_to_voxel(world_sp)).astype(np.int32)
    voxel_ep = voxel_sp + cropping_size
    image_crop = ctools.crop(image, voxel_sp, voxel_ep)

    return image_crop


  def sample_positive_points(self, image_file, image):
    # go through all existing positive classes for the indexed volume
    existing_positive_labels = []
    for i in range(self.num_positive_labels):
      if image_file in self.label_list[i].keys():
        if len(self.label_list[i][image_file]) >= 1:
          existing_positive_labels.append(i)

    num_existing_positive_labels = len(existing_positive_labels)
    if num_existing_positive_labels == 0:
      raise AssertionError("Each volume must contain at least one positive sample.")

    sample_positive_points_world = []
    sample_positive_labels = []
    for i in range(self.num_pos_patches_per_image):
      # randomly sample the positive classes to make sure each positive class is
      # sampled equally regardless of the number of its instances in the volume.
      label_index = np.random.randint(0, num_existing_positive_labels)
      positive_label = existing_positive_labels[label_index]

      # randomly sample the positive instances of the given label in the volume.
      num_positive_instances = len(self.label_list[positive_label][image_file])
      instance_index = np.random.randint(0, num_positive_instances)
      sample_point_world = self.label_list[positive_label][image_file][instance_index]
      sample_point_voxel = image.world_to_voxel(sample_point_world)

      # randomly perturb the sampling point.
      num_positive_perturbs = len(self.positive_perturbs)
      perturb_index = np.random.randint(0, num_positive_perturbs)
      perturb_voxel = self.positive_perturbs[perturb_index]

      sample_point_voxel += perturb_voxel
      sample_point_world = image.voxel_to_world(sample_point_voxel)

      sample_positive_points_world.append(sample_point_world)
      # + 1 to make positive class labels starting from 1 instead of 0.
      # Here we assume that instances of different positive classes are
      # farther from each other than the slight perturbation. In other
      # word, the small neighborhood of a positive sample all belong to
      # the same class label.
      sample_positive_labels.append(positive_label + 1)


    return sample_positive_points_world, sample_positive_labels


  def sample_negative_points(self, image_file, image):
    dimension = [image.width(), image.height(), image.depth()]

    # merge all labelled positive points in the given volume.
    labelled_positive_points_voxel = []
    for i in range(0, self.num_positive_labels):
      if image_file in self.label_list[i].keys():
        for labelled_positive_point_voxel in self.label_list[i][image_file]:
          labelled_positive_points_voxel.append(
            image.world_to_voxel(labelled_positive_point_voxel))

    num_voxels = dimension[0] * dimension[1] * dimension[2]
    voxel_index = 0
    sample_negative_points_world = []
    while len(sample_negative_points_world) < self.num_neg_patches_per_image \
            and voxel_index < num_voxels:
      x = np.random.randint(0, image.width())
      y = np.random.randint(0, image.height())
      z = np.random.randint(0, image.depth())

      sample_point_voxel = [x, y, z]

      voxel_index += 1

      is_negative = True
      # Only select negative samples with enough distance from every labelled
      # positive sample point.
      for labelled_positive_point_voxel in labelled_positive_points_voxel:
        diff_vector = labelled_positive_point_voxel - sample_point_voxel
        if np.linalg.norm(diff_vector) <= self.negative_lower_bound:
          is_negative = False
          break

      if is_negative:
        sample_negative_points_world.append(image.voxel_to_world(
          sample_point_voxel))

    return sample_negative_points_world



  def __getitem__(self, index):
    """ get the item """
    assert index < len(self.image_list)
    image_file = self.image_list[index]
    image_path = os.path.join(self.image_folder, image_file)
    im = cio.read_image(image_path, dtype=np.float32)

    image_spacing = im.frame().spacing()

    # only resize the volume if its resolution is different from the specified
    if np.linalg.norm(image_spacing - self.voxel_spacing) > 1e-4:
      im = ctools.resample_volume_nn_rai(im, self.voxel_spacing)

    # random sample positives from the given volume.
    positive_samples_world, positive_labels = \
      self.sample_positive_points(image_file, im)
    positive_labels = np.array(positive_labels)

    # random sample negatives from the given volume.
    negative_samples_world = self.sample_negative_points(image_file, im)
    negative_labels = np.zeros(len(negative_samples_world), dtype=int)

    cropped_images = []
    cropped_masks = []

    # crop the positive boxes from the given volume
    for positive_sample_world in positive_samples_world:
      cropped_image = self.crop_center(im, positive_sample_world, self.cropping_size)
      # normalize the cropped image intensity.
      ctools.intensity_normalize(cropped_image,
                                 self.normalization_mean,
                                 self.normalization_stddev,
                                 self.normalization_clip)

      cropped_mask = self.crop_mask(image_file,
                                    cropped_image,
                                    positive_sample_world,
                                    self.sampling_size)

      cropped_images.append([cropped_image])
      cropped_masks.append(cropped_mask)

    # crop the negative boxes from the given volume.
    for negative_sample_world in negative_samples_world:
      cropped_image = self.crop_center(im, negative_sample_world, self.cropping_size)
      # normalized the cropped image intensity
      ctools.intensity_normalize(cropped_image,
                                 self.normalization_mean,
                                 self.normalization_stddev,
                                 self.normalization_clip)

      cropped_mask = self.crop_mask(image_file,
                                    cropped_image,
                                    negative_sample_world,
                                    self.sampling_size)

      cropped_images.append([cropped_image])
      cropped_masks.append(cropped_mask)


    # The cropped_images and cropped_masks are both lists of Image3d objects lists.
    # The outer list indexes different image patches, and the inner list indexes
    # different channels, where cropped_images only has one channel, and cropped_masks
    # has one or four channels depending on whether the regression is turned on or not.
    num_crops = len(cropped_images)
    if num_crops != len(cropped_masks):
      raise AssertionError("The list of cropped images has different length than the"
                           " list of cropped masks.")

    cropped_images_tensor = []

    for i in range(num_crops):
      cropped_tensor = ToTensor()(cropped_images[i])
      cropped_tensor = torch.unsqueeze(cropped_tensor, 0)
      cropped_images_tensor.append(cropped_tensor)
    cropped_images_tensor = torch.cat(cropped_images_tensor, 0)

    cropped_masks_tensor = []
    for i in range(num_crops):
      cropped_tensor = ToTensor()(cropped_masks[i])
      cropped_tensor = torch.unsqueeze(cropped_tensor, 0)
      cropped_masks_tensor.append(cropped_tensor)
    cropped_masks_tensor = torch.cat(cropped_masks_tensor, 0)

    # frame header information for debugging purpose
    crop_frames = []
    for i in range(num_crops):
      crop_frame = cropped_images[i][0].frame().to_numpy()
      crop_frames.append(np.expand_dims(crop_frame, axis=0))
    crop_frames = np.concatenate(crop_frames, 0)

    # The labels is of 1-d array where corresponds to the label of the center
    # sampling point of each cropped patch.
    labels = np.concatenate((positive_labels, negative_labels))

    return cropped_images_tensor, cropped_masks_tensor, labels, crop_frames
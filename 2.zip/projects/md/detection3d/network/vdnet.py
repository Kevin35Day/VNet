import torch
import torch.nn as nn
from md.mdpytorch.module.vbnet_downblock import DownBlock
from md.mdpytorch.module.vbnet_inputblock import InputBlock
from md.mdpytorch.module.vbnet_upblock import UpBlock
from md.mdpytorch.init.kaiming_init import kaiming_weight_init


def ApplyKaimingInit(net):
  net.apply(kaiming_weight_init)

class OutputBlock(nn.Module):
    """ output block of v-net
    """
    def __init__(self, in_channels, num_classes, use_regression):
      super(OutputBlock, self).__init__()
      self.num_classes = num_classes
      self.use_regression = use_regression

      out_channels = num_classes
      self.class_conv1 = nn.Conv3d(
         in_channels, out_channels, kernel_size=3, padding=1)
      self.class_bn1 = nn.BatchNorm3d(out_channels)
      self.class_act1 = nn.ReLU(inplace=True)
      self.class_conv2 = nn.Conv3d(out_channels, out_channels, kernel_size=1)
      self.softmax = nn.Softmax()

      if use_regression:
        out_channels = 3 * (num_classes - 1)
        self.regression_conv1 = nn.Conv3d(
          in_channels, out_channels, kernel_size=3, padding=1)
        self.regression_bn1 = nn.BatchNorm3d(out_channels)
        self.regression_act1 = nn.ReLU(inplace=True)
        self.regression_conv2 = nn.Conv3d(out_channels, out_channels, kernel_size=1)

    def forward(self, input):
      out = self.class_act1(self.class_bn1(self.class_conv1(input)))
      out = self.class_conv2(out)
      out_size = out.size()
      # out_size = [batch_size, out_channels, dim_z, dim_y, dim_x]

      # move channels to last dimension and softmax
      out = out.permute(0, 2, 3, 4, 1).contiguous()
      out = out.view(out.numel() // out_size[1], out_size[1])
      out = self.softmax(out)

      # reshape back to output size
      out = out.view(out_size[0], out_size[2], out_size[3], out_size[4], out_size[1])
      out = out.permute(0, 4, 1, 2, 3)

      if self.use_regression:
        out_regression = self.regression_act1(self.regression_bn1(self.regression_conv1(input)))
        out_regression = self.regression_conv2(out_regression)
        out = torch.cat((out, out_regression), 1)

      out = out.contiguous()
      return out

class VNet(nn.Module):
  """ v-net for detection """

  def __init__(self, in_channels, num_classes, use_regression):
    super(VNet, self).__init__()
    self.in_block   =   InputBlock(in_channels, 16)
    self.down_32    =   DownBlock(16, 1, use_bottle_neck=False)
    self.down_64    =   DownBlock(32, 2, use_bottle_neck=False)
    self.up_64      =   UpBlock(64, 64, 2, use_bottle_neck=False)
    self.up_32      =   UpBlock(64, 32, 1, use_bottle_neck=False)
    self.out_block  =   OutputBlock(32, num_classes, use_regression)

  def forward(self, input):
    out16  =  self.in_block(input)
    out32  =  self.down_32(out16)
    out64  =  self.down_64(out32)
    out    =  self.up_64(out64, out32)
    out    =  self.up_32(out, out16)
    out    =  self.out_block(out)
    return out

  def max_stride(self):
    return 4

from PyQt5.Qt import *
import os
from md.viewer.view_client import ViewClient
import md
import numpy as np
import pandas as pd
import csv
from md.utils.python.file_tools import readlines
from md.detection3d.vdet_pyimpl import autodet_load_model, autodet_volume
import md.image3d.python.image3d_io as cio
import md.image3d.python.image3d_tools as ctools


class ConsoleToolbar(QMainWindow):
    """
    Detection Landmark Menu
    A convenient tool to load image and label landmark
    """

    def __init__(self, name):
        super(ConsoleToolbar, self).__init__()
        # Initial a viewclient
        self.viewclient = ViewClient(name)
        self.viewclient.open()

        # landmark table initialize
        self.radiusEditable = True
        self.dimension = np.array([0, 0], dtype=np.int)
        self.table = LandMarkTable(self.dimension, self.radiusEditable)
        self.imglist_table = ImgList([], [])

        # clicked button to save landmark
        self.table.clicked_button.connect(self.save_cursor)
        self.table.edit_finish.connect(self.goto_cursor)
        self.Widget = QWidget()
        self.upleftbox = QVBoxLayout()
        self.upleftbox1 = QVBoxLayout()
        self.upleftbox2 = QVBoxLayout()

        # image
        self.imlist = []
        self.imgidx = 0

        # model
        self.detmodel = None
        self.im3 = None

        # landmark template
        self.lmfilename = 'LMtemplate.csv'
        self.lmbutton = True
        self.csvdir = ''
        self.imgdir = ''
        self.imgname = ''
        self.initial_cursor = np.array([0, 0, 0])

        self.casenum = 0
        self.currentImg = ''
        self.statuslist = []
        self.haveSaved = False
        self.loadStatus = ''
        self.tabletitle = ['Index', 'LM_name', 'VoxelX', 'VoxelY', 'VoxelZ', 'WorldX', 'WorldY', 'WorldZ', 'Radius',
                           'AcceptLM']
        self.confirm = False

        # image process params
        # wc for window center and ww for window width
        self.auto_wcww = False
        self.wc = 0
        self.ww = 1000
        self.auto_wc = None
        self.auto_ww = None

        self.setup_ui()

    def setup_ui(self):

        # Menu Bar
        menuBar = self.menuBar()
        fileMenu = menuBar.addMenu('&File')

        newMenu = QMenu('&Open Image...', self)
        loadMhdAct = QAction('&Load Mhd...', self)
        loadDicomAct = QAction('&Load Dicom...', self)
        newMenu.addAction(loadMhdAct)
        newMenu.addAction(loadDicomAct)
        loadMhdAct.triggered.connect(self.load_mhd)
        loadDicomAct.triggered.connect(self.load_dicom)
        fileMenu.addMenu(newMenu)

        # load Image from folder
        folderMenu = QMenu('&Open folder...', self)
        dicomfolderAct = QAction('&Open dicom folder', self)
        dicomfolderAct.triggered.connect(self.read_imlist_from_dicomfolder)
        mhdfolderAct = QAction('&Open mhd folder', self)
        mhdfolderAct.triggered.connect(self.read_imlist_from_mhdfolder)
        folderMenu.addAction(mhdfolderAct)
        folderMenu.addAction(dicomfolderAct)
        fileMenu.addMenu(folderMenu)

        # load Image from file
        fileAct = QAction('&Open Image List file...', self)
        fileAct.triggered.connect(self.read_imlist_from_file)
        fileMenu.addAction(fileAct)

        # save csv
        savecsvAct = QAction('&Save Csv..', self)
        savecsvAct.triggered.connect(self.save_table)
        fileMenu.addAction(savecsvAct)

        # load Csv Template
        csvMenu = menuBar.addMenu('&Template')
        tempAct = QAction('&Create landmark template...', self)
        tempAct.triggered.connect(self.create_table)
        csvMenu.addAction(tempAct)
        
        # Set radius label mode
        radius_label_menu = QMenu('&Radius label mode...', self)
        radius_label_on_act = QAction('Able to label radius', self)
        radius_label_off_act = QAction('Unable to label radius', self)
        radius_label_menu.addAction(radius_label_on_act)
        radius_label_on_act.triggered.connect(self.SetRadiusEditable)
        radius_label_menu.addAction(radius_label_off_act)
        radius_label_off_act.triggered.connect(self.SetRadiusUneditable)
        csvMenu.addMenu(radius_label_menu)

        # load Image Contrast
        tools_menu = menuBar.addMenu('Tools')
        image_contrast_menu = QMenu('Image Contrast', self)
        contrast_adjust_act = QAction('Contrast Adjustment...', self)
        auto_contrast_act = QAction('Auto-Adjust Contrast (all layers)', self)
        image_contrast_menu.addAction(contrast_adjust_act)
        image_contrast_menu.addAction(auto_contrast_act)
        contrast_adjust_act.triggered.connect(self.adjust_contrast)
        auto_contrast_act.triggered.connect(self.auto_contrast)
        tools_menu.addMenu(image_contrast_menu)

        # load model #
        modelMenu = menuBar.addMenu('Model')
        model_load_act = QAction('Load AI Model ...', self)
        model_load_act.triggered.connect(self.load_model_clicked)
        modelMenu.addAction(model_load_act)

        # Define Layout
        globalbox = QVBoxLayout(self.Widget)

        # UpLayout
        upbox = QHBoxLayout()
        uprightbox = QVBoxLayout()

        self.upleftbox1.addWidget(self.table)
        self.upleftbox2.addWidget(self.imglist_table)
        self.upleftbox.addLayout(self.upleftbox1)
        self.upleftbox.addLayout(self.upleftbox2)

        deletelmButton = QPushButton('Delete', self)
        deletelmButton.clicked.connect(self.delete_cursor)
        notexistNodeButton = QPushButton('NotExist', self)
        notexistNodeButton.clicked.connect(self.mark_notexist_lm)
        returnButton = QPushButton('Recenter', self)
        returnButton.clicked.connect(self.returnCenter)
        displaylmButton = QPushButton('TextOn/Off', self)
        displaylmButton.clicked.connect(self.displaylmButtonClicked)
        modelButton = QPushButton('Detect', self)
        modelButton.clicked.connect(self.det_button_clicked)
        confirmButton = QPushButton('Confirm', self)
        confirmButton.clicked.connect(self.confirm_button_clicked)
        prevButton = QPushButton('<-', self)
        prevButton.clicked.connect(self.prevClicked)
        nextButton = QPushButton('->', self)
        nextButton.clicked.connect(self.nextClicked)

        uprightbox.addWidget(modelButton)
        uprightbox.addWidget(displaylmButton)
        uprightbox.addWidget(returnButton)
        uprightbox.addWidget(deletelmButton)
        uprightbox.addWidget(notexistNodeButton)
        uprightbox.addWidget(confirmButton)
        uprightbox.addWidget(prevButton)
        uprightbox.addWidget(nextButton)
        uprightbox.addStretch(1)

        upbox.addLayout(self.upleftbox)
        upbox.addLayout(uprightbox)

        # DownLayout
        downbox = QHBoxLayout()
        downleftbox = QHBoxLayout()
        self.text = "{}".format(self.imgname)
        self.label = QLabel(self.text, self)
        downleftbox_Label = QLabel('Current Image:')
        downbox.addWidget(downleftbox_Label, 1)
        downbox.addWidget(self.label, 5)
        downbox.addWidget(self.label)

        # HeadLayout
        headbox = QHBoxLayout()
        self.headbox = QLineEdit()
        self.headbox.setText("<Please to choose a folder path in which to open or save a csv file>")
        self.headbox.setStyleSheet("color:grey")
        headbox_button = QPushButton('Save path', self)
        headbox_button.clicked.connect(self.__change_csv_dir)
        headbox.addWidget(self.headbox, 5.5)
        headbox.addWidget(headbox_button, 0.5)
        downbox.addLayout(downleftbox)

        globalbox.addLayout(headbox)
        globalbox.addLayout(upbox)
        globalbox.addLayout(downbox)

        # Table Widget
        self.Widget.setLayout(globalbox)
        self.setCentralWidget(self.Widget)
        self.setWindowTitle('Landmark Toolbar')
        self.setGeometry(50, 50, 950, 500)

    def load_mhd(self):
        # Confirm all landmarks have been marked
        imgpath = QFileDialog.getOpenFileName(self, 'Open file',
                                              filter='Images(*.mhd *.mha *.hdr *.nii *.nii,gz)')

        if len(imgpath[0]) == 0:
            return

        self.imgdir = os.path.split(imgpath[0])[0]

        # get image folder name and initial csv file directory
        if self.csvdir == '':
            QMessageBox.warning(self, 'Info', 'Pelease select the csv dir first')
            self.__change_csv_dir()

        self.load_img_and_csv(imgpath[0])
        self.imlist = {}
        self.__delete_imglist()

    def load_dicom(self):
        imgpath = QFileDialog.getExistingDirectory(self, 'Open Dicom Series')

        if imgpath == '':
            return

        self.imgdir = os.path.dirname(os.path.dirname(imgpath))

        if self.csvdir == '':
            QMessageBox.warning(self, 'Info', 'Pelease select the csv dir first')
            self.__change_csv_dir()

        self.load_img_and_csv(imgpath)
        self.imlist = {}
        self.__delete_imglist()

    def __delete_imglist(self):

        if self.upleftbox2.count() != 0:
            self.upleftbox2.removeWidget(self.imglist_table)
            self.imglist_table.deleteLater()

    def set_imgidx_and_loadImg(self, rowidx, imgpath):
        self.__check_mark_done()
        if self.imgidx == rowidx:
            return
        else:
            self.imgidx = rowidx
            self.load_img_and_csv(imgpath)

    def load_img_and_csv(self, imgpath):
        self.remove_all_lm()

        if self.__check_is_dicom_folder(imgpath):
            print "Image Type: Dicom"
            if self.__check_is_dicom_series(imgpath):
                im, _ = md.read_dicom_series(imgpath)
                self.imgname = os.path.basename(os.path.dirname(imgpath))
                filename = self.imgname
            else:
                return
        else:
            img_exts = ['.nii', '.nii.gz', '.mhd', '.mha', '.hdr']
            for ext in img_exts:
                if imgpath.endswith(ext):
                    print "Image Type: {}".format(ext)
                    break
            try:
                im = cio.read_image(imgpath, dtype=np.float32)
                self.imgname = os.path.split(imgpath)[1]
                filename = os.path.splitext(self.imgname)[0]
            except:
                return

        self.im3 = im
        self.viewclient.add_image(im, 'Img', self.wc, self.ww, 0, 0.5, True)
        self.initial_cursor = self.viewclient.get_cursor()

        self.text = "{}".format(self.imgname)
        self.label.setText(self.text)
        
        template_path = os.path.join(self.csvdir, self.lmfilename)
        csv_path = os.path.join(self.csvdir, filename + '.csv')

        if os.path.isfile(csv_path):
            self.load_csv(csv_path)
        elif os.path.isfile(template_path):
            self.load_csv(template_path)
        else:
            self.create_table()

    def SetRadiusEditable(self):
        if not self.radiusEditable:
            self.radiusEditable = True
            self.tabletitle = ['Index', 'LM_name', 'VoxelX', 'VoxelY', 'VoxelZ', 'WorldX', 'WorldY', 'WorldZ', 'Radius',
                               'AcceptLM']
            print "Radius mode has change please reload image "

    def SetRadiusUneditable(self):
        if self.radiusEditable:
            self.radiusEditable = False
            self.tabletitle = ['Index', 'LM_name', 'VoxelX', 'VoxelY', 'VoxelZ', 'WorldX', 'WorldY', 'WorldZ', 'AcceptLM']

    def create_table(self):

        reply = QMessageBox.information(self,
                                        'Create New Landmark table',
                                        'Please create a landmark table',
                                        QMessageBox.Yes | QMessageBox.No)
        if reply == QMessageBox.Yes:
            rowNumber, ok = QInputDialog.getInt(self, 'LandMark Number', 'LandMark Number')
            columnNumber = len(self.tabletitle)
            if ok:
                self.dimension = np.array([rowNumber, columnNumber])

                self.upleftbox1.removeWidget(self.table)
                self.table.deleteLater()

                self.table = LandMarkTable(self.dimension, self.radiusEditable)
                # Change the table editable
                self.table.setEditTriggers(QAbstractItemView.DoubleClicked)
                self.table.setHorizontalHeaderLabels(self.tabletitle)

                # connect fuction to table
                self.table.itemDoubleClicked.connect(self.goto_item_cursor)
                self.table.clicked_button.connect(self.save_cursor)
                self.table.edit_finish.connect(self.goto_cursor)

                # resize table to content
                header = self.table.horizontalHeader()
                for i in range(self.dimension[1]):
                    header.setSectionResizeMode(i, QHeaderView.ResizeToContents)

                self.upleftbox1.addWidget(self.table)

    def load_csv(self, csvpath):

        self.upleftbox1.removeWidget(self.table)
        self.table.deleteLater()

        data = pd.read_csv(csvpath)
        # adjust radius label table title
        col_num = len(self.tabletitle)
        if col_num != len(data.columns):
            QMessageBox.warning(self, 'Warning', 'Wrong file or Wrong label mode?')
            return
        row_num = len(data.index)

        self.dimension = np.array([row_num, col_num])
        self.table = LandMarkTable(self.dimension, self.radiusEditable)
        self.table.setHorizontalHeaderLabels(self.tabletitle)
        self.table.clicked_button.connect(self.save_cursor)
        self.table.edit_finish.connect(self.goto_cursor)
        self.table.itemDoubleClicked.connect(self.goto_item_cursor)

        header = self.table.horizontalHeader()
        for i in range(col_num):
            header.setSectionResizeMode(i, QHeaderView.ResizeToContents)

        for i in range(row_num):
            # Set Radius
            if self.radiusEditable:
                radius = ''
                if not pd.isnull(data.iloc[i, -2]):
                    radius = str((data.iloc[i, -2]))
                self.table.cellWidget(i, self.dimension[1] - 2).setText('{}'.format(radius))

            for j in range(col_num):
                self.table.setItem(i, j, QTableWidgetItem(str(data.iloc[i, j])))
                # Initial LM Row Color
                try:
                    imgstatus = self.statuslist[self.imgidx]
                    if imgstatus == 'Not Started' or imgstatus == 'In Progress':
                        self.table.set_row_background_color(i, 'Initial')
                    elif imgstatus == 'Completed':
                        self.table.set_row_background_color(i, 'Confirm')
                    else:
                        return
                except:
                    self.table.set_row_background_color(i, 'Initial')

        self.upleftbox1.addWidget(self.table)

    def save_current_imgname_to_file(self):
        try:
            f = open(self.imlistfile, 'w')
            f.write(str(self.casenum) + '\n')
            f.write(self.imlist[self.imgidx] + '\n')
            f.write(self.csvdir + '\n')
            for index in range(self.casenum):
                f.write(self.imlist[index] + ',' + self.statuslist[index] + '\n')
            f.close()
        except:
            return

    def save_table(self):
        if self.csvdir == '':
            return
        self.save_lm_csv()
        self.save_template_csv()
        self.save_current_imgname_to_file()
        self.haveSaved = True

    def save_lm_csv(self):
        if self.imgname == '':
            return
        filename = os.path.splitext(self.imgname)[0]
        if self.csvdir == '' or (os.path.exists(self.csvdir) == False):
            self.csvdir = QFileDialog.getExistingDirectory(self, 'Please select the save path')
            return

        csvpath = os.path.join(self.csvdir, filename + '.csv')
        csvfile = file(csvpath, 'w')
        writer = csv.writer(csvfile)
        list = self.tabletitle
        writer.writerow(list)
        for rowidx in range(self.dimension[0]):
            list = []
            for columnIndex in range(self.dimension[1]):
                item = self.get_table_item(rowidx, columnIndex)
                list.append(item)
            writer.writerow(list)
        csvfile.close()

    def get_table_item(self, rowidx, colidx):
        if self.radiusEditable and colidx == self.dimension[1] - 2:
            item = self.table.cellWidget(rowidx, colidx)
            try:
                item = int(float(item.text()))
            except:
                item = ''
        else:
            item = self.table.item(rowidx, colidx)
            try:
                item = item.text()
                if item == 'nan':
                    item = ''
            except:
                item = ''
        return item

    def save_template_csv(self):
        # Save landmark template file
        lmfilename = os.path.join(self.csvdir, self.lmfilename)
        lmtemplatefile = file(lmfilename, 'w')
        writer = csv.writer(lmtemplatefile)
        list = self.tabletitle
        writer.writerow(list)
        for rowidx in range(self.dimension[0]):
            list = []
            # the last column is for add landmark button
            for columnIndex in range(self.dimension[1]):
                item = self.table.item(rowidx, columnIndex)
                if columnIndex > 1:
                    list.append(' ')
                elif item == None:
                    return
                else:
                    list.append(item.text())
            writer.writerow(list)
        lmtemplatefile.close()

    def save_cursor(self, rowidx):
        world = self.viewclient.get_cursor()
        voxel = self.viewclient.get_voxel('Img')
        world = np.round(world, 3)
        voxel = np.round(voxel, 0)
        for index in range(3):
            self.table.setItem(rowidx, index + 2, QTableWidgetItem(str(voxel[index])))
            self.table.setItem(rowidx, index + 5, QTableWidgetItem(str(world[index])))
        self.table.set_row_background_color(rowidx, 'Confirm')

        # mark landmark and set cofirm color
        lmname = self.table.item(rowidx, 1).text()
        if lmname == '' or lmname == 'nan' or lmname == ' ' or lmname == None:
            QMessageBox.warning(self, 'Warning', 'Please define landmark name')
            return
        if self.radiusEditable:
            radius = self.table.cellWidget(rowidx, self.dimension[1] - 2).text()
            if radius == '' or radius == 'nan' or radius == ' ' or radius == None:
                print "The radius is Empty"
                self.viewclient.marklm_cursor(world[0], world[1], world[2], self.table.item(rowidx, 1).text(), '', True,
                                              self.lmbutton)
            else:
                radius = int(float(radius))
                self.viewclient.marklm_cursor(world[0], world[1], world[2], self.table.item(rowidx, 1).text(), '', True,
                                              self.lmbutton, radius)
                self.table.set_row_background_color(rowidx, 'Confirm')
        else:
            self.viewclient.marklm_cursor(world[0], world[1], world[2], self.table.item(rowidx, 1).text(), '', True,
                                          self.lmbutton)
            self.table.set_row_background_color(rowidx, 'Confirm')

        self.save_table()

    def goto_item_cursor(self, Item=None):
        if Item == None:
            return
        rowidx = Item.row()
        radius = self.table.cellWidget(rowidx, self.dimension[1] - 2)
        try:
            radius = int(float(radius.text()))
        except:
            radius = ''
        self.goto_cursor(rowidx, radius)

    def goto_cursor(self, rowidx, radius=None):
        voxel = [0.0, 0.0, 0.0]
        world = [0.0, 0.0, 0.0]

        for index in range(3):
            item_w = self.table.item(rowidx, index + 5)
            if item_w == None:
                return
            world[index] = item_w.text()

        if world[0] == '' or world[0] == 'nan' or world[0] == ' ':
            return

        for index in range(3):
            item_v = self.table.item(rowidx, index + 2)
            if item_v is not None:
                voxel[index] = item_v.text()

        if voxel[0] == '-1.0':
            QMessageBox.warning(self, 'Warning', 'Landmark is not exist in image')
            return

        self.viewclient.goto(world)

        # mark landmark
        lmname = self.table.item(rowidx, 1).text()
        if lmname == '' or lmname == 'nan' or lmname == ' ' or lmname == None:
            QMessageBox.warning(self, 'Warning', 'Please define landmark name')
            return
        if self.radiusEditable:
            if radius == '' or radius == 'nan' or radius == ' ' or radius == 0:
                self.viewclient.marklm_cursor(world[0], world[1], world[2], self.table.item(rowidx, 1).text(), '', True,
                                              self.lmbutton)
            else:
                radius = int(radius)
                self.viewclient.marklm_cursor(world[0], world[1], world[2], self.table.item(rowidx, 1).text(), '', True,
                                              self.lmbutton, radius)
        else:
            self.viewclient.marklm_cursor(world[0], world[1], world[2], self.table.item(rowidx, 1).text(), '', True,
                                          self.lmbutton)

    def displaylmButtonClicked(self):
        if self.lmbutton is True:
            self.lmbutton = False
        else:
            self.lmbutton = True

        lms = self.viewclient.lms()
        for lm in lms:
            world = lms[lm]['coord']
            self.viewclient.goto(world)
            self.viewclient.marklm_cursor(world[0], world[1], world[2], lm, '', True, self.lmbutton)

    def delete_cursor(self):
        rowidx = self.table.currentRow()
        if rowidx is -1:
            QMessageBox.warning(self, 'Warning', 'Please select a row to delete')
            return
        else:
            lmname = self.table.item(rowidx, 1).text()
            if lmname in self.viewclient.lms():
                self.viewclient.removelm(lmname)
            self.table.set_row_background_color(rowidx, 'Initial')
            for index in range(6):
                self.table.setItem(rowidx, index + 2, QTableWidgetItem(''))
            if self.radiusEditable:
                self.table.cellWidget(rowidx, self.dimension[1] - 2).setText('{}'.format(''))

        self.save_table()

    def remove_all_lm(self):
        if self.viewclient.lms() == None:
            return
        for lmname in self.viewclient.lms():
            self.viewclient.removelm(lmname)

    def mark_notexist_lm(self):
        rowidx = self.table.currentRow()

        if rowidx is -1:
            QMessageBox.warning(self, 'Warning', 'Please select a row to mark')
            return

        # remove orange circle in image
        lmname = self.table.item(rowidx, 1).text()
        if lmname in self.viewclient.lms():
            self.viewclient.removelm(lmname)

        # reset landmark value in table
        for index in range(6):
            self.table.setItem(rowidx, index + 2, QTableWidgetItem('-1.0'))
        if self.radiusEditable:
            self.table.cellWidget(rowidx, self.dimension[1] - 2).setText('{}'.format('-1'))
        self.table.set_row_background_color(rowidx, 'Confirm')
        self.save_table()

    def returnCenter(self):
        self.viewclient.goto(self.initial_cursor)

    def closeEvent(self, event):
        if self.haveSaved == False:
            reply = QMessageBox.question(self, 'Warning',
                                         "You have not saved landmarks. Are you sure to quit?",
                                         QMessageBox.Yes | QMessageBox.No)
            if reply == QMessageBox.Yes:
                event.accept()
                self.viewclient.close()
                return
            else:
                event.ignore()
                return

        isfile_empty = 0

        for r in range(self.dimension[0]):
            # the last column is for add landmark button
            for c in range(self.dimension[1] - 1):
                if self.table.item(r, c) == None:
                    isfile_empty = 1
                else:
                    item = self.table.item(r, c).text()
                    if item == '' or item == 'nan' or item == None or item == ' ':
                        isfile_empty = 1
                        break

        if isfile_empty == 1:
            reply = QMessageBox.question(self, 'Warning',
                                         "The Table not finished. Are you sure to quit?", QMessageBox.Yes |
                                         QMessageBox.No, QMessageBox.No)
            if reply == QMessageBox.Yes:
                event.accept()
                self.viewclient.close()
                return
            else:
                event.ignore()
                return

        if isfile_empty == 0:
            reply = QMessageBox.question(self, 'Warning',
                                         "Are you sure to quit?", QMessageBox.Yes |
                                         QMessageBox.No, QMessageBox.No)
            if reply == QMessageBox.Yes:
                event.accept()
                self.viewclient.close()
                return
            else:
                event.ignore()
                return

    def read_imlist_from_file(self):
        # read filename
        filename = QFileDialog.getOpenFileName(self, 'Open Imlist File', filter='Imlist Files (*.txt)')
        if len(filename[0]) == 0:
            return

        filename = filename[0]
        lines = readlines(filename)
        self.imlistfile = filename
        print len(lines)
        if len(lines) < 3:
            QMessageBox.warning(self, 'Warning', 'empty/wrong file? too few lines')
            return
        self.read_imlist_from_lines(lines)

    def read_imlist_from_lines(self, lines):
        imlist = []
        statuslist = []
        casenum = int(lines[0])
        currentImg = str(lines[1])
        csvfolderpath = str(lines[2])

        if not os.path.isdir(csvfolderpath):
            QMessageBox.warning(self, 'Warning', 'Landmark File Path Not Found')
            return

        temp = str(lines[3])
        if os.path.split(temp)[1] == '':
            # dicom file
            for i in range(3):
                temp = os.path.dirname(temp)
            imgfolderpath = temp
        else:
            # mhd file
            imgfolderpath = os.path.dirname(temp)

        for i in range(casenum):
            tempstring = lines[3 + i].split(',')
            if len(tempstring) == 2:
                im_path = tempstring[0]
                status = tempstring[1]
            else:
                im_path = tempstring[0]
                status = 'Not Started'
            imlist.append(im_path)
            statuslist.append(status)

        self.imlist = imlist
        self.statuslist = statuslist

        if currentImg in imlist:
            self.imgidx = imlist.index(currentImg)
        else:
            self.imgidx = 0

        self.imgdir = imgfolderpath
        self.casenum = casenum
        self.csvdir = csvfolderpath
        imgpath = self.imlist[self.imgidx]
        self.load_img_and_csv(imgpath)
        self.create_imglist_table()
        self.imglist_table.setCurrentCell(self.imgidx, 1)

    def create_imglist_table(self):
        if self.upleftbox2.count() != 0:
            self.upleftbox2.removeWidget(self.imglist_table)
            self.imglist_table.deleteLater()
        self.imglist_table = ImgList(self.imlist, self.statuslist)
        for index in range(len(self.statuslist)):
            if self.statuslist[index] == 'Completed':
                self.imglist_table.set_row_background_color(index, 'Completed')
            if self.statuslist[index] == 'In Progress':
                self.imglist_table.set_row_background_color(index, 'In Progress')
            if self.statuslist[index] == 'Not Started':
                self.imglist_table.set_row_background_color(index, 'Not Started')

        self.imglist_table.itemselected.connect(self.set_imgidx_and_loadImg)
        self.upleftbox2.addWidget(self.imglist_table)

    def read_imlist_from_dicomfolder(self):
        self.__change_img_dir()
        if self.imgdir == '':
            return

        dicomlist = os.listdir(self.imgdir)
        dicomlist.sort()
        if dicomlist == []:
            QMessageBox.warning(self, 'Error', 'Empty folder')
            return

        imlist = {}
        n = 0
        for i in range(len(dicomlist)):
            temp = os.path.join(self.imgdir, dicomlist[i])
            if os.path.isfile(temp):  # if mhd exist, continue
                continue
            # change it to dicom folder
            if os.path.exists(temp):
                templist = os.listdir(temp)
                for j in range(len(templist)):
                    temp_path = os.path.join(temp, templist[j])
                    imlist[n] = temp_path.replace('\\', '/')
                    n = n + 1
        self.read_imlist_from_folder(imlist)

    def read_imlist_from_mhdfolder(self):
        self.__change_img_dir()
        if self.imgdir == '':
            return
        filelist = [filename for filename in os.listdir(self.imgdir) if not self.__check_is_dicom_folder(filename)]
        filelist.sort()
        if filelist == []:
            return
        imlist = {}
        for i in range(len(filelist)):
            temp = os.path.join(self.imgdir, filelist[i])
            imlist[i] = temp.replace('\\', '/')
        self.read_imlist_from_folder(imlist)

    def read_imlist_from_folder(self, imlist):
        if imlist == {}:
            return

        if self.csvdir == '':
            QMessageBox.warning(self, 'Info', 'Pelease select the csv dir first')
            self.__change_csv_dir()
            if self.csvdir == '':
                return

        # check image list file in csv folder
        tempname = 'LandmarkList_' + os.path.basename(self.imgdir) + '.txt'
        self.imlistfile = os.path.join(self.csvdir, tempname)

        if tempname in os.listdir(self.csvdir):
            lines = readlines(self.imlistfile)
            if len(lines) < 4:
                QMessageBox.warning(self, 'Error', 'empty/wrong file? too few lines')
                return

            if lines[3].split(',')[0] != imlist[0]:
                QMessageBox.warning(self, 'Error',
                                    'An image list txt is exist, but it is not match to the current folder')
                return
            self.read_imlist_from_lines(lines)
            if len(imlist) != len(self.imlist):
                QMessageBox.warning(self, 'Error', 'empty/wrong file? too few lines')
            else:
                return
        else:
            # create an image list file
            f = open(self.imlistfile, 'w')
            lines = {}
            lines[0] = str(len(imlist))
            lines[1] = str(imlist[0])
            lines[2] = str(self.csvdir)
            f.write(lines[0] + '\n')
            f.write(lines[1] + '\n')  # first image path
            f.write(lines[2] + '\n')
            for i in range(len(imlist)):
                lines[i + 3] = str(imlist[i])
                f.write(lines[i + 3] + '\n')
            f.close()
            self.read_imlist_from_lines(lines)

    def prevClicked(self):
        rows = len(self.imlist)
        if rows == 0:
            return
        self.__check_mark_done()

        if self.imgidx == 0:
            QMessageBox.information(self, 'Info', 'You have reached the beginning of image list')
            return

        self.imgidx = self.imgidx - 1
        imgpath = self.imlist[self.imgidx]
        self.load_img_and_csv(imgpath)
        self.imglist_table.setCurrentCell(self.imgidx, 1)

    def nextClicked(self):
        rows = len(self.imlist)
        if rows == 0:
            return
        self.__check_mark_done()

        if self.imgidx == rows - 1:
            QMessageBox.information(self, 'Info', 'You have reached the end of image list')
            return

        self.imgidx = self.imgidx + 1
        imgpath = self.imlist[self.imgidx]
        self.load_img_and_csv(imgpath)
        self.imglist_table.setCurrentCell(self.imgidx, 1)

    def __change_csv_dir(self):
        self.csvdir = QFileDialog.getExistingDirectory(self, 'Please select the save path')
        if self.csvdir == '':
            return
        self.headbox.setText(self.csvdir)

    def __change_img_dir(self):
        self.imgdir = QFileDialog.getExistingDirectory(self, 'Please select the image path')
        if self.imgdir == '':
            return

    def __check_is_dicom_series(self, imgpath):
        filelist = [f for f in os.listdir(imgpath) if f.endswith(".dcm")]
        if len(filelist) == 0:
            return False
        else:
            return True

    def __check_is_dicom_folder(self, imgpath):
        img_exts = ['.nii', '.nii.gz', '.mhd', '.mha', '.hdr']
        if any([imgpath.endswith(ext) for ext in img_exts]):
            return False
        else:
            return True

    def __check_mark_done(self):
        status = np.ones([self.dimension[0], self.dimension[1]], dtype=bool)
        for r in range(self.dimension[0]):
            # the last column is for add landmark button
            for c in range(self.dimension[1] - 1):
                item = self.table.item(r, c)
                if item == None:
                    status[r, c] = False
                elif item.text() == ' ' or item.text() == 'nan' or item.text() == '':
                    status[r, c] = False
                else:
                    status[r, c] = True

        if bool(status.all(axis=1).any()) is False:
            self.statuslist[self.imgidx] = 'Not Started'
            self.imglist_table.setItem(self.imgidx, 2, QTableWidgetItem('Not Started'))
            self.imglist_table.set_row_background_color(self.imgidx, 'Not Started')
            self.save_current_imgname_to_file()
            self.confirm = False
            return
        if (bool(status.all()) and self.confirm) or \
                (self.statuslist[self.imgidx] == 'Completed' and bool(status.all())):
            self.statuslist[self.imgidx] = 'Completed'
            self.imglist_table.setItem(self.imgidx, 2, QTableWidgetItem('Completed'))
            self.imglist_table.set_row_background_color(self.imgidx, 'Completed')
            self.save_current_imgname_to_file()
            self.confirm = False
            return
        if bool(status.all(axis=1).any()) is True:
            self.statuslist[self.imgidx] = 'In Progress'
            self.imglist_table.setItem(self.imgidx, 2, QTableWidgetItem('In Progress'))
            self.imglist_table.set_row_background_color(self.imgidx, 'In Progress')
            self.save_current_imgname_to_file()
            self.confirm = False

    def confirm_button_clicked(self):
        self.confirm = True
        if len(self.statuslist) == 0:
            return
        self.statuslist[self.imgidx] = 'Completed'
        self.imglist_table.setItem(self.imgidx, 2, QTableWidgetItem('Completed'))
        self.imglist_table.set_row_background_color(self.imgidx, 'Completed')
        for row in range(self.dimension[0]):
            self.table.set_row_background_color(row, 'Confirm')
        self.save_table()

    def load_model_clicked(self):
        foldername = QFileDialog.getExistingDirectory(self, 'Open Detection Model Folder',
                                                      options=QFileDialog.ShowDirsOnly | QFileDialog.DontResolveSymlinks)
        if len(foldername) == 0:
            return

        try:
            self.detmodel = autodet_load_model(foldername)
        except Exception as e:
            print e
            self.detmodel = {}
            QMessageBox.information(self, 'Info', 'Fail to load the detection model')

    def det_button_clicked(self):
        if self.im3 is None or self.imgidx < 0:
            QMessageBox.information(self, 'Info', 'Please open an image')
            return

        if self.detmodel == None:
            QMessageBox.information(self, 'Info', 'The detection model is invalid.')
            return

        # detection
        im3_copy = self.im3.deep_copy()
        _, lmlist, test_time = autodet_volume(im3_copy, self.detmodel)

        for lm_name in lmlist:
            world = [lmlist[lm_name]['x'], lmlist[lm_name]['y'], lmlist[lm_name]['z']]
            voxel = self.im3.world_to_voxel([float(world[0]), float(world[1]), float(world[2])])
            lmlist[lm_name]['voxel_x'] = voxel[0]
            lmlist[lm_name]['voxel_y'] = voxel[1]
            lmlist[lm_name]['voxel_z'] = voxel[2]
        print lmlist

        self.lmlist = lmlist

        # update table
        self.set_lm_table()

    def set_lm_table(self):

        lmlist = self.lmlist
        for rowidx in range(self.dimension[0]):
            item = self.table.item(rowidx, 1)
            lm_name = item.text()
            if lm_name in lmlist:
                voxel = lmlist[lm_name]['voxel_x'], lmlist[lm_name]['voxel_y'], lmlist[lm_name]['voxel_z']
                world = lmlist[lm_name]['x'], lmlist[lm_name]['y'], lmlist[lm_name]['z']
                world = np.round(world, 3)
                voxel = np.round(voxel, 0)
                for i in range(3):
                    self.table.setItem(rowidx, i + 2, QTableWidgetItem(str(voxel[i])))
                    self.table.setItem(rowidx, i + 5, QTableWidgetItem(str(world[i])))

    def adjust_contrast(self):
        contrast_plane = QDialog()
        # wc for window center
        wc_text = QLabel('wc:')
        wc_edit = QLineEdit(self)
        wc_edit.setText('{}'.format(self.wc))
        wc_edit.editingFinished.connect(self.wcEditingFinished)

        # ww for window width
        ww_text = QLabel('ww:')
        ww_edit = QLineEdit(self)
        ww_edit.setText('{}'.format(self.ww))
        ww_edit.editingFinished.connect(self.wwEditingFinished)

        win_layout = QHBoxLayout()
        win_layout.addWidget(wc_text)
        win_layout.addWidget(wc_edit)

        win_layout.addWidget(ww_text)
        win_layout.addWidget(ww_edit)

        contrast_layout = QVBoxLayout()
        contrast_layout.addLayout(win_layout)

        contrast_plane.setLayout(contrast_layout)
        contrast_plane.resize(300, 200)
        contrast_plane.exec_()

    def wcEditingFinished(self):

        edit = self.sender()
        try:
            self.wc = int(edit.text())

            if self.imgidx >= 0:
                self.viewclient.adjust_wcww('Img', self.wc, self.ww)

        except:
            # edit.setText('{}'.format(self.wc))
            # QMessageBox.critical(self, 'Error', 'incorrect integer for wc')
            print "Incorrect integer for window center."

    def wwEditingFinished(self):

        edit = self.sender()
        try:
            self.ww = int(edit.text())

            if self.imgidx >= 0:
                self.viewclient.adjust_wcww('Img', self.wc, self.ww)

        except:
            # edit.setText('{}'.format(self.ww))
            # QMessageBox.critical(self, 'Error', 'incorrect integer for ww')
            print "Incorrect integer for window width."

    def auto_contrast(self):
        if self.im3 is not None:
            if self.auto_ww is not None and self.auto_wc is not None:
                # use cached value if possible
                wc, ww = self.auto_wc, self.auto_ww
            else:
                # compute wc, ww
                minv, maxv = ctools.percentiles(self.im3, [0.001, 0.999])
                wc, ww = (minv + maxv) / 2.0, maxv - minv
                self.auto_wc, self.auto_ww = wc, ww

            self.wc, self.ww = int(wc), int(ww)
            self.viewclient.adjust_wcww('Img', wc, ww)


class LandMarkTable(QTableWidget):
    clicked_button = pyqtSignal(int)
    edit_finish = pyqtSignal(int, int)

    def __init__(self, dimension, radiusEditable):
        super(LandMarkTable, self).__init__()
        self.setRowCount(dimension[0])
        self.setColumnCount(dimension[1])
        self.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.setSelectionBehavior(QAbstractItemView.SelectRows)
        for index in range(dimension[0]):
            self.AddButton = QPushButton('AcceptLM', self)
            self.AddButton.clicked.connect(self.__buttonclicked)
            self.setCellWidget(index, dimension[1] - 1, self.AddButton)

        self.radius = ''
        if radiusEditable:
            for index in range(dimension[0]):
                self.radiusBox = QLineEdit()
                self.radiusBox.setText('{}'.format(self.radius))
                self.radiusBox.editingFinished.connect(self.__editfinished)
                self.setCellWidget(index, dimension[1] - 2, self.radiusBox)

    def __editfinished(self):
        edit = self.sender()
        try:
            if self.radius != int(float(edit.text())):
                self.radius = int(float(edit.text()))
                if self.radius > 0:
                    index = self.indexAt(edit.pos())
                    self.edit_finish.emit(index.row(), self.radius)
        except:
            # edit.setText('{}'.format(self.radius))
            # QMessageBox.critical(self, 'Error', 'incorrect integer for radius')
            print "incorrect integer for radius cannot goto cursor"

    def __buttonclicked(self):
        button = self.sender()
        index = self.indexAt(button.pos())
        self.clicked_button.emit(index.row())

    def set_row_background_color(self, rowIndex, status):
        col_num = self.columnCount()
        for colIndex in range(col_num):
            temp = self.item(rowIndex, colIndex)
            # .text()
            item = QTableWidgetItem(temp)
            if status == 'Confirm':
                item.setBackground(QColor(196, 226, 255))
            if status == 'Initial':
                item.setBackground(QColor(255, 255, 255))
            self.setItem(rowIndex, colIndex, item)


class ImgList(QTableWidget):
    itemselected = pyqtSignal(int, str)

    def __init__(self, imlist, statuslist):
        super(ImgList, self).__init__()
        rowNum = len(imlist)
        self.setRowCount(rowNum)
        self.setColumnCount(3)
        self.setHorizontalHeaderLabels(['ID', 'FilePath', 'Status'])
        for index in range(rowNum):
            self.setItem(index, 0, QTableWidgetItem(str(index + 1)))
            self.setItem(index, 1, QTableWidgetItem(imlist[index]))
            self.setItem(index, 2, QTableWidgetItem(statuslist[index]))
        self.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.setEditTriggers(QAbstractItemView.NoEditTriggers)
        header = self.horizontalHeader()
        for i in range(3):
            header.setSectionResizeMode(i, QHeaderView.ResizeToContents)
        self.itemDoubleClicked.connect(self.__itemselected)

    def __itemselected(self):
        rowIndex = self.currentRow()
        item = self.item(rowIndex, 1)
        if item != None:
            imgpath = item.text()
            self.itemselected.emit(rowIndex, imgpath)
        else:
            return

    def set_row_background_color(self, rowIndex, status):
        for colIndex in range(3):
            string = self.item(rowIndex, colIndex).text()
            item = QTableWidgetItem(string)
            if status == 'Completed':
                item.setBackground(QColor(196, 226, 255))
            if status == 'In Progress':
                item.setBackground(QColor(211, 211, 211))
            if status == 'Not Started':
                item.setBackground(QColor(255, 255, 255))
            self.setItem(rowIndex, colIndex, item)


if __name__ == '__main__':
    import sys

    app = QApplication(sys.argv)
    viewer = ConsoleToolbar('Annotation Tool')
    viewer.show()
    sys.exit(app.exec_())

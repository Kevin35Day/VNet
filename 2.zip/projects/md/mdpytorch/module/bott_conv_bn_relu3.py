import torch.nn as nn
from md.mdpytorch.module.conv_bn_relu3 import ConvBnRelu3


class BottConvBnRelu3(nn.Module):
    """Bottle neck structure"""

    def __init__(self, channels, ratio, do_act=True):
        super(BottConvBnRelu3, self).__init__()
        self.conv1 = ConvBnRelu3(channels, channels/ratio, ksize=1, padding=0, do_act=True)
        self.conv2 = ConvBnRelu3(channels/ratio, channels/ratio, ksize=3, padding=1, do_act=True)
        self.conv3 = ConvBnRelu3(channels/ratio, channels, ksize=1, padding=0, do_act=do_act)

    def forward(self, input):
        out = self.conv3(self.conv2(self.conv1(input)))
        return out

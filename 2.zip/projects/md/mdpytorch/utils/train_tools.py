import random
from torch.utils.data.sampler import Sampler


class EpochConcateSampler(Sampler):
    """Concatenate  all epoch index arrays into one index array.

    Arguments:
        data_source (Dataset): dataset to sample from
        epoch(int): epoch num
    """

    def __init__(self, data_source, epoch):
        self.data_length = len(data_source)
        self.epoch = epoch

    def __iter__(self):
        index_all = []
        for i in range(self.epoch):
            index = range(self.data_length)
            random.shuffle(index)
            index_all += index
        return iter(index_all)

    def __len__(self):
        return self.data_length * self.epoch

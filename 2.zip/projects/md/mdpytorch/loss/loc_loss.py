import torch
from torch.autograd import Variable
from torch import nn


class LocLoss(nn.Module):

    def __init__(self, class_num, lamda):
        super(LocLoss, self).__init__()
        self.class_num = class_num
        self.lamda = torch.FloatTensor(lamda)

    def forward(self, input, target):
        assert input.dim() == 2 and target.dim() == 2
        assert input.size()[1] == self.class_num + (self.class_num - 1) * 3
        assert target.size()[1] == 4

        ground_truth_labels = target[:, 0].data

        loss = Variable(torch.FloatTensor([0]), requires_grad=False)
        loss = loss.cuda()

        for sampleIndex in range(0, input.size()[0]):
          GtLabel = ground_truth_labels[sampleIndex]
          if GtLabel != 0:
            channel_start = int(self.class_num + (GtLabel - 1) * 3)
            for axisIndex in range(0,3):
              dif = input[sampleIndex, channel_start + axisIndex] - \
                    target[sampleIndex,1 + axisIndex]
              if (dif.data.abs())[0] < 1.0:
                loss += 0.5 * dif * dif
              else:
                loss += (torch.abs(dif) - 0.5)

        lamda = Variable(self.lamda, requires_grad=False)
        lamda = lamda.cuda()

        return lamda * loss

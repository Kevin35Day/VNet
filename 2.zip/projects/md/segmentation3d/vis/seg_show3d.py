import vtk
import os


def read_image(filename):

    if filename.endswith('.nii') or filename.endswith('.nii.gz'):
        reader = vtk.vtkNIFTIImageReader()
    elif filename.endswith('.mhd') or filename.endswith('.mha'):
        reader = vtk.vtkMetaImageReader()
    else:
        raise ValueError('Unknown file extention')

    reader.SetFileName(filename)
    reader.Update()
    return reader


def object_actor(seg_reader, label, color, opacity):

    # extract surface from vtk image
    obj_surf = vtk.vtkDiscreteMarchingCubes()
    obj_surf.SetInputConnection(seg_reader.GetOutputPort())
    obj_surf.ComputeNormalsOn()
    obj_surf.SetValue(0, label)

    surf_smoother = vtk.vtkWindowedSincPolyDataFilter()
    surf_smoother.SetInputConnection(obj_surf.GetOutputPort())
    surf_smoother.SetNumberOfIterations(15)
    surf_smoother.BoundarySmoothingOff()
    surf_smoother.FeatureEdgeSmoothingOff()
    surf_smoother.SetFeatureAngle(120.0)
    surf_smoother.SetPassBand(0.001)
    surf_smoother.NonManifoldSmoothingOn()
    surf_smoother.NormalizeCoordinatesOn()

    obj_mapper = vtk.vtkPolyDataMapper()
    obj_mapper.SetInputConnection(surf_smoother.GetOutputPort())
    obj_mapper.ScalarVisibilityOff()

    obj_actor = vtk.vtkLODActor()
    obj_actor.SetNumberOfCloudPoints(1000000)
    obj_actor.SetMapper(obj_mapper)
    obj_actor.GetProperty().SetColor(color[0], color[1], color[2])
    obj_actor.GetProperty().SetOpacity(opacity)

    return obj_actor


class vtkTimerCallback():

    def __init__(self, start_slice, end_slice, slice_incre, rotate_incre, ending_frames,
                 render_win, plane_widget, camera, save_frames):

        self.current_slice = start_slice
        self.start_slice = start_slice
        self.end_slice = end_slice
        self.slice_incre = slice_incre
        self.rotate_incre = rotate_incre
        self.ending_frames = ending_frames
        self.save_frames = save_frames

        if end_slice < start_slice:
            self.slice_incre = - self.slice_incre

        self.rotate_angle = 0
        self.count = 0
        self.ending_count = 0

        self.screensaver = vtk.vtkWindowToImageFilter()
        self.screensaver.SetInput(render_win)

        self.screenwriter = vtk.vtkPNGWriter()
        self.screenwriter.SetInputConnection(self.screensaver.GetOutputPort())

        self.plane_widget = plane_widget
        self.camera = camera

    def save_screen(self):

        folder_name = 'screenshots'
        if not os.path.isdir(folder_name):
            os.mkdir(folder_name)

        self.screensaver.Modified()
        filename = '{}/im.{:04d}.png'.format(folder_name, self.count)
        self.screenwriter.SetFileName(filename)
        self.screenwriter.Write()

    def execute(self, obj, event):

        iren = obj

        # first animation stage
        if (self.slice_incre > 0 and self.current_slice <= self.end_slice) \
                or (self.slice_incre < 0 and self.current_slice >= self.end_slice):

            self.plane_widget.SetSliceIndex(self.current_slice)
            self.current_slice += self.slice_incre

        # second rotate around
        elif self.rotate_angle < 360:

            self.plane_widget.EnabledOff()
            self.camera.Azimuth(self.rotate_incre)
            self.rotate_angle += self.rotate_incre

        # last ending pose
        elif self.ending_count < self.ending_frames:

            self.ending_count += 1

        # clean and destroy window
        else:
            iren.DestroyTimer()
            iren.GetRenderWindow().Finalize()
            iren.TerminateApp()
            return

        # render
        iren.GetRenderWindow().Render()

        if self.save_frames:
            self.save_screen()

        self.count += 1


if __name__ == '__main__':

    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('-i', '--input',
                        default='/home/ubuntu2/data/abdomen/0001/image.nii.gz',
                        help='intensity volume image')

    parser.add_argument('-s', '--seg',
                        default='/home/ubuntu2/data/abdomen/0001/kidney_left.nii.gz',
                        help='segmentation volume image')

    parser.add_argument('-d', '--direction', type=int,
                        default=1,
                        help='0 for sagittal, 1 for coronal, 2 for axial')

    parser.add_argument('--level', type=int,
                        default=-50,
                        help='window level')

    parser.add_argument('--window', type=int,
                        default=500,
                        help='window width')

    parser.add_argument('--camera-offset', type=float,
                        default=1000,
                        help='camera offset from image center')

    parser.add_argument('--save', type=bool,
                        default=False,
                        help='True to save frames')

    args = parser.parse_args()

    im_reader = read_image(args.input)
    seg_reader = read_image(args.seg)

    im_width, im_height, im_depth = im_reader.GetOutput().GetDimensions()
    im_sizes = [im_width, im_height, im_depth]
    im_spacing = im_reader.GetOutput().GetSpacing()
    im_origin = im_reader.GetOutput().GetOrigin()
    im_center = [0, 0, 0]
    im_center[0] = im_origin[0] + im_spacing[0] * im_width / 2.0
    im_center[1] = im_origin[1] + im_spacing[1] * im_height / 2.0
    im_center[2] = im_origin[2] + im_spacing[2] * im_depth / 2.0
    view_focus = [im_center[0], im_center[1], im_center[2]]

    view_pos = im_center
    view_up = [0, 0, 1]
    if args.direction >= 0 and args.direction <= 2:
        view_pos[args.direction] += args.camera_offset

        if args.direction == 0 or args.direction == 1:
            view_up = [0, 0, 1]
        else:
            view_up = [0, -1, 0]
    else:
        raise ValueError('invalid scrolling direction')

    seg_width, seg_height, seg_depth = seg_reader.GetOutput().GetDimensions()
    if im_width != seg_width or im_height != seg_height or im_depth != seg_depth:
        raise ValueError('image and segmentation size mismatch')

    im_low, im_high = im_reader.GetOutput().GetScalarRange()
    print "Range of image: %d--%d" % (im_low, im_high)

    seg_low, seg_high = seg_reader.GetOutput().GetScalarRange()
    print "Range of segmented image: %d--%d" %(seg_low, seg_high)

    # renderer and render window
    volume_width = int(im_width * im_spacing[0] + 0.5)
    volume_height = int(im_height * im_spacing[1] + 0.5)
    volume_depth = int(im_depth * im_spacing[2] + 0.5)

    win_width = 512
    if args.direction == 0:
        win_height = win_width * volume_depth / volume_height
    elif args.direction == 1:
        win_height = win_width * volume_depth / volume_width
    elif args.direction == 2:
        win_height = win_width * volume_height / volume_width
    else:
        raise ValueError('invalid scrolling direction')

    ren = vtk.vtkRenderer()
    ren.SetBackground(.2, .2, .2)
    renWin = vtk.vtkRenderWindow()
    renWin.SetSize(win_width, win_height)
    renWin.AddRenderer(ren)

    iren = vtk.vtkRenderWindowInteractor()
    iren.SetRenderWindow(renWin)

    # use same picker for all
    picker = vtk.vtkCellPicker()
    picker.SetTolerance(0.005)

    plane_widget = vtk.vtkImagePlaneWidget()
    plane_widget.SetPicker(picker)
    plane_widget.SetInputData(im_reader.GetOutput())
    plane_widget.SetWindowLevel(args.window, args.level)
    plane_widget.SetCurrentRenderer(ren)
    plane_widget.SetInteractor(iren)
    plane_widget.PlaceWidget()

    if args.direction == 0:
        plane_widget.SetPlaneOrientationToXAxes()
        start_slice = im_width - 1
        end_slice = 0
        plane_widget.SetSliceIndex(start_slice)
    elif args.direction == 1:
        plane_widget.SetPlaneOrientationToYAxes()
        start_slice = im_height - 1
        end_slice = 0
        plane_widget.SetSliceIndex(start_slice)
    elif args.direction == 2:
        plane_widget.SetPlaneOrientationToZAxes()
        start_slice = im_depth - 1
        end_slice = 0
        plane_widget.SetSliceIndex(start_slice)
    else:
        raise ValueError('invalid scrolling axes')

    plane_widget.DisplayTextOn()
    plane_widget.EnabledOn()

    label_colors = {1: [1, 0, 0],
                    2: [0, 1, 0],
                    3: [0, 0, 1],
                    4: [1, 1, 0],
                    5: [1, 0, 1],
                    6: [0, 1, 1],
                    7: [0.5,   0,   0],
                    8: [  0, 0.5,   0],
                    9: [  0,   0, 0.5],
                    11:[0.5, 0.5,   0],
                    12:[0.5,   0, 0.5],
                    13:[  0, 0.5, 0.5]}

    for label in range(1, int(seg_high+1)):
        actor = object_actor(seg_reader, label, label_colors[label], 1.0)
        ren.AddActor(actor)

    camera = ren.GetActiveCamera()
    camera.SetPosition(view_pos[0], view_pos[1], view_pos[2])
    camera.SetFocalPoint(view_focus[0], view_focus[1], view_focus[2])
    camera.ComputeViewPlaneNormal()
    camera.SetViewUp(view_up[0], view_up[1], view_up[2])
    camera.SetClippingRange(0.1, 99999)

    renWin.Render()
    iren.Initialize()

    cb = vtkTimerCallback(start_slice=start_slice,
                          end_slice=end_slice,
                          slice_incre=1,
                          rotate_incre=1,
                          ending_frames=10,
                          render_win=renWin,
                          plane_widget=plane_widget,
                          camera=camera,
                          save_frames=args.save)

    iren.AddObserver('TimerEvent', cb.execute)
    iren.CreateRepeatingTimer(2)
    iren.Start()

from vseg_test import test as vnet_test

if __name__ == '__main__':
    # input = '/home/mfh/organs/bladder_v1/test1.txt'
    # model = '/home/mfh/organs/bladder_v1'
    # output = '/mnt/disk/mfh_Data/test_392_0412'
    #
    # vnet_test(input, model, output, gpu_id=3)

    # input = '/home/mfh/organs/test_Aorta.txt'
    # model = '/home/mfh/organs/femur_left_v3'
    # output = '/mnt/disk/mfh_Data/test_femur_left_Aorta'
    #
    # vnet_test(input, model, output, gpu_id=3)

    input = '/home/mfh/organs/test_Aorta_1.txt'
    model = '/home/mfh/organs/femur_right_v1'
    output = '/mnt/disk/mfh_Data/test_femur_right_Aorta'

    vnet_test(input, model, output, gpu_id=3)
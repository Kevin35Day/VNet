import torch
import md
import os
import shutil
from md.neuro.python.neuro_tools import NeuroFile
from md.segmentation3d.utils.vseg_helpers import last_checkpoint
import numpy as np


def convert_str_to_bytearray(input, bytearray_len):
    """
    convert string to byte array of given size
    :param input: input string
    :param bytearray_len: length of byte array
    :return: a byte array with fixed len and filled content
    """
    assert bytearray_len > len(input), 'length of byte array must be >= input'
    buffer = bytearray(bytearray_len)
    buffer[:len(input)] = input
    return buffer


def convert_paramfile_to_neuro(input_path, output_path):
    """
    convert a pytorch parameter file to neuro file format

    version #: x.y.z
    x stands for neuro file format version
    y stands for application number
    z stands for sub-version in each application

    :param input_path   pth file
    :param output_path  the output neuro file
    """
    params = torch.load(input_path)
    neuro_file = NeuroFile('1.0.1')

    # save network name into a 128-length byte array
    netname_bytes = convert_str_to_bytearray(params['net'], 128)
    neuro_file.put_key('net', netname_bytes)

    neuro_file.put_key('epoch', params['epoch'])
    neuro_file.put_key('spacing', np.array(params['spacing'], dtype=np.float32))
    neuro_file.put_key('batch', params['batch'])
    neuro_file.put_key('max_stride', int(params['max_stride']))

    normalizer = params['crop_normalizer']
    normalizer['type'] = 0
    if normalizer['type'] == 0:
        neuro_file.put_key('normalizer.type', 0)
        neuro_file.put_key('fixed_normalizer.mean', float(normalizer['mean']))
        neuro_file.put_key('fixed_normalizer.stddev', float(normalizer['stddev']))
        neuro_file.put_key('fixed_normalizer.clip', 1 if normalizer['clip'] else 0)

    elif normalizer['type'] == 1:
        neuro_file.put_key('normalizer.type', 1)
        neuro_file.put_key('adaptive_normalizer.min_p', float(normalizer['min_p']))
        neuro_file.put_key('adaptive_normalizer.max_p', float(normalizer['max_p']))
        neuro_file.put_key('adaptive_normalizer.clip', 1 if normalizer['clip'] else 0)

    else:
        raise ValueError('Unknown Crop Normalizer')

    # network params
    for key, value in params['state_dict'].iteritems():
        neuro_file.put_key(key, value)

    neuro_file.write(output_path)


def convert_pymodel_to_neuro(model_dir):
    """
    convert pytorch model (coarse+fine) to neuro model

    :param model_dir: model directory
    :return: None
    """
    ini_file = os.path.join(model_dir, 'params.ini')
    assert os.path.isfile(ini_file), 'params ini not found in model folder'

    deploy_folder = os.path.join(model_dir, 'deploy')
    if not os.path.isdir(deploy_folder):
        os.makedirs(deploy_folder)

    coarse_chk_folder = last_checkpoint(os.path.join(model_dir, 'coarse', 'checkpoints'))
    convert_paramfile_to_neuro(os.path.join(coarse_chk_folder, 'params.pth'),
                               os.path.join(deploy_folder, 'coarse.neuro'))

    fine_chk_folder = last_checkpoint(os.path.join(model_dir, 'fine', 'checkpoints'))
    convert_paramfile_to_neuro(os.path.join(fine_chk_folder, 'params.pth'),
                               os.path.join(deploy_folder, 'fine.neuro'))

    shutil.copy(ini_file, deploy_folder)


if __name__ == '__main__':

    model_dir = '/home/ubuntu2/projects/organs/v2.0/spleen'
    convert_pymodel_to_neuro(model_dir)

import os
import numpy as np
from torch.utils.data import Dataset
from md.utils.python.file_tools import readlines
import md.image3d.python.image3d_io as cio
import md.image3d.python.image3d_tools as ctools
from md.mdpytorch.utils.tensor_tools import ToTensor


def read_imlist_file(imlist_file):
    """
    read image list file
    :param imlist_file: image list file path
    :return: list of image paths, list of segmentation paths
    """
    lines = readlines(imlist_file)
    ncases = int(lines[0])

    if len(lines)-1 < ncases * 2:
        raise ValueError('too few lines in imlist_file')

    im_list, seg_list = [], []
    for i in range(ncases):
        im_path, seg_path = lines[1 + i * 2], lines[2 + i * 2]
        if not os.path.isfile(im_path):
            raise ValueError('image not exist: {}'.format(im_path))
        if not os.path.isfile(seg_path):
            raise ValueError('seg not exist: {}'.format(seg_path))
        im_list.append(im_path)
        seg_list.append(seg_path)

    return im_list, seg_list


class SingleSegDataset(Dataset):
    """
    training dataset for single-organ segmentation

    The input image list file is as follows:

    N
    path_of_image1
    path_of_seg1
    ...
    path_of_imageN
    path_of_segN
    """
    def __init__(self, imlist_file, label, spacing, cropsize, sampling_method, box_pad_voxel,
                 crop_always_in, cropper, crop_normalizer):
        """
        constructor
        :param imlist_file: image-segmentation list file
        :param label: organ label in the label map
        :param spacing: the resolution
        :param cropsize: crop size
        :param sampling_method: 0 for global random, 1 for mask box, 2 for mask
        :param box_pad_voxel: the number of voxels for box padding
        :param crop_always_in: whether to force the crop always in the image
        :param cropper: used to crop a patch from image
        :param crop_normalizer: used to normalize the image crop
        """
        self.im_list, self.seg_list = read_imlist_file(imlist_file)
        self.label = label
        self.spacing = np.array(spacing, dtype=np.double)
        self.cropsize = np.array(cropsize, dtype=np.int32)
        self.sampling_method = sampling_method
        self.box_pad_voxel = box_pad_voxel
        self.crop_always_in = crop_always_in
        self.cropper = cropper
        self.crop_normalizer = crop_normalizer
        assert self.spacing.size == 3, 'only 3-element of spacing is supported'

    def __len__(self):
        """ get the number of images in this dataset """
        return len(self.im_list)

    def random_image_crop(self, image):
        """
        random sample a crop in the entire image space
        :param image: an image3d object
        :return: crop center coordinate
        """
        image_size = image.size()
        sp = np.array([0, 0, 0], dtype=np.int32)
        for i in range(3):
            if image_size[i] > self.cropsize[i]:
                sp[i] = np.random.randint(0, image_size[i] - self.cropsize[i] + 1)
        center = sp + np.array(self.cropsize, dtype=np.int32) // 2
        return center

    def random_box_crop(self, image, minbox, maxbox):
        """
        random sample a crop in the bounding box
        :param image: an image3d object
        :param minbox: minimum coord of box
        :param maxbox: maximum coord of box
        :return: crop center coordinate
        """
        imsize = image.size()
        cropsize = np.array(self.cropsize, dtype=np.int32)

        # calculate the padded bounding box
        minbox = minbox - self.box_pad_voxel
        maxbox = maxbox + self.box_pad_voxel

        if self.crop_always_in:
            # calculate the maximum bounding box of image
            # in order to avoid padding
            im_minbox = np.array([0, 0, 0], dtype=np.int32)
            im_minbox = im_minbox + cropsize // 2
            im_maxbox = imsize - 1
            im_maxbox = im_maxbox - (cropsize - cropsize // 2 - 1)

            # check whether the volume is too small to hold the entire crop
            small = im_minbox > im_maxbox

            # adjust padded bounding box to be within max image box
            for i in range(3):
                if not small[i]:
                    minbox[i] = np.clip(minbox[i], im_minbox[i], im_maxbox[i])
                    maxbox[i] = np.clip(maxbox[i], im_minbox[i], im_maxbox[i])

            # random a crop center
            center = np.empty((3,), dtype=np.int32)
            for i in range(3):
                if small[i]:
                    # if too small, start from the edge
                    center[i] = cropsize[i] // 2
                else:
                    center[i] = np.random.randint(minbox[i], maxbox[i] + 1)

        else:
            # make sure the sampling box in the image domain
            for i in range(3):
                minbox[i] = np.clip(minbox[i], 0, imsize[i]-1)
                maxbox[i] = np.clip(maxbox[i], 0, imsize[i]-1)

            # random a center point in the sampling box
            center = np.empty((3,), dtype=np.int32)
            for i in range(3):
                center[i] = np.random.randint(minbox[i], maxbox[i] + 1)

        return center

    def random_sample(self, seg):

        # global random sampling
        if self.sampling_method == 0:
            center = self.random_image_crop(seg)

        # random sample a crop on the padded box space
        elif self.sampling_method == 1:
            minbox, maxbox = ctools.bounding_box_voxel(seg, self.label, self.label)

            # if there is no specified label, return a random crop
            if minbox is None or maxbox is None:
                center = self.random_image_crop(seg)
            else:
                center = self.random_box_crop(seg, minbox, maxbox)

        # random sampling center on selected mask
        elif self.sampling_method == 2:
            center = ctools.random_voxels(seg, 1, self.label ,self.label)

            # if there is no specified label, return a random crop
            if len(center) == 0:
                center = self.random_image_crop(seg)
            else:
                center = center[0]

        else:
            raise ValueError('Unknown sampling method')

        return center

    def __getitem__(self, index):

        image_path = self.im_list[index]
        seg_path = self.seg_list[index]

        # sub-folder name as casename
        casename = os.path.basename(os.path.dirname(image_path))
        casename += '_' + os.path.basename(image_path)

        im = cio.read_image(image_path, dtype=np.float32)
        seg = cio.read_image(seg_path, dtype=np.int16)

        # resample into the canonical space
        im = ctools.resample_volume_nn_rai(im, self.spacing)
        seg = ctools.resample_volume_nn_rai(seg, self.spacing)

        # random sample a voxel
        voxel = self.random_sample(seg)
        world_coord = seg.voxel_to_world(voxel)

        # get an image and segmentation crop
        im, seg = self.cropper(im, seg, world_coord)
        ctools.convert_multi_label_to_binary(seg, self.label)

        frame = im.frame().to_numpy()

        if self.crop_normalizer is not None:
            self.crop_normalizer(im)

        # convert to tensors
        im = ToTensor()(im)
        seg = ToTensor()(seg)

        return im, seg, frame, casename


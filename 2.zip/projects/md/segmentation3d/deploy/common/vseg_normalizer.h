#ifndef VSEG_NORMALIZER_H
#define VSEG_NORMALIZER_H

#include "image3d/csrc/image3d.h"
#include "image3d/csrc/image3d_tools.h"


namespace medvision {


template <typename T>
class Normalizer
{
public:
    virtual ~Normalizer() {}
    virtual void normalize(Image3d& im) const = 0;
};


template <typename T>
class FixedNormalizer: public Normalizer<T>
{
public:
    FixedNormalizer(double mean, double stddev, bool clip=false);
    ~FixedNormalizer();
    void normalize(Image3d& im) const;
private:
    double m_mean, m_stddev;
    bool m_clip;
};


template <typename T>
class AdaptiveNormalizer: public Normalizer<T>
{
public:
    AdaptiveNormalizer(double min_p, double max_p, bool clip=true);
    ~AdaptiveNormalizer();
    void normalize(Image3d& im) const;
private:
    double m_min_p, m_max_p;
    bool m_clip;
};


// implementation
template <typename T>
FixedNormalizer<T>::FixedNormalizer(double mean, double stddev, bool clip)
{
    m_mean = mean;
    m_stddev = stddev;
    m_clip = clip;
}

template <typename T>
FixedNormalizer<T>::~FixedNormalizer()
{
}

template <typename T>
void FixedNormalizer<T>::normalize(Image3d& im) const
{
    intensity_normalize<T>(im, m_mean, m_stddev, m_clip);
}

template <typename T>
AdaptiveNormalizer<T>::AdaptiveNormalizer(double min_p, double max_p, bool clip)
{
    m_min_p = min_p;
    m_max_p = max_p;
    m_clip = clip;
}

template <typename T>
AdaptiveNormalizer<T>::~AdaptiveNormalizer()
{

}

template <typename T>
void AdaptiveNormalizer<T>::normalize(Image3d& im) const
{
    const size_t len = 2;
    double percents[] = {m_min_p, m_max_p};
    double values[len];
    percentiles<T>(im, percents, len, values);

    double normalize_mean = (values[0] + values[1]) / 2.0;
    double normalize_stddev = (values[1] - values[0]) / 2.0;
    intensity_normalize<T>(im, normalize_mean, normalize_stddev, m_clip);
}


}

#endif

#include "segmentation3d/deploy/common/vseg_errors.h"


namespace medvision {

const char* vsegGetErrorString(vsegError_t errcode)
{
    switch(errcode) {
    case VSEG_Success:              return "VSEG_Success";
    case VSEG_ModelIOError:         return "VSEG_ModelIOError";
    case VSEG_UnknownNormalizer:    return "VSEG_UnknownNormalizer";
    case VSEG_INIError:             return "VSEG_INIError";
    case VSEG_INIParseError:        return "VSEG_INIParseError";
    case VSEG_NotFloatData:         return "VSEG_NotFloatData";
    case VSEG_NotImplemented:       return "VSEG_NotImplemented";
    case VSEG_BigVolumeError:       return "VSEG_BigVolumeError";
    case VSEG_TypeCastError:        return "VSEG_TypeCastError";
    case VSEG_ContextError:         return "VSEG_ContextError";
    case VSEG_NetError:             return "VSEG_NetError";
    case VSEG_InputError:           return "VSEG_InputError";
    case VSEG_ChannelError:         return "VSEG_ChannelError";
    case VSEG_NoSegmentation:       return "VSEG_NoSegmentation";
    case VSEG_EmptyTensor:          return "VSEG_EmptyTensor";
    case VSEG_NeuroError:           return "VSEG_NeuroError";
    case VSEG_CudaError:            return "VSEG_CudaError";
    case VSEG_CudnnError:           return "VSEG_CudnnError";
    case VSEG_UnknownError:         return "VSEG_UnknownError";
    case VSEG_WrongCudaVersion:     return "VSEG_WrongCudaVersion";
    case VSEG_WrongCudnnVersion:    return "VSEG_WrongCudnnVersion";
    case VSEG_WrongOutPixelType:    return "VSEG_WrongOutPixelType";
    case VSEG_NullOutputPointer:    return "VSEG_NullOutputPointer";
    case VSEG_FieldLengthError:     return "VSEG_FieldLengthError";
    default:                        return "VSEG_Unknown";
    }
}


}

#ifndef VSEG_ERRORS_H
#define VSEG_ERRORS_H

#include <string>

namespace medvision {

enum vsegError_t {

    VSEG_Success                = 0,
    VSEG_ModelIOError           = 1,
    VSEG_UnknownNormalizer      = 2,
    VSEG_INIError               = 3,
    VSEG_INIParseError          = 4,
    VSEG_NotFloatData           = 5,
    VSEG_NotImplemented         = 6,
    VSEG_BigVolumeError         = 7,
    VSEG_TypeCastError          = 8,
    VSEG_ContextError           = 9,
    VSEG_NetError               = 10,
    VSEG_InputError             = 11,
    VSEG_ChannelError           = 12,
    VSEG_NoSegmentation         = 13,
    VSEG_EmptyTensor            = 14,
    VSEG_NeuroError             = 15,
    VSEG_CudaError              = 16,
    VSEG_CudnnError             = 17,
    VSEG_UnknownError           = 18,
    VSEG_WrongCudaVersion       = 19,
    VSEG_WrongCudnnVersion      = 20,
    VSEG_WrongOutPixelType      = 21,
    VSEG_NullOutputPointer      = 22,
    VSEG_FieldLengthError       = 23
};

// vseg get error string
const char* vsegGetErrorString(vsegError_t code);


#define checkVSEG(status) do {                                                      \
    vsegError_t err_code = status;                                                  \
    if (err_code != VSEG_Success) {                                                 \
        return err_code;                                                            \
    }                                                                               \
} while(0)


}


#endif

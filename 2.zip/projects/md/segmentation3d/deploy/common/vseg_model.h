#ifndef VSEG_MODEL_H
#define VSEG_MODEL_H

#include <unordered_map>
#include <memory>
#include "neuro/csrc/io.h"
#include "math/vec3d.h"
#include "segmentation3d/deploy/common/vseg_normalizer.h"
#include "segmentation3d/deploy/common/vseg_errors.h"

namespace medvision {


/*! \brief segmentation model for single resolution
 *
 *  Load a single neuro file
 */
class VSegModel
{
public:
    typedef std::unordered_map<std::string, void*> ParamDictType;

    VSegModel();
    ~VSegModel();

    /*! \brief load a neuro file from disk */
    vsegError_t load_model(const char* filepath);

    /*! \brief release the loaded model */
    void release_model();

    /*! \brief get the pointer of parameter device buffer */
    inline const void* param_ptr() const { return m_device_param_buffer; }

    /*! \brief get parameter dictionary */
    inline const ParamDictType* param_dict() const { return &m_device_ptrs; }

    /*! \brief get spacing */
    inline vec3d<double> spacing() const { return m_spacing; }

    /*! \brief maximum stride */
    inline int max_stride() const { return m_max_stride; }

    /*! \brief get normalizer */
    const Normalizer<float>* normalizer() const { return m_normalizer.get(); }

    /*! \brief get network name */
    std::string netname() const { return m_netname; }

private:

    // read non-neural-network parameters from page-locked memory
    vsegError_t read_params(const NeuroFile& file, const void* in_ptr);

    // a continuous device buffer for all parameters in pth file
    void* m_device_param_buffer;

    // a dictionary from parameter name to device buffer pointer
    std::unordered_map<std::string, void*> m_device_ptrs;

    // spacing
    vec3d<double> m_spacing;

    // maximum stride
    int m_max_stride;

    // crop normalizer
    std::unique_ptr< Normalizer<float> > m_normalizer;

    // network name
    std::string m_netname;
};


}

#endif

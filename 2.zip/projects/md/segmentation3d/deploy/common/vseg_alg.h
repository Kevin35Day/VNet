#ifndef VSEG_ALG_H
#define VSEG_ALG_H

#include <unordered_map>
#include <memory>
#include "image3d/csrc/image3d.h"
#include "neuro/csrc/io.h"
#include "segmentation3d/deploy/network/vnet3.h"
#include "segmentation3d/deploy/network/vbnet3.h"
#include "segmentation3d/deploy/network/vbbnet3.h"
#include "segmentation3d/deploy/common/vseg_errors.h"
#include "segmentation3d/deploy/common/vseg_normalizer.h"
#include "segmentation3d/deploy/common/vseg_model.h"


namespace medvision {


/*! \brief device switcher */
class DeviceSwitcher
{
public:
    DeviceSwitcher(int gpu_id);
    ~DeviceSwitcher();

private:
    int m_orig_gpu_id;
};



/*! \brief volumetric segmentation algorithm  */
class VSegAlg
{
public:

    /*! \brief constructor
     *
     *  \param gpu_id       which gpu to run algorithm
     */
    VSegAlg(int gpu_id=0);

    /*! \brief destructor */
    ~VSegAlg();

    /*! \brief load coarse and fine models and networks from disk
     *
     *  folder -
     *         - coarse.neuro
     *         - fine.neuro
     *         - params.ini
     *
     *  \param folder   the folder containing coarse and fine models
     */
    vsegError_t load(const char* folder);

    /*! \brief release models and networks */
    void release();

    /*! \brief segment an image
     *
     *  \param im           the input image
     *  \param im_slope     intensity rescale to HU
     *  \param im_intercept intensity rescale to HU
     *  \param seg          the output segmentation
     *  \param box_center   center of bounding box (mm)
     *  \param box_size     bounding box size (mm)
     *  \param out_alloc    whether to allocate the buffer for seg
     */
    vsegError_t segment(const Image3d& im, float im_slope, float im_intercept, Image3d& seg, vec3d<double>& box_center, vec3d<double>& box_size, bool out_alloc=true);

private:

    /*! \brief check whether cuda and cudnn runtime version is correct */
    vsegError_t check_version() const;

    /*! \brief read parameters from ini file */
    vsegError_t read_ini_params(const char* ini_file);

    /*! \brief create network architecture */
    vsegError_t create_network(const std::string& netname, int in_channels, NetworkModule** network);

    /*! \brief release network architecture */
    void release_networks();

    /*! \brief convert CT value to HU value */
    vsegError_t CT_to_HU(Image3d& im, float im_slope, float im_intercept);

    /*! \brief network forward pass */
    vsegError_t network_forward(Image3d& im, NetworkModule* net, Image3d& mask);

    /*! \brief compute segmentation box and size in mm */
    vsegError_t compute_target_pos_and_size(const Image3d& mask, vec3d<int>& minbox_voxel, vec3d<int>& maxbox_voxel,
                                            vec3d<double>& center, vec3d<double>& size);

    /*! \brief segmentation on single scale */
    vsegError_t segment_(const Image3d& im,
                         float im_slope,
                         float im_intercept,
                         VSegModel& model,
                         NetworkModule* net,
                         Image3d& out,
                         const Image3d* prev_seg = nullptr);

    // cudnn handles
    cudnnHandle_t m_cudnn_handle;
    int m_gpu_id;

    // system parameters
    vec3d<double> m_padmm;
    vec3d<int> m_maxcropsize;

    // model parameters
    VSegModel m_coarse_model, m_fine_model;

    // network architecture
    NetworkModule* m_coarse_net, *m_fine_net;

};


}

#endif

#include "segmentation3d/deploy/network/vbbnet3.h"
#include "neuro/csrc/errors.h"

namespace medvision {

#define V(x) vec3d<int>(x,x,x)

// VBBNet3

VBBNet3::VBBNet3(int in_channels, int ksize, int pad): m_name("module"),
    m_d1(m_name + std::string(".pre_block"), "conv", "bn", in_channels, in_channels, V(2), V(2), V(0)),
    m_d16(m_name + std::string(".in_block"), "conv", "bn", in_channels, 16, V(ksize), V(1), V(pad)),
    m_d32(m_name + std::string(".down_32"), "down_conv", "down_bn", 16, 32, V(2), V(2)),
    m_dr32(m_name + std::string(".down_32.rblock"), "conv", "bn", 1, 32, ksize, pad),
    m_d64(m_name + ".down_64", "down_conv", "down_bn", 32, 64, V(2), V(2)),
    m_dr64(m_name + ".down_64.rblock", "conv1", "conv2", "conv3", 2, 64, ksize, pad),
    m_d128(m_name + ".down_128", "down_conv", "down_bn", 64, 128, V(2), V(2)),
    m_dr128(m_name + ".down_128.rblock", "conv1", "conv2", "conv3", 3, 128, ksize, pad),
    m_d256(m_name + ".down_256", "down_conv", "down_bn", 128, 256, V(2), V(2)),
    m_dr256(m_name + ".down_256.rblock", "conv1", "conv2", "conv3", 3, 256, ksize, pad),
    m_u256(m_name + ".up_256", "up_conv", "up_bn", 256, 128, V(2), V(2)),
    m_ur256(m_name + ".up_256.rblock", "conv1", "conv2", "conv3", 3, 256, ksize, pad),
    m_u128(m_name + ".up_128", "up_conv", "up_bn", 256, 64, V(2), V(2)),
    m_ur128(m_name + ".up_128.rblock", "conv1", "conv2", "conv3", 3, 128, ksize, pad),
    m_u64(m_name + ".up_64", "up_conv", "up_bn", 128, 32, V(2), V(2)),
    m_ur64(m_name + ".up_64.rblock", "conv", "bn", 2, 64, ksize, pad),
    m_u32(m_name + ".up_32", "up_conv", "up_bn", 64, 16, V(2), V(2)),
    m_ur32(m_name + ".up_32.rblock", "conv", "bn", 1, 32, ksize, pad),
    m_u2_32(m_name + ".pro_block", "conv1", "bn1", 32, 2, V(ksize), V(1), V(pad)),
    m_u2_2(m_name + ".pro_block.conv2", 2, 2, V(1), V(1)),
    m_uu2_2(m_name + ".post_block", "up_conv", "up_bn", 2, 2, V(2), V(2)),
    m_u2_combine(m_name + ".out_block", "conv1", "bn1", in_channels+2, 2, V(ksize), V(1), V(pad)),
    m_final(m_name + ".out_block.conv2", 2, 2, V(1), V(1))
{
    m_cudnn_handle = nullptr;
    m_bytes_of_u256_in = 0;
    m_bytes_of_u128_in = 0;
    m_bytes_of_u64_in = 0;
    m_bytes_of_u32_in = 0;
    m_bytes_of_input_in = 0;
    m_in_channels = in_channels;
}


neuroError_t VBBNet3::set_param_ptrs(const ParamDictType& param_ptrs)
{
    checkNeuro(m_d1.set_param_ptrs(param_ptrs));
    checkNeuro(m_d16.set_param_ptrs(param_ptrs));
    checkNeuro(m_d32.set_param_ptrs(param_ptrs));
    checkNeuro(m_dr32.set_param_ptrs(param_ptrs));
    checkNeuro(m_d64.set_param_ptrs(param_ptrs));
    checkNeuro(m_dr64.set_param_ptrs(param_ptrs));
    checkNeuro(m_d128.set_param_ptrs(param_ptrs));
    checkNeuro(m_dr128.set_param_ptrs(param_ptrs));
    checkNeuro(m_d256.set_param_ptrs(param_ptrs));
    checkNeuro(m_dr256.set_param_ptrs(param_ptrs));
    checkNeuro(m_u256.set_param_ptrs(param_ptrs));
    checkNeuro(m_ur256.set_param_ptrs(param_ptrs));
    checkNeuro(m_u128.set_param_ptrs(param_ptrs));
    checkNeuro(m_ur128.set_param_ptrs(param_ptrs));
    checkNeuro(m_u64.set_param_ptrs(param_ptrs));
    checkNeuro(m_ur64.set_param_ptrs(param_ptrs));
    checkNeuro(m_u32.set_param_ptrs(param_ptrs));
    checkNeuro(m_ur32.set_param_ptrs(param_ptrs));
    checkNeuro(m_u2_32.set_param_ptrs(param_ptrs));
    checkNeuro(m_u2_2.set_param_ptrs(param_ptrs));
    checkNeuro(m_uu2_2.set_param_ptrs(param_ptrs));
    checkNeuro(m_u2_combine.set_param_ptrs(param_ptrs));
    checkNeuro(m_final.set_param_ptrs(param_ptrs));
    return Neuro_Success;
}


neuroError_t VBBNet3::create_concatenate_desc(const FloatTensor5& half, FloatTensor5& full)
{
    const int* size = half.size();
    int cat_size[5] = {size[0], size[1] * 2, size[2], size[3], size[4]};
    full.set_size(cat_size);
    full.create_desc();
    return Neuro_Success;
}

neuroError_t VBBNet3::create_last_concatenate_desc(const FloatTensor5& half, FloatTensor5& full)
{
    const int* size = half.size();
    int cat_size[5] = {size[0], size[1]+m_in_channels, size[2], size[3], size[4]};
    full.set_size(cat_size);
    full.create_desc();
    return Neuro_Success;
}


neuroError_t VBBNet3::create_descs(cudnnHandle_t cudnn_handle, const Tensor& intensor, Tensor& outtensor,
                                 bool infer_shape, size_t& max_layer_size, size_t& workspace_size)
{
    if(intensor.size()[0] != 1) {
        std::cerr << "Neuro supports only batchsize = 1" << std::endl;
        return Neuro_Unsupported;
    }

    m_cudnn_handle = cudnn_handle;

    checkNeuro(m_d1.create_descs(cudnn_handle, intensor, m_d1_out, true, max_layer_size, workspace_size));
    checkNeuro(m_d16.create_descs(cudnn_handle, m_d1_out, m_d16_out, true, max_layer_size, workspace_size));
    checkNeuro(m_d32.create_descs(cudnn_handle, m_d16_out, m_d32_out, true, max_layer_size, workspace_size));
    checkNeuro(m_dr32.create_descs(cudnn_handle, m_d32_out, m_dr32_out, true, max_layer_size, workspace_size));
    checkNeuro(m_d64.create_descs(cudnn_handle, m_dr32_out, m_d64_out, true, max_layer_size, workspace_size));
    checkNeuro(m_dr64.create_descs(cudnn_handle, m_d64_out, m_dr64_out, true, max_layer_size, workspace_size));
    checkNeuro(m_d128.create_descs(cudnn_handle, m_dr64_out, m_d128_out, true, max_layer_size, workspace_size));
    checkNeuro(m_dr128.create_descs(cudnn_handle, m_d128_out, m_dr128_out, true, max_layer_size, workspace_size));
    checkNeuro(m_d256.create_descs(cudnn_handle, m_dr128_out, m_d256_out, true, max_layer_size, workspace_size));
    checkNeuro(m_dr256.create_descs(cudnn_handle, m_d256_out, m_dr256_out, true, max_layer_size, workspace_size));
    checkNeuro(m_u256.create_descs(cudnn_handle, m_dr256_out, m_u128_out, true, max_layer_size, workspace_size));
    checkNeuro(create_concatenate_desc(m_u128_out, m_u256_in));
    checkNeuro(m_ur256.create_descs(cudnn_handle, m_u256_in, m_ur256_out, true, max_layer_size, workspace_size));
    checkNeuro(m_u128.create_descs(cudnn_handle, m_ur256_out, m_u64_out, true, max_layer_size, workspace_size));
    checkNeuro(create_concatenate_desc(m_u64_out, m_u128_in));
    checkNeuro(m_ur128.create_descs(cudnn_handle, m_u128_in, m_ur128_out, true, max_layer_size, workspace_size));
    checkNeuro(m_u64.create_descs(cudnn_handle, m_ur128_out, m_u32_out, true, max_layer_size, workspace_size));
    checkNeuro(create_concatenate_desc(m_u32_out, m_u64_in));
    checkNeuro(m_ur64.create_descs(cudnn_handle, m_u64_in, m_ur64_out, true, max_layer_size, workspace_size));
    checkNeuro(m_u32.create_descs(cudnn_handle, m_ur64_out, m_u16_out, true, max_layer_size, workspace_size));
    checkNeuro(create_concatenate_desc(m_u16_out, m_u32_in));
    checkNeuro(m_ur32.create_descs(cudnn_handle, m_u32_in, m_ur32_out, true, max_layer_size, workspace_size));
    checkNeuro(m_u2_32.create_descs(cudnn_handle, m_ur32_out, m_u2_32_out, true, max_layer_size, workspace_size));
    checkNeuro(m_u2_2.create_descs(cudnn_handle, m_u2_32_out, m_u2_2_out, true, max_layer_size, workspace_size));
    checkNeuro(m_uu2_2.create_descs(cudnn_handle, m_u2_2_out, m_uu2_2_out, true, max_layer_size, workspace_size));
    checkNeuro(create_last_concatenate_desc(m_uu2_2_out, m_u_combine_in));
    checkNeuro(m_u2_combine.create_descs(cudnn_handle, m_u_combine_in, m_u2_combine_out, true, max_layer_size, workspace_size));
    checkNeuro(m_final.create_descs(cudnn_handle, m_u2_combine_out, outtensor, infer_shape, max_layer_size, workspace_size));

    m_input_buffer.set_size(intensor.size());
    m_input_buffer.create_desc();

    // bytes of skip-connection buffer
    m_bytes_of_u256_in = m_u256_in.bytes();
    m_bytes_of_u128_in = m_u128_in.bytes();
    m_bytes_of_u64_in = m_u64_in.bytes();
    m_bytes_of_u32_in = m_u32_in.bytes();
    m_bytes_of_input_in = intensor.bytes();

    workspace_size += m_bytes_of_input_in;

    return Neuro_Success;
}

neuroError_t VBBNet3::forward(Tensor& intensor, Tensor& outtensor, void* workspace)
{
    /* save a backup of input */
    m_input_buffer.set_ptr(workspace);
    checkNeuro(TensorOps::add(m_cudnn_handle, 1.0f, intensor, 0.0f, m_input_buffer));
    void* alg_workspace = (void*)((char*)workspace + m_bytes_of_input_in);

    /* input_channels -> input channels */
    m_d1_out.set_ptr(intensor.ptr());
    checkNeuro(m_d1.forward(m_input_buffer, m_d1_out, alg_workspace));

    /* input_channels -> 16 */
    void* out_ptr = (void*)((char*)outtensor.ptr() + m_bytes_of_u32_in / 2);
    m_d16_out.set_ptr(out_ptr);
    checkNeuro(m_d16.forward(m_d1_out, m_d16_out, alg_workspace));

    /* downsample layer, channels 16 -> 32 */
    m_d32_out.set_ptr(outtensor.ptr());
    checkNeuro(m_d32.forward(m_d16_out, m_d32_out, alg_workspace));

    /* residual block, channels 32 -> 32 */
    out_ptr = (void*)((char*)outtensor.ptr() + m_bytes_of_u64_in / 2);
    m_dr32_out.set_ptr(out_ptr);
    checkNeuro(m_dr32.forward(m_d32_out, m_dr32_out, alg_workspace));

    /* downsample layer, channels 32 -> 64 */
    m_d64_out.set_ptr(outtensor.ptr());
    checkNeuro(m_d64.forward(m_dr32_out, m_d64_out, alg_workspace));

    /* residual block, channels 64 -> 64 */
    out_ptr = (void*)((char*)outtensor.ptr() + m_bytes_of_u128_in / 2);
    m_dr64_out.set_ptr(out_ptr);
    checkNeuro(m_dr64.forward(m_d64_out, m_dr64_out, alg_workspace));

    /* downsample layer, channels 64 -> 128 */
    m_d128_out.set_ptr(outtensor.ptr());
    checkNeuro(m_d128.forward(m_dr64_out, m_d128_out, alg_workspace));

    /* residual block, channels 128 -> 128 */
    out_ptr = (void*)((char*)outtensor.ptr() + m_bytes_of_u256_in / 2);
    m_dr128_out.set_ptr(out_ptr);
    checkNeuro(m_dr128.forward(m_d128_out, m_dr128_out, alg_workspace));

    /* downsample layer, channels 128 -> 256 */
    m_d256_out.set_ptr(outtensor.ptr());
    checkNeuro(m_d256.forward(m_dr128_out, m_d256_out, alg_workspace));

    /* residual block, channels 256 -> 256 */
    m_dr256_out.set_ptr(intensor.ptr());
    checkNeuro(m_dr256.forward(m_d256_out, m_dr256_out, alg_workspace));

    /* upsample layer, channels 256 -> 128 + 128 */
    m_u128_out.set_ptr(outtensor.ptr());
    checkNeuro(m_u256.forward(m_dr256_out, m_u128_out, alg_workspace));

    /* residual block, channels 256 -> 256 */
    m_u256_in.set_ptr(outtensor.ptr());
    m_ur256_out.set_ptr(intensor.ptr());
    checkNeuro(m_ur256.forward(m_u256_in, m_ur256_out, alg_workspace));

    /* upsample layer, channels 256 -> 64 + 64 */
    m_u64_out.set_ptr(outtensor.ptr());
    checkNeuro(m_u128.forward(m_ur256_out, m_u64_out, alg_workspace));

    /* residual block, channels 128 -> 128 */
    m_u128_in.set_ptr(outtensor.ptr());
    m_ur128_out.set_ptr(intensor.ptr());
    checkNeuro(m_ur128.forward(m_u128_in, m_ur128_out, alg_workspace));

    /* upsample layer, channels 128 -> 32 + 32 */
    m_u32_out.set_ptr(outtensor.ptr());
    checkNeuro(m_u64.forward(m_ur128_out, m_u32_out, alg_workspace));

    /* residual block, channels 64 -> 64 */
    m_u64_in.set_ptr(outtensor.ptr());
    m_ur64_out.set_ptr(intensor.ptr());
    checkNeuro(m_ur64.forward(m_u64_in, m_ur64_out, alg_workspace));

    /* upsample layer, channels 64 -> 16 + 16 */
    m_u16_out.set_ptr(outtensor.ptr());
    checkNeuro(m_u32.forward(m_ur64_out, m_u16_out, alg_workspace));

    /* residual block, channels 32 -> 32 */
    m_u32_in.set_ptr(outtensor.ptr());
    m_ur32_out.set_ptr(intensor.ptr());
    checkNeuro(m_ur32.forward(m_u32_in, m_ur32_out, alg_workspace));

    /* pro block, channels 32 -> 2 -> 2 */
    m_u2_32_out.set_ptr(outtensor.ptr());
    m_u2_2_out.set_ptr(intensor.ptr());
    checkNeuro(m_u2_32.forward(m_ur32_out, m_u2_32_out, alg_workspace));
    checkNeuro(m_u2_2.forward(m_u2_32_out, m_u2_2_out, alg_workspace));

    // softmax over channels
    TensorOps::softmax_spatial(m_cudnn_handle, m_u2_2_out);

    /* post block, channels 2  -> 2 (upsample) + in_channels (copy the input) */
    m_uu2_2_out.set_ptr(outtensor.ptr());
    checkNeuro(m_uu2_2.forward(m_u2_2_out, m_uu2_2_out, alg_workspace));

    /* concatenate with the input channels */
    out_ptr = (void*)((char*)outtensor.ptr() + m_uu2_2_out.bytes());
    void* in_ptr = intensor.ptr();                  // backup input tensor pointer
    intensor.set_ptr(out_ptr);                      // reuse intensor descriptor
    checkNeuro(TensorOps::add(m_cudnn_handle, 1.0f, m_input_buffer, 0.0f, intensor));
    intensor.set_ptr(in_ptr);                       // restore input tensor pointer

    /* output block, channels (2+in_channels) -> 2 -> 2 */
    m_u_combine_in.set_ptr(outtensor.ptr());
    m_u2_combine_out.set_ptr(intensor.ptr());
    checkNeuro(m_u2_combine.forward(m_u_combine_in, m_u2_combine_out, alg_workspace));
    checkNeuro(m_final.forward(m_u2_combine_out, outtensor, alg_workspace));

    // softmax over channels
    TensorOps::softmax_spatial(m_cudnn_handle, outtensor);

    return Neuro_Success;
}

}

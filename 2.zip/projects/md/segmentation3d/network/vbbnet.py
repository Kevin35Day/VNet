import torch.nn as nn
import torch
import numpy as np
from md.mdpytorch.module.vbnet_inputblock import InputBlock
from md.mdpytorch.module.vbnet_downblock import DownBlock
from md.mdpytorch.module.vbnet_upblock import UpBlock
from md.mdpytorch.init.kaiming_init import kaiming_weight_init
from md.mdpytorch.init.gaussian_init import gaussian_weight_init


class PreBlock(nn.Module):
    """ initial downsample block """

    def __init__(self, in_channels, out_channels):
        super(PreBlock, self).__init__()
        self.conv = nn.Conv3d(in_channels, out_channels, kernel_size=2, stride=2)
        self.bn = nn.BatchNorm3d(out_channels)
        self.act = nn.ReLU(inplace=True)

    def forward(self, input):
        out = self.act(self.bn(self.conv(input)))
        return out


class PostBlock(nn.Module):

    def __init__(self, in_channels, out_channels):
        super(PostBlock, self).__init__()
        self.up_conv = nn.ConvTranspose3d(in_channels, out_channels, kernel_size=2, stride=2)
        self.up_bn = nn.BatchNorm3d(out_channels)
        self.up_act = nn.ReLU(inplace=True)

    def forward(self, input, skip):
        out = self.up_act(self.up_bn(self.up_conv(input)))
        out = torch.cat((out, skip), 1)
        return out


class OutputBlock(nn.Module):
    """ output block of v-net

        The output is a list of foreground-background probability vectors.
        The length of the list equals to the number of voxels in the volume
    """

    def __init__(self, in_channels):
        super(OutputBlock, self).__init__()
        self.conv1 = nn.Conv3d(in_channels, 2, kernel_size=3, padding=1)
        self.bn1 = nn.BatchNorm3d(2)
        self.act1 = nn.ReLU(inplace=True)
        self.conv2 = nn.Conv3d(2, 2, kernel_size=1)

        tokens = torch.__version__.split('.')
        version = int(tokens[0] + tokens[1])
        if version < 3:
            self.softmax = nn.Softmax()
        else:
            self.softmax = nn.Softmax(dim=1)

    def forward(self, input):
        out = self.act1(self.bn1(self.conv1(input)))
        out = self.conv2(out)
        out_size = out.size()

        # move channels to last dimension and softmax
        out = out.permute(0, 2, 3, 4, 1).contiguous()
        out = out.view(out.numel() // 2, 2)
        out = self.softmax(out)

        # reshape back to output size
        out = out.view(out_size[0], out_size[2], out_size[3], out_size[4], out_size[1])
        out = out.permute(0, 4, 1, 2, 3).contiguous()

        return out


def vnet_kaiming_init(net):

    net.apply(kaiming_weight_init)


def vnet_focal_init(net, obj_p):

    net.apply(gaussian_weight_init)
    # initialize bias such as the initial predicted prob for objects are at obj_p.
    net.out_block.conv2.bias.data[1] = -np.log((1 - obj_p) / obj_p)


class VNet(nn.Module):
    """ v-net for segmentation """

    def __init__(self, in_channels):
        super(VNet, self).__init__()
        self.pre_block = PreBlock(in_channels, in_channels)
        self.in_block = InputBlock(in_channels, 16)
        self.down_32 = DownBlock(16, 1, use_bottle_neck=False)
        self.down_64 = DownBlock(32, 2, use_bottle_neck=True)
        self.down_128 = DownBlock(64, 3, use_bottle_neck=True)
        self.down_256 = DownBlock(128, 3,use_bottle_neck=True)
        self.up_256 = UpBlock(256, 256, 3, use_bottle_neck=True)
        self.up_128 = UpBlock(256, 128, 3, use_bottle_neck=True)
        self.up_64 = UpBlock(128, 64, 2, use_bottle_neck=False)
        self.up_32 = UpBlock(64, 32, 1, use_bottle_neck=False)
        self.pro_block = OutputBlock(32)
        self.post_block = PostBlock(2, 2)
        self.out_block = OutputBlock(3)

    def forward(self, input):
        dout = self.pre_block(input)
        out16 = self.in_block(dout)
        out32 = self.down_32(out16)
        out64 = self.down_64(out32)
        out128 = self.down_128(out64)
        out256 = self.down_256(out128)
        out = self.up_256(out256, out128)
        out = self.up_128(out, out64)
        out = self.up_64(out, out32)
        out = self.up_32(out, out16)
        out = self.pro_block(out)
        out = self.post_block(out, input)
        out = self.out_block(out)
        return out

    def max_stride(self):
        return 32

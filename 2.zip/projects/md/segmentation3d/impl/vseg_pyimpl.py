# python implementation of vnet segmentation

import os
import ConfigParser
import time
import numpy as np
import importlib
import sys

import torch
import torch.nn as nn
from torch.autograd import Variable
import md.image3d.python.image3d_tools as imtools
from md.image3d.python.image3d import Image3d
from md.mdpytorch.utils.tensor_tools import ToTensor, ToImage
from md.segmentation3d.utils.vseg_helpers import last_checkpoint, get_gpu_memory, FixedNormalizer, AdaptiveNormalizer


def load_net_module(net_file):
    """
    load network module dynamically
    :param net_file     network file
    :return a loaded network module
    """
    dirname = os.path.dirname(net_file)
    basename = os.path.basename(net_file)
    modulename, _ = os.path.splitext(basename)

    need_reload = modulename in sys.modules

    os.sys.path.append(dirname)
    lib = importlib.import_module(modulename)
    if need_reload:
        reload(lib)
    del os.sys.path[-1]

    return lib


def load_model(model_dir, resolution):
    """
    load model for either coarse or fine resolution
    :param model_dir: model directory
    :param resolution: resolution, either coarse or fine
    :return: a loaded dictionary with all model info
    """
    resolution_dir = os.path.join(model_dir, resolution)

    if not os.path.isdir(resolution_dir):
        raise ValueError('resolution dir not found: {}'.format(resolution_dir))

    checkpoint_dir = last_checkpoint(os.path.join(resolution_dir, 'checkpoints'))
    param_file = os.path.join(checkpoint_dir, 'params.pth')
    net_file = os.path.join(checkpoint_dir, 'net.py')

    if not os.path.isfile(param_file):
        raise ValueError('param file not found: {}'.format(param_file))

    if not os.path.isfile(net_file):
        raise ValueError('net file not found: {}'.format(net_file))

    # load network parameters
    state = torch.load(param_file)
    spacing = np.array(state['spacing'], dtype=np.double)
    assert spacing.ndim == 1, 'spacing must be 3-dim array'

    crop_normalizer = state['crop_normalizer']
    if crop_normalizer['type'] == 0:
        normalizer = FixedNormalizer(crop_normalizer['mean'], crop_normalizer['stddev'], crop_normalizer['clip'])
    elif crop_normalizer['type'] == 1:
        normalizer = AdaptiveNormalizer(crop_normalizer['min_p'], crop_normalizer['max_p'], crop_normalizer['clip'])
    else:
        raise ValueError('unknown normalizer type')

    # load network structure
    net_module = load_net_module(net_file)
    net = net_module.VNet(1)
    net = nn.parallel.DataParallel(net)
    net = net.cuda()
    net.load_state_dict(state['state_dict'])
    net.eval()

    return {'net': net,
            'spacing': spacing,
            'max_stride': state['max_stride'],
            'crop_normalizer': normalizer}


def vnet_seg(image, prev_pred, model, pad_mm, maxsize):
    """
    v-net segmentation core function
    :param image: an image3d object to be segmented
    :param prev_pred: the previous prediction result, None for coarse.
    :param model: loaded segmentation model
    :param pad_mm: padding in mm
    :param maxsize: the maximum size of crop
    :return: segmentation result
    """
    net, max_stride, spacing = model['net'], model['max_stride'], model['spacing']

    assert isinstance(spacing, np.ndarray) and spacing.ndim == 1 and len(spacing) == 3, \
        'spacing must be a 3-dim ndarray'

    if prev_pred is None:

        iso_image = imtools.resample_volume_nn_with_padding_rai(image, spacing, max_stride)
        iso_frame = iso_image.frame().deep_copy()

    else:

        minbox, maxbox = imtools.bounding_box_voxel(prev_pred, 1, 1)
        # if no segmentation, no need to refine
        if minbox is None or maxbox is None:
            return prev_pred

        # box pad mms in case coarse is not accurate
        box_pad = pad_mm
        minbox_world = prev_pred.voxel_to_world(minbox)
        maxbox_world = prev_pred.voxel_to_world(maxbox)
        minbox_world -= box_pad
        maxbox_world += box_pad

        iso_frame = prev_pred.frame().deep_copy()
        iso_frame.set_origin(minbox_world)
        iso_frame.set_spacing(spacing)

        box_size = np.round((maxbox_world - minbox_world) / spacing).astype(np.int32)
        iso_image = imtools.resample_nn_with_padding(image, iso_frame, box_size, max_stride)

    # check whether crop is beyond maximum crop size
    if maxsize[0] > 0 and maxsize[1] > 0 and maxsize[2] > 0:
        iso_imsize = iso_image.size()
        # if something is wrong (too big), output an empty image
        if iso_imsize[0] > maxsize[0] and iso_imsize[1] > maxsize[1] and iso_imsize[2] > maxsize[2]:
            pred = imtools.create_image3d_like(iso_image, fill_value=0)
            print('Case skiped. Iso_image size exceeds max size!')
            return pred

    if model['crop_normalizer'] is not None:
        model['crop_normalizer'](iso_image)

    # convert to tensor
    iso_image = ToTensor()(iso_image).unsqueeze(0)
    iso_image = iso_image.cuda()
    iso_image_v = Variable(iso_image, volatile=True)

    pred = net(iso_image_v)
    _, pred = pred.max(1)
    pred = pred.short()

    pred = ToImage()(pred[0].data)
    pred.set_frame(iso_frame)

    imtools.pick_largest_component(pred)

    return pred


def seg_volume(image, coarse_model, fine_model, pad_mm, maxsize):
    """
    segmetation entry function
    :param image: an image3d object to segment
    :param coarse_model: the coarse model
    :param fine_model: the fine model
    :param pad_mm: the box padding in mm
    :param maxsize: the maximum crop size
    :return: segmentation result
    """
    pred = vnet_seg(image, None, coarse_model, pad_mm, maxsize)
    if 'net' in fine_model:
        pred = vnet_seg(image, pred, fine_model, pad_mm, maxsize)

    return pred


def autoseg_load_model(folder, gpu_id=0):
    """
    load segmentation model from folder
    :param folder:    the folder that contains segmentation model
    :param gpu_id:          which gpu to run segmentation model
    :return: a segmentation model
    """
    assert isinstance(gpu_id, int)

    # switch to specific gpu
    os.environ['CUDA_VISIBLE_DEVICES'] = '{}'.format(gpu_id)

    model = {}
    param_file = os.path.join(folder, 'params.ini')

    conf = ConfigParser.ConfigParser()
    if not conf.read(param_file):
        raise OSError('{} does not exist!'.format(param_file))

    padmm_str = conf.get('General', 'pad_mm')
    if ',' not in padmm_str:
        padmm = float(padmm_str)
        model['pad_mm'] = [padmm, padmm, padmm]
    else:
        model['pad_mm'] = [float(i) for i in padmm_str.split(',')]
        assert len(model['pad_mm']) == 3

    maxsize_str = conf.get('General', 'maxsize')
    maxsize = [float(i) for i in maxsize_str.split(',')]

    if len(maxsize) != 3:
        return {}

    model['maxsize'] = maxsize
    model['coarse'] = load_model(folder, 'coarse')
    model['fine'] = load_model(folder, 'fine')
    model['gpu_id'] = gpu_id

    # switch back to default
    del os.environ['CUDA_VISIBLE_DEVICES']

    return model


def autoseg_volume(image, model):
    """
    segment image using the pre-loaded model
    :param image:      an image3d object
    :param model:      the pre-loaded model
    :return: a segmentation image
    """
    assert isinstance(image, Image3d)

    # switch to specific GPU
    os.environ['CUDA_VISIBLE_DEVICES'] = '{}'.format(model['gpu_id'])

    coarse_model = model['coarse']
    fine_model = model['fine']
    pad_mm = model['pad_mm']
    maxsize = model['maxsize']

    if image.pixel_type() != np.float32:
        image = image.deep_copy()
        image.cast(np.float32)

    begin = time.time()
    # segmentation
    pred = seg_volume(image, coarse_model, fine_model, pad_mm, maxsize)

    # compute organ localization and size for visualization
    minb, maxb = imtools.bounding_box_voxel(pred, 1, 1)
    if minb is None or maxb is None:
        min_coord, max_coord = image.world_box()
        box_size = max_coord - min_coord
        box_center = image.center()
    else:
        spacing = pred.spacing()
        box_size = (maxb - minb) * spacing
        box_center = (maxb + minb) / 2.0
        box_center = pred.voxel_to_world(box_center)

    # resample mask back to original image space
    pred = imtools.resample_mask_as_ref(pred, 1, 1, image)
    test_time = time.time() - begin

    # switch back to default
    del os.environ['CUDA_VISIBLE_DEVICES']

    print 'GPU Memory Used:', get_gpu_memory(model['gpu_id']), 'MB'

    return pred, box_center, box_size, test_time

# -*- coding: utf-8 -*-
import sys
import os
import json

import numpy as np
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *

class TestNameDialog(QDialog):

    def __init__(self, fontsize=16):

        super(TestNameDialog, self).__init__()

        self.org_name = ''

        font = self.font()
        font.setPointSize(fontsize)

        layout = QVBoxLayout()

        org_label = QLabel('Image')
        self.org_combobox = QComboBox(self)
        self.org_combobox.setEditable(False)
        self.org_combobox.currentIndexChanged.connect(self.orgIndexChanged)
        org_label.setFont(font)
        self.org_combobox.setFont(font)

        layout1 = QHBoxLayout()
        layout1.addWidget(org_label)
        layout1.addWidget(self.org_combobox)

        layout2 = QHBoxLayout()
        ok_button = QPushButton('OK')
        ok_button.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        ok_button.clicked.connect(self.accept)
        ok_button.setFont(font)

        cancel_button = QPushButton('Cancel')
        cancel_button.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        cancel_button.clicked.connect(self.reject)
        cancel_button.setFont(font)

        layout2.addWidget(ok_button)
        layout2.addWidget(cancel_button)

        layout.addLayout(layout1)
        layout.addLayout(layout2)

        self.setLayout(layout)

    def orgIndexChanged(self, _):

        self.org_name = self.org_combobox.currentText()

    def segIndexChanged(self, _):

        self.seg_name = self.seg_combobox.currentText()


class TrainNameDialog(QDialog):

    def __init__(self, fontsize=16):

        super(TrainNameDialog, self).__init__()

        self.org_name = ''
        self.seg_name = ''

        font = self.font()
        font.setPointSize(fontsize)

        layout = QVBoxLayout()

        layout1 = QHBoxLayout()
        org_label = QLabel('Image')
        self.org_combobox = QComboBox(self)
        self.org_combobox.setEditable(False)
        self.org_combobox.currentIndexChanged.connect(self.orgIndexChanged)

        seg_label = QLabel('Seg')
        self.seg_combobox = QComboBox(self)
        self.seg_combobox.setEditable(False)
        self.seg_combobox.currentIndexChanged.connect(self.segIndexChanged)

        org_label.setFont(font)
        self.org_combobox.setFont(font)
        seg_label.setFont(font)
        self.seg_combobox.setFont(font)

        layout1.addWidget(org_label)
        layout1.addWidget(self.org_combobox)
        layout1.addWidget(seg_label)
        layout1.addWidget(self.seg_combobox)

        layout2 = QHBoxLayout()
        ok_button = QPushButton('OK')
        ok_button.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        ok_button.clicked.connect(self.accept)
        ok_button.setFont(font)

        cancel_button = QPushButton('Cancel')
        cancel_button.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        cancel_button.clicked.connect(self.reject)
        cancel_button.setFont(font)

        layout2.addWidget(ok_button)
        layout2.addWidget(cancel_button)

        layout.addLayout(layout1)
        layout.addLayout(layout2)

        self.setLayout(layout)

    def orgIndexChanged(self, _):
        self.org_name = self.org_combobox.currentText()

    def segIndexChanged(self, _):
        self.seg_name = self.seg_combobox.currentText()

class EditDialog(QDialog):

    def __init__(self, json_file_path):
        super(EditDialog,self).__init__()

        self.setWindowTitle('Edit Image Infomation')
        self.resize(400, 300)
        self.center()

        self.gender_box = False
        self.gender = ''

        self.bodyparts_box = False
        self.bodyparts_list = []

        self.tags_box = False
        self.tags_info = []

        self.json_file_path = json_file_path

        self.setupUi(self)


    def setupUi(self, EditDialog):

        #MainWindow
        self.MainDialog = QWidget(EditDialog)
        self.VLayout = QVBoxLayout(self.MainDialog)

        # 1. File Path
        self.HLayout_File = QHBoxLayout()
        self.label_File = QLabel("File Path:")
        self.edit_File_Path = QLineEdit()
        self.HLayout_File.addWidget(self.label_File)
        self.HLayout_File.addWidget(self.edit_File_Path)

        self.edit_File_Path.setText(self.json_file_path)
        self.edit_File_Path.setReadOnly(True)

        self.line_1 = QFrame()
        self.line_1.setFrameShape(QFrame.HLine)
        self.line_1.setFrameShadow(QFrame.Sunken)

        #2. Gender
        self.box_Gender = QCheckBox("Gender", self)
        self.HLayout_Gender = QHBoxLayout()
        self.label_empty9 = QLabel()
        self.label_empty9.setText("")
        self.HLayout_Gender.addWidget(self.label_empty9)
        self.radio_Male = QRadioButton('Male        ')
        self.HLayout_Gender.addWidget(self.radio_Male)
        self.label_empty10 = QLabel()
        self.label_empty10.setText("")
        self.HLayout_Gender.addWidget(self.label_empty10)
        self.radio_Female = QRadioButton('Female')
        self.HLayout_Gender.addWidget(self.radio_Female)
        self.label_empty11 = QLabel()
        self.label_empty11.setText("")
        self.HLayout_Gender.addWidget(self.label_empty11)
        self.radio_GenderX = QRadioButton('X              ')
        self.HLayout_Gender.addWidget(self.radio_GenderX)
        self.label_empty12 = QLabel()
        self.label_empty12.setText("")
        self.HLayout_Gender.addWidget(self.label_empty12)

        self.btn_GenderGroup = QButtonGroup()
        self.btn_GenderGroup.addButton(self.radio_Male)
        self.btn_GenderGroup.addButton(self.radio_Female)
        self.btn_GenderGroup.addButton(self.radio_GenderX)

        self.box_Gender.stateChanged.connect(self.GenderStateChanged)
        self.radio_Male.clicked.connect(self.GenderGroupClicked)
        self.radio_Female.clicked.connect(self.GenderGroupClicked)
        self.radio_GenderX.clicked.connect(self.GenderGroupClicked)

        #3. Body Parts
        self.box_BodyParts = QCheckBox("BodyParts", self)
        #First Line
        self.GLayout_BodyParts = QGridLayout()
        self.label_empty1 = QLabel()
        self.label_empty1.setText("")
        self.GLayout_BodyParts.addWidget(self.label_empty1, 0, 0, 1, 1)
        self.box_BodyHead = QCheckBox('Head')
        self.GLayout_BodyParts.addWidget(self.box_BodyHead, 0, 1, 1, 1)
        self.label_empty2 = QLabel()
        self.label_empty2.setText("")
        self.GLayout_BodyParts.addWidget(self.label_empty2, 0, 2, 1, 1)
        self.box_BodyNeck = QCheckBox('Neck  ')
        self.GLayout_BodyParts.addWidget(self.box_BodyNeck, 0, 3, 1, 1)
        self.label_empty3 = QLabel()
        self.label_empty3.setText("")
        self.GLayout_BodyParts.addWidget(self.label_empty3, 0, 4, 1, 1)
        self.box_BodyChest = QCheckBox('Chest')
        self.GLayout_BodyParts.addWidget(self.box_BodyChest, 0, 5, 1, 1)
        self.label_empty4 = QLabel()
        self.label_empty4.setText("")
        self.GLayout_BodyParts.addWidget(self.label_empty4, 0, 6, 1, 1)
        #Second Line
        self.label_empty5 = QLabel()
        self.label_empty5.setText("")
        self.GLayout_BodyParts.addWidget(self.label_empty5, 1, 0, 1, 1)
        self.box_BodyAbdomen = QCheckBox('Abdomen')
        self.GLayout_BodyParts.addWidget(self.box_BodyAbdomen, 1, 1, 1, 1)
        self.label_empty6 = QLabel()
        self.label_empty6.setText("")
        self.GLayout_BodyParts.addWidget(self.label_empty6, 1, 2, 1, 1)
        self.box_BodyPelvis = QCheckBox('Pelvis ')
        self.GLayout_BodyParts.addWidget(self.box_BodyPelvis, 1, 3, 1, 1)
        self.label_empty7 = QLabel()
        self.label_empty7.setText("")
        self.GLayout_BodyParts.addWidget(self.label_empty7, 1, 4, 1, 1)
        self.box_BodyUndefined = QCheckBox('Undefined')
        self.GLayout_BodyParts.addWidget(self.box_BodyUndefined, 1, 5, 1, 1)
        self.label_empty8 = QLabel()
        self.label_empty8.setText("")
        self.GLayout_BodyParts.addWidget(self.label_empty8, 1, 6, 1, 1)

        self.btn_BodyGroup = QButtonGroup()
        self.btn_BodyGroup.setExclusive(False)
        self.btn_BodyGroup.addButton(self.box_BodyHead)
        self.btn_BodyGroup.addButton(self.box_BodyNeck)
        self.btn_BodyGroup.addButton(self.box_BodyChest)
        self.btn_BodyGroup.addButton(self.box_BodyAbdomen)
        self.btn_BodyGroup.addButton(self.box_BodyPelvis)
        self.btn_BodyGroup.addButton(self.box_BodyUndefined)

        self.box_BodyParts.stateChanged.connect(self.BodypartsStateChanged)
        self.box_BodyHead.clicked.connect(self.BodyPartsClicked)
        self.box_BodyNeck.clicked.connect(self.BodyPartsClicked)
        self.box_BodyChest.clicked.connect(self.BodyPartsClicked)
        self.box_BodyAbdomen.clicked.connect(self.BodyPartsClicked)
        self.box_BodyPelvis.clicked.connect(self.BodyPartsClicked)
        self.box_BodyUndefined.clicked.connect(self.BodyPartsClicked)

        #4. Tags
        self.HLayout_Tags = QHBoxLayout()
        self.box_Tags = QCheckBox("Tags", self)
        self.edit_Tags = QLineEdit()
        self.HLayout_Tags.addWidget(self.box_Tags)
        self.HLayout_Tags.addWidget(self.edit_Tags)

        self.box_Tags.stateChanged.connect(self.TagsStateChanged)
        self.edit_Tags.editingFinished.connect(self.TagsEditingFinished)

        self.line_2 = QFrame()
        self.line_2.setFrameShape(QFrame.HLine)
        self.line_2.setFrameShadow(QFrame.Sunken)

        #5. save Button
        self.HLayout_Edit = QHBoxLayout()
        self.label_empty13 = QLabel()
        self.label_empty13.setText("")
        self.HLayout_Edit.addWidget(self.label_empty13)
        self.label_empty14 = QLabel()
        self.label_empty14.setText("")
        self.HLayout_Edit.addWidget(self.label_empty14)
        self.btn_Cancel = QPushButton('Cancel', self)
        self.HLayout_Edit.addWidget(self.btn_Cancel)
        self.btn_Save = QPushButton('Save', self)
        self.HLayout_Edit.addWidget(self.btn_Save)

        self.VLayout.addLayout(self.HLayout_File)
        self.VLayout.addWidget(self.line_1)
        self.VLayout.addSpacing(10)
        self.VLayout.addWidget(self.box_Gender)
        self.VLayout.addLayout(self.HLayout_Gender)
        self.VLayout.addSpacing(10)
        self.VLayout.addWidget(self.box_BodyParts)
        self.VLayout.addLayout(self.GLayout_BodyParts)
        self.VLayout.addSpacing(10)
        self.VLayout.addLayout(self.HLayout_Tags)
        self.VLayout.addSpacing(10)
        self.VLayout.addWidget(self.line_2)
        self.VLayout.addLayout(self.HLayout_Edit)

        self.btn_Save.clicked.connect(self.SaveClicked)
        self.btn_Cancel.clicked.connect(self.CancleClicked)

        self.setLayout(self.VLayout)

    def center(self):
        qr = self.frameGeometry()
        cp = QDesktopWidget().availableGeometry().center()
        qr.moveCenter(cp)
        self.move(qr.topLeft())

    def GenderStateChanged(self, state):

        if state == Qt.Checked:
            self.btn_GenderGroup.setExclusive(True)
            self.gender_box = True
        else:
            self.btn_GenderGroup.setExclusive(False)
            self.radio_Male.setChecked(False)
            self.radio_Female.setChecked(False)
            self.radio_GenderX.setChecked(False)
            self.gender = ''
            self.gender_box = False

    def GenderGroupClicked(self):

        if self.radio_Male.isChecked():
            self.gender = 'M'
        elif self.radio_Female.isChecked():
            self.gender = 'F'
        elif self.radio_GenderX.isChecked():
            self.gender = 'X'
        else:
            self.gender = ''

    def BodypartsStateChanged(self, state):

        if state == Qt.Checked:
            self.bodyparts_box = True

        else:
            self.box_BodyHead.setChecked(False)
            self.box_BodyNeck.setChecked(False)
            self.box_BodyChest.setChecked(False)
            self.box_BodyAbdomen.setChecked(False)
            self.box_BodyPelvis.setChecked(False)
            self.box_BodyUndefined.setChecked(False)
            self.bodyparts_list = []
            self.bodyparts_box = False

    def BodyPartsClicked(self):

        self.bodyparts_list = []
        if self.box_BodyHead.isChecked():
            self.bodyparts_list.append('head')

        if self.box_BodyNeck.isChecked():
            self.bodyparts_list.append('neck')

        if self.box_BodyChest.isChecked():
            self.bodyparts_list.append('chest')

        if self.box_BodyAbdomen.isChecked():
            self.bodyparts_list.append('abdomen')

        if self.box_BodyPelvis.isChecked():
            self.bodyparts_list.append('pelvis')

        if self.box_BodyUndefined.isChecked():
            self.bodyparts_list.append('undefined')

    def TagsStateChanged(self, state):

        if state == Qt.Checked:
            self.tags_box = True
        else:
            self.tags_info = []
            self.edit_Tags.setText('{}'.format(''))
            self.tags_box = False

    def TagsEditingFinished(self):

        edit = self.sender()
        try:
            tag = str(edit.text())
            self.tags_info = tag.split(';')
            # self.tags_info = str(edit.text())

        except:
            self.tags_info = []
            edit.setText('{}'.format(''))
            QMessageBox.warning(self, 'warning', 'Wrong tags')

    def SaveClicked(self):

        reply = QMessageBox.information(self,
                                        'Save Json File',
                                        'Are you sure to modify the json file information',
                                        QMessageBox.Yes | QMessageBox.No)

        if reply == QMessageBox.Yes:
             file_dir = self.json_file_path
             if os.path.isfile(file_dir):
                 fp = open(file_dir, 'r')
                 info = json.load(fp)
                 fp.close()

                 if self.gender_box == True:
                     if self.gender == '':
                        QMessageBox.critical(self, 'Error', 'No choice Gender')
                     else:
                        info['gender'] = self.gender

                 if self.bodyparts_box == True:
                     info['body_parts'] = self.bodyparts_list

                 if self.tags_box == True:
                     info['tags'] = self.tags_info

                 fp = open(file_dir, 'w')
                 json.dump(info,fp)
                 fp.close()

    def CancleClicked(self):

        reply = QMessageBox.information(self,
                                        'Cancle',
                                        'Are you sure to cancle the modification',
                                        QMessageBox.Yes | QMessageBox.No)

        if reply == QMessageBox.Yes:

            self.btn_GenderGroup.setExclusive(False)
            self.radio_Male.setChecked(False)
            self.radio_Female.setChecked(False)
            self.radio_GenderX.setChecked(False)
            self.box_Tags.setChecked(False)
            self.gender = ''
            self.gender_box = False

            self.box_BodyHead.setChecked(False)
            self.box_BodyNeck.setChecked(False)
            self.box_BodyChest.setChecked(False)
            self.box_BodyAbdomen.setChecked(False)
            self.box_BodyPelvis.setChecked(False)
            self.box_BodyUndefined.setChecked(False)
            self.bodyparts_list = []
            self.bodyparts_box = False
            self.box_BodyParts.setChecked(False)

            self.box_Tags = False
            self.tags_info = []
            self.edit_Tags.setText('{}'.format(''))
            self.box_Gender.setChecked(False)

img_exts = ['.nii', '.nii.gz', '.mhd', '.mha', '.hdr']
def find_image_names(folder, exts=img_exts):

    img_files = set()
    img_path = set()
    for case_name in os.listdir(folder):
        case_folder = os.path.join(folder, case_name)
        for root, folders, files in os.walk(case_folder):
            for file in files:
                if any([file.endswith(ext) for ext in exts]):
                    img_files.add(file)
                    img_folder = root.rstrip('/')
                    img_path.add(img_folder)

    return img_files,img_path

def find_image_names_with_json_file(folder, exts=img_exts):

    img_files = set()
    img_path = set()
    for case_name in os.listdir(folder):
        case_folder = os.path.join(folder, case_name)
        for root, folders, files in os.walk(case_folder):
            json_flag = False
            for file in files:
                if file == 'meta.json':
                    json_flag = True
                    break
            if json_flag == True:
                for file in files:
                    if any([file.endswith(ext) for ext in exts]):
                        img_files.add(file)
                        img_folder = root.rstrip('/')
                        img_path.add(img_folder)

    return img_files,img_path

class SearchViewer(QMainWindow):

    def __init__(self):
        super(SearchViewer,self).__init__()

        self.setWindowTitle('Search Viewer')
        self.resize(600, 500)
        self.center()

        self.xspacing_box = False
        self.yspacing_box = False
        self.zspacing_box = False
        self.x_minvalue = 0.0
        self.x_maxvalue = 2.0
        self.y_minvalue = 0.0
        self.y_maxvalue = 2.0
        self.z_minvalue = 0.0
        self.z_maxvalue = 10.0

        self.gender_box = False
        self.gender = ''

        self.bodyparts_box = False
        self.bodyparts_list = []

        self.tags_box = False
        self.tags_info = []
        # self.tags_info = ''

        self.segmentation_box = False
        self.seg_list = ['lung_left', 'lung_right', 'liver', 'spleen', 'kidney_left', 'kidney_right', 'female_bladder',
                         'femoralhead_left', 'femoralhead_right']
        self.sel_seg_list = set()

        self.all_folder_list = set()
        self.sel_seg_list_json = set()
        self.all_folder_list_json = set()
        self.imlist = []
        self.select_imlist = set()
        self.train_imlist = []
        self.test_imlist = []
        self.total_num = -1
        self.total_json_num = -1
        self.imidx = -1

        self.train_list = []
        self.test_list = []
        self.train_num = -1
        self.test_num = -1

        self.edit_data = ''
        self.all_filename = set()

        self.setupUi()

    def setupUi(self):

        #Menu Bar
        self.menubar = QMenuBar()
        self.menuFile = self.menubar.addMenu('&File')
        self.setMenuBar(self.menubar)

        self.Open_Image = QMenu('&Open Image', self)
        self.Open_Image_From_Folder = QAction('&Open Image From Folder', self)
        self.Open_Image_From_Folder_Json = QAction('&Open Image From Folder With Json File', self)
        self.Open_Image.addAction(self.Open_Image_From_Folder)
        self.Open_Image.addAction(self.Open_Image_From_Folder_Json)
        self.Open_Image_From_Folder.triggered.connect(self.read_imlist_from_folder)
        self.Open_Image_From_Folder_Json.triggered.connect(self.read_imlist_from_folder_with_json_file)
        self.menuFile.addMenu(self.Open_Image)

        #Status Bar
        self.statusbar = QStatusBar()
        self.setStatusBar(self.statusbar)

        #MainWindow(Grid layout)
        self.Widget = QWidget()
        self.GLayout = QGridLayout(self.Widget)

        ########### Left Plane #############
        #1. Search Item
        self.label_SearchItem = QLabel('Search Item')
        self.GLayout.addWidget(self.label_SearchItem, 0, 0, 1, 1)

        #2. Voxel Spacing(Grid layout)
        self.GLayout_Spacing = QGridLayout()
        self.GLayout.addLayout(self.GLayout_Spacing, 1, 0, 1, 1)
        #X spacing
        self.box_XSpacing = QCheckBox('X Spacing', self)
        self.GLayout_Spacing.addWidget(self.box_XSpacing, 0, 0, 1, 1)
        self.label_XMinimum = QLabel('Mininum:')
        self.GLayout_Spacing.addWidget(self.label_XMinimum, 0, 1, 1, 1)
        self.edit_XMinimum = QLineEdit()
        self.GLayout_Spacing.addWidget(self.edit_XMinimum, 0, 2, 1, 1)
        self.label_XMaximum = QLabel('Maxinum:')
        self.GLayout_Spacing.addWidget(self.label_XMaximum, 0, 3, 1, 1)
        self.edit_XMaximum = QLineEdit()
        self.GLayout_Spacing.addWidget(self.edit_XMaximum, 0, 4, 1, 1)
        #Y spacing
        self.box_YSpacing = QCheckBox('Y Spacing', self)
        self.GLayout_Spacing.addWidget(self.box_YSpacing, 1, 0, 1, 1)
        self.label_YMinimum = QLabel('Mininum:',)
        self.GLayout_Spacing.addWidget(self.label_YMinimum, 1, 1, 1, 1)
        self.edit_YMinimum = QLineEdit()
        self.GLayout_Spacing.addWidget(self.edit_YMinimum, 1, 2, 1, 1)
        self.label_YMaximun = QLabel('Maxinum:')
        self.GLayout_Spacing.addWidget(self.label_YMaximun, 1, 3, 1, 1)
        self.edit_YMaximum = QLineEdit()
        self.GLayout_Spacing.addWidget(self.edit_YMaximum, 1, 4, 1, 1)
        #Z spacing
        self.box_ZSpacing = QCheckBox('Z Spacing', self)
        self.GLayout_Spacing.addWidget(self.box_ZSpacing, 2, 0, 1, 1)
        self.label_ZMinimum = QLabel('Mininum:',)
        self.GLayout_Spacing.addWidget(self.label_ZMinimum, 2, 1, 1, 1)
        self.edit_ZMinimum = QLineEdit()
        self.GLayout_Spacing.addWidget(self.edit_ZMinimum, 2, 2, 1, 1)
        self.label_ZMaximum = QLabel('Maxinum:')
        self.GLayout_Spacing.addWidget(self.label_ZMaximum, 2, 3, 1, 1)
        self.edit_ZMaximum = QLineEdit()
        self.GLayout_Spacing.addWidget(self.edit_ZMaximum, 2, 4, 1, 1)

        self.box_XSpacing.stateChanged.connect(self.XSpacingStateChanged)
        self.box_YSpacing.stateChanged.connect(self.YSpacingStateChanged)
        self.box_ZSpacing.stateChanged.connect(self.ZSpacingStateChanged)

        self.edit_XMinimum.editingFinished.connect(self.XMinEditingFinished)
        self.edit_XMaximum.editingFinished.connect(self.XMaxEditingFinished)
        self.edit_YMinimum.editingFinished.connect(self.YMinEditingFinished)
        self.edit_YMaximum.editingFinished.connect(self.YMaxEditingFinished)
        self.edit_ZMinimum.editingFinished.connect(self.ZMinEditingFinished)
        self.edit_ZMaximum.editingFinished.connect(self.ZMaxEditingFinished)

        self.line_1 = QFrame()
        self.line_1.setFrameShape(QFrame.HLine)
        self.line_1.setFrameShadow(QFrame.Sunken)
        self.GLayout.addWidget(self.line_1, 2, 0, 1, 1)
        self.line_1.raise_()

        #3. Gender
        self.box_Gender = QCheckBox("Gender", self)
        self.GLayout.addWidget(self.box_Gender, 3, 0, 1, 1)
        self.HLayout_Gender = QHBoxLayout()
        self.GLayout.addLayout(self.HLayout_Gender, 4, 0, 1, 1)
        self.label_empty9 = QLabel()
        self.label_empty9.setText("")
        self.HLayout_Gender.addWidget(self.label_empty9)
        self.radio_Male = QRadioButton('Male        ')
        self.HLayout_Gender.addWidget(self.radio_Male)
        self.label_empty10 = QLabel()
        self.label_empty10.setText("")
        self.HLayout_Gender.addWidget(self.label_empty10)
        self.radio_Female = QRadioButton('Female')
        self.HLayout_Gender.addWidget(self.radio_Female)
        self.label_empty11 = QLabel()
        self.label_empty11.setText("")
        self.HLayout_Gender.addWidget(self.label_empty11)
        self.radio_GenderX = QRadioButton('X              ')
        self.HLayout_Gender.addWidget(self.radio_GenderX)
        self.label_empty12 = QLabel()
        self.label_empty12.setText("")
        self.HLayout_Gender.addWidget(self.label_empty12)

        self.line_2 = QFrame()
        self.line_2.setFrameShape(QFrame.HLine)
        self.line_2.setFrameShadow(QFrame.Sunken)
        self.GLayout.addWidget(self.line_2, 5, 0, 1, 1)
        self.line_2.raise_()

        self.btn_GenderGroup = QButtonGroup()
        self.btn_GenderGroup.addButton(self.radio_Male)
        self.btn_GenderGroup.addButton(self.radio_Female)
        self.btn_GenderGroup.addButton(self.radio_GenderX)

        self.box_Gender.stateChanged.connect(self.GenderStateChanged)
        self.radio_Male.clicked.connect(self.GenderGroupClicked)
        self.radio_Female.clicked.connect(self.GenderGroupClicked)
        self.radio_GenderX.clicked.connect(self.GenderGroupClicked)

        #4. Body Parts
        self.box_BodyParts = QCheckBox("BodyParts", self)
        self.GLayout.addWidget(self.box_BodyParts, 6, 0, 1, 1)
        #First Line
        self.GLayout_BodyParts = QGridLayout()
        self.GLayout.addLayout(self.GLayout_BodyParts, 7, 0, 1, 1)
        self.label_empty1 = QLabel()
        self.label_empty1.setText("")
        self.GLayout_BodyParts.addWidget(self.label_empty1, 0, 0, 1, 1)
        self.box_BodyHead = QCheckBox('Head')
        self.GLayout_BodyParts.addWidget(self.box_BodyHead, 0, 1, 1, 1)
        self.label_empty2 = QLabel()
        self.label_empty2.setText("")
        self.GLayout_BodyParts.addWidget(self.label_empty2, 0, 2, 1, 1)
        self.box_BodyNeck = QCheckBox('Neck  ')
        self.GLayout_BodyParts.addWidget(self.box_BodyNeck, 0, 3, 1, 1)
        self.label_empty3 = QLabel()
        self.label_empty3.setText("")
        self.GLayout_BodyParts.addWidget(self.label_empty3, 0, 4, 1, 1)
        self.box_BodyChest = QCheckBox('Chest')
        self.GLayout_BodyParts.addWidget(self.box_BodyChest, 0, 5, 1, 1)
        self.label_empty4 = QLabel()
        self.label_empty4.setText("")
        self.GLayout_BodyParts.addWidget(self.label_empty4, 0, 6, 1, 1)
        #Second Line
        self.label_empty5 = QLabel()
        self.label_empty5.setText("")
        self.GLayout_BodyParts.addWidget(self.label_empty5, 1, 0, 1, 1)
        self.box_BodyAbdomen = QCheckBox('Abdomen')
        self.GLayout_BodyParts.addWidget(self.box_BodyAbdomen, 1, 1, 1, 1)
        self.label_empty6 = QLabel()
        self.label_empty6.setText("")
        self.GLayout_BodyParts.addWidget(self.label_empty6, 1, 2, 1, 1)
        self.box_BodyPelvis = QCheckBox('Pelvis ')
        self.GLayout_BodyParts.addWidget(self.box_BodyPelvis, 1, 3, 1, 1)
        self.label_empty7 = QLabel()
        self.label_empty7.setText("")
        self.GLayout_BodyParts.addWidget(self.label_empty7, 1, 4, 1, 1)
        self.box_BodyUndefined = QCheckBox('Undefined')
        self.GLayout_BodyParts.addWidget(self.box_BodyUndefined, 1, 5, 1, 1)
        self.label_empty8 = QLabel()
        self.label_empty8.setText("")
        self.GLayout_BodyParts.addWidget(self.label_empty8, 1, 6, 1, 1)

        self.line_3 = QFrame()
        self.line_3.setFrameShape(QFrame.HLine)
        self.line_3.setFrameShadow(QFrame.Sunken)
        self.GLayout.addWidget(self.line_3, 8, 0, 1, 1)
        self.line_3.raise_()

        self.btn_BodyGroup = QButtonGroup()
        self.btn_BodyGroup.setExclusive(False)
        self.btn_BodyGroup.addButton(self.box_BodyHead)
        self.btn_BodyGroup.addButton(self.box_BodyNeck)
        self.btn_BodyGroup.addButton(self.box_BodyChest)
        self.btn_BodyGroup.addButton(self.box_BodyAbdomen)
        self.btn_BodyGroup.addButton(self.box_BodyPelvis)
        self.btn_BodyGroup.addButton(self.box_BodyUndefined)

        self.box_BodyParts.stateChanged.connect(self.BodypartsStateChanged)
        self.box_BodyHead.clicked.connect(self.BodyPartsClicked)
        self.box_BodyNeck.clicked.connect(self.BodyPartsClicked)
        self.box_BodyChest.clicked.connect(self.BodyPartsClicked)
        self.box_BodyAbdomen.clicked.connect(self.BodyPartsClicked)
        self.box_BodyPelvis.clicked.connect(self.BodyPartsClicked)
        self.box_BodyUndefined.clicked.connect(self.BodyPartsClicked)

        #5. Tags
        self.HLayout_Tags = QHBoxLayout()
        self.box_Tags = QCheckBox("Tags", self)
        self.HLayout_Tags.addWidget(self.box_Tags)
        self.GLayout.addLayout(self.HLayout_Tags, 9, 0, 1, 1)
        self.edit_Tags = QLineEdit()
        self.HLayout_Tags.addWidget(self.edit_Tags)

        self.box_Tags.stateChanged.connect(self.TagsStateChanged)
        self.edit_Tags.editingFinished.connect(self.TagsEditingFinished)

        self.line_4 = QFrame()
        self.line_4.setFrameShape(QFrame.HLine)
        self.line_4.setFrameShadow(QFrame.Sunken)
        self.GLayout.addWidget(self.line_4, 10, 0, 1, 1)
        self.line_4.raise_()

        #6. Segmentation
        self.box_Segmentation = QCheckBox("Segmentation", self)
        self.GLayout.addWidget(self.box_Segmentation, 11, 0, 1, 1)
        self.imlist_Seg_view = QListView()
        self.imlist_seg_model = QStandardItemModel()
        self.imlist_Seg_view.setModel(self.imlist_seg_model)
        self.imlist_Seg_view.doubleClicked.connect(self.seg_imlist_item_doubleclicked)
        self.imlist_Seg_view.clicked.connect(self.seg_imlist_item_doubleclicked)
        self.imlist_Seg_view.installEventFilter(self)
        self.GLayout.addWidget(self.imlist_Seg_view, 12, 0, 1, 1)

        self.imlist_Seg_view.setSelectionMode(QAbstractItemView.MultiSelection)
        self.imlist_Seg_view.installEventFilter(self)
        self.update_seglistview()
        self.box_Segmentation.stateChanged.connect(self.SegmentationStateChanged)

        #7. Query Button
        self.HLayout_Edit = QHBoxLayout()
        self.btn_ExportTrain = QPushButton('Export Train', self)
        self.HLayout_Edit.addWidget(self.btn_ExportTrain)
        self.btn_ExportTest = QPushButton('Export Test', self)
        self.HLayout_Edit.addWidget(self.btn_ExportTest)
        self.btn_Query = QPushButton('Query', self)
        self.HLayout_Edit.addWidget(self.btn_Query)
        self.GLayout.addLayout(self.HLayout_Edit, 13, 0, 1, 1)

        self.btn_ExportTrain.clicked.connect(self.ExportTrainClicked)
        self.btn_ExportTest.clicked.connect(self.ExportTestClicked)
        self.btn_Query.clicked.connect(self.QueryClicked)

        self.line_5 = QFrame()
        self.line_5.setFrameShape(QFrame.VLine)
        self.line_5.setFrameShadow(QFrame.Sunken)
        self.GLayout.addWidget(self.line_5, 13, 1, 1, 1, Qt.AlignBottom)
        self.line_5.raise_()

        ########## Right Plane ####################
        #1. Image List Label
        self.label_ImageList = QLabel('Image List')
        self.GLayout.addWidget(self.label_ImageList, 0, 1, 1, 1)

        #2. Image List
        self.imlist_view = QListView()
        self.imlist_model = QStandardItemModel()
        self.imlist_view.setModel(self.imlist_model)
        self.imlist_view.doubleClicked.connect(self.imlist_item_doubleclicked)
        self.imlist_view.clicked.connect(self.imlist_item_doubleclicked)
        self.imlist_view.installEventFilter(self)
        self.GLayout.addWidget(self.imlist_view, 1, 1, 12, 1)
        self.imlist_view.setSelectionMode(QAbstractItemView.SingleSelection)

        #3. Edit Button
        self.HLayout_Edit = QHBoxLayout()
        self.btn_Prev = QPushButton('Prev', self)
        self.HLayout_Edit.addWidget(self.btn_Prev)
        self.btn_Next = QPushButton('Next', self)
        self.HLayout_Edit.addWidget(self.btn_Next)
        self.btn_Edit = QPushButton('Edit', self)
        self.HLayout_Edit.addWidget(self.btn_Edit)
        self.GLayout.addLayout(self.HLayout_Edit, 13, 1, 1, 1)

        self.btn_Prev.clicked.connect(self.PrevClicked)
        self.btn_Next.clicked.connect(self.NextClicked)
        self.btn_Edit.clicked.connect(self.EditClicked)

        self.Widget.setLayout(self.GLayout)
        self.setCentralWidget(self.Widget)

    def center(self):
        qr = self.frameGeometry()
        cp = QDesktopWidget().availableGeometry().center()
        qr.moveCenter(cp)
        self.move(qr.topLeft())

    def read_imlist_from_folder(self):

        top_folder = QFileDialog.getExistingDirectory(self, 'Open Image Folder', '',
                                                      QFileDialog.ShowDirsOnly | QFileDialog.DontResolveSymlinks)
        if len(top_folder) == 0:
            return

        self.all_filename,self.all_folder_list = find_image_names(top_folder)
        if len(self.all_filename) == 0:
            QMessageBox.critical(self, 'Error', 'Empty folder')
        else:
            self.all_filename_json, self.all_folder_list_json = find_image_names_with_json_file(top_folder)
            self.imlist = sorted(list(self.all_folder_list))
            self.total_num = len(self.imlist)
            self.total_json_num = len(self.all_folder_list_json)
            self.statusbar.showMessage('%d folders were found, %d folders with json file' %(self.total_num, self.total_json_num))
            self.imidx = 0
            self.update_listview()

    def read_imlist_from_folder_with_json_file(self):

        top_folder = QFileDialog.getExistingDirectory(self, 'Open Image Folder', '',
                                                      QFileDialog.ShowDirsOnly | QFileDialog.DontResolveSymlinks)
        if len(top_folder) == 0:
            return

        self.all_filename_json,self.all_folder_list_json = find_image_names_with_json_file(top_folder)
        if len(self.all_filename_json) == 0:
            QMessageBox.critical(self, 'Error', 'Empty folder')
        else:
            self.imlist = sorted(list(self.all_folder_list_json))
            self.total_json_num = len(self.imlist )
            self.statusbar.showMessage('%d folders were found with json file' %(self.total_json_num))
            self.imidx = 0
            self.update_listview()

    def update_seglistview(self):
        model = self.imlist_Seg_view.model()
        assert isinstance(model, QStandardItemModel)
        model.removeRows(0, model.rowCount())

        if len(self.seg_list) > 0:
            digits = int(np.ceil(np.log10(len(self.seg_list))))
            format_str = '{:0' + str(digits) + 'd}'

            for i, file in enumerate(self.seg_list):
                item = QStandardItem(format_str.format(i) + ' ' + file)
                item.setEditable(False)
                model.appendRow(item)

    def update_listview(self):
        model = self.imlist_view.model()
        assert isinstance(model, QStandardItemModel)
        model.removeRows(0, model.rowCount())

        if len(self.imlist) == 0:
            QMessageBox.critical(self, 'Error', 'No image exist')

        if len(self.imlist) > 0:
            digits = int(np.ceil(np.log10(len(self.imlist))))
            format_str = '{:0' + str(digits) + 'd}'

            for i, file in enumerate(self.imlist):
                item = QStandardItem(format_str.format(i) + ' ' + file)
                item.setEditable(False)
                model.appendRow(item)

    def XSpacingStateChanged(self, state):

        if state == Qt.Checked:
            self.edit_XMinimum.setText('{}'.format(self.x_minvalue))
            self.edit_XMaximum.setText('{}'.format(self.x_maxvalue))
            self.xspacing_box = True

        else:
            self.edit_XMinimum.setText('{}'.format(''))
            self.edit_XMaximum.setText('{}'.format(''))
            self.xspacing_box = False


    def XMinEditingFinished(self):
        edit = self.sender()
        try:
            self.x_minvalue = float(edit.text())
            if self.x_minvalue < 0:
                edit.setText('0.0'.format(self.edit_XMinimum))
                QMessageBox.warning(self, 'Warning', 'x spacing can not be less than 0')
        except:
            edit.setText('{}'.format(self.edit_XMinimum))
            QMessageBox.critical(self, 'Error', 'incorrect integer for x spacing')

    def XMaxEditingFinished(self):

        edit = self.sender()
        try:
            self.x_maxvalue = float(edit.text())
            if self.x_maxvalue < 0:
                edit.setText('0.0'.format(self.edit_XMaximum))
                QMessageBox.warning(self, 'Warning', 'x spacing can not be less than 0')

            if self.x_minvalue is not None:
                if self.x_minvalue > self.x_maxvalue:
                    edit.setText(str(self.x_minvalue).format(self.edit_XMaximum))
                    QMessageBox.warning(self, 'warning', 'Maximum spacing must bigger than Minimum spacing')
        except:
            edit.setText('{}'.format(self.edit_XMaximum))
            QMessageBox.warning(self, 'warning', 'incorrect integer for x spacing')

    def YSpacingStateChanged(self, state):

        if state == Qt.Checked:
            self.edit_YMinimum.setText('{}'.format(self.y_minvalue))
            self.edit_YMaximum.setText('{}'.format(self.y_maxvalue))
            self.yspacing_box = True

        else:
            self.edit_YMinimum.setText('{}'.format(''))
            self.edit_YMaximum.setText('{}'.format(''))
            self.yspacing_box = False

    def YMinEditingFinished(self):

        edit = self.sender()
        try:
            self.y_minvalue = float(edit.text())
            if self.y_minvalue < 0:
                edit.setText('0.0'.format(self.edit_YMinimum))
                QMessageBox.warning(self, 'Warning', 'y spacing can not be less than 0')

        except:
            edit.setText('{}'.format(self.edit_YMinimum))
            QMessageBox.warning(self, 'warning', 'incorrect number for y spacing')

    def YMaxEditingFinished(self):

        edit = self.sender()
        try:
            self.y_maxvalue = float(edit.text())
            if self.y_maxvalue < 0:
                edit.setText('0.0'.format(self.edit_YMaximum))
                QMessageBox.warning(self, 'Warning', 'y spacing can not be less than 0')

            if self.y_minvalue is not None:
                if self.y_minvalue > self.y_maxvalue:
                    edit.setText(str(self.y_minvalue).format(self.edit_YMaximum))
                    QMessageBox.warning(self, 'warning', 'Maximum spacing must bigger than Minimum spacing')
        except:
            edit.setText('{}'.format(self.edit_YMaximum))
            QMessageBox.warning(self, 'warning', 'incorrect number for y spacing')

    def ZSpacingStateChanged(self, state):

        if state == Qt.Checked:
            self.edit_ZMinimum.setText('{}'.format(self.z_minvalue))
            self.edit_ZMaximum.setText('{}'.format(self.z_maxvalue))
            self.zspacing_box = True

        else:
            self.edit_ZMinimum.setText('{}'.format(''))
            self.edit_ZMaximum.setText('{}'.format(''))
            self.zspacing_box = False

    def ZMinEditingFinished(self):

        edit = self.sender()
        try:
            self.z_minvalue = float(edit.text())
            if self.z_minvalue < 0:
                edit.setText('0.0'.format(self.edit_ZMinimum))
                QMessageBox.warning(self, 'Warning', 'z spacing can not be less than 0')
        except:
            edit.setText('{}'.format(self.edit_ZMinimum))
            QMessageBox.warning(self, 'warning', 'incorrect number for z spacing')

    def ZMaxEditingFinished(self):

        edit = self.sender()
        try:
            self.z_maxvalue = float(edit.text())
            if self.z_maxvalue < 0:
                edit.setText('0.0'.format(self.edit_ZMaximum))
                QMessageBox.warning(self, 'Warning', 'z spacing can not be less than 0')

            if self.z_minvalue is not None:
                if self.z_minvalue > self.z_maxvalue:
                    edit.setText(str(self.z_minvalue).format(self.edit_ZMaximum))
                    QMessageBox.warning(self, 'warning', 'Maximum spacing must bigger than Minimum spacing')
        except:
            edit.setText('{}'.format(self.edit_ZMaximum))
            QMessageBox.warning(self, 'warning', 'incorrect integer for z spacing')


    def GenderStateChanged(self, state):

        if state == Qt.Checked:
            self.btn_GenderGroup.setExclusive(True)
            self.gender_box = True

        else:
            self.btn_GenderGroup.setExclusive(False)
            self.radio_Male.setChecked(False)
            self.radio_Female.setChecked(False)
            self.radio_GenderX.setChecked(False)
            self.gender = ''
            self.gender_box = False

    def GenderGroupClicked(self):

        if self.radio_Male.isChecked():
            self.gender = 'M'
        elif self.radio_Female.isChecked():
            self.gender = 'F'
        elif self.radio_GenderX.isChecked():
            self.gender = 'X'
        else:
            self.gender = ''

    def BodypartsStateChanged(self, state):

        if state == Qt.Checked:
            self.bodyparts_box = True
        else:
            self.box_BodyHead.setChecked(False)
            self.box_BodyNeck.setChecked(False)
            self.box_BodyChest.setChecked(False)
            self.box_BodyAbdomen.setChecked(False)
            self.box_BodyPelvis.setChecked(False)
            self.box_BodyUndefined.setChecked(False)
            self.bodyparts_list = []
            self.bodyparts_box = False

    def BodyPartsClicked(self):

        self.bodyparts_list = []
        if self.box_BodyHead.isChecked():
            self.bodyparts_list.append('head')

        if self.box_BodyNeck.isChecked():
            self.bodyparts_list.append('neck')

        if self.box_BodyChest.isChecked():
            self.bodyparts_list.append('chest')

        if self.box_BodyAbdomen.isChecked():
            self.bodyparts_list.append('abdomen')

        if self.box_BodyPelvis.isChecked():
            self.bodyparts_list.append('pelvis')

        if self.box_BodyUndefined.isChecked():
            self.bodyparts_list.append('undefined')

    def TagsStateChanged(self, state):

        if state == Qt.Checked:
            self.tags_box = True
        else:
            self.tags_info = []
            self.edit_Tags.setText('{}'.format(''))
            self.tags_box = False

    def TagsEditingFinished(self):

        edit = self.sender()
        try:
            tag = str(edit.text())
            self.tags_info = list(tag.split(';'))
        except:
            self.tags_info = []
            edit.setText('{}'.format(''))
            QMessageBox.warning(self, 'warning', 'Wrong tags')

    def SegmentationStateChanged(self, state):

        if state == Qt.Checked:
            self.segmentation_box = True
        else:
            self.sel_seg_list = set()
            self.segmentation_box = False
            self.update_seglistview()

    def ExportTrainClicked(self):

        if len(self.all_filename_json) < 2:
            QMessageBox.critical(self, 'Error', 'Less than two different image names')
        else:
            names = list(self.all_filename_json)
            diag = TrainNameDialog()
            diag.org_combobox.addItems(names)
            diag.seg_combobox.addItems(names)
            diag.exec_()

            ind = 0
            name_text = ''
            if diag.result() == QDialog.Accepted:
                org_name = diag.org_name
                seg_name = diag.seg_name
                for im_path in self.select_imlist:
                    file_img_path = os.path.join(im_path, org_name)
                    file_seg_path = os.path.join(im_path, seg_name)
                    IMG_EXIST = 0
                    SEG_EXIST = 0
                    if os.path.isfile(file_img_path):
                        IMG_EXIST = 1
                    if os.path.isfile(file_seg_path):
                        SEG_EXIST = 1

                    if SEG_EXIST and IMG_EXIST:
                        ind = ind + 1
                        name_text = name_text + file_img_path + '\n'
                        name_text = name_text + file_seg_path + '\n'

            foldername = QFileDialog.getExistingDirectory(
                self, 'Open Training List Save Folder',
                options=QFileDialog.ShowDirsOnly | QFileDialog.DontResolveSymlinks)
            if len(foldername) == 0:
                return

            out_file = os.path.join(foldername, 'train.txt')
            fp = open(out_file, 'w')
            if ind > 0:
                fp.write(str(ind) + '\n' + name_text)
                self.statusbar.showMessage('%d image files were exported out for training.' % ind)
            else:
                self.statusbar.showMessage('No image file were exported out for training!')

    def ExportTestClicked(self):

        if len(self.all_filename_json) == 0:
            QMessageBox.critical(self, 'Error', 'Empty folder with json file')
        else:
            names = list(self.all_filename_json)
            diag = TestNameDialog()
            diag.org_combobox.addItems(names)
            diag.exec_()

            ind = 0
            name_text = ''
            if diag.result() == QDialog.Accepted:
                org_name = diag.org_name
                for im_path in self.select_imlist:
                    im_path = str(im_path)
                    _,case_name = os.path.split(im_path)
                    file_path = os.path.join(im_path, org_name)
                    if os.path.isfile(file_path):
                        ind = ind + 1
                        name_text += case_name + ' ' + file_path + '\n'

            foldername = QFileDialog.getExistingDirectory(
                self, 'Open Training List Save Folder',
                options=QFileDialog.ShowDirsOnly | QFileDialog.DontResolveSymlinks)
            if len(foldername) == 0:
                return

            out_file = os.path.join(foldername, 'test.txt')
            fp = open(out_file, 'w')
            if ind > 0:
                fp.write(str(ind) + '\n' + name_text)
                self.statusbar.showMessage('%d image files were exported out for testing.' % ind)
            else:
                self.statusbar.showMessage('No image file were exported out for testing!')

    def QueryClicked(self):

        self.select_imlist = set()

        if self.xspacing_box or self.yspacing_box or self.zspacing_box or self.gender_box or self.bodyparts_box or self.tags_box:
            if len(self.all_folder_list_json) == 0:
                QMessageBox.critical(self, 'Error', 'No folder with json file')
                return

        for folder_path in sorted(list(self.all_folder_list_json)):
            json_file = os.path.join(folder_path, 'meta.json')
            fp = open(json_file, 'r')
            info = json.load(fp)
            fp.close()

            sel_flag = True
            if self.xspacing_box and sel_flag:
                if 'x_spacing' not in info:
                    sel_flag = False
                    continue
                if info['x_spacing'] < self.x_minvalue or info['x_spacing'] > self.x_maxvalue:
                    sel_flag = False
                    continue

            if self.yspacing_box and sel_flag:
                if 'y_spacing' not in info:
                    sel_flag = False
                    continue
                if info['y_spacing'] < self.y_minvalue or info['y_spacing'] > self.y_maxvalue:
                    sel_flag = False
                    continue

            if self.zspacing_box and sel_flag:
                if 'z_spacing' not in info:
                    sel_flag = False
                    continue
                if info['z_spacing'] < self.z_minvalue or info['z_spacing'] > self.z_maxvalue:
                    sel_flag = False
                    continue

            if self.gender_box and sel_flag:
                if 'gender' not in info:
                    sel_flag = False
                    continue

                if self.gender != '':
                    if info['gender'] != self.gender:
                        sel_flag = False
                        continue

            if self.bodyparts_box and sel_flag:
                if 'body_parts' not in info:
                    sel_flag = False
                    continue

                info_body = []
                for body in info['body_parts']:
                    info_body.append(body.encode('utf-8'))

                for body in self.bodyparts_list:
                    if body not in info_body:
                        sel_flag = False
                        continue

            if self.tags_box and sel_flag:
                if 'tags' not in info:
                    sel_flag = False
                    continue

                info_tag = []
                for tag in info['tags']:
                    info_tag.append(tag.encode('utf-8'))

                for tag in self.tags_info:
                    if tag not in info_tag:
                        sel_flag = False
                        continue

            if sel_flag and self.segmentation_box:

                seg_organs_list = []
                for organs in self.sel_seg_list:
                    if organs == 'female_bladder' or organs == 'male_bladder':
                        seg_organs_list.append('bladder.nii.gz')
                    else:
                        seg_organs_list.append(organs+'.nii.gz')

                for seg_organ in seg_organs_list:
                    flag_seg = False
                    for file_name in sorted(os.listdir(folder_path)):
                        if seg_organ == file_name.encode('utf-8'):
                            flag_seg = True
                            break

                    if flag_seg == False:
                        sel_flag = False
                        break

            if sel_flag == True:
                self.select_imlist.add(folder_path)

        self.imlist = sorted(list(self.select_imlist))
        self.total_select_num = len(self.imlist )
        self.statusbar.showMessage('%d folders were retrieved' %(self.total_select_num))
        self.imidx = 0
        self.update_listview()

    def PrevClicked(self):

        rows = self.imlist_model.rowCount()
        if rows == 0:
            return

        if self.imidx == 0:
            QMessageBox.information(self, 'Info', 'You have reached the beginning of image list')
            return

        self.imidx = (self.imidx - 1) % rows
        idx = self.imlist_model.index(self.imidx, 0)
        data = self.imlist_model.data(idx)
        idx = data.index(' ')
        self.edit_data = str(data[idx+1:])

    def NextClicked(self):

        rows = self.imlist_model.rowCount()
        if rows == 0:
            return

        if self.imidx == rows - 1:
            QMessageBox.information(self, 'Info', 'You have reached the end of image list')
            return

        self.imidx = (self.imidx + 1) % rows
        idx = self.imlist_model.index(self.imidx, 0)
        data = self.imlist_model.data(idx)
        idx = data.index(' ')
        self.edit_data = str(data[idx+1:])

    def imlist_item_doubleclicked(self, idx):

        data = self.imlist_model.data(idx)
        idx = data.index(' ')
        self.imidx = int(data[:idx])
        self.edit_data = str(data[idx+1:])

    def seg_imlist_item_doubleclicked(self, idx):

        data = self.imlist_seg_model.data(idx)
        idx = data.index(' ')
        organ_name = str(data[idx+1:])
        if organ_name in self.sel_seg_list:
            self.sel_seg_list.remove(organ_name)
        else:
            self.sel_seg_list.add(organ_name)

        if len(self.sel_seg_list) == 0:
            self.segmentation_box = False
        else:
            self.segmentation_box = True

    def EditClicked(self):

        if self.edit_data == '':
            QMessageBox.critical(self, 'Error', 'Please select the image to be edited')
        else:
            json_file_path = os.path.join(self.edit_data,'meta.json')
            diag = EditDialog(json_file_path)
            diag.exec_()

if __name__ == "__main__":

    app = QApplication(sys.argv)
    viewer = SearchViewer()
    viewer.show()

    sys.exit(app.exec_())
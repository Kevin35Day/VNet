import platform

# switch between linux and windows system
if platform.system() == 'Linux':
    # from md.segmentation3d.impl.vseg_pyimpl import autoseg_load_model, autoseg_volume
    from md.segmentation3d.impl.vseg_cimpl import autoseg_load_model, autoseg_volume
elif platform.system() == 'Windows':
    from md.segmentation3d.impl.vseg_cimpl import autoseg_load_model, autoseg_volume
else:
    raise OSError('Operation System Not Supported!')

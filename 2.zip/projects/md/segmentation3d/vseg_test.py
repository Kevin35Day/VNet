import argparse
import glob
import os
import time
import numpy as np
import md.image3d.python.image3d_io as cio
from md.utils.python.file_tools import readlines
from md.segmentation3d.vseg import autoseg_volume, autoseg_load_model


def test(input_path, model_folder, output_folder, gpu_id=0):
    """
    volumetric image segmentation engine
    :param input_path:          a path of text file, a single image file or a root dir with all image files
    :param model_folder:        path of trained model
    :param output_folder:       path of out folder
    :param gpu_id:              which gpu to use, by default, 0
    :return: None
    """
    if not os.path.isdir(output_folder):
        os.makedirs(output_folder)
    total_test_time = 0
    model = autoseg_load_model(model_folder, gpu_id)

    # determine testing cases
    suffix = ['.mhd', '.nii', '.hdr', '.nii.gz', '.mha']
    file_list = []
    name_list = []
    SINGLE_FILE = 0
    if os.path.isfile(input_path):
        for suf in suffix:
            if input_path.endswith(suf):
                # test single file
                file_list = [input_path]
                SINGLE_FILE = 1
                break
        if SINGLE_FILE == 0:
            # test image files in the text file
            lines = readlines(input_path)
            case_num = int(lines[0])
            if len(lines) - 1 != case_num:
                raise ValueError('case num do not equal path num!')
            for i in range(case_num):
                im_msg = lines[1+i]
                # idx = im_msg.index(' ')
                # im_name = im_msg[:idx]
                # im_path = im_msg[idx+1:]
                idx = im_msg.index('/')
                im_name = im_msg[:idx-1]
                im_path = im_msg[idx:]
                # im_path = im_path[:-1]
                if not os.path.isfile(im_path):
                    raise ValueError('image not exist: {}'.format(im_path))
                file_list.append(im_path)
                name_list.append(im_name)

    elif os.path.isdir(input_path):
        # test image file in the input path
        for suf in suffix:
            file_list += glob.glob(os.path.join(input_path, '*'+suf))
    else:
        raise ValueError('Input path do not exist!')

    success_cases = 0
    for i, file in enumerate(file_list):
        print '{}: {}'.format(i, file)

        begin = time.time()
        image = cio.read_image(file, dtype=np.float32)
        read_time = time.time() - begin

        try:
            pred, _, _, test_time = autoseg_volume(image, model)
        except Exception as e:
            print 'fails to segment volume: ', file, ', {}'.format(e)
            continue

        if len(name_list) == 0:
            _, filename = os.path.split(file)
            for suf in suffix:
                idx = filename.find(suf)
                if idx != -1:
                    filename = filename[:idx]
                    break
        else:
            filename = name_list[i]

        out_folder = os.path.join(output_folder, filename)
        if not os.path.isdir(out_folder):
            os.makedirs(out_folder)

        ct_path = os.path.join(out_folder, 'org.mha')
        seg_path = os.path.join(out_folder, 'seg.mha')

        begin = time.time()
        cio.write_image(image, ct_path)
        cio.write_image(pred, seg_path, compression=True)
        output_time = time.time() - begin

        total_time = read_time + test_time + output_time
        total_test_time = test_time + total_test_time
        success_cases += 1
        print 'read: {:.2f} s, test: {:.2f} s, write: {:.2f} s,' \
              ' total: {:.2f} s, avg test time: {:.2f}'.format(
            read_time, test_time, output_time, total_time, total_test_time/float(success_cases))


if __name__ == '__main__':

    parser = argparse.ArgumentParser()

    parser.add_argument('-i', '--input',
                        default='/home/ubuntu2/projects/organs/v2.0/kidney_left/test.txt',
                        help='input folder/file for intensity images')

    parser.add_argument('-m', '--model',
                        default='/home/ubuntu2/projects/organs/v2.0/kidney_left',
                        help='model root folder')

    parser.add_argument('-o', '--output',
                        default='/home/ubuntu2/Desktop',
                        help='output folder for segmentation')

    parser.add_argument('-g', '--gpu-id',
                        default='0',
                        help='the gpu id to run model')

    args = parser.parse_args()
    test(args.input, args.model, args.output, int(args.gpu_id))

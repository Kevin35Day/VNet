import md
import os
import numpy as np
from md.segmentation3d.utils.imlist_tools import *
from md.image3d.python.image3d_io import *
from md.utils.python.eval import cal_dsc


def cal_dice_all():

    root_dir = '/mnt/disk/mfh_Data/test_392'
    gt_dir = '/mnt/disk/mfh_Data/test_392_0412'
    out_path = '/home/mfh/organs/bladder51_dice_DL.txt'
    # pattern = MedImagePattern('liver\.nii\.gz$')
    # pattern = MedImagePattern('bladder.nii.gz')
    pattern = MedImagePattern('seg.mha')
    suc_rate = []
    dice_ind = []
    for case_name in sorted(os.listdir(root_dir)):
        curr_GT = []
        curr_Result = []
        case_dir = os.path.join(gt_dir, case_name)
        if os.path.isdir(case_dir):
            result_path = os.path.join(root_dir, case_name, 'seg.mha')
            #result_path = os.path.join(gt_dir, case_name,'C_Result', 'liverC.nii.gz')
            if os.path.isfile(result_path):
                curr_Result = read_image(result_path)
            else:
                dice_ind.append(0)
                suc_rate.append(0)
                continue
            for file_name in os.listdir(case_dir):
                if pattern.test(file_name):
                    gt_path = os.path.join(gt_dir, case_name, file_name)
                    curr_GT = read_image(gt_path)
                    break
        if curr_GT and curr_Result:
            # ctools.replace_pixel(curr_Result, 1 , 2)
            dice = cal_dsc(curr_Result, curr_GT, 1)
            dice_ind.append(dice)
            # print ('%.4f' % (dice))
            print ('%s' % (case_name))
            # print ('case name: %s, dice: %.4f'%(case_name, dice))
            if dice >= 0.8:
                suc_rate.append(1)
            else:
                suc_rate.append(0)
        else:
            dice_ind.append(-1)
            print('Case name: %s, No seg result!')%(case_name)
    sum_suc = float(sum(suc_rate)) / len(suc_rate)
    dice_ind = np.array(dice_ind)
    dice_tmp = dice_ind[dice_ind>=0.8]
    avg_dice = dice_tmp.mean()
    std_dice = dice_tmp.std()
    with open(out_path, 'w') as fp:
        fp.write('success rate: ' + str(sum_suc) + '\n' + 'avg dice: ' + str(avg_dice) + '\n' + 'std dice: ' + str(
            std_dice) + '\n')
        for i, j in zip(dice_ind, sorted(os.listdir(root_dir))):
            fp.write(str(j) + ': ' + str(i) + '\n')
        fp.close()
    print('Success rate is %.4f. \n Average dice is %.4f. \n Standard deviation dice is %.4f.' % (
    sum_suc, avg_dice, std_dice))

if __name__ == '__main__':
    cal_dice_all()
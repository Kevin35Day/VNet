from md.tools.imlist_tools import *
import numpy as np
from md._c._cimage3d_io import read_image, write_image
import md._c._cimage3d_tools as ctools
from md.tools.file_tools import readlines
import os
from md.tools.image3d_tools import*
from md._c._cimage3d_tools import*
import  shutil
from md._c._cimage3d_eval import cal_dsc
from md.seg import vnet3_test
import md.vis.plotly_tools as pt
# from md.seg.vnet_helpers import convert_pymodel_to_neuro
#import paramiko


def make_norm_image(file_path, dim):
    """
    #read image, rewrite header file and filp image in y dim
    :param file_path: file path
    :param out_path: out path
    :return: bool param
    """
    image = read_image(file_path)
    axes = np.array([[1,0,0],[0,1,0],[0,0,1]])
    image.set_axes(axes)
    img = image.to_numpy()
    img = np.flip(img, dim)
    # img = np.flip(img, 2)
    # img = np.flip(img, 0)
    # img[img == 1] = 2
    image.from_numpy(img)
    out_path, _ = os.path.split(file_path)
    out_path = out_path + '/spleen.nii.gz'
    return write_image(image, out_path, dtype=np.int8, compression=True)


def make_modified_seg_mhd(seg_path, image_path, out_path):
    make_norm_image(seg_path, out_path, d_type=np.uint8, compression=True)
    lines=readlines(seg_path)
    lines_image=readlines(image_path)
    lines[7]=lines_image[6]
    with open(out_path,'w') as fp:
        for i in range(len(lines)):
            fp.write(lines[i]+'\n')
            fp.close


def cal_dice_all():

    #root_dir = '/media/4t/abdomen/test/spleen_dice-c_dice-f'
    root_dir = '/mnt/disk/Data/pelvic/bladder_test_0207'
    # root_dir_C = '/home/ubuntu1/data/abdomen/data_all_number'
    #gt_dir = '/media/4t/abdomen/data'
    gt_dir = '/mnt/disk/Data/pelvic/female'
    out_path = '/home/mfh/organs/liver168_dice_DL.txt'
    pattern = MedImagePattern('bladder.nii.gz')
    suc_rate = []
    dice_ind = []
    for case_name in sorted(os.listdir(root_dir)):
        curr_GT = []
        curr_Result = []
        case_dir = os.path.join(gt_dir, case_name)
        if os.path.isdir(case_dir):
            result_path = os.path.join(root_dir, case_name, 'seg.mha')
            #result_path = os.path.join(gt_dir, case_name,'C_Result', 'liverC.nii.gz')
            if os.path.isfile(result_path):
                curr_Result = read_image(result_path)
            else:
                dice_ind.append(0)
                suc_rate.append(0)
                continue
            for file_name in os.listdir(case_dir):
                if pattern.test(file_name):
                    gt_path = os.path.join(gt_dir, case_name, file_name)
                    curr_GT = read_image(gt_path)
                    break
        if curr_GT and curr_Result:
            # ctools.replace_pixel(curr_Result, 1 , 2)
            dice = cal_dsc(curr_Result, curr_GT, 1)
            dice_ind.append(dice)
            print ('case name: %s, dice: %.2f'%(case_name, dice))
            if dice >= 0.8:
                suc_rate.append(1)
            else:
                suc_rate.append(0)
        else:
            dice_ind.append(-1)
            print('Case name: %s, No seg result!')%(case_name)
    sum_suc = float(sum(suc_rate)) / len(suc_rate)
    dice_ind = np.array(dice_ind)
    dice_tmp = dice_ind[dice_ind>=0.8]
    avg_dice = dice_tmp.mean()
    std_dice = dice_tmp.std()
    with open(out_path, 'w') as fp:
        fp.write('success rate: ' + str(sum_suc) + '\n' + 'avg dice: ' + str(avg_dice) + '\n' + 'std dice: ' + str(
            std_dice) + '\n')
        for i, j in zip(dice_ind, sorted(os.listdir(root_dir))):
            fp.write(str(j) + ': ' + str(i) + '\n')
        fp.close()
    print('Success rate is %.2f. \n Average dice is %.2f. \n Standard deviation dice is %.2f.' % (
    sum_suc, avg_dice, std_dice))


def print_space(dir, org_name):
    for file_name in os.listdir(dir):
        file_path = os.path.join(dir,file_name)
        if os.path.isfile(file_path):
            if org_name.test(file_name):
                text_file = readlines(file_path)
                spacing = text_file[9]
                im_size = text_file[10]
                print (file_name, spacing, im_size)


def replace_imlist():
    txtfile=readlines('/media/4t/abdomen/model/spleen1215/train.txt')
    txt = ''
    for i, line in enumerate(txtfile):
        line = line.replace('/media/4t/abdomen/data', '/home/zhangyu/abdomen/data')
        # line = line.replace('image.nii.gz', 'image_norm.mhd')
        # line = line.replace('kidney', 'kidney.nii.gz')
        # line = line.replace('kidney_all.mha', 'kidney.nii.gz')
        txt = txt + line +'\n'
    fp=open('/media/4t/abdomen/model/spleen1215/train2.txt','w')
    fp.write(txt)
    fp.close()


def make_hist_file():
    txtfile=readlines('/home/mfh/organs/right-kidney/dice_result_C.txt')
    num = len(txtfile)
    dice = []
    hists = []
    for i in range(3, num):
       lines=txtfile[i]
       dice.append(lines[5:-1])
    hist1= pt.build_hist(dice, 'TPS', 0.8, 1, 0.005, color='#0000FF', opacity=1.0)
    hists.append(hist1)

    txtfile=readlines('/home/mfh/organs/right-kidney/dice_result_vnet.txt')
    num = len(txtfile)
    dice = []
    for i in range(3, num):
       lines=txtfile[i]
       dice.append(lines[5:-1])
    hist2= pt.build_hist(dice, 'Deep Learning', 0.8, 1, 0.005, color='#FF0000', opacity=1.0)
    hists.append(hist2)

    out_file='/home/mfh/organs/right-kidney_vs-TPS.html'
    pt.hist_comp(hists, out_file,title='Histogram of right-kidney segmentation', xname='Dice', yname='Count')


def case_list_process():
    root_dir = '/media/4t/bladder_data/data_original/female_organized/U'
    out_dir = '/media/4t/bladder_data/data/female'
    image_name = MedImagePattern('image.nii.gz')
    seg_name = MedImagePattern('bladder_uncheck.nii.gz')
    count = 0
    case_count = 171
    for case_name in sorted(os.listdir(root_dir)):
        case_dir = os.path.join(root_dir, case_name)
        if os.path.isdir(case_dir):
            # print case_name
            # print out_case_dir
            # os.mkdir(out_case_dir)
            for file_name in os.listdir(case_dir):
                file_dir = os.path.join(case_dir, file_name)
                remote_dir = os.path.join(out_dir, case_name, 'spleen.nii.gz')
                if os.path.isfile(file_dir):
                    # if  image_name.test(file_name):
                    #     shutil.copyfile(file_dir, os.path.join(out_case_dir, file_name))
                    #     count +=1
                    if seg_name.test(file_name):
                        print  file_name
                        print out_case_dir
                        shutil.copyfile(file_dir, os.path.join(out_case_dir, file_name))
                        count +=1
                        # shutil.copyfile(file_dir,)

                        # print file_name
                        # count+=1
                        # if  org.test(file_name):
                        #     continue
                        #     print file_name
                        #     count+=1
                        #
                        #     outfile = os.path.join(out_dir, case_name, 'bladder.nii.gz')
                        #     image = read_image(file_dir)
                        #     write_image(image, outfile, dtype=np.int8, compression=True)
                        # else:
                        #     print file_name
                        #     count += 1
                        #     outfile = os.path.join(out_dir, case_name, 'image.nii.gz')
                        #     image = read_image(file_dir)
                        #     write_image(image, outfile, dtype=np.int16, compression=True)
                        # try:
                        #     remote_operation(file_dir, remote_dir)
                        #     count += 1
                        #     print ('success: %s' % (case_name))
                        # except :
                        #     print ('fail: %s'%(case_name))

    print ('process case num is :%d'%(count))


def mean_blur(file_path, thre=0.5, sz=3):
    image = read_image(file_path, dtype=np.double)
    # replace_pixel(image, 1, 2)
    label = 1
    filter = np.ones([sz, sz, sz], dtype=np.double)
    filter = filter / (sz*sz*sz)

    imfilt(image, filter)
    img = image.to_numpy()
    img[img < thre] = 0
    img[img >= thre] = label
    image.from_numpy(img)
    save_path, _ = os.path.split(file_path)
    save_path = os.path.join(save_path, 'spleen.nii.gz')
    write_image(image, save_path, dtype=np.int8, compression=True)


def remote_operation(local_dir, remote_dir):
    host = '10.9.19.50'
    usrname = 'zhangyu'
    password = 'zy13882188701'
    t = paramiko.Transport((host, 22))
    t.connect(username=usrname, password=password)
    sftp = paramiko.SFTPClient.from_transport(t)
    # sftp.remove(remote_dir)
    sftp.put(local_dir, remote_dir)

    t.close()

def bladder():
    root_dir = '/media/4t/bladder data/data/'
    female = '/media/4t/bladder data/female_data'
    male = '/media/4t/bladder data/male_data'
    for case_name in sorted(os.listdir(root_dir)):
        case_dir = os.path.join(root_dir, case_name)
        if os.path.isdir(case_dir):
            pass


if __name__ == '__main__':
    # vnet3_test('/media/4t/abdomen/data/0139/image.nii.gz', '/media/4t/abdomen/model/spleen1215/','/media/4t/abdomen/model/spleen_focal_0.9c/')
    # replace_imlist()
    # cfg_file = '/media/zhangyu/4e3b15a6-e2d7-419a-b642-fa44a05492d1/abdomen/model/test1028/fine.py'
    # train(cfg_file)
    cal_dice_all()

    #model_path = '/media/4t/abdomen/model/spleen1215/coarse/checkpoints/chk_0/params.pth'
    #out_path = '/media/4t/abdomen/model/spleen1215/coarse/checkpoints/chk_0/temp.neuro'
    #convert_pymodel_to_neuro(model_path, out_path)
    # make_hist_file()


    # case_list_process()

    # case_count += 1
    # if case_count < 10:
    #     name = '000' + str(case_count)
    # elif case_count< 100:
    #     name = '00' + str(case_count)
    # else:
    #     name = '0' + str(case_count)
    # out_case_dir = os.path.join(out_dir, name)
    # root_dir = '/media/4t/bladder_data/data/female'
    # out_dir = '/media/4t/bladder_data/data/female_imlist.txt'
    # org = 'image\.nii\.gz'
    # seg = 'spleen\.nii\.gz'
    # make_train_imlist(root_dir, out_dir, org, seg)
    # cut_shuffle_train_imlist(out_dir)
    # filter = TxtFilter('/media/4t/abdomen/model/spleen1215/train.txt')
    # notfilter = NotFilter(filter)
    # make_test_imlist(root_dir,out_dir,'image\.nii\.gz')

    # file_path = '/media/4t/abdomen/test/spleen_1214/' \
    #             '0427/spleen.nii.gz'
    # make_norm_image(file_path, 2)

    # image = read_image(file_path)
    # impad(image, [5,5,5])
    # write_image(image, '/mnt/disk/abdomen/test/spleen_test_0920/vnet_seg/0070/imagepad.nii.gz')
    # #
    # file_path = '/media/4t/abdomen/data/0431/spleen2.nii.gz'
    # mean_blur(file_path, 0.5, sz=5)
    # image = read_image(file_path)
    # size = pick_largest_component(image)
    # write_image(image, file_path, compression=True)
    # print (size)


    # file_path = '/media/zhangyu/4e3b15a6-e2d7-419a-b642-fa44a05492d1/abdomen/data/' \
    #             '0258/spleen.nii.gz'
    # out_path = '/media/zhangyu/4e3b15a6-e2d7-419a-b642-fa44a05492d1/abdomen/data/' \
    #            '0258/spleen2.nii.gz'
    # make_norm_image(file_path, out_path)


    # print(case_name)
    # segright = read_image(os.path.join(root_dir, case_name, 'kidney_right.nii.gz'))
    # segleft = read_image(os.path.join(out_dir, case_name, 'kidney_left.mha'))
    # img = segleft.to_numpy()
    # imgtmp = segright.to_numpy()
    # imgtmp = np.flip(imgtmp, 2)
    # img[imgtmp == 1] = 2
    # segleft.from_numpy(img)
    # write_image(segleft, os.path.join('/media/ubuntu1/4e3b15a6-e2d7-419a-b642-fa44a05492d1/abdomen/data', case_name,
    #                                   'kidney.nii.gz'), dtype=np.int16, compression=True)

    # root_dir = '/home/ubuntu1/data/SKI10_MRKnee/TrainingData'
    # org_name = MedImagePattern('image\S+\.mhd$')
    # print_space(root_dir, org_name)
    # image = read_image('/home/ubuntu1/data/SKI10_MRKnee/TrainingData/labels-033.mhd')
    # ctools.imdilate(image, 9, 4)
    # spacing = [0.3906*4,0.3906*4,1*4]
    # image_samp = resample_volume_nn_rai(image, spacing, padtype=0)
    # write_image(image_samp, '/home/ubuntu1/data/SKI10_MRKnee/samp_seg.mhd')

    # # cal_dice_all()
    # # print ('process image %d  %d'%(count1,count2))
    # root_dir = '/home/ubuntu1/data/LUNA16/seg-lungs'
    # org_name = ('org\.mha')
    # seg_name = (r'seg\.mha')
    #
    # out_file = '/home/ubuntu1/projects/organs/kidney_1010/test_MedImagePattern.txt'
    # train_txt_path = '/home/ubuntu1/projects/organs/kidney_1010/train_80.txt'
    # name_exclude = 'kidney_v1.nii'
    # filter_txt = TxtFilter(train_txt_path)
    # filter_name = FileNameFilter(name_exclude)
    # my_and_filter = AndFilter()
    # my_and_filter.add_filter(filter_txt)
    # my_and_filter.add_filter(filter_name)
    # my_not_filter = NotFilter(filter_txt)
    # # make_train_imlist(root_dir, out_file, org_name, seg_name, my_not_filter)#
    #
    # make_test_imlist(root_dir, out_file)

    # num = int(case_name)
    # V2_EXIST = 0
    # case_dir = os.path.join(root_dir, case_name)
    # for file_name in os.listdir(case_dir):
    #     if os.path.isfile(os.path.join(case_dir, file_name)):
    #         if file_name == 'kidney_v3.mha':
    #             file_path = os.path.join(case_dir, file_name)
    #             V2_EXIST = 1
    #
    # if V2_EXIST == 1:
    #     seg_image = read_image(file_path)
    #     out_path = os.path.join(out_dir, case_name, 'kidney_right.mha')
    #     make_norm_image(file_path, out_path, np.uint8, True)
    #     # write_image(seg_image, out_path, np.uint8, True)
    #     count1 += 1


    # flip_case = np.array([66,67,90,94,98,100,112,119,125,136,138,145,146,152,162,190,241
    #            ,260,268,270,271]+range(277,296)+range(305,340)+range(351,439))
    # seg_path = '/home/ubuntu1/data/abdomen/data_all_number/0444/kidney_left.mha'
    # out_seg_path = '/home/ubuntu1/data/abdomen/data_all_number/0444/kidney_left.mha'

    # file_path = '/home/ubuntu1/projects/organs/kidney_1010/train_tmp.txt'

    # out_path = '/home/ubuntu1/data/abdomen/data_all_number/0444/image_norm.mhd'
    # make_norm_image(image_path,out_path)
    # make_norm_image(seg_path,out_seg_path,np.uint8,True)
    # if file_name == 'image.nii':
    #     file_path = os.path.join(case_dir, file_name)
    #     out_path = os.path.join(case_dir, 'image_norm.mhd')
    #     make_norm_image(file_path, out_path)
    #     # make_norm_image(file_path, out_path, d_type=np.uint8, compression=False)
    #     count += 1

    # if file_name == 'kidney_v1.mhd':
    #     print (case_name)
    # if file_name == 'image_norm.mhd':
    #     seg_path = os.path.join(case_dir, file_name)
    #     image_path = os.path.join(case_dir, 'image_norm.mhd')
    #     out_path = os.path.join(case_dir, 'kidney_modified.mhd')
    #     make_modified_seg_mhd(seg_path, image_path, out_path)
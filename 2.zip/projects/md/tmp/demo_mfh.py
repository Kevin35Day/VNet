import md
import os
import shutil
import numpy as np
import md.image3d.python.image3d_io as cio
import json



def copyfile_image(input_dir,output_dir,source_filename,save_filename):
    """
    copy image file
    :param input_dir: the source file path
    :param output_dir: the destination file path
    :return: bool param
    """
    num = 1
    for case_name in sorted(os.listdir(input_dir)):

        case_dir = os.path.join(input_dir, case_name)
        file_name = os.path.join(case_dir, source_filename)

        if os.path.isfile(file_name):

            if num > 0:
                # print case_name
                try:
                    save_dir = os.path.join(output_dir, case_name)
                    if not os.path.isdir(save_dir):
                        os.makedirs(save_dir)
                    save_file_dir = os.path.join(save_dir, save_filename)
                    shutil.copy(file_name, save_file_dir)

                    # #copy json file
                    # source_json_dir = os.path.join(case_dir, 'meta.json')
                    # save_json_dir = os.path.join(save_dir, 'meta.json')
                    # if os.path.isfile(source_json_dir):
                    #     shutil.copy(source_json_dir, save_json_dir)

                except Exception:
                    print num,case_name

        num = num + 1


def convert_mha_to_nii(input_dir, output_dir, mha_filename, nii_filename):

    for case_name in sorted(os.listdir(input_dir)):

        case_dir = os.path.join(input_dir, case_name)
        file_name = os.path.join(case_dir, mha_filename)

        if os.path.isfile(file_name):
            print case_name
            im = md.read_image(file_name)

            save_dir = os.path.join(output_dir, case_name)
            if not os.path.isdir(save_dir):
                os.makedirs(save_dir)
            save_file_dir = os.path.join(save_dir, nii_filename)

            md.write_image(im, save_file_dir)


def iamge_convert_to_RAI(input_dir, output_dir):
    """
    convert to patient coordinate system RAI
    :param input_dir: the original image path
    :param output_dir: patient coordinate system image path
    :return: bool param
    """

    num = 1
    for case_name in sorted(os.listdir(input_dir)):

        if num > 0:
            print case_name
            case_dir = os.path.join(input_dir, case_name)
            file_name = os.path.join(case_dir, 'image.nii.gz')

            if os.path.isfile(file_name):

                im = md.read_image(file_name)
                axes = np.array([[1,0,0],[0,1,0],[0,0,1]])
                im.set_axes(axes)

                save_dir = os.path.join(output_dir, case_name)
                if not os.path.isdir(save_dir):
                    os.makedirs(save_dir)
                save_file_dir = os.path.join(save_dir,'image.nii.gz')

                md.write_image(im, save_file_dir)

        num = num + 1


def read_dicomRT_contour(input_dir, output_dir):

    num = 1
    for case_name in sorted(os.listdir(input_dir)):
        print case_name
        if num > 0:
            case_dir = os.path.join(input_dir, case_name)

            dicom_contour = md.read_dicom_rt_contours(case_dir)

            for key in dicom_contour:
                contour_name = key+'.nii.gz'
                save_case_dir = os.path.join(output_dir, case_name, contour_name)
                md.write_image(dicom_contour[key], save_case_dir)

        num = num +1


def convert_dicom_to_nifti(input_dir, output_dir):

        num = 1
        for case_name in sorted(os.listdir(input_dir)):
            # print num
            if num > 0:

                case_dir = os.path.join(input_dir, case_name)
                try:
                    im, tags = md.read_dicom_series(case_dir)
                    save_dir = os.path.join(output_dir, case_name, 'image.nii.gz')
                    md.write_image(im, save_dir)

                    # im = md.read_image(output_dir)
                    # output_dir1 = os.path.join(output_path, case_name)
                    # md.write_dicom_series(im, output_dir1, tags=tags)

                except Exception:

                    print num, case_name

            num = num + 1

def dicom_tags_dict(
        modality='CT',
        image_type=r'DERIVED\\SECONDARY',
        conversion_type='DV',
        patient_position='HFS',
        series_description='UIH-AI',
        study_description='RTSeg',
        patient_name='Anonymous',
        patient_id='20171230',
        patient_age='99',
        rescale_type='HU',
        rescale_slope='1',
        rescale_intercept='0'):

    tags = {}
    tags['0008|0060'] = modality
    tags['0008|0008'] = image_type
    tags['0008|0064'] = conversion_type
    tags['0008|103E'] = series_description
    tags['0008|1030'] = study_description
    tags['0018|5100'] = patient_position
    tags['0010|0010'] = patient_name
    tags['0010|0020'] = patient_id
    tags['0010|1010'] = patient_age
    tags['0028|1052'] = rescale_intercept
    tags['0028|1053'] = rescale_slope
    tags['0028|1054'] = rescale_type

    return tags

def convert_nifti_to_dicom(input_dir, output_dir):

    num = 1
    for case_name in sorted(os.listdir(input_dir)):
        # print num
        if num > 0:

            case_dir = os.path.join(input_dir, case_name)
            try:
                #method one
                file_name = os.path.join(case_dir, 'image.nii.gz')

                patient_name = 'female-' + case_name
                save_dir = os.path.join(output_dir, case_name)

                im = md.read_image(file_name)
                tags = dicom_tags_dict(patient_name=patient_name)
                md.write_dicom_series(im, output_dir, tags=tags)

                # #method two
                # im, tags = md.read_dicom_series(case_dir)
                # save_dir = os.path.join(output_dir, case_name, 'image.nii.gz')
                # md.write_image(im, save_dir)
                #
                # im = md.read_image(output_dir)
                # output_dir1 = os.path.join(output_dir, case_name)
                # md.write_dicom_series(im, output_dir1, tags=tags)


            except Exception:

                print num, case_name

        num = num + 1



def write_json_information(input_dir,output_dir, txt_dir):

    """
    :param input_dir: the source file path
    :param output_dir: the json file path
    :param txt_dir: the body_parts information,numbers as"00000" or "11111" represent head,neck,chest,abdomen,pelvis respectively
    :return:bool param
    """

    fid = open(txt_dir,'r')
    label = int(fid.readline())

    num = 1
    for case_name in sorted(os.listdir(input_dir)):
        # print num

        if num > 0:
            # print case_name
            case_dir = os.path.join(input_dir, case_name, 'dicom')
            file_dir = os.path.join(output_dir, case_name, 'meta.json')
            try:
                # print num,num,case_name
                im, tags = cio.read_dicom_series(case_dir)

                info = {}
                patient_id = tags['0010|0020']
                info['patient_id'] = patient_id.strip()
                gender = tags['0010|0040']
                info['gender'] = gender.strip()

                body_parts = []
                if label/10000 == 1:
                    body_parts.append('head')

                if label/1000%10 == 1:
                    body_parts.append('neck')

                if label/100%10 == 1:
                    body_parts.append('chest')

                if label/10%10 == 1:
                    body_parts.append('abdomen')

                if label%10 == 1:
                    body_parts.append('pelvis')

                info['body_parts'] = body_parts

                fp = file(file_dir, 'w')
                json.dump(info,fp)
                fp.close()

            except Exception:

                print num, case_name

        label = int(fid.readline())
        num = num + 1

    fid.close()




if __name__ == '__main__':

    # # 1. copy image file from input_dir to output_dir
    # input_dir = '/mnt/disk/Data/ZhejiangRenminHospital/ZJRM_DataSet'
    # output_dir = '/mnt/disk/Data/UII-CT/ZJRM'
    # source_filename = 'image.nii.gz'
    # save_filename = source_filename
    # copyfile_image(input_dir,output_dir,source_filename,save_filename)

    #2. convert a 3D volume to disk with the another specified output type
    input_dir = '/home/mfh/Data/test_male'
    output_dir = '/home/mfh/Data/pelvic/male'
    mha_filename = 'seg.mha'
    nii_filename = 'bladder.nii.gz'
    convert_mha_to_nii(input_dir, output_dir, mha_filename, nii_filename)

    # #3. convert to patient coordinate system RAI
    # input_dir = '/mnt/disk/Data/ZhejiangRenminHospital/TEST'
    # output_path = '/mnt/disk/Data/ZhejiangRenminHospital/TEST'
    # iamge_convert_to_RAI(input_dir, output_dir)
    #
    # #4. read dicomRT contour
    # input_dir = '/mnt/disk/Data/pelvic/female_contour'
    # output_dir = '/mnt/disk/Data/UII-CT/pelvic/female'
    # read_dicomRT_contour(input_dir, output_dir)
    #
    # #5. convert dicom image to nifti image
    # input_dir = '/mnt/disk/Data/ZhejiangRenminHospital/TEST'
    # output_dir = input_dir
    # convert_dicom_to_nifti(input_dir, output_dir)
    #
    #
    # #6. convert nifti image to dicom image
    # input_path = '/mnt/disk/Data/pelvic/male'
    # output_path = '/mnt/disk/Data/pelvic/male_dicom'
    # convert_nifti_to_dicom(input_dir, output_dir)
    #
    #
    # #test image list
    #
    #
    #
    #
    # #8. write json information
    # input_dir = '/mnt/disk/Data/ZhejiangRenminHospital/ZJRM_DataSet'
    # txt_dir = '/home/mfh/organs/info_label.txt'
    # output_dir = input_dir
    # write_json_information(input_dir, output_dir, txt_dir)
    #
    #
    #
    #



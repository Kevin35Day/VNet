import md.image3d.python.image3d_io as cio
import os
import json

def write_json_information():

    input_path = '/mnt/disk/Data/ZhejiangRenminHospital/ZJRM_DataSet'
    txt_filename = '/home/mfh/organs/info_label.txt'
    output_path = input_path

    fid = open(txt_filename,'r')
    label = int(fid.readline())

    num = 1
    for case_name in sorted(os.listdir(input_path)):
        # print num

        if num > 0:
            print case_name
            case_dir = os.path.join(input_path, case_name, 'dicom')
            file_dir = os.path.join(output_path, case_name, 'meta.json')
            try:
                # print num,num,case_name
                im, tags = cio.read_dicom_series(case_dir)

                info = {}
                info['patient_ID'] = tags['0010|0020']
                info['gender'] = tags['0010|0040']

                body_parts = []
                if label/10000 == 1:
                    body_parts.append('head')

                if label/1000%10 == 1:
                    body_parts.append('neck')

                if label/100%10 == 1:
                    body_parts.append('chest')

                if label/10%10 == 1:
                    body_parts.append('abdomen')

                if label%10 == 1:
                    body_parts.append('pelvis')

                info['body_parts'] = body_parts

                fp = file(file_dir, 'w')
                json.dump(info,fp)
                fp.close()

            except Exception:

                print num, case_name

        label = int(fid.readline())
        num = num + 1

    fid.close()

if __name__ == '__main__':
    write_json_information()





import md
import os

def read_dicom_contour():

    input_dir = '/mnt/disk/Data/pelvic/female_contour'
    output_dir = '/mnt/disk/Data/UII-CT/pelvic/female'
    num = 1
    for case_name in sorted(os.listdir(input_dir)):
        print case_name
        if num > 0:
            case_dir = os.path.join(input_dir, case_name)

            dicom_contour = md.read_dicom_rt_contours(case_dir)

            for key in dicom_contour:
                contour_name = key+'.nii.gz'
                save_case_dir = os.path.join(output_dir, case_name, contour_name)
                md.write_image(dicom_contour[key], save_case_dir)

        num = num +1


if __name__ == '__main__':

    read_dicom_contour()

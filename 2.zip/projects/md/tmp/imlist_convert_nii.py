import numpy as np
import md
import os

def iamge_config_axes():

    input_dir = '/mnt/disk/mfh_Data/test_femur_right_Aorta'
    output_path = '/mnt/disk/mfh_Data/test_femur_right_Aorta1'

    for case_name in sorted(os.listdir(input_dir)):

        case_dir = os.path.join(input_dir, case_name)
        file_name = os.path.join(case_dir, 'seg.mha')

        if os.path.isfile(file_name):
            print case_name
            im = md.read_image(file_name)
            axes = np.array([[1,0,0],[0,1,0],[0,0,1]])
            im.set_axes(axes)

            save_dir = os.path.join(output_path, case_name)
            if not os.path.isdir(save_dir):
                os.makedirs(save_dir)
            save_file_dir = os.path.join(save_dir,'FemoralHead_Right.nii.gz')

            md.write_image(im, save_file_dir)


if __name__ == '__main__':

    iamge_config_axes()


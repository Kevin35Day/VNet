import md
import os
import shutil


def iamge_config_axes():

    input_dir = '/mnt/disk/Data/ZhejiangRenminHospital/ZJRM_DataSet'
    output_path = '/mnt/disk/Data/UII-CT/ZJRM'
    num = 1
    for case_name in sorted(os.listdir(input_dir)):

        case_dir = os.path.join(input_dir, case_name)
        file_name = os.path.join(case_dir, 'image.nii.gz')

        if os.path.isfile(file_name):

            if num < 21:
                print case_name
                try:
                    save_dir = os.path.join(output_path, case_name)
                    if not os.path.isdir(save_dir):
                        os.makedirs(save_dir)
                    save_file_dir = os.path.join(save_dir, 'image.nii.gz')
                    # source_json_dir = os.path.join(case_dir, 'meta.json')
                    # save_json_dir = os.path.join(save_dir, 'meta.json')

                    shutil.copy(file_name, save_file_dir)
                    # shutil.copy(source_json_dir, save_json_dir)

                except Exception:
                    print case_name

            num = num + 1


if __name__ == '__main__':

    iamge_config_axes()


import md
import os
import numpy as np

def flipdim_image(input_path, out_path, dim):

    num = 1
    for case_name in sorted(os.listdir(input_path)):
        if num > 133:
            print case_name
            case_dir = os.path.join(input_path, case_name, 'seg.mha')
            image = md.read_image(case_dir)
            axes = np.array([[1, 0, 0], [0, 1, 0], [0, 0, 1]])
            image.set_axes(axes)
            img = image.to_numpy()
            img = np.flip(img, dim)
            image.from_numpy(img)

            save_file_dir = os.path.join(out_path, case_name)
            if not os.path.isdir(save_file_dir):
                os.makedirs(save_file_dir)
            save_file_dir = os.path.join(save_file_dir, 'FemoralHead_Right.nii.gz')

            md.write_image(image, save_file_dir)

        # shutil.copy(dicom_dir, save_file_dir)
        #
        # image = read_image(file_path)
        # axes = np.array([[1,0,0],[0,1,0],[0,0,1]])
        # image.set_axes(axes)
        # img = image.to_numpy()
        # img = np.flip(img, dim)
        # # img = np.flip(img, 2)
        # # img = np.flip(img, 0)
        # # img[img == 1] = 2
        # image.from_numpy(img)
        # out_path, _ = os.path.split(file_path)
        # out_path = out_path + '/spleen.nii.gz'
        # return write_image(image, out_path, dtype=np.int8, compression=True)
        num = num+1


if __name__ == '__main__':
    input_path = '/mnt/disk/Data/pelvic/femur_right_test_v1_male'
    out_path = '/mnt/disk/Data/pelvic/right_femur_male'
    flipdim_image(input_path, out_path, 2)
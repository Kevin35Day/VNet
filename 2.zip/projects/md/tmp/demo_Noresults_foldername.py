import numpy as np
import md
import os

def find_noresults_folder_name():

    input_dir = '/mnt/disk/Data/ZhejiangRenminHospital/ZJRM_DataSet'
    output_path = '/mnt/disk/Data/UII-CT/ZJRM'

    for case_name in sorted(os.listdir(input_dir)):
        # print case_name

        check_folder = os.path.join(output_path, case_name)
        if os.path.isdir(check_folder) == False:
            print 1, case_name


if __name__ == '__main__':
    find_noresults_folder_name()
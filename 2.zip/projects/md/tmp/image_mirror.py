import os
import re
import md
import numpy as np
import md.image3d.python.image3d_io as cio
import datetime

class Filter(object):
    """ interface class for file path filtering
        True to keep the file, False to discard the file
    """

    def test(self, file_path):
        return True


class Pattern(object):

    def test(self, filename):
        raise NotImplementedError("test function not implemented in Pattern sub-class")


class MedImagePattern(Pattern):

    def __init__(self, file_name=None):
        if file_name:
            self.cpl = re.compile(file_name)
        else:
            self.cpl = re.compile('\S+\.(mha|mhd|nii\.gz|nii|hdr)$')

    def test(self, file_name):
        match_result = self.cpl.match(file_name)
        if match_result:
            return True
        else:
            return False


def mirror(input_dir, output_dir,img_name='image.nii.gz', filter=None):
    """
    generate image-seg pairs from a input_folder
    :param input_dir: the top-level folder
    :param output_dir: the output folder
    :param img_name: intensity image name, class MedImagePattern
    :param filter: rules to choose cases
    :return: None
    """
    #  check inputs

    assert isinstance(img_name, (Pattern, str, unicode))
    if isinstance(img_name, (str, unicode)):
        img_name = MedImagePattern(img_name)
    if filter is None:
        filter = Filter()

    ind = 0

    for dir_name in sorted(os.listdir(input_dir)):
        if os.path.isdir(os.path.join(input_dir, dir_name)):
            case_dir = os.path.join(input_dir, dir_name)
            IMG_EXIST = 0
            for parent, _, file_name_all in os.walk(case_dir):
                for file_name in file_name_all:
                    name_to_match = os.path.join(parent.split(case_dir)[1], file_name)
                    name_to_match = name_to_match.lstrip('/')
                    if img_name.test(name_to_match):
                        file_path = os.path.join(parent, file_name)
                        patient_id = parent[-16:] #depend on your dir name
                        if filter.test(file_path):
                            IMG_EXIST = 1
                            img_file_path = file_path
                            save_path = os.path.join(output_dir, patient_id)
            if IMG_EXIST :
                ind = ind + 1
                img_path = img_file_path
                if not os.path.exists(save_path):
                    os.makedirs(save_path)
                    print ('creat dir %s'%save_path)
                starttime = datetime.datetime.now()
                image = cio.read_image(img_path, dtype=np.int16)
                img = image.to_numpy()
                mirror_img = np.flip(img, 2)
                image.from_numpy(mirror_img)
                md.write_image(image, save_path + '/image.nii.gz')
                endtime = datetime.datetime.now()
                print ('%d image files have been converted.' % ind)
                print ('use %d s to mirror.' % (endtime - starttime).seconds)
    if ind > 0:
        print('%d image files were converted.' % ind)
    else:
        raise ValueError('No image file exist in input_dir!')

if __name__ == '__main__':
    mirror('/mnt/disk/Data/UII-CT/MI_Aorta', '/home/yaojun/mirror_data/MI_Aorta')
    #mirror('/mnt/disk/Data/UII-CT/pelvic/male', '/home/yaojun/mirror_data/male')

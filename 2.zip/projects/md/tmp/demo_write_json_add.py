import md
# import md.image3d.python.image3d_io as cio
import os
import json
import numpy as np

def write_json_information():

    input_path = '/mnt/disk/Data/UII-CT/ZJRM'
    # txt_filename = '/home/mfh/organs/info_label.txt'
    output_path = input_path

    # fid = open(txt_filename,'r')
    # label = int(fid.readline())

    num = 1
    for case_name in sorted(os.listdir(input_path)):
        # print num

        if num > 0:
            print case_name
            case_dir = os.path.join(input_path, case_name)
            file_name = os.path.join(case_dir, 'image.nii.gz')
            file_dir = os.path.join(output_path, case_name, 'meta.json')

            im = md.read_image(file_name)
            dimension = im.spacing()
            print type(dimension)
            # dimension = np.dtype('float32')

            fp = open(file_dir, 'r')
            info = json.load(fp)
            fp.close()
            print info

            info['tags'] = 'ZJRM'

            print type(dimension)

            info['x_spacing'] = dimension[0]
            info['y_spacing'] = dimension[1]
            info['z_spacing'] = dimension[2]

            print info

            # fp = open(file_dir, 'w')
            # json.dump(info,fp)
            # fp.close()

        num = num + 1

    # fid.close()

if __name__ == '__main__':
    write_json_information()





import md
import os

def dicom_tags_dict(
        modality='CT',
        image_type=r'DERIVED\\SECONDARY',
        conversion_type='DV',
        patient_position='HFS',
        series_description='UIH-AI',
        study_description='RTSeg',
        patient_name='Anonymous',
        patient_id='20171230',
        patient_age='99',
        rescale_type='HU',
        rescale_slope='1',
        rescale_intercept='0'):

    tags = {}
    tags['0008|0060'] = modality
    tags['0008|0008'] = image_type
    tags['0008|0064'] = conversion_type
    tags['0008|103E'] = series_description
    tags['0008|1030'] = study_description
    tags['0018|5100'] = patient_position
    tags['0010|0010'] = patient_name
    tags['0010|0020'] = patient_id
    tags['0010|1010'] = patient_age
    tags['0028|1052'] = rescale_intercept
    tags['0028|1053'] = rescale_slope
    tags['0028|1054'] = rescale_type

    return tags



if __name__ == '__main__':


    input_path = '/mnt/disk/Data/pelvic/male'
    output_path = '/mnt/disk/Data/pelvic/male_dicom'


    for case_name in sorted(os.listdir(input_path)):
        print case_name
        case_dir = os.path.join(input_path, case_name)
        file_name = os.path.join(case_dir, 'image.nii.gz')

        patient_name = 'female-' + case_name
        output_dir = os.path.join(output_path, case_name)

        im = md.read_image(file_name)
        tags = dicom_tags_dict(patient_name = patient_name)
        md.write_dicom_series(im, output_dir, tags=tags)

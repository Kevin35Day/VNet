import md
import os

if __name__ == '__main__':

    input_path = '/mnt/disk/Data/ZhejiangRenminHospital/TEST'
    output_path = input_path
    num = 1

    for case_name in sorted(os.listdir(input_path)):
        # print num

        if num > 0 :
            # print case_name
            case_dir = os.path.join(input_path, case_name)
            try:
                # print num,num,case_name
                im, tags = md.read_dicom_series(case_dir)

                output_dir = os.path.join(output_path, case_name,'image.nii.gz')

                md.write_image(im, output_dir)

                # im = md.read_image(output_dir)
                # output_dir1 = os.path.join(output_path, case_name)
                # md.write_dicom_series(im, output_dir1, tags=tags)

            except Exception:

                print num, case_name

        # num = num + 1
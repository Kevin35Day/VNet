import md.segmentation3d.vseg_test as test


if __name__ == '__main__':
    input = '/home/mfh/organs/bladder/test.txt'
    model = '/home/mfh/organs/bladder'
    output = '/mnt/disk/Data/pelvic/ZJRM_test'

    test(input, model, output,gpu_id=1)


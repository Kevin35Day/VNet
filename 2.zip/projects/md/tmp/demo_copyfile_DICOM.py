import md
import os
import shutil


def iamge_config_axes():

    input_dir = '/mnt/disk/Data/MI_Aorta'
    output_path = '/mnt/disk/mfh_Data/MI_Aorta_Dicom'
    num = 1
    for case_name in sorted(os.listdir(input_dir)):
        if num>155:
            case_dir = os.path.join(input_dir, case_name)
            for case_name1 in sorted(os.listdir(case_dir)):
                dicom_dir = os.path.join(case_dir, case_name1, '00000020.dcm')
                save_file_dir = os.path.join(output_path, case_name)
                if not os.path.isdir(save_file_dir):
                    os.makedirs(save_file_dir)
                save_file_dir = os.path.join(save_file_dir, '00000020.dcm')
                shutil.copy(dicom_dir, save_file_dir)

        num = num+1


if __name__ == '__main__':

    iamge_config_axes()


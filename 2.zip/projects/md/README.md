# MD

联影智能代码平台

---
---

## 安装手册（概要）

下载并安装 [CMake](https://cmake.org/download) v3.4 及以上版本．

下载并安装 [ITK](https://itk.org/ITK/resources/software.html) v4.11 及以上版本

编译MD项目

```bash
# 从命令行进入md的父目录

# 创建一个空的编译目录，并进入这个目录
mkdir md_build && cd md_build

# 设置ITK的路径
export ITK_DIR=[ITK installation folder]

# 利用cmake产生Makefile
ccmake ../md

# 编译（八线程）
make -j8

# 将Medvision加入Python路径以及动态链接库路径
cd ..
export PYTHONPATH=`realpath .`:$PYTHONPATH
export LD_LIBRARY_PATH=`realpath md/lib/Release`:$LD_LIBRARY_PATH

# 恭喜你，MD已经配置成功

#include "utils/pywrappers/pyeval.h"
#include "utils/csrc/eval.h"
#include "image3d/csrc/image3d.h"
#include "utils/csrc/template_macros.h"

using namespace medvision;


double image3d_cal_dsc(void* seg1, void* seg2, int label)
{
    const Image3d* im1 = static_cast<const Image3d*>(seg1);
    const Image3d* im2 = static_cast<const Image3d*>(seg2);

    PixelType ptype1 = im1->pixel_type();
    PixelType ptype2 = im2->pixel_type();

    double ret = 0;
    ptypeassign_2(cal_dice, ptype1, ptype2, ret, *im1, *im2, label);

    return ret;
}

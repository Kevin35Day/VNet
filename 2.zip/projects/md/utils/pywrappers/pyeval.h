#ifndef PYIMAGE3D_EVAL_H
#define PYIMAGE3D_EVAL_H

#include <cstddef>

#ifdef __cplusplus
extern "C" {
#endif

/*! \brief compute dice between two seg images */
double image3d_cal_dsc(void* seg1, void* seg2, int label);

#ifdef __cplusplus
}
#endif

#endif // PYIMAGE3D_EVAL_H

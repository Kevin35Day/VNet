#ifndef EVAL_H
#define EVAL_H

#include "image3d/csrc/image3d.h"

namespace medvision {

    /*! \brief dice calculation
     *
     *  \param curr_GT        ground truth image
     *  \param curr_Result    segmentation result
     *  \param label          label input, defult value is 1
     *  \return dice value
     */
    template <typename T1, typename T2>
    double cal_dice(const Image3d& curr_Result, const Image3d& curr_GT, int label=1)
    {
        vec3d<int> im_size = curr_GT.size();
        vec3d<int> seg_size = curr_Result.size();
        //check input size
        if (im_size[0]!=seg_size[0] || im_size[1]!=seg_size[1] ||im_size[2]!=seg_size[2]){
            std::cerr << "[Error] input image size do not equal!" << std::endl;
            return 0;
        }

        size_t pix_num = im_size.self_prod<size_t>();
        size_t gt = 0, re = 0, intersection = 0 ;
        const T1* re_data = static_cast<const T1*>(curr_Result.data());
        const T2* gt_data = static_cast<const T2*>(curr_GT.data());

        for(size_t i=0;i<pix_num;i++){
            int gt_value = static_cast<int>(gt_data[i]);
            int re_value = static_cast<int>(re_data[i]);
            if (gt_value==label){
                gt += 1;
            }
            if (re_value==label){
                re += 1;
            }
            if (gt_value==label && re_value==label)
                intersection += 1;
        }
        double dice = (2.0 * intersection) / (re + gt + 1e-12);
        return dice;
    }

}


#endif

import plotly.offline as py
import plotly.graph_objs as go
import numpy as np


def build_hist(x, name, start, end, stride, color='#FF0000', opacity=1.0):

    trace = go.Histogram(x=x, histnorm='count', name=name,
                         xbins=dict(start=start, end=end, size=stride),
                         marker=dict(color=color), opacity=opacity)
    return trace


def hist_comp(hists, out_file, title='histograms', xname='Value', yname='Count',
              bargap=0.2, bargroupgap=0.1, auto_open=False):
    """
    generate a figure with multiple histograms
    :param hists: a list of histogram objects
    :param out_file: output file path
    :param title: the figure title
    :param xname: the name of x axis
    :param yname: the name of y axis
    :param bargap: the gap between bars
    :param bargroupgap: the gap between bar groups
    :param auto_open: automatically open figure when save
    :return: None
    """
    layout = go.Layout(
        title=title,
        xaxis=dict(title=xname),
        yaxis=dict(title=yname),
        bargap=bargap,
        bargroupgap=bargroupgap
    )
    fig = go.Figure(data=hists, layout=layout)
    py.plot(fig, filename=out_file, auto_open=auto_open)


def plot_loss(log_file, out_file, name='dloss', display='Dice loss'):
    """
    plot loss curve from the data in log_file
    :param log_file: log file
    :param out_file: output plot html file
    :return: None
    """
    batch_word = 'batch:'
    loss_word = name + ':'

    batch_idxs = []
    loss_values = []

    with open(log_file, 'r') as f:
        for line in f:
            if not batch_word in line:
                continue
            if not loss_word in line:
                continue

            start = line.find(batch_word) + len(batch_word)
            end = line.find(',', start)
            try:
                batch_idx = float(line[start:end])
            except:
                continue

            start = line.find(loss_word) + len(loss_word)
            end = line.find(',', start)
            try:
                loss_value = float(line[start:end])
            except:
                continue

            batch_idxs.append(batch_idx)
            loss_values.append(loss_value)

    # plot curve and save it to html
    trace = go.Scatter(
        x = np.array(batch_idxs, dtype=np.float),
        y = np.array(loss_values, dtype=np.float)
    )

    data = [trace]
    layout = dict(title=display + ' during training',
                  xaxis=dict(title='Batch iteration'),
                  yaxis=dict(title=display))

    fig = dict(data=data, layout=layout)
    py.plot(fig, filename=out_file, auto_open=False)


if __name__ == '__main__':

    plot_loss('/home/ubuntu2/data/vnet_1/train_log.txt', '/home/ubuntu2/data/vnet_1/dloss.html')

import re


def readlines(file):
    """
    read lines by removing '\n' in the end of line
    :param file: a text file
    :return: a list of line strings
    """
    fp = open(file, 'r')
    linelist = fp.readlines()
    fp.close()
    for i in range(len(linelist)):
        linelist[i] = linelist[i].rstrip('\n')
    return linelist


def read_str_array(file, sep='\t'):
    lines = readlines(file)
    content = []
    for line in lines:
        content.append(re.split(sep, line))
    return content

#ifndef NEURO_ERRORS_H
#define NEURO_ERRORS_H

#include <cudnn.h>
#include <iostream>
#include <sstream>

namespace medvision {

/*! \brief neuro error enum type */
enum neuroError_t {

    Neuro_Success               = 0,
    Neuro_Unsupported           = 1,
    Neuro_FileNotFound          = 2,
    Neuro_ReadIncomplete        = 3,
    Neuro_WrongVersion          = 4,
    Neuro_InvalidObject         = 5,
    Neuro_SeekFailure           = 6,
    Neuro_ParamNotFound         = 7,
    Neuro_InvalidContext        = 8,
    Neuro_EmptyTensor           = 9,
    Neuro_SizeMismatch          = 10,
    Neuro_EmptyDesc             = 11,
    Neuro_NoFwdAlg              = 12,
    Neuro_NoBwdAlg              = 13,
    Neuro_BadParam              = 14,
    Neuro_UnsupportedDim        = 15
};


/*! \brief get string representation of error code */
const char* neuroGetErrorString(neuroError_t code);


#ifndef _MSC_VER
#define NOEXCEPT noexcept
#else
#define NOEXCEPT
#endif


/*! \brief cuda exception */
class cuda_error: public std::runtime_error
{
public:
    cuda_error(cudaError_t code);
    const char* what() const NOEXCEPT;
private:
    cudaError_t m_code;
};


/*! \brief macro to throw cuda exception by checking error code */
#define cudaThrowError(ans) {               \
    cudaError_t code = (ans);               \
    if(code != cudaSuccess) {               \
        std::stringstream _message;         \
        _message << "CudaError: " << cudaGetErrorString(code) << " at " << __FILE__ << ":" << __LINE__;    \
        std::cerr << _message.str() << std::endl;  \
        throw cuda_error(code);             \
    }                                       \
}while(0)


/*! \brief cudnn exception */
class cudnn_error: public std::runtime_error
{
public:
    cudnn_error(cudnnStatus_t code);
    const char* what() const NOEXCEPT;

private:
    cudnnStatus_t m_code;
};


/*! \brief macro to throw cudnn exception by checking error code */
#define cudnnThrowError(ans) {               \
    cudnnStatus_t code = (ans);              \
    if(code != CUDNN_STATUS_SUCCESS) {       \
        std::stringstream _message;          \
        _message << "CUDNN failure: " << cudnnGetErrorString(code) << " at " << __FILE__ << ":" << __LINE__;    \
        std::cerr << _message.str() << std::endl;  \
        throw cudnn_error(code);             \
    }                                        \
}while(0)


/*! \brief neuro exception */
class neuro_error: public std::runtime_error
{
public:
    neuro_error(neuroError_t code);
    const char* what() const NOEXCEPT;
private:
    neuroError_t m_code;
};


/*! \brief macro to throw neuro exception by checking error code */
#define neuroThrowError(ans) {              \
    neuroError_t code = (ans);              \
    if(code != Neuro_Success) {             \
        std::stringstream _message;         \
        _message << "Neuro failure: " << neuroGetErrorString(code) << " at " << __FILE__ << ":" << __LINE__;    \
        std::cerr << _message.str() << std::endl;  \
        throw neuro_error(code);            \
    }                                       \
}while(0)


/*! \brief macro to return neuro error code if not success */
#define checkNeuro(status) do {                 \
    neuroError_t err_code = status;             \
    if(err_code != Neuro_Success) {             \
        return err_code;                        \
    }                                           \
} while(0)


/*! \brief cuda host memory deleter */
struct CudaHostDeleter
{
public:
    void operator() (void* ptr);
};


/*! \brief cuda device memory deleter */
struct CudaDeviceDeleter
{
public:
    void operator() (void* d_ptr);
};

}

#endif


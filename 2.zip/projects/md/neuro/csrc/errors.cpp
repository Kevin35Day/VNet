#include "neuro/csrc/errors.h"

namespace medvision {


const char* neuroGetErrorString(neuroError_t code)
{
    switch (code) {
    case Neuro_Success:         return "Neuro_Success"; break;
    case Neuro_Unsupported:     return "Neuro_Unsupported"; break;
    case Neuro_FileNotFound:    return "Neuro_FileNotFound"; break;
    case Neuro_ReadIncomplete:  return "Neuro_ReadIncomplete"; break;
    case Neuro_WrongVersion:    return "Neuro_WrongVersion"; break;
    case Neuro_InvalidObject:   return "Neuro_InvalidObject"; break;
    case Neuro_SeekFailure:     return "Neuro_SeekFailure"; break;
    case Neuro_ParamNotFound:   return "Neuro_ParamNotFound"; break;
    case Neuro_InvalidContext:  return "Neuro_InvalidContext"; break;
    case Neuro_EmptyTensor:     return "Neuro_EmptyTensor"; break;
    case Neuro_SizeMismatch:    return "Neuro_SizeMismatch"; break;
    case Neuro_EmptyDesc:       return "Neuro_EmptyDesc"; break;
    case Neuro_NoFwdAlg:        return "Neuro_NoFwdAlg"; break;
    case Neuro_NoBwdAlg:        return "Neuro_NoBwdAlg"; break;
    case Neuro_UnsupportedDim:  return "Neuro_UnsupportedDim"; break;
    default:                    return "Neuro_Unknown"; break;
    }
}


cuda_error::cuda_error(cudaError_t code): runtime_error("")
{
    m_code = code;
}


const char* cuda_error::what() const NOEXCEPT
{
    return cudaGetErrorString(m_code);
}


cudnn_error::cudnn_error(cudnnStatus_t code): runtime_error("")
{
    m_code = code;
}


const char* cudnn_error::what() const NOEXCEPT
{
    return cudnnGetErrorString(m_code);
}


neuro_error::neuro_error(neuroError_t code): runtime_error("")
{
    m_code = code;
}


const char* neuro_error::what() const NOEXCEPT
{
    return neuroGetErrorString(m_code);
}


void CudaHostDeleter::operator() (void* ptr)
{
    cudaThrowError(cudaFreeHost(ptr));
}


void CudaDeviceDeleter::operator () (void* d_ptr)
{
    cudaThrowError(cudaFree(d_ptr));
}


}

#include "neuro/csrc/layers/prelu2.h"

namespace medvision {

PRelu2::PRelu2()
{
    m_handle = nullptr;
}

PRelu2::PRelu2(const std::string& name)
{
    m_handle = nullptr;
    m_name = name;
}

void PRelu2::initialize(const std::string &name)
{
    m_handle = nullptr;
    m_name = name;
}

neuroError_t PRelu2::set_param_ptrs(const ParamDictType &param_dict)
{
    std::string weight_name = m_name + std::string(".weight");
    auto it = param_dict.find(weight_name);
    if(it == param_dict.end()) {
        std::cerr << "PRelu2: " << weight_name << " not found!" << std::endl;
        return Neuro_ParamNotFound;
    } else {
        m_weight.set_ptr(it->second);
    }
    return Neuro_Success;
}

neuroError_t PRelu2::create_descs(cudnnHandle_t handle,
                                  const Tensor& intensor,
                                  Tensor& outtensor,
                                  bool infer_shape,
                                  size_t& max_layer_size,
                                  size_t& workspace_size)
{
    m_handle = handle;

    if(infer_shape) {
        outtensor.set_size(intensor.size());
        outtensor.create_desc();
    }

    m_workspace.set_size(intensor.size());
    m_workspace.create_desc();

    int channels = outtensor.size()[1];
    int size[] = {1, channels, 1, 1};
    m_weight.set_size(size);
    m_weight.create_desc();

    m_max_op.create_desc(handle);
    m_min_op.create_desc(handle);
    m_mult_op.create_desc(handle);

    max_layer_size = std::max<size_t>(max_layer_size, intensor.bytes());

    size_t local_workspace_size = intensor.bytes();
    workspace_size = std::max<size_t>(workspace_size, local_workspace_size);

    return Neuro_Success;
}


neuroError_t PRelu2::forward(Tensor& intensor, Tensor& outtensor, void* workspace)
{
    m_workspace.set_ptr(workspace);

    // copy intensor to workspace
    TensorOps::copy(m_handle, intensor, m_workspace);
    checkNeuro(m_min_op(1.0f, m_workspace, 0.0f, m_workspace, 0.0f, m_workspace));
    checkNeuro(m_mult_op(1.0f, m_workspace, 1.0f, m_weight, 0.0f, m_workspace));
    checkNeuro(m_max_op(1.0f, intensor, 0.0f, intensor, 0.0f, outtensor));
    checkNeuro(TensorOps::add(m_handle, 1.0f, m_workspace, 1.0f, outtensor));

    return Neuro_Success;
}


}

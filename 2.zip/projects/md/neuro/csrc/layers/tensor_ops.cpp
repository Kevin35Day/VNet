#include "neuro/csrc/layers/tensor_ops.h"

namespace medvision {

// tensor ops
neuroError_t TensorOps::add(cudnnHandle_t cudnn_handle, float alpha, const Tensor& op1, float beta, Tensor& op2)
{
    cudnnThrowError(cudnnAddTensor(cudnn_handle, &alpha, op1.desc(), op1.ptr(), &beta, op2.desc(), op2.ptr()));
    return Neuro_Success;
}

neuroError_t TensorOps::copy(cudnnHandle_t cudnn_handle, const Tensor& src, Tensor& dst)
{
    checkNeuro(add(cudnn_handle, 1.0f, src, 0.0f, dst));
    return Neuro_Success;
}

neuroError_t TensorOps::softmax_spatial(cudnnHandle_t cudnn_handle, Tensor& in, cudnnSoftmaxAlgorithm_t alg)
{
    float alpha = 1.0f, beta = 0.0f;
    cudnnThrowError(cudnnSoftmaxForward(cudnn_handle, alg, CUDNN_SOFTMAX_MODE_CHANNEL, &alpha, in.desc(), in.ptr(), &beta, in.desc(), in.ptr()));
    return Neuro_Success;
}

// tensor add
TensorAddOp::TensorAddOp()
{
    m_op_desc = nullptr;
}

TensorAddOp::~TensorAddOp()
{
    if(m_op_desc != nullptr) {
        cudnnThrowError(cudnnDestroyOpTensorDescriptor(m_op_desc));
        m_op_desc = nullptr;
    }
}

void TensorAddOp::create_desc(cudnnHandle_t cudnn_handle)
{
    m_cudnn_handle = cudnn_handle;

    if(m_op_desc != nullptr) {
        cudnnThrowError(cudnnDestroyOpTensorDescriptor(m_op_desc));
        m_op_desc = nullptr;
    }

    cudnnThrowError(cudnnCreateOpTensorDescriptor(&m_op_desc));
    cudnnThrowError(cudnnSetOpTensorDescriptor(m_op_desc, CUDNN_OP_TENSOR_ADD, CUDNN_DATA_FLOAT, CUDNN_PROPAGATE_NAN));
}

neuroError_t TensorAddOp::operator() (float alpha1, const Tensor& op1, float alpha2, const Tensor& op2, float beta, Tensor& op3)
{
    cudnnThrowError(cudnnOpTensor(m_cudnn_handle, m_op_desc,
                                  &alpha1, op1.desc(), op1.ptr(),
                                  &alpha2, op2.desc(), op2.ptr(),
                                  &beta,   op3.desc(), op3.ptr()));

    return Neuro_Success;
}

// tensor mult
TensorMultOp::TensorMultOp()
{
    m_op_desc = nullptr;
}

TensorMultOp::~TensorMultOp()
{
    if(m_op_desc != nullptr) {
        cudnnThrowError(cudnnDestroyOpTensorDescriptor(m_op_desc));
        m_op_desc = nullptr;
    }
}

void TensorMultOp::create_desc(cudnnHandle_t cudnn_handle)
{
    m_cudnn_handle = cudnn_handle;

    if(m_op_desc != nullptr) {
        cudnnThrowError(cudnnDestroyOpTensorDescriptor(m_op_desc));
        m_op_desc = nullptr;
    }

    cudnnThrowError(cudnnCreateOpTensorDescriptor(&m_op_desc));
    cudnnThrowError(cudnnSetOpTensorDescriptor(m_op_desc, CUDNN_OP_TENSOR_MUL, CUDNN_DATA_FLOAT, CUDNN_PROPAGATE_NAN));
}

neuroError_t TensorMultOp::operator() (float alpha1, const Tensor& op1, float alpha2, const Tensor& op2, float beta, Tensor& op3)
{
    cudnnThrowError(cudnnOpTensor(m_cudnn_handle, m_op_desc,
                                  &alpha1, op1.desc(), op1.ptr(),
                                  &alpha2, op2.desc(), op2.ptr(),
                                  &beta,   op3.desc(), op3.ptr()));

    return Neuro_Success;
}

// tensor min op
TensorMinOp::TensorMinOp()
{
    m_op_desc = nullptr;
}

TensorMinOp::~TensorMinOp()
{
    if(m_op_desc != nullptr) {
        cudnnThrowError(cudnnDestroyOpTensorDescriptor(m_op_desc));
        m_op_desc = nullptr;
    }
}

void TensorMinOp::create_desc(cudnnHandle_t cudnn_handle)
{
    m_cudnn_handle = cudnn_handle;

    if(m_op_desc != nullptr) {
        cudnnThrowError(cudnnDestroyOpTensorDescriptor(m_op_desc));
        m_op_desc = nullptr;
    }

    cudnnThrowError(cudnnCreateOpTensorDescriptor(&m_op_desc));
    cudnnThrowError(cudnnSetOpTensorDescriptor(m_op_desc, CUDNN_OP_TENSOR_MIN, CUDNN_DATA_FLOAT, CUDNN_PROPAGATE_NAN));
}

neuroError_t TensorMinOp::operator() (float alpha1, const Tensor& op1, float alpha2, const Tensor& op2, float beta, Tensor& op3)
{
    cudnnThrowError(cudnnOpTensor(m_cudnn_handle, m_op_desc,
                                  &alpha1, op1.desc(), op1.ptr(),
                                  &alpha2, op2.desc(), op2.ptr(),
                                  &beta,   op3.desc(), op3.ptr()));

    return Neuro_Success;
}

// tensor max op
TensorMaxOp::TensorMaxOp()
{
    m_op_desc = nullptr;
}

TensorMaxOp::~TensorMaxOp()
{
    if(m_op_desc != nullptr) {
        cudnnThrowError(cudnnDestroyOpTensorDescriptor(m_op_desc));
        m_op_desc = nullptr;
    }
}

void TensorMaxOp::create_desc(cudnnHandle_t cudnn_handle)
{
    m_cudnn_handle = cudnn_handle;

    if(m_op_desc != nullptr) {
        cudnnThrowError(cudnnDestroyOpTensorDescriptor(m_op_desc));
        m_op_desc = nullptr;
    }

    cudnnThrowError(cudnnCreateOpTensorDescriptor(&m_op_desc));
    cudnnThrowError(cudnnSetOpTensorDescriptor(m_op_desc, CUDNN_OP_TENSOR_MAX, CUDNN_DATA_FLOAT, CUDNN_PROPAGATE_NAN));
}

neuroError_t TensorMaxOp::operator() (float alpha1, const Tensor& op1, float alpha2, const Tensor& op2, float beta, Tensor& op3)
{
    cudnnThrowError(cudnnOpTensor(m_cudnn_handle, m_op_desc,
                                  &alpha1, op1.desc(), op1.ptr(),
                                  &alpha2, op2.desc(), op2.ptr(),
                                  &beta,   op3.desc(), op3.ptr()));

    return Neuro_Success;
}


}

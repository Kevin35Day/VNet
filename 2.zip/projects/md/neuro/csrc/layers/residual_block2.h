#ifndef RESIDUAL_BLOCK2_H
#define RESIDUAL_BLOCK2_H

#include <cudnn.h>
#include "math/vec2d.h"
#include <unordered_map>
#include <vector>
#include "neuro/csrc/filter.h"
#include "neuro/csrc/tensor.h"
#include "neuro/csrc/errors.h"
#include "neuro/csrc/layers/network_module.h"
#include "neuro/csrc/layers/conv_bn_elu2.h"
#include "neuro/csrc/layers/elu.h"

namespace medvision {

/*! \brief Residual block with various number of convolutions
 *
 *  stride 1, fixed channel size, isotropic kernel size, padding
 */
class ResidualBlock2: public NetworkModule
{
public:
    /*! \brief parametric constructor
     *
     *  \param name         the module name
     *  \param conv_name    the name of convolution module
     *  \param bn_name      the name of batch-normalization module
     *  \param convs        num of ConvBnElu2
     *  \param channels     the number of input channels and output channels
     *  \param ksize        the kernel size
     *  \param pad          the padding number
     */
    ResidualBlock2(const std::string& name, const std::string& conv_name, const std::string& bn_name, int convs, int channels, int ksize, int pad);

    /*! \brief detailed implementation of set_param_ptrs */
    virtual neuroError_t set_param_ptrs(const ParamDictType& param_dict);

    /*! \brief detailed implementation of create_descs */
    virtual neuroError_t create_descs(cudnnHandle_t handle,
                                      const Tensor& intensor,
                                      Tensor& outtensor,
                                      bool infer_shape,
                                      size_t& max_layer_size,
                                      size_t& workspace_size);

    /*! \brief detailed implementation of forward */
    virtual neuroError_t forward(Tensor& intensor, Tensor& outtensor, void* workspace);

private:
    std::string m_name, m_conv_name, m_bn_name;
    cudnnHandle_t m_cudnn_handle;

    std::vector<ConvBnElu2> m_ops;
    Elu m_act;
};

}

#endif

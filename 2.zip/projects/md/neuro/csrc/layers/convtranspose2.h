#ifndef NEURO_CONVTRANSPOSE2_H
#define NEURO_CONVTRANSPOSE2_H

#include <cudnn.h>
#include "math/vec2d.h"
#include <unordered_map>
#include "neuro/csrc/filter.h"
#include "neuro/csrc/tensor.h"
#include "neuro/csrc/errors.h"
#include "neuro/csrc/layers/network_module.h"

namespace medvision {

/*! \brief transposed convolution 2d module */
class ConvTranspose2: public NetworkModule
{
public:
    /*! \brief default constructor */
    ConvTranspose2();

    /*! \brief parametric constructor
     *
     *  \param name         the module name
     *  \param in_channels  the number of input channels
     *  \param out_channels the nunber of output channels
     *  \param ksize2       the 2d kernel size in Height-Width order
     *  \param stride2      the 2d stride in Height-Width order
     *  \param pad2         the 2d padding in Height-Width order
     *  \param dilate2      the 2d dilation in Height-Width order
     *  \param num_groups   the number of groups in group convolution
     *  \param enable_bias  whether to use bias in transposed convolution
     *  \param alpha        the alpha value in cudnn for convolution
     *  \param beta         the beta value in cudnn for convolution
     */
    ConvTranspose2(const std::string& name,
                   int in_channels,
                   int out_channels,
                   const vec2d<int>& ksize2,
                   const vec2d<int>& stride2,
                   const vec2d<int>& pad2 = vec2d<int>(0, 0),
                   const vec2d<int>& dilate2 = vec2d<int>(1, 1),
                   int num_groups = 1,
                   bool enable_bias = true,
                   float alpah = 1.0f,
                   float beta = 0.0f);

    /*! \brief deconstructor */
    virtual ~ConvTranspose2();

    /*! \brief initialization function
     *
     *  \param name         the module name
     *  \param in_channels  the number of input channels
     *  \param out_channels the nunber of output channels
     *  \param ksize2       the 2d kernel size in Height-Width order
     *  \param stride2      the 2d stride in Height-Width order
     *  \param pad2         the 2d padding in Height-Width order
     *  \param dilate2      the 2d dilation in Height-Width order
     *  \param num_groups   the number of groups in group convolution
     *  \param enable_bias  whether to use bias in transposed convolution
     *  \param alpha        the alpha value in cudnn for convolution
     *  \param beta         the beta value in cudnn for convolution
     */
    void initialize(const std::string& name,
                    int in_channels,
                    int out_channels,
                    const vec2d<int>& ksize2,
                    const vec2d<int>& stride2,
                    const vec2d<int>& pad2 = vec2d<int>(0, 0),
                    const vec2d<int>& dilate2 = vec2d<int>(1, 1),
                    int num_groups = 1,
                    bool enable_bias = true,
                    float alpha = 1.0f,
                    float beta = 0.0f);

    /*! \brief detailed implementation of virtual function set_param_ptrs */
    virtual neuroError_t set_param_ptrs(const ParamDictType& param_dict);

    /*! \brief detailed implementation of virtual function create_descs */
    virtual neuroError_t create_descs(cudnnHandle_t handle,
                                      const Tensor& intensor,
                                      Tensor& outtensor,
                                      bool infer_shape,
                                      size_t& max_layer_size,
                                      size_t& workspace_size);

    /*! \brief detailed implementation of virtual function forward */
    virtual neuroError_t forward(Tensor& intensor, Tensor& outtensor, void* workspace);

private:

    std::string m_name;

    int m_inchannels;
    int m_outchannels;
    vec2d<int> m_ksize2;
    vec2d<int> m_stride2;
    vec2d<int> m_pad2;
    vec2d<int> m_dilate2;
    int m_num_groups;
    bool m_enable_bias;
    float m_alpha;
    float m_beta;

    FloatFilter4 m_filter;
    FloatTensor4 m_bias;

    cudnnConvolutionDescriptor_t m_convdesc;
    cudnnConvolutionBwdDataAlgo_t m_bwdalg;
    size_t m_workspace_size;

    cudnnHandle_t m_cudnn_handle;
};

}

#endif

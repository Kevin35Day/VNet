#include "neuro/csrc/layers/residual_block2.h"
#include "neuro/csrc/layers/tensor_ops.h"
#include "neuro/csrc/tensor_utils.h"
#include <sstream>

namespace medvision {

// Residual Block 2D Implementation
ResidualBlock2::ResidualBlock2(const std::string& name, const std::string& conv_name, const std::string& bn_name, int convs, int channels, int ksize, int pad)
{
    if(convs <= 0 || ksize <= 0 || pad < 0) {
        neuroThrowError(Neuro_BadParam);
    }

    m_name = name;
    m_conv_name = conv_name;
    m_bn_name = bn_name;

    m_cudnn_handle = nullptr;

    std::stringstream ss;
    vec2d<int> ksize2   = vec2d<int>(ksize, ksize);
    vec2d<int> stride2  = vec2d<int>(1, 1);
    vec2d<int> pad2     = vec2d<int>(pad, pad);
    vec2d<int> dilate2  = vec2d<int>(1, 1);

    m_ops.resize(convs);

    for(int i = 0; i < convs; ++i) {
        ss.clear();
        ss.str(std::string(""));
        ss << name << ".ops." << i;
        m_ops[i].initialize(ss.str(), conv_name, bn_name, channels, channels, ksize2, stride2, pad2, dilate2);
    }
}


neuroError_t ResidualBlock2::set_param_ptrs(const ParamDictType& param_ptrs)
{
    for(size_t i = 0; i < m_ops.size(); ++i) {
        checkNeuro(m_ops[i].set_param_ptrs(param_ptrs));
    }
    return Neuro_Success;
}


neuroError_t ResidualBlock2::create_descs(cudnnHandle_t cudnn_handle, const Tensor& intensor, Tensor& outtensor,
                                         bool infer_shape, size_t& max_layer_size, size_t& workspace_size)
{
    m_cudnn_handle = cudnn_handle;

    if(infer_shape) {
        outtensor.set_size(intensor.size());
        outtensor.create_desc();
    }

    if(outtensor.desc() == nullptr)
        return Neuro_EmptyTensor;

    size_t tmp_workspace_size = 0;
    for(size_t i = 0; i < m_ops.size(); ++i)
        checkNeuro(m_ops[i].create_descs(cudnn_handle, intensor, outtensor, false, max_layer_size, tmp_workspace_size));
    checkNeuro(m_act.create_descs(cudnn_handle, outtensor, outtensor, false, max_layer_size, tmp_workspace_size));

    if(m_ops.size() != 1) {
        // need to keep a copy of intensor for skip connection
        tmp_workspace_size += intensor.bytes();
    }
    workspace_size = std::max<size_t>(workspace_size, tmp_workspace_size);

    return Neuro_Success;
}


neuroError_t ResidualBlock2::forward(Tensor& intensor, Tensor& outtensor, void* workspace)
{
    if(m_ops.size() != 1) {
        FloatTensor4 tmp_tensor;
        tmp_tensor.set_size(intensor.size());
        tmp_tensor.create_desc();
        tmp_tensor.set_ptr(workspace);

        void* alg_workspace = (void*)((char*)(workspace) + intensor.bytes());
        Tensor* in_ptr = &intensor, *out_ptr = nullptr, *back_ptr = nullptr;
        if(m_ops.size() % 2 == 0) {
            out_ptr = &tmp_tensor;
            back_ptr = &outtensor;
        } else {
            out_ptr = &outtensor;
            back_ptr = &tmp_tensor;
        }

        for(size_t i = 0; i < m_ops.size(); ++i) {
            checkNeuro(m_ops[i].forward(*in_ptr, *out_ptr, alg_workspace));
            in_ptr = out_ptr;
            std::swap(out_ptr, back_ptr);
        }

        checkNeuro(TensorOps::add(m_cudnn_handle, 1.0f, intensor, 1.0f, outtensor));
        checkNeuro(m_act.forward(outtensor, outtensor, alg_workspace));
    }
    else {
        checkNeuro(m_ops[0].forward(intensor, outtensor, workspace));
        checkNeuro(TensorOps::add(m_cudnn_handle, 1.0f, intensor, 1.0f, outtensor));
        checkNeuro(m_act.forward(outtensor, outtensor, workspace));
    }

    return Neuro_Success;
}

}

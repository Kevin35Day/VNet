#include "neuro/csrc/layers/bott_residual_block3.h"
#include "neuro/csrc/layers/tensor_ops.h"
#include <sstream>

namespace medvision {

//bottle neck residual block implementation
BottResidualBlock3::BottResidualBlock3(const std::string& name, const std::string& downsample_name,
                                       const std::string& conv_name, const std::string& upsample_name,
                                       int convs, int channels, int ksize, int pad, float ratio)
{
    if(convs <= 0 || channels <= 0 || ratio <= 0|| ksize <= 0 || pad < 0) {
        neuroThrowError(Neuro_BadParam);
    }

    m_name = name;
    m_downsample_name = downsample_name;
    m_conv_name = conv_name;
    m_upsample_name = upsample_name;

    m_cudnn_handle = nullptr;

    vec3d<int> ksize3   = vec3d<int>(ksize, ksize, ksize);
    vec3d<int> stride3  = vec3d<int>(1, 1, 1);
    vec3d<int> pad3     = vec3d<int>(pad, pad, pad);
    vec3d<int> dilate3  = vec3d<int>(1, 1, 1);
    int num_groups = 1;
    bool enable_bias = true;
    std::stringstream ss;

    m_ops.resize(convs);
    for(int i = 0; i < convs; ++i) {
        ss.clear();
        ss.str(std::string(""));
        ss << name << ".ops." << i;
        if(i != convs - 1)
            m_ops[i].initialize(ss.str(), downsample_name, conv_name, upsample_name, channels, channels, ratio, ksize3, stride3, pad3, dilate3, num_groups, enable_bias, true);
        else
            m_ops[i].initialize(ss.str(), downsample_name, conv_name, upsample_name, channels, channels, ratio, ksize3, stride3, pad3, dilate3, num_groups, enable_bias, false);
    }
}

neuroError_t BottResidualBlock3::set_param_ptrs(const ParamDictType& param_dict)
{
    for(size_t i = 0; i < m_ops.size(); ++i) {
        checkNeuro(m_ops[i].set_param_ptrs(param_dict));
    }
    return Neuro_Success;
}


neuroError_t BottResidualBlock3::create_descs(cudnnHandle_t cudnn_handle, const Tensor& intensor, Tensor& outtensor,
                                         bool infer_shape, size_t& max_layer_size, size_t& workspace_size)
{
    m_cudnn_handle = cudnn_handle;

    if(infer_shape) {
        outtensor.set_size(intensor.size());
        outtensor.create_desc();
    }

    if(outtensor.desc() == nullptr)
        return Neuro_EmptyTensor;

    size_t tmp_workspace_size = 0;
    for(size_t i = 0; i < m_ops.size(); ++i)
        checkNeuro(m_ops[i].create_descs(cudnn_handle, intensor, outtensor, false, max_layer_size, tmp_workspace_size));

    checkNeuro(m_act.create_descs(cudnn_handle, outtensor, outtensor, false, max_layer_size, tmp_workspace_size));

    // need to keep a copy of intensor for skip connection
    tmp_workspace_size += intensor.bytes();
    workspace_size = std::max<size_t>(workspace_size, tmp_workspace_size);

    return Neuro_Success;
}


neuroError_t BottResidualBlock3::forward(Tensor& intensor, Tensor& outtensor, void* workspace)
{

    FloatTensor5 tmp_tensor;
    tmp_tensor.set_size(intensor.size());
    tmp_tensor.create_desc();
    tmp_tensor.set_ptr(workspace);

    //save a copy of intensor in workspace
    checkNeuro(TensorOps::add(m_cudnn_handle, 1.0f, intensor, 0.0f, tmp_tensor));

    void* alg_workspace = (void*)((char*)(workspace) + intensor.bytes());
    Tensor* in_ptr = &intensor, *out_ptr = &outtensor;
    for(size_t i = 0; i < m_ops.size(); ++i) {
        checkNeuro(m_ops[i].forward(*in_ptr, *out_ptr, alg_workspace));
        std::swap(in_ptr, out_ptr);
    }

    checkNeuro(TensorOps::add(m_cudnn_handle, 1.0f, *in_ptr, 1.0f, tmp_tensor));
    checkNeuro(m_act.forward(tmp_tensor, outtensor, alg_workspace));
    return Neuro_Success;
}

}

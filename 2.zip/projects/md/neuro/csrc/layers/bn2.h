#ifndef NEURO_BN2_H
#define NEURO_BN2_H

#include <cudnn.h>
#include <unordered_map>
#include "math/vec2d.h"
#include "neuro/csrc/filter.h"
#include "neuro/csrc/tensor.h"
#include "neuro/csrc/errors.h"
#include "neuro/csrc/layers/network_module.h"

namespace medvision {

/*! \brief spatial 3D batch normalization (inference only) */
class BN2: public NetworkModule
{
public:
    /*! \brief constructor */
    BN2();

    /*! \brief parametric constructor
     *
     *  \param name     the module name
     *  \param epsilon  the epsilon for variance to avoid division of 0
     */
    BN2(const std::string& name, double epsilon=1e-5);

    /*! \brief initialize function
     *
     *  \param name     the module name
     *  \param epsilon  the epsilon for variance to avoid division of 0
     */
    void initialize(const std::string& name, double epsilon=1e-5);

    /*! \brief detailed implementation of set_param_ptrs */
    virtual neuroError_t set_param_ptrs(const ParamDictType& param_dict);

    /*! \brief detailed implementation of create_descs */
    virtual neuroError_t create_descs(cudnnHandle_t handle,
                                      const Tensor& intensor,
                                      Tensor& outtensor,
                                      bool infer_shape,
                                      size_t& max_layer_size,
                                      size_t& workspace_size);

    /*! \brief detailed implementation of forward */
    virtual neuroError_t forward(Tensor& intensor, Tensor& outtensor, void* workspace);

private:

    std::string m_name;
    double m_epsilon;

    // all params share the same descriptor
    FloatTensor4 m_desc;

    void* m_weight;
    void* m_bias;
    void* m_mean;
    void* m_var;

    cudnnHandle_t m_cudnn_handle;
};

}

#endif

#ifndef NEURO_IO_H
#define NEURO_IO_H

#include <string>
#include <vector>
#include <unordered_map>
#include "neuro/csrc/errors.h"

namespace medvision {


/*! \brief a neuro binary file */
class NeuroFile
{
public:
    /*! \brief constructor
     *
     *  \param version_num "x.y.z", e.g., 1.0.1.
     *         x stands for neuro version,
     *         y stands for application number,
     *         z stands for application version
     */
    NeuroFile(const char* version_num);

    /*! \brief destructor */
    ~NeuroFile();

    /*! \brief open a file */
    neuroError_t open(const char* path);

    /*! \brief close file */
    void close();

    /*! \brief read value of a field */
    neuroError_t read(const char* name, void* buffer);

    /*! \brief read entire data block */
    neuroError_t read(void* buffer);

    /*! \brief get position in data buffer */
    size_t pos_in_datablock(const std::string& name) const;

    /*! \brief list all field names */
    std::vector<std::string> list_names() const;

    /*! \brief get byte size of a field */
    size_t get_byte_size(const char* name) const;

    /*! \brief get data start offset */
    size_t get_data_offset() const;

    /*! \brief get total byte size */
    size_t get_data_bytes() const;

private:

    std::string m_version_text;

    FILE* m_fp;
    std::unordered_map<std::string, size_t> m_starts;
    std::unordered_map<std::string, size_t> m_sizes;
};


}


#endif

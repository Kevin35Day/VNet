#include "neuro/csrc/tensor_utils.h"
#include <iomanip>
#include <memory>
#include "neuro/csrc/layers/conv2.h"

namespace medvision {


neuroError_t copy_floatims_to_tensor(const Image3d* floatims, int num, Tensor& out)
{
    size_t bytes = 0;
    for(int i = 0; i < num; ++i)
        bytes += floatims[i].data_bytes();

    // allocate page-locked memory for data transfer
    void* ims_buffer_ptr = nullptr;
    cudaThrowError(cudaMallocHost(&ims_buffer_ptr, bytes));

    size_t offset = 0;
    for(int i = 0; i < num; ++i) {
        floatims[i].copy_data_to(((char *)ims_buffer_ptr) + offset);
        offset += floatims[i].data_bytes();
    }

    std::unique_ptr<void, CudaHostDeleter> im_buffer;
    im_buffer.reset(ims_buffer_ptr);

    if(out.ptr() == nullptr) {
        std::cerr << "[Error] output gpu memory not allocated " << " at " << __FILE__ << ":" << __LINE__ << std::endl;
        return Neuro_EmptyTensor;
    }

    cudaThrowError(cudaMemcpy(out.ptr(), im_buffer.get(), bytes, cudaMemcpyHostToDevice));
    return Neuro_Success;
}


neuroError_t convert_binaryProbTensor_to_mask(const Tensor& in, Image3d& out)
{
    const int* tensor_size = in.size();
    if(tensor_size[0] != 1) {
        std::cerr << "[Error] Only support batch size = 1 " << " at " << __FILE__ << ":" << __LINE__ << std::endl;
        return Neuro_Unsupported;
    }

    // 2-channels image
    // only the first half data needs to be copied
    size_t bytes = in.bytes() / 2;

    void* buffer_ptr = nullptr;
    cudaThrowError(cudaMallocHost(&buffer_ptr, bytes));

    std::unique_ptr<void, CudaHostDeleter> buffer;
    buffer.reset(buffer_ptr);

    cudaThrowError(cudaMemcpy(buffer_ptr, in.ptr(), bytes, cudaMemcpyDeviceToHost));
    if (in.dim() == 5)
        out.allocate(tensor_size[4], tensor_size[3], tensor_size[2], PT_CHAR);
    else if (in.dim() == 4)
        out.allocate(tensor_size[3], tensor_size[2], 1, PT_CHAR);
    else {
        std::cerr << "[Error] wrong tensor dim" << " at " << __FILE__ << ":" << __LINE__ << std::endl;
        return Neuro_UnsupportedDim;
    }

    const float* float_ptr = static_cast<const float*>(buffer_ptr);
    char* out_ptr = static_cast<char*>(out.data());

    size_t voxel_num = out.size().self_prod<size_t>();
    for(size_t i = 0; i < voxel_num; ++i) {
        if(float_ptr[i] <= 0.5)
            out_ptr[i] = 1;
        else
            out_ptr[i] = 0;
    }

    return Neuro_Success;
}


neuroError_t imfilt2d_cudnn(cudnnHandle_t handle, Image3d& float_im, const float* kernel, int kw, int kh, int pw, int ph)
{
    vec3d<int> imsize = float_im.size();
    if(imsize[2] != 1) {
        std::cerr << "[Error] imfilt2d_cudnn requires 2D image as input " << std::endl;
        return Neuro_BadParam;
    }

    if(float_im.pixel_type() != PT_FLOAT) {
        std::cerr << "[Error] imfilt2d_cudnn requires float-type image as input" << std::endl;
        return Neuro_BadParam;
    }

    // copy image data from cpu to gpu memory
    FloatTensor4 imtensor(1, 1, imsize[1], imsize[0]), outtensor;
    imtensor.create_desc();

    // construct convolution layer
    vec2d<int> ksize(kh, kw), stride(1, 1), pad(ph, pw), dilate(1, 1);
    int num_groups = 1, in_channels = 1, out_channels = 1;
    bool enable_bias = false;

    Conv2 layer("tmp", in_channels, out_channels, ksize, stride, pad, dilate, num_groups, enable_bias);

    size_t max_layer_size = 0, max_workspace_size = 0, filter_size = kw * kh * sizeof(float);
    checkNeuro(layer.create_descs(handle, imtensor, outtensor, true, max_layer_size, max_workspace_size));

    // allocate gpu memory for filter, input buffer, output buffer and workspace
    void* gpu_buffer_ptr = nullptr;
    cudaThrowError(cudaMalloc(&gpu_buffer_ptr, filter_size + max_layer_size * 2 + max_workspace_size));
    std::unique_ptr<void, CudaDeviceDeleter> gpu_buffer;
    gpu_buffer.reset(gpu_buffer_ptr);

    void* filter_ptr = gpu_buffer_ptr;
    void* input_ptr = (void*)(((char*)filter_ptr) + filter_size);
    void* output_ptr = (void*)(((char*)input_ptr) + max_layer_size);
    void* workspace_ptr = (void*)(((char*)output_ptr) + max_layer_size);

    // copy image filter and construct parameter dictionary
    cudaThrowError(cudaMemcpy(filter_ptr, kernel, filter_size, cudaMemcpyHostToDevice));

    Conv2::ParamDictType dict;
    dict["tmp.weight"] = gpu_buffer.get();

    // load weight parameters
    layer.set_param_ptrs(dict);

    // convolution
    imtensor.set_ptr(input_ptr);
    outtensor.set_ptr(output_ptr);
    checkNeuro(copy_floatims_to_tensor(&float_im, 1, imtensor));
    checkNeuro(layer.forward(imtensor, outtensor, workspace_ptr));

    // copy results back to image
    cudaThrowError(cudaMemcpy(float_im.data(), outtensor.ptr(), outtensor.bytes(), cudaMemcpyDeviceToHost));

    return Neuro_Success;
}


void output_tensor_ptr(std::ostream& os, const float* data_ptr, const int* size, const int* stride, int len, int depth)
{
    const int max_out = 6;

    if(len <= 0)
        return;

    if(len == 1) {
        os << "[";
        if(size[0] <= max_out) {
            for(int i = 0; i < size[0]; ++i) {
                os << std::fixed << std::setprecision(6) << std::setw(10) << std::right << data_ptr[i];
                if(i != size[0] - 1)
                    os << ",";
            }
        }
        else {
            for(int i = 0; i < max_out / 2; ++i)
                os << std::fixed << std::setprecision(6) << std::setw(10) << std::right << data_ptr[i] << ",";
            os << " ...,";
            for(int i = max_out/2-1; i >= 0; --i) {
                os << std::fixed << std::setprecision(6) << std::setw(10) << std::right << data_ptr[size[0]-1-i];
                if(i != 0)
                    os << ",";
            }
        }
        os << "]";
        std::flush(os);
    }
    else {
        os << "[";
        if(size[0] <= max_out) {
            for(int i = 0; i < size[0]; ++i) {
                const float* new_data_ptr = data_ptr + stride[0] * i;
                output_tensor_ptr(os, new_data_ptr, size + 1, stride + 1, len - 1, depth + 1);
                if(i != size[0] - 1)
                    os << "," << std::endl << std::string(depth+1, ' ');
            }
        }
        else {
            for(int i = 0; i < max_out/2; ++i) {
                const float* new_data_ptr = data_ptr + stride[0] * i;
                output_tensor_ptr(os, new_data_ptr, size + 1, stride + 1, len - 1, depth + 1);
                os << "," << std::endl << std::string(depth+1, ' ');
            }
            os << "...," << std::endl << std::string(depth+1, ' ');
            for(int i = max_out/2-1; i >= 0; --i) {
                const float* new_data_ptr = data_ptr + stride[0] * (size[0]-1-i);
                output_tensor_ptr(os, new_data_ptr, size + 1, stride + 1, len - 1, depth + 1);
                if(i != 0)
                    os << "," << std::endl << std::string(depth+1, ' ');
            }
        }
        os << "]";
        std::flush(os);
    }
}


void print_tensor(std::ostream& os, const Tensor& tensor)
{
    void* cpu_buffer = malloc(tensor.bytes());
    tensor.cpu(cpu_buffer);

    const float* data_ptr = static_cast<const float*>(cpu_buffer);

    const int* size = tensor.size();
    const int* stride = tensor.stride();
    int dim = tensor.dim();
    output_tensor_ptr(os, data_ptr, size, stride, dim, 0);
    free(cpu_buffer);
}


void print_filter(std::ostream& os, const Filter& filter)
{
    void* cpu_buffer = malloc(filter.bytes());
    filter.cpu(cpu_buffer);

    const float* data_ptr = static_cast<const float*>(cpu_buffer);

    const int* size = filter.size();
    const int* stride = filter.stride();
    int dim = filter.dim();
    output_tensor_ptr(os, data_ptr, size, stride, dim, 0);
    free(cpu_buffer);
}


double compute_tensor_mean(const Tensor& tensor)
{
    void* cpu_buffer = malloc(tensor.bytes());
    tensor.cpu(cpu_buffer);

    float* data_buffer = static_cast<float*>(cpu_buffer);
    size_t elems = 1;
    for(int i = 0; i < tensor.dim(); ++i) {
        elems *= tensor.size()[i];
    }

    double sum = 0.0f;
    for(size_t i = 0; i < elems; ++i)
        sum += data_buffer[i];

    return sum / elems;
}


void print_tensor_mean(const Tensor &tensor)
{
    double tensor_mean = compute_tensor_mean(tensor);
    std::cout << std::setprecision(8) << tensor_mean << std::endl;
}


}
